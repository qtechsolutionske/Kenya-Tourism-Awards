import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
};

interface PaystackInitRequest {
  email: string;
  amount: number;
  orderId: string;
  currency?: string;
  metadata?: Record<string, any>;
}

interface PaystackConfig {
  public_key: string;
  secret_key: string;
  webhook_secret: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false } }
    );

    const url = new URL(req.url);
    const action = url.pathname.split('/').pop();

    switch (action) {
      case 'initialize':
        return await initializePayment(req, supabase);
      case 'verify':
        return await verifyPayment(req, supabase);
      case 'webhook':
        return await handleWebhook(req, supabase);
      default:
        throw new Error('Invalid action');
    }
  } catch (error) {
    console.error('Paystack Error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Internal server error' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

async function initializePayment(req: Request, supabase: any) {
  const { email, amount, orderId, currency = 'KES', metadata = {} }: PaystackInitRequest = await req.json();

  // Get Paystack configuration
  const { data: configData, error: configError } = await supabase
    .from('payment_methods')
    .select('config, is_live')
    .eq('method', 'paystack')
    .eq('is_enabled', true)
    .single();

  if (configError || !configData) {
    throw new Error('Paystack configuration not found or disabled');
  }

  const config: PaystackConfig = configData.config;
  const isLive = configData.is_live;

  const secretKey = isLive ? config.secret_key : config.secret_key; // Use test keys for sandbox

  // Generate unique reference
  const reference = `kta_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  // Initialize Paystack transaction
  const paystackUrl = 'https://api.paystack.co/transaction/initialize';
  
  const paystackPayload = {
    email,
    amount: Math.round(amount * 100), // Paystack expects amount in kobo/cents
    reference,
    currency,
    callback_url: `${Deno.env.get('SUPABASE_URL')}/functions/v1/payments-paystack/callback?orderId=${orderId}`,
    metadata: {
      order_id: orderId,
      ...metadata
    }
  };

  const paystackResponse = await fetch(paystackUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${secretKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(paystackPayload),
  });

  if (!paystackResponse.ok) {
    const errorData = await paystackResponse.json();
    throw new Error(`Paystack initialization failed: ${errorData.message}`);
  }

  const paystackData = await paystackResponse.json();

  if (!paystackData.status) {
    throw new Error(paystackData.message || 'Transaction initialization failed');
  }

  // Create payment record
  const { data: payment, error: paymentError } = await supabase
    .from('payments')
    .insert({
      user_id: orderId.includes('ticket') ? null : orderId,
      order_id: orderId,
      method: 'paystack',
      reference,
      amount: amount,
      currency,
      status: 'pending',
      email,
      metadata: {
        paystack_reference: reference,
        authorization_url: paystackData.data.authorization_url,
        access_code: paystackData.data.access_code
      }
    })
    .select()
    .single();

  if (paymentError) {
    throw new Error('Failed to create payment record');
  }

  // Log the initiation
  await supabase
    .from('payment_logs')
    .insert({
      payment_id: payment.id,
      event_type: 'paystack_initialized',
      event_data: {
        reference,
        authorization_url: paystackData.data.authorization_url,
        amount,
        currency
      }
    });

  return new Response(
    JSON.stringify({
      success: true,
      data: {
        authorization_url: paystackData.data.authorization_url,
        access_code: paystackData.data.access_code,
        reference,
        payment_id: payment.id,
        public_key: isLive ? config.public_key : config.public_key
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function verifyPayment(req: Request, supabase: any) {
  const url = new URL(req.url);
  const reference = url.searchParams.get('reference');

  if (!reference) {
    throw new Error('Transaction reference required');
  }

  // Get Paystack configuration
  const { data: configData } = await supabase
    .from('payment_methods')
    .select('config, is_live')
    .eq('method', 'paystack')
    .single();

  const config: PaystackConfig = configData.config;
  const secretKey = configData.is_live ? config.secret_key : config.secret_key;

  // Verify transaction with Paystack
  const verifyUrl = `https://api.paystack.co/transaction/verify/${reference}`;
  
  const verifyResponse = await fetch(verifyUrl, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${secretKey}`,
    },
  });

  if (!verifyResponse.ok) {
    throw new Error('Failed to verify transaction with Paystack');
  }

  const verifyData = await verifyResponse.json();

  if (!verifyData.status) {
    throw new Error('Transaction verification failed');
  }

  const transaction = verifyData.data;

  // Update payment record
  const status = transaction.status === 'success' ? 'success' : 'failed';
  const verifiedAt = status === 'success' ? new Date().toISOString() : null;

  const { data: payment, error: updateError } = await supabase
    .from('payments')
    .update({
      status,
      verified_at: verifiedAt,
      callback_data: transaction,
      metadata: {
        ...transaction.metadata,
        paystack_transaction_id: transaction.id,
        gateway_response: transaction.gateway_response,
        paid_at: transaction.paid_at
      }
    })
    .eq('reference', reference)
    .select()
    .single();

  if (updateError) {
    throw new Error('Failed to update payment status');
  }

  // If this is a gala ticket purchase and payment is successful, confirm ticket
  if (status === 'success' && payment.order_id.includes('ticket')) {
    await supabase
      .from('gala_tickets')
      .update({ ticket_status: 'confirmed' })
      .eq('payment_id', payment.id);
  }

  // Log the verification
  await supabase
    .from('payment_logs')
    .insert({
      payment_id: payment.id,
      event_type: 'paystack_verified',
      event_data: transaction
    });

  return new Response(
    JSON.stringify({
      success: true,
      data: {
        status,
        amount: transaction.amount / 100, // Convert back from kobo/cents
        currency: transaction.currency,
        reference: transaction.reference,
        paid_at: transaction.paid_at
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function handleWebhook(req: Request, supabase: any) {
  // Verify webhook signature
  const signature = req.headers.get('x-paystack-signature');
  const body = await req.text();

  const { data: configData } = await supabase
    .from('payment_methods')
    .select('config')
    .eq('method', 'paystack')
    .single();

  if (!configData) {
    return new Response('Configuration not found', { status: 404, headers: corsHeaders });
  }

  const config: PaystackConfig = configData.config;
  
  // Verify signature (in production, implement proper HMAC verification)
  // const expectedSignature = crypto.createHmac('sha512', config.webhook_secret).update(body).digest('hex');
  // if (signature !== expectedSignature) {
  //   return new Response('Invalid signature', { status: 401, headers: corsHeaders });
  // }

  const event = JSON.parse(body);
  console.log('Paystack Webhook:', event);

  // Process webhook events
  if (event.event === 'charge.success') {
    const transaction = event.data;
    
    // Update payment status
    await supabase
      .from('payments')
      .update({
        status: 'success',
        verified_at: new Date().toISOString(),
        callback_data: transaction
      })
      .eq('reference', transaction.reference);

    // Log the webhook
    await supabase
      .from('payment_logs')
      .insert({
        payment_id: null, // Will be filled by trigger if needed
        event_type: 'paystack_webhook',
        event_data: event
      });
  }

  return new Response('OK', { status: 200, headers: corsHeaders });
}