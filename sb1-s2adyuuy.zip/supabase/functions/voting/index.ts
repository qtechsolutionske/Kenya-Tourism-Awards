import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
};

interface VoteRequest {
  voterEmail: string;
  voterPhone?: string;
  voterName?: string;
  voterCounty?: string;
  submissionId: string;
  category: string;
  bundleId?: string;
  voteCount?: number;
  referralCode?: string;
  captchaToken?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false } }
    );

    const url = new URL(req.url);
    const action = url.pathname.split('/').pop();

    switch (action) {
      case 'submit':
        return await handleVoteSubmission(req, supabase);
      case 'verify':
        return await handleVoterVerification(req, supabase);
      case 'analytics':
        return await getVotingAnalytics(req, supabase);
      case 'fraud-check':
        return await performFraudCheck(req, supabase);
      default:
        throw new Error('Invalid action');
    }
  } catch (error) {
    console.error('Voting Error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Internal server error' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

async function handleVoteSubmission(req: Request, supabase: any) {
  const voteRequest: VoteRequest = await req.json();
  const clientIp = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
  const userAgent = req.headers.get('user-agent') || '';

  // Get voting settings
  const { data: settings } = await supabase
    .from('voting_settings')
    .select('*')
    .eq('id', 1)
    .single();

  if (!settings || !settings.is_voting_open) {
    return new Response(
      JSON.stringify({ success: false, error: 'Voting is currently closed' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Validate email domain
  const emailDomain = voteRequest.voterEmail.split('@')[1];
  if (settings.blocked_email_domains.includes(emailDomain)) {
    await logFraudAttempt(supabase, null, voteRequest.voterEmail, 'blocked_domain', 
                         'Email from blocked domain', clientIp, userAgent);
    return new Response(
      JSON.stringify({ success: false, error: 'Email domain not allowed' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Get or create voter
  let { data: voter } = await supabase
    .from('voters')
    .select('*')
    .eq('email', voteRequest.voterEmail)
    .single();

  if (!voter) {
    const { data: newVoter, error: voterError } = await supabase
      .from('voters')
      .insert({
        email: voteRequest.voterEmail,
        phone: voteRequest.voterPhone,
        full_name: voteRequest.voterName,
        county: voteRequest.voterCounty,
        ip_addresses: [clientIp]
      })
      .select()
      .single();

    if (voterError) {
      throw new Error('Failed to create voter record');
    }
    voter = newVoter;
  }

  // Check if voter is blocked
  if (voter.is_blocked) {
    return new Response(
      JSON.stringify({ success: false, error: 'Voter account is blocked' }),
      { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Check for nominee self-voting
  const { data: submission } = await supabase
    .from('submissions')
    .select('submitter_email, contact_email')
    .eq('id', voteRequest.submissionId)
    .single();

  if (submission && !settings.allow_nominee_voting) {
    const submitterEmails = [submission.submitter_email, submission.contact_email].filter(Boolean);
    if (submitterEmails.includes(voteRequest.voterEmail)) {
      await logFraudAttempt(supabase, null, voteRequest.voterEmail, 'nominee_self_vote',
                           'Nominee attempted to vote for themselves', clientIp, userAgent);
      return new Response(
        JSON.stringify({ success: false, error: 'Nominees cannot vote for themselves' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  }

  // Check rate limits
  const { data: recentVotes } = await supabase
    .from('votes')
    .select('count')
    .eq('voter_id', voter.id)
    .gte('vote_time', new Date(Date.now() - settings.rate_limit_window_minutes * 60000).toISOString())
    .single();

  if (recentVotes && recentVotes.count >= settings.max_votes_per_email_per_day) {
    await logFraudAttempt(supabase, null, voteRequest.voterEmail, 'rate_limit_exceeded',
                         'Voter exceeded daily vote limit', clientIp, userAgent);
    return new Response(
      JSON.stringify({ success: false, error: 'Daily vote limit exceeded' }),
      { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  const voteCount = voteRequest.voteCount || 1;
  const isFreevoting = settings.voting_mode === 'free';
  const totalAmount = isFreevoting ? 0 : settings.fee_per_vote * voteCount;

  if (!isFreevoting && totalAmount > 0) {
    // Handle paid voting - create pending vote and initiate payment
    const { data: vote, error: voteError } = await supabase
      .from('votes')
      .insert({
        voter_id: voter.id,
        submission_id: voteRequest.submissionId,
        category: voteRequest.category,
        is_paid: true,
        amount_paid: totalAmount,
        vote_weight: voteCount,
        ip_address: clientIp,
        user_agent: userAgent,
        status: 'pending',
        verification_method: 'email',
        referral_code: voteRequest.referralCode
      })
      .select()
      .single();

    if (voteError) throw new Error('Failed to create vote record');

    // Create payment for the vote
    const orderId = `vote_${vote.id}`;
    
    // For now, return payment URL (implementation depends on chosen payment method)
    const paymentUrl = `/payment?vote_id=${vote.id}&amount=${totalAmount}`;

    return new Response(
      JSON.stringify({
        success: true,
        data: {
          voteId: vote.id,
          requiresPayment: true,
          paymentUrl,
          message: 'Please complete payment to confirm your vote'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } else {
    // Handle free voting - create confirmed vote immediately
    const { data: vote, error: voteError } = await supabase
      .from('votes')
      .insert({
        voter_id: voter.id,
        submission_id: voteRequest.submissionId,
        category: voteRequest.category,
        is_paid: false,
        amount_paid: 0,
        vote_weight: 1,
        ip_address: clientIp,
        user_agent: userAgent,
        status: 'confirmed',
        verification_method: 'email'
      })
      .select()
      .single();

    if (voteError) throw new Error('Failed to create vote record');

    // Update submission vote count
    await supabase
      .from('submissions')
      .update({ 
        public_votes: supabase.raw('public_votes + 1'),
        updated_at: new Date().toISOString()
      })
      .eq('id', voteRequest.submissionId);

    // Send confirmation email
    if (settings.email_confirmation_enabled) {
      await sendVoteConfirmation(supabase, vote, voteRequest.voterEmail);
    }

    return new Response(
      JSON.stringify({
        success: true,
        data: {
          voteId: vote.id,
          confirmationToken: vote.id, // Use vote ID as confirmation token
          requiresPayment: false,
          message: 'Vote submitted successfully! Check your email for confirmation.'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function handleVoterVerification(req: Request, supabase: any) {
  const { email, token } = await req.json();

  const { error } = await supabase
    .from('voters')
    .update({ email_verified: true })
    .eq('email', email)
    .eq('verification_token', token);

  return new Response(
    JSON.stringify({ success: !error }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function getVotingAnalytics(req: Request, supabase: any) {
  try {
    // Get total vote statistics
    const { data: voteStats } = await supabase
      .from('votes')
      .select('is_paid, amount_paid, status, category')
      .eq('status', 'confirmed');

    const totalVotes = voteStats?.length || 0;
    const paidVotes = voteStats?.filter(v => v.is_paid).length || 0;
    const freeVotes = totalVotes - paidVotes;
    const totalRevenue = voteStats?.reduce((sum, v) => sum + parseFloat(v.amount_paid), 0) || 0;

    // Get unique voters count
    const { data: uniqueVoters } = await supabase
      .from('voters')
      .select('count')
      .single();

    // Get votes by category
    const votingsByCategory: Record<string, number> = {};
    voteStats?.forEach(vote => {
      votingsByCategory[vote.category] = (votingsByCategory[vote.category] || 0) + 1;
    });

    // Get fraud attempts
    const { data: fraudStats } = await supabase
      .from('vote_fraud_logs')
      .select('count')
      .single();

    const analytics = {
      totalVotes,
      paidVotes,
      freeVotes,
      totalRevenue,
      uniqueVoters: uniqueVoters?.count || 0,
      votingsByCategory,
      votingsByHour: {}, // Would implement time-series data
      fraudAttempts: fraudStats?.count || 0,
      blockedVotes: 0,
      conversionRate: paidVotes > 0 ? (paidVotes / totalVotes) * 100 : 0,
      averageVotesPerUser: totalVotes > 0 ? totalVotes / (uniqueVoters?.count || 1) : 0
    };

    return new Response(
      JSON.stringify({ success: true, data: analytics }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function performFraudCheck(req: Request, supabase: any) {
  const { voterEmail, ipAddress, userAgent } = await req.json();
  let fraudScore = 0;
  const reasons = [];

  // Check for duplicate votes from same IP
  const { data: ipVotes } = await supabase
    .from('votes')
    .select('count')
    .eq('ip_address', ipAddress)
    .gte('vote_time', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

  if (ipVotes && ipVotes.count > 5) {
    fraudScore += 25;
    reasons.push('High vote frequency from IP');
  }

  // Check for suspicious email patterns
  if (voterEmail.includes('test') || voterEmail.includes('fake')) {
    fraudScore += 30;
    reasons.push('Suspicious email pattern');
  }

  return new Response(
    JSON.stringify({ 
      success: true, 
      data: { fraudScore, reasons, isHighRisk: fraudScore > 50 }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function sendVoteConfirmation(supabase: any, vote: any, voterEmail: string) {
  const confirmationToken = `conf_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await supabase
    .from('vote_confirmations')
    .insert({
      vote_id: vote.id,
      voter_email: voterEmail,
      confirmation_token: confirmationToken,
      status: 'sent',
      email_sent_at: new Date().toISOString()
    });

  // Here you would integrate with your email service (SendGrid, etc.)
  console.log(`Sending vote confirmation to ${voterEmail} for vote ${vote.id}`);
}

async function logFraudAttempt(
  supabase: any, 
  voteId: string | null, 
  voterEmail: string, 
  fraudType: string, 
  reason: string, 
  ipAddress: string, 
  userAgent: string
) {
  await supabase
    .from('vote_fraud_logs')
    .insert({
      vote_id: voteId,
      voter_email: voterEmail,
      fraud_type: fraudType,
      fraud_score: 100,
      detection_reason: reason,
      ip_address: ipAddress,
      user_agent: userAgent,
      action_taken: 'blocked'
    });
}