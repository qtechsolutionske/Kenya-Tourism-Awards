import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
};

interface MPESASTKRequest {
  phone: string;
  amount: number;
  orderId: string;
  accountReference: string;
  transactionDesc: string;
}

interface MPESAConfig {
  consumer_key: string;
  consumer_secret: string;
  business_short_code: string;
  passkey: string;
  result_url: string;
  confirmation_url: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false } }
    );

    const url = new URL(req.url);
    const action = url.pathname.split('/').pop();

    switch (action) {
      case 'initiate':
        return await handleSTKPush(req, supabase);
      case 'callback':
        return await handleCallback(req, supabase);
      case 'status':
        return await checkTransactionStatus(req, supabase);
      default:
        throw new Error('Invalid action');
    }
  } catch (error) {
    console.error('MPESA Error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Internal server error' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

async function handleSTKPush(req: Request, supabase: any) {
  const { phone, amount, orderId, accountReference, transactionDesc }: MPESASTKRequest = await req.json();

  // Get MPESA configuration
  const { data: configData, error: configError } = await supabase
    .from('payment_methods')
    .select('config, is_live')
    .eq('method', 'mpesa')
    .eq('is_enabled', true)
    .single();

  if (configError || !configData) {
    throw new Error('MPESA configuration not found or disabled');
  }

  const config: MPESAConfig = configData.config;
  const isLive = configData.is_live;

  // Generate access token
  const auth = btoa(`${config.consumer_key}:${config.consumer_secret}`);
  const authUrl = isLive 
    ? 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
    : 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

  const tokenResponse = await fetch(authUrl, {
    method: 'GET',
    headers: {
      'Authorization': `Basic ${auth}`,
    },
  });

  if (!tokenResponse.ok) {
    throw new Error('Failed to get MPESA access token');
  }

  const tokenData = await tokenResponse.json();
  const accessToken = tokenData.access_token;

  // Format phone number (ensure it starts with 254)
  const formattedPhone = phone.startsWith('254') ? phone : `254${phone.replace(/^0/, '')}`;

  // Generate timestamp
  const timestamp = new Date().toISOString().slice(0, 19).replace(/[-:]/g, '').replace('T', '');
  
  // Generate password
  const password = btoa(`${config.business_short_code}${config.passkey}${timestamp}`);

  // STK Push request
  const stkUrl = isLive
    ? 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
    : 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

  const stkPayload = {
    BusinessShortCode: config.business_short_code,
    Password: password,
    Timestamp: timestamp,
    TransactionType: 'CustomerPayBillOnline',
    Amount: Math.round(amount),
    PartyA: formattedPhone,
    PartyB: config.business_short_code,
    PhoneNumber: formattedPhone,
    CallBackURL: `${config.result_url}?orderId=${orderId}`,
    AccountReference: accountReference,
    TransactionDesc: transactionDesc,
  };

  const stkResponse = await fetch(stkUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(stkPayload),
  });

  if (!stkResponse.ok) {
    throw new Error('STK Push request failed');
  }

  const stkData = await stkResponse.json();

  if (stkData.ResponseCode !== '0') {
    throw new Error(stkData.ResponseDescription || 'STK Push failed');
  }

  // Create payment record
  const { data: payment, error: paymentError } = await supabase
    .from('payments')
    .insert({
      user_id: orderId.includes('ticket') ? null : orderId, // Handle both user payments and ticket purchases
      order_id: orderId,
      method: 'mpesa',
      reference: stkData.CheckoutRequestID,
      amount: amount,
      currency: 'KES',
      status: 'pending',
      phone_number: formattedPhone,
      metadata: {
        merchant_request_id: stkData.MerchantRequestID,
        checkout_request_id: stkData.CheckoutRequestID,
        account_reference: accountReference,
        transaction_desc: transactionDesc
      }
    })
    .select()
    .single();

  if (paymentError) {
    throw new Error('Failed to create payment record');
  }

  // Log the initiation
  await supabase
    .from('payment_logs')
    .insert({
      payment_id: payment.id,
      event_type: 'stk_initiated',
      event_data: {
        checkout_request_id: stkData.CheckoutRequestID,
        phone_number: formattedPhone,
        amount: amount
      }
    });

  return new Response(
    JSON.stringify({
      success: true,
      data: {
        checkout_request_id: stkData.CheckoutRequestID,
        merchant_request_id: stkData.MerchantRequestID,
        payment_id: payment.id,
        message: 'STK Push sent successfully. Please check your phone.'
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function handleCallback(req: Request, supabase: any) {
  const callbackData = await req.json();
  const url = new URL(req.url);
  const orderId = url.searchParams.get('orderId');

  console.log('MPESA Callback received:', callbackData);

  const stkCallback = callbackData.Body?.stkCallback;
  if (!stkCallback) {
    return new Response('Invalid callback format', { status: 400, headers: corsHeaders });
  }

  const checkoutRequestId = stkCallback.CheckoutRequestID;
  const resultCode = stkCallback.ResultCode;

  // Find the payment record
  const { data: payment, error: findError } = await supabase
    .from('payments')
    .select('*')
    .eq('reference', checkoutRequestId)
    .single();

  if (findError || !payment) {
    console.error('Payment not found:', findError);
    return new Response('Payment not found', { status: 404, headers: corsHeaders });
  }

  let status = 'failed';
  let verifiedAt = null;
  let failedReason = null;

  if (resultCode === 0) {
    // Payment successful
    status = 'success';
    verifiedAt = new Date().toISOString();
    
    // Extract transaction details from callback
    const callbackMetadata = stkCallback.CallbackMetadata?.Item || [];
    const transactionId = callbackMetadata.find((item: any) => item.Name === 'MpesaReceiptNumber')?.Value;
    const amountPaid = callbackMetadata.find((item: any) => item.Name === 'Amount')?.Value;
    const phoneNumber = callbackMetadata.find((item: any) => item.Name === 'PhoneNumber')?.Value;

    // Update payment record
    await supabase
      .from('payments')
      .update({
        status,
        verified_at: verifiedAt,
        callback_data: callbackData,
        metadata: {
          ...payment.metadata,
          mpesa_receipt_number: transactionId,
          amount_paid: amountPaid,
          phone_confirmed: phoneNumber
        }
      })
      .eq('id', payment.id);

    // If this is a gala ticket purchase, update ticket status
    if (payment.order_id.includes('ticket')) {
      await supabase
        .from('gala_tickets')
        .update({ ticket_status: 'confirmed' })
        .eq('payment_id', payment.id);
    }

  } else {
    // Payment failed
    failedReason = stkCallback.ResultDesc || 'Transaction failed';
    
    await supabase
      .from('payments')
      .update({
        status,
        failed_reason: failedReason,
        callback_data: callbackData
      })
      .eq('id', payment.id);
  }

  // Log the callback
  await supabase
    .from('payment_logs')
    .insert({
      payment_id: payment.id,
      event_type: 'stk_callback',
      event_data: callbackData
    });

  return new Response(
    JSON.stringify({ success: true, status, message: 'Callback processed' }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function checkTransactionStatus(req: Request, supabase: any) {
  const url = new URL(req.url);
  const paymentId = url.searchParams.get('payment_id');
  
  if (!paymentId) {
    return new Response(
      JSON.stringify({ success: false, error: 'Payment ID required' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  const { data: payment, error } = await supabase
    .from('payments')
    .select('*')
    .eq('id', paymentId)
    .single();

  if (error || !payment) {
    return new Response(
      JSON.stringify({ success: false, error: 'Payment not found' }),
      { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  return new Response(
    JSON.stringify({ 
      success: true, 
      data: {
        status: payment.status,
        amount: payment.amount,
        currency: payment.currency,
        reference: payment.reference,
        verified_at: payment.verified_at,
        failed_reason: payment.failed_reason
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}