/*
  # Payment System Setup

  1. New Tables
    - `payments` - Store payment transactions
    - `payment_methods` - Configure MPESA and Paystack settings
    - `gala_tickets` - Store ticket purchases with payment links
    - `payment_logs` - Track payment attempts and callbacks

  2. Security
    - Enable RLS on all payment tables
    - Add policies for user access and admin management
    - Secure API credential storage

  3. Functions
    - Payment verification functions
    - Automatic status updates
    - Refund processing capabilities
*/

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  order_id uuid,
  method varchar(20) NOT NULL CHECK (method IN ('mpesa', 'paystack')),
  reference varchar(100) UNIQUE NOT NULL,
  amount decimal(10,2) NOT NULL CHECK (amount > 0),
  currency varchar(10) DEFAULT 'KES',
  status varchar(20) DEFAULT 'pending' CHECK (status IN ('pending', 'success', 'failed', 'refunded')),
  phone_number varchar(20),
  email varchar(100),
  metadata jsonb DEFAULT '{}',
  callback_data jsonb,
  verified_at timestamptz,
  failed_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payment method configurations
CREATE TABLE IF NOT EXISTS payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  method varchar(20) NOT NULL UNIQUE CHECK (method IN ('mpesa', 'paystack')),
  is_enabled boolean DEFAULT true,
  is_live boolean DEFAULT false,
  config jsonb NOT NULL DEFAULT '{}', -- Store encrypted API credentials
  fees jsonb DEFAULT '{}', -- Store fee structure
  display_name varchar(100),
  description text,
  icon_url varchar(255),
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Gala tickets with payment integration
CREATE TABLE IF NOT EXISTS gala_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id uuid REFERENCES payments(id),
  ticket_type varchar(20) NOT NULL CHECK (ticket_type IN ('standard', 'vip', 'vvip', 'corporate')),
  quantity integer DEFAULT 1 CHECK (quantity > 0),
  unit_price decimal(10,2) NOT NULL,
  total_amount decimal(10,2) NOT NULL,
  buyer_name varchar(100) NOT NULL,
  buyer_email varchar(100) NOT NULL,
  buyer_phone varchar(20) NOT NULL,
  organization varchar(100),
  special_requirements text,
  qr_code varchar(100),
  ticket_status varchar(20) DEFAULT 'pending' CHECK (ticket_status IN ('pending', 'confirmed', 'cancelled')),
  event_date timestamptz DEFAULT '2025-03-15 18:00:00+03',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payment logs for debugging and audit
CREATE TABLE IF NOT EXISTS payment_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id uuid REFERENCES payments(id),
  event_type varchar(50) NOT NULL,
  event_data jsonb NOT NULL DEFAULT '{}',
  ip_address inet,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE gala_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for payments
CREATE POLICY "Users can view own payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create payments"
  ON payments
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admin can view all payments"
  ON payments
  FOR ALL
  TO authenticated
  USING (
    auth.jwt() ->> 'email' IN (
      SELECT email FROM auth.users WHERE raw_user_meta_data ->> 'role' IN ('superadmin', 'admin')
    )
  );

-- RLS Policies for payment methods
CREATE POLICY "Users can view enabled payment methods"
  ON payment_methods
  FOR SELECT
  TO authenticated
  USING (is_enabled = true);

CREATE POLICY "Superadmin can manage payment methods"
  ON payment_methods
  FOR ALL
  TO authenticated
  USING (
    auth.jwt() ->> 'email' IN (
      SELECT email FROM auth.users WHERE raw_user_meta_data ->> 'role' = 'superadmin'
    )
  );

-- RLS Policies for gala tickets
CREATE POLICY "Users can view own tickets"
  ON gala_tickets
  FOR SELECT
  TO authenticated
  USING (
    buyer_email = auth.jwt() ->> 'email' OR
    auth.jwt() ->> 'email' IN (
      SELECT email FROM auth.users WHERE raw_user_meta_data ->> 'role' IN ('superadmin', 'admin')
    )
  );

CREATE POLICY "Users can create tickets"
  ON gala_tickets
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for payment logs
CREATE POLICY "Admin can view payment logs"
  ON payment_logs
  FOR ALL
  TO authenticated
  USING (
    auth.jwt() ->> 'email' IN (
      SELECT email FROM auth.users WHERE raw_user_meta_data ->> 'role' IN ('superadmin', 'admin')
    )
  );

-- Insert default payment methods
INSERT INTO payment_methods (method, display_name, description, config, fees, icon_url, sort_order) VALUES
(
  'mpesa', 
  'M-Pesa', 
  'Pay instantly with your M-Pesa mobile money account',
  '{"sandbox_consumer_key": "", "sandbox_consumer_secret": "", "live_consumer_key": "", "live_consumer_secret": "", "passkey": "", "business_short_code": "", "result_url": "", "confirmation_url": ""}',
  '{"transaction_fee": 0, "percentage_fee": 0}',
  'https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/M-PESA_LOGO-01.svg/1200px-M-PESA_LOGO-01.svg.png',
  1
),
(
  'paystack', 
  'Paystack', 
  'Pay with card, bank transfer, or mobile money',
  '{"test_public_key": "", "test_secret_key": "", "live_public_key": "", "live_secret_key": "", "webhook_secret": ""}',
  '{"transaction_fee": 100, "percentage_fee": 1.5}',
  'https://paystack.com/assets/img/logo/paystack-icon.png',
  2
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_reference ON payments(reference);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_method ON payments(method);
CREATE INDEX IF NOT EXISTS idx_gala_tickets_payment_id ON gala_tickets(payment_id);
CREATE INDEX IF NOT EXISTS idx_gala_tickets_buyer_email ON gala_tickets(buyer_email);
CREATE INDEX IF NOT EXISTS idx_payment_logs_payment_id ON payment_logs(payment_id);

-- Update function for timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add update triggers
CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payment_methods_updated_at BEFORE UPDATE ON payment_methods
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_gala_tickets_updated_at BEFORE UPDATE ON gala_tickets
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();