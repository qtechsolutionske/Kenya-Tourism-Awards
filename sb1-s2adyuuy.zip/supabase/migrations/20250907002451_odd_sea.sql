/*
# Entries/Submissions Portal System

1. New Tables
   - `form_definitions` - Editable form templates for each category
   - `submissions` - Entry submissions from users
   - `process_state` - System stage management
   - `user_privileges` - Enhanced role-based permissions
   - `submission_reviews` - Jury reviews and scoring
   - `submission_attachments` - File upload management
   - `submission_history` - Audit trail for changes

2. Security
   - Enable RLS on all new tables
   - Add policies for role-based access control
   - Audit logging for all changes

3. Features
   - 51 form templates based on categories
   - Dynamic form validation and rendering
   - State machine for process stages
   - File upload management
   - Jury vetting and scoring system
*/

-- Form definitions table for editable forms
CREATE TABLE IF NOT EXISTS form_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug varchar(120) UNIQUE NOT NULL,
  category_group varchar(120) NOT NULL,
  category varchar(120) NOT NULL,
  title varchar(255) NOT NULL,
  description text,
  schema jsonb NOT NULL DEFAULT '{}',
  published boolean DEFAULT false,
  version integer DEFAULT 1,
  metadata jsonb DEFAULT '{}',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enhanced submissions table
CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  form_definition_id uuid REFERENCES form_definitions(id) ON DELETE CASCADE,
  category_group varchar(120) NOT NULL,
  category varchar(120) NOT NULL,
  submitter_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  submitter_email varchar(255),
  nominee_name varchar(255) NOT NULL,
  organization_name varchar(255),
  contact_person varchar(255) NOT NULL,
  contact_email varchar(255) NOT NULL,
  contact_phone varchar(50),
  county varchar(100),
  year_established integer,
  physical_address text,
  website_url varchar(500),
  nominee_details jsonb NOT NULL DEFAULT '{}',
  attachments jsonb NOT NULL DEFAULT '{}',
  status varchar(30) DEFAULT 'pending' CHECK (status IN ('pending', 'under_review', 'verified', 'rejected', 'shortlisted', 'winner', 'runner_up')),
  jury_score numeric(3,1),
  public_votes integer DEFAULT 0,
  total_score numeric(5,2),
  rejection_reason text,
  review_notes text,
  priority integer DEFAULT 0,
  featured boolean DEFAULT false,
  submission_ip inet,
  submission_user_agent text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Process state management
CREATE TABLE IF NOT EXISTS process_state (
  id integer PRIMARY KEY DEFAULT 1,
  current_stage varchar(50) NOT NULL DEFAULT 'setup' 
    CHECK (current_stage IN ('setup', 'entries_open', 'entries_closed', 'jury_vetting', 'vetting_closed', 'voting_open', 'voting_closed', 'results_announced')),
  stage_start timestamptz,
  stage_end timestamptz,
  auto_transition jsonb DEFAULT '{}',
  stage_metadata jsonb DEFAULT '{}',
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at timestamptz DEFAULT now()
);

-- User privileges for fine-grained access control
CREATE TABLE IF NOT EXISTS user_privileges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  privilege_type varchar(100) NOT NULL,
  resource_type varchar(50),
  resource_id uuid,
  granted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  expires_at timestamptz,
  is_active boolean DEFAULT true,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Submission reviews and scoring
CREATE TABLE IF NOT EXISTS submission_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid REFERENCES submissions(id) ON DELETE CASCADE,
  reviewer_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  reviewer_role varchar(50) NOT NULL,
  scores jsonb DEFAULT '{}',
  overall_score numeric(3,1),
  comments text,
  recommendations text,
  review_status varchar(20) DEFAULT 'draft' CHECK (review_status IN ('draft', 'submitted', 'final')),
  reviewed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- File attachment management
CREATE TABLE IF NOT EXISTS submission_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid REFERENCES submissions(id) ON DELETE CASCADE,
  file_type varchar(50) NOT NULL,
  original_name varchar(255) NOT NULL,
  file_url varchar(1000) NOT NULL,
  file_size bigint,
  mime_type varchar(100),
  upload_status varchar(20) DEFAULT 'uploaded' CHECK (upload_status IN ('uploading', 'uploaded', 'processed', 'failed')),
  alt_text varchar(255),
  caption text,
  metadata jsonb DEFAULT '{}',
  uploaded_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Audit trail for submissions
CREATE TABLE IF NOT EXISTS submission_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid REFERENCES submissions(id) ON DELETE CASCADE,
  version_number integer NOT NULL DEFAULT 1,
  field_changes jsonb DEFAULT '{}',
  changed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  change_reason varchar(500),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE form_definitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE process_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_privileges ENABLE ROW LEVEL SECURITY;
ALTER TABLE submission_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE submission_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE submission_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for form_definitions
CREATE POLICY "Public can view published forms" 
  ON form_definitions FOR SELECT 
  TO public 
  USING (published = true);

CREATE POLICY "Authenticated can view forms" 
  ON form_definitions FOR SELECT 
  TO authenticated 
  USING (true);

CREATE POLICY "Admins can manage forms" 
  ON form_definitions FOR ALL 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

-- RLS Policies for submissions
CREATE POLICY "Users can view own submissions" 
  ON submissions FOR SELECT 
  TO authenticated 
  USING (submitter_id = auth.uid());

CREATE POLICY "Users can create submissions" 
  ON submissions FOR INSERT 
  TO authenticated 
  WITH CHECK (submitter_id = auth.uid());

CREATE POLICY "Staff can view all submissions" 
  ON submissions FOR SELECT 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager', 'jury')
    )
  );

CREATE POLICY "Staff can manage submissions" 
  ON submissions FOR UPDATE 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

-- RLS Policies for process_state
CREATE POLICY "Anyone can view process state" 
  ON process_state FOR SELECT 
  TO public 
  USING (true);

CREATE POLICY "Superadmin can manage process state" 
  ON process_state FOR ALL 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' = 'superadmin'
    )
  );

-- RLS Policies for user_privileges
CREATE POLICY "Users can view own privileges" 
  ON user_privileges FOR SELECT 
  TO authenticated 
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage privileges" 
  ON user_privileges FOR ALL 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' IN ('superadmin', 'admin')
    )
  );

-- RLS Policies for submission_reviews
CREATE POLICY "Reviewers can view assigned reviews" 
  ON submission_reviews FOR SELECT 
  TO authenticated 
  USING (
    reviewer_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' IN ('superadmin', 'admin')
    )
  );

CREATE POLICY "Reviewers can manage own reviews" 
  ON submission_reviews FOR ALL 
  TO authenticated 
  USING (reviewer_id = auth.uid());

-- RLS Policies for submission_attachments
CREATE POLICY "Users can view submission attachments" 
  ON submission_attachments FOR SELECT 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM submissions s 
      WHERE s.id = submission_id 
      AND (s.submitter_id = auth.uid() OR 
           EXISTS (
             SELECT 1 FROM auth.users 
             WHERE id = auth.uid() 
             AND raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager', 'jury')
           ))
    )
  );

-- RLS Policies for submission_history
CREATE POLICY "Staff can view submission history" 
  ON submission_history FOR SELECT 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_form_definitions_slug ON form_definitions(slug);
CREATE INDEX IF NOT EXISTS idx_form_definitions_published ON form_definitions(published);
CREATE INDEX IF NOT EXISTS idx_form_definitions_category ON form_definitions(category_group, category);

CREATE INDEX IF NOT EXISTS idx_submissions_category ON submissions(category_group, category);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON submissions(status);
CREATE INDEX IF NOT EXISTS idx_submissions_submitter ON submissions(submitter_id);
CREATE INDEX IF NOT EXISTS idx_submissions_created ON submissions(created_at);
CREATE INDEX IF NOT EXISTS idx_submissions_featured ON submissions(featured) WHERE featured = true;

CREATE INDEX IF NOT EXISTS idx_user_privileges_user ON user_privileges(user_id, is_active);
CREATE INDEX IF NOT EXISTS idx_user_privileges_type ON user_privileges(privilege_type, resource_type);

CREATE INDEX IF NOT EXISTS idx_submission_reviews_submission ON submission_reviews(submission_id);
CREATE INDEX IF NOT EXISTS idx_submission_reviews_reviewer ON submission_reviews(reviewer_id);

-- Insert default process state
INSERT INTO process_state (id, current_stage, updated_at) 
VALUES (1, 'setup', now()) 
ON CONFLICT (id) DO NOTHING;

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add triggers for updated_at
CREATE TRIGGER update_form_definitions_updated_at 
  BEFORE UPDATE ON form_definitions 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_submissions_updated_at 
  BEFORE UPDATE ON submissions 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_privileges_updated_at 
  BEFORE UPDATE ON user_privileges 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_submission_reviews_updated_at 
  BEFORE UPDATE ON submission_reviews 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();