/*
  # Create Page Management System Tables

  1. New Tables
    - `pages`
      - `id` (uuid, primary key)
      - `title` (text) 
      - `slug` (text, unique)
      - `template_type` (text)
      - `status` (text)
      - `visibility` (text) 
      - `meta_title` (text)
      - `meta_description` (text)
      - `meta_keywords` (text)
      - `og_title` (text)
      - `og_description` (text)
      - `og_image` (text)
      - `featured_image` (text)
      - `excerpt` (text)
      - `show_in_navigation` (boolean)
      - `navigation_parent_id` (uuid)
      - `navigation_order` (integer)
      - `created_by` (uuid)
      - `updated_by` (uuid)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `page_sections`
      - `id` (uuid, primary key)
      - `page_id` (uuid, foreign key)
      - `section_type` (text)
      - `section_name` (text)
      - `content` (jsonb)
      - `styles` (jsonb)
      - `settings` (jsonb)
      - `is_visible` (boolean)
      - `section_order` (integer)
      - `created_by` (uuid)
      - `updated_by` (uuid)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `page_revisions`
      - `id` (uuid, primary key)
      - `page_id` (uuid, foreign key)
      - `revision_number` (integer)
      - `title` (text)
      - `content_snapshot` (jsonb)
      - `change_summary` (text)
      - `created_by` (uuid)
      - `created_at` (timestamp)

    - `navigation_items`
      - `id` (uuid, primary key)
      - `page_id` (uuid, foreign key)
      - `label` (text)
      - `url` (text)
      - `is_external` (boolean)
      - `target_blank` (boolean)
      - `parent_id` (uuid)
      - `menu_location` (text)
      - `order_position` (integer)
      - `is_visible` (boolean)
      - `required_role` (text)
      - `icon_class` (text)
      - `css_classes` (text)
      - `created_by` (uuid)
      - `updated_by` (uuid)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for role-based access (superadmin, admin, manager)
*/

-- Create pages table
CREATE TABLE IF NOT EXISTS pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  template_type text DEFAULT 'default' CHECK (template_type IN ('default', 'landing', 'blog', 'gallery', 'contact', 'service')),
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  visibility text DEFAULT 'public' CHECK (visibility IN ('public', 'private', 'role_based')),
  meta_title text,
  meta_description text,
  meta_keywords text,
  og_title text,
  og_description text,
  og_image text,
  featured_image text,
  excerpt text,
  show_in_navigation boolean DEFAULT true,
  navigation_parent_id uuid REFERENCES pages(id) ON DELETE SET NULL,
  navigation_order integer DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create page_sections table
CREATE TABLE IF NOT EXISTS page_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
  section_type text NOT NULL CHECK (section_type IN ('hero', 'text', 'image', 'gallery', 'stats', 'team', 'testimonials', 'services', 'contact_form', 'video', 'cta', 'faq')),
  section_name text NOT NULL,
  content jsonb DEFAULT '{}',
  styles jsonb DEFAULT '{}',
  settings jsonb DEFAULT '{}',
  is_visible boolean DEFAULT true,
  section_order integer DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create page_revisions table
CREATE TABLE IF NOT EXISTS page_revisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
  revision_number integer NOT NULL DEFAULT 1,
  title text NOT NULL,
  content_snapshot jsonb DEFAULT '{}',
  change_summary text,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Create navigation_items table
CREATE TABLE IF NOT EXISTS navigation_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid REFERENCES pages(id) ON DELETE CASCADE,
  label text NOT NULL,
  url text,
  is_external boolean DEFAULT false,
  target_blank boolean DEFAULT false,
  parent_id uuid REFERENCES navigation_items(id) ON DELETE CASCADE,
  menu_location text DEFAULT 'main' CHECK (menu_location IN ('main', 'footer', 'sidebar')),
  order_position integer DEFAULT 0,
  is_visible boolean DEFAULT true,
  required_role text CHECK (required_role IN ('superadmin', 'admin', 'manager', 'jury', 'voter', 'nominee')),
  icon_class text,
  css_classes text,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_pages_slug ON pages(slug);
CREATE INDEX IF NOT EXISTS idx_pages_status ON pages(status);
CREATE INDEX IF NOT EXISTS idx_pages_visibility ON pages(visibility);
CREATE INDEX IF NOT EXISTS idx_page_sections_page_id ON page_sections(page_id);
CREATE INDEX IF NOT EXISTS idx_page_sections_order ON page_sections(page_id, section_order);
CREATE INDEX IF NOT EXISTS idx_navigation_items_menu_location ON navigation_items(menu_location, order_position);
CREATE INDEX IF NOT EXISTS idx_page_revisions_page_id ON page_revisions(page_id, created_at);

-- Enable Row Level Security
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE page_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE page_revisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE navigation_items ENABLE ROW LEVEL SECURITY;

-- Pages policies
CREATE POLICY "Public can view published pages"
  ON pages FOR SELECT
  TO public
  USING (status = 'published' AND visibility = 'public');

CREATE POLICY "Authenticated users can view all pages"
  ON pages FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage pages"
  ON pages FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE auth.users.id = auth.uid() 
      AND auth.users.raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

-- Page sections policies
CREATE POLICY "Public can view sections of published pages"
  ON page_sections FOR SELECT
  TO public
  USING (
    is_visible = true AND
    EXISTS (
      SELECT 1 FROM pages 
      WHERE pages.id = page_sections.page_id 
      AND pages.status = 'published' 
      AND pages.visibility = 'public'
    )
  );

CREATE POLICY "Authenticated users can view all sections"
  ON page_sections FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage page sections"
  ON page_sections FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE auth.users.id = auth.uid() 
      AND auth.users.raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

-- Page revisions policies
CREATE POLICY "Admins can view page revisions"
  ON page_revisions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE auth.users.id = auth.uid() 
      AND auth.users.raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

CREATE POLICY "Admins can create page revisions"
  ON page_revisions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE auth.users.id = auth.uid() 
      AND auth.users.raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

-- Navigation items policies
CREATE POLICY "Public can view visible navigation items"
  ON navigation_items FOR SELECT
  TO public
  USING (is_visible = true AND (required_role IS NULL OR required_role = ''));

CREATE POLICY "Authenticated users can view navigation items"
  ON navigation_items FOR SELECT
  TO authenticated
  USING (
    is_visible = true AND (
      required_role IS NULL OR 
      required_role = '' OR
      EXISTS (
        SELECT 1 FROM auth.users 
        WHERE auth.users.id = auth.uid() 
        AND auth.users.raw_user_meta_data->>'role' = required_role
      )
    )
  );

CREATE POLICY "Admins can manage navigation items"
  ON navigation_items FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE auth.users.id = auth.uid() 
      AND auth.users.raw_user_meta_data->>'role' IN ('superadmin', 'admin', 'manager')
    )
  );

-- Create triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_pages_updated_at 
  BEFORE UPDATE ON pages 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_page_sections_updated_at 
  BEFORE UPDATE ON page_sections 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_navigation_items_updated_at 
  BEFORE UPDATE ON navigation_items 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert default navigation items
INSERT INTO navigation_items (label, url, menu_location, order_position, is_visible, created_by) VALUES
('Home', '/', 'main', 0, true, NULL),
('About', '/about', 'main', 1, true, NULL),
('Nominees', '/nominees', 'main', 2, true, NULL),
('Gallery', '/gallery', 'main', 3, true, NULL),
('Gala', '/gala', 'main', 4, true, NULL),
('Winners', '/winners', 'main', 5, true, NULL),
('Contact', '/contact', 'main', 6, true, NULL);