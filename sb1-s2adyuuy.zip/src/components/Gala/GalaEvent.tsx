import React, { useState } from 'react';
import { Calendar, MapPin, Clock, Users, CreditCard, QrCode, Star, Trophy, Ticket } from 'lucide-react';
import GalaBookingSystem from './GalaBookingSystem';

const GalaEvent: React.FC = () => {
  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Kenya Tourism Awards 2025 Gala</h2>
            <p className="text-amber-100 text-lg mb-4">
              Join us for an unforgettable evening celebrating excellence in tourism
            </p>
            <div className="flex flex-wrap items-center gap-6 text-amber-100">
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>March 15, 2025</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>6:00 PM - 11:00 PM</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-5 h-5" />
                <span>Kenyatta International Convention Centre</span>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <Trophy className="w-24 h-24 text-amber-200" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Tickets Sold</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">847</p>
            </div>
            <div className="p-3 rounded-lg bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400">
              <Ticket className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Expected Guests</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">1,200</p>
            </div>
            <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Days to Event</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">45</p>
            </div>
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400">
              <Calendar className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Revenue</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">25M</p>
            </div>
            <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400">
              <CreditCard className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Event Program</h3>
        <div className="space-y-4">
          {[
            { time: '6:00 PM', event: 'Registration & Welcome Reception', description: 'Guest check-in and networking' },
            { time: '7:00 PM', event: 'Opening Ceremony', description: 'Welcome address and cultural performance' },
            { time: '7:30 PM', event: 'Dinner Service', description: 'Gourmet dinner and entertainment' },
            { time: '8:30 PM', event: 'Awards Ceremony', description: 'Category-by-category winner announcements' },
            { time: '10:30 PM', event: 'Closing & After Party', description: 'Celebration and networking continues' }
          ].map((item, index) => (
            <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="flex-shrink-0 w-20 text-sm font-medium text-amber-600 dark:text-amber-400">
                {item.time}
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-900 dark:text-white">{item.event}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <GalaBookingSystem />
    </div>
  );
};

export default GalaEvent;