import React, { useState } from 'react';
import { Calendar, MapPin, Clock, Users, Star, Ticket, CreditCard, Smartphone, CheckCircle } from 'lucide-react';
import PaymentModal from '../Payments/PaymentModal';
import { GalaTicket } from '../../types/payment';

interface TicketType {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  available: number;
  total: number;
}

const ticketTypes: TicketType[] = [
  {
    id: 'standard',
    name: 'Standard',
    price: 15000,
    description: 'General admission to the gala event',
    features: ['Event access', 'Welcome drink', 'Dinner', 'Awards ceremony'],
    available: 150,
    total: 200
  },
  {
    id: 'vip',
    name: 'VIP',
    price: 35000,
    description: 'Premium experience with exclusive benefits',
    features: ['Priority seating', 'VIP lounge access', 'Premium dinner', 'Meet & greet', 'Gift bag'],
    available: 45,
    total: 50
  },
  {
    id: 'vvip',
    name: 'VVIP',
    price: 75000,
    description: 'Ultimate luxury experience',
    features: ['Front row seating', 'Private reception', 'Gourmet dinner', 'Photo opportunities', 'Exclusive gifts', 'After-party access'],
    available: 8,
    total: 10
  },
  {
    id: 'corporate',
    name: 'Corporate Table',
    price: 250000,
    description: 'Table for 8 with corporate branding',
    features: ['Reserved table for 8', 'Corporate branding', 'Networking opportunities', 'Premium service', 'Marketing materials'],
    available: 5,
    total: 15
  }
];

const GalaBookingSystem: React.FC = () => {
  const [selectedTicket, setSelectedTicket] = useState<string | null>(null);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [bookingData, setBookingData] = useState({
    name: '',
    email: '',
    phone: '',
    organization: '',
    quantity: 1,
    specialRequirements: ''
  });
  const [paymentData, setPaymentData] = useState({
    amount: 0,
    orderId: '',
    orderDetails: {
      description: '',
      items: [] as Array<{ name: string; quantity: number; price: number; }>
    }
  });

  const handleBooking = (ticketId: string) => {
    const ticket = ticketTypes.find(t => t.id === ticketId);
    if (!ticket) return;

    setSelectedTicket(ticketId);
    setShowBookingForm(true);
  };

  const handleProceedToPayment = () => {
    const ticket = ticketTypes.find(t => t.id === selectedTicket);
    if (!ticket) return;

    const totalAmount = ticket.price * bookingData.quantity;
    const orderId = `ticket_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    setPaymentData({
      amount: totalAmount,
      orderId,
      orderDetails: {
        description: `${ticket.name} Ticket${bookingData.quantity > 1 ? 's' : ''} - KTA 2025 Gala`,
        items: [
          {
            name: `${ticket.name} Ticket`,
            quantity: bookingData.quantity,
            price: ticket.price
          }
        ]
      }
    });

    setShowBookingForm(false);
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = (paymentResult: any) => {
    console.log('Payment successful:', paymentResult);
    // Here you would typically:
    // 1. Create the ticket record in the database
    // 2. Send confirmation email
    // 3. Generate QR codes
    // 4. Show success message
    setShowPaymentModal(false);
    alert('Booking successful! You will receive confirmation details via email.');
  };

  const handlePaymentError = (error: string) => {
    console.error('Payment failed:', error);
    alert(`Payment failed: ${error}`);
  };

  const selectedTicketType = ticketTypes.find(t => t.id === selectedTicket);

  const BookingForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">
              Book {selectedTicketType?.name} Ticket
            </h3>
            <button
              onClick={() => setShowBookingForm(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-amber-900 dark:text-amber-400">
                  {selectedTicketType?.name} - KES {selectedTicketType?.price.toLocaleString()}
                </h4>
                <p className="text-sm text-amber-700 dark:text-amber-500">
                  {selectedTicketType?.description}
                </p>
              </div>
              <Ticket className="w-8 h-8 text-amber-600 dark:text-amber-400" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Full Name *
              </label>
              <input
                type="text"
                value={bookingData.name}
                onChange={(e) => setBookingData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Email Address *
              </label>
              <input
                type="email"
                value={bookingData.email}
                onChange={(e) => setBookingData(prev => ({ ...prev, email: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Phone Number *
              </label>
              <input
                type="tel"
                value={bookingData.phone}
                onChange={(e) => setBookingData(prev => ({ ...prev, phone: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="+254712345678"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Organization (Optional)
              </label>
              <input
                type="text"
                value={bookingData.organization}
                onChange={(e) => setBookingData(prev => ({ ...prev, organization: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
          </div>

          {selectedTicketType?.id !== 'corporate' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Quantity
              </label>
              <select
                value={bookingData.quantity}
                onChange={(e) => setBookingData(prev => ({ ...prev, quantity: parseInt(e.target.value) }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                {[1, 2, 3, 4, 5].map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Special Requirements (Optional)
            </label>
            <textarea
              value={bookingData.specialRequirements}
              onChange={(e) => setBookingData(prev => ({ ...prev, specialRequirements: e.target.value }))}
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Any dietary restrictions, accessibility needs, etc."
            />
          </div>

          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between text-lg font-bold text-gray-900 dark:text-white">
              <span>Total Amount:</span>
              <span>KES {((selectedTicketType?.price || 0) * bookingData.quantity).toLocaleString()}</span>
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              onClick={() => setShowBookingForm(false)}
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleProceedToPayment}
              disabled={!bookingData.name || !bookingData.email || !bookingData.phone}
              className="flex-1 px-4 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center justify-center space-x-2"
            >
              <CreditCard className="w-4 h-4" />
              <span>Proceed to Payment</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Event Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Kenya Tourism Awards 2025 Gala</h2>
            <p className="text-amber-100 text-lg mb-4">
              Join us for an unforgettable evening celebrating excellence in tourism
            </p>
            <div className="flex flex-wrap items-center gap-6 text-amber-100">
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>March 15, 2025</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>6:00 PM - 11:00 PM</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-5 h-5" />
                <span>Kenyatta International Convention Centre</span>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <Ticket className="w-24 h-24 text-amber-200" />
          </div>
        </div>
      </div>

      {/* Payment Methods Banner */}
      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-6 border border-blue-200 dark:border-blue-800">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-blue-900 dark:text-blue-400 mb-2">
              Secure Payment Options Available
            </h3>
            <p className="text-sm text-blue-800 dark:text-blue-300">
              Choose from multiple payment methods for your convenience
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-blue-800 dark:text-blue-300">
              <Smartphone className="w-5 h-5 text-green-600" />
              <span>M-Pesa</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-blue-800 dark:text-blue-300">
              <CreditCard className="w-5 h-5 text-blue-600" />
              <span>Cards & Banking</span>
            </div>
          </div>
        </div>
      </div>

      {/* Ticket Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {ticketTypes.map((ticket) => (
          <div key={ticket.id} className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 hover:shadow-lg transition-all duration-300 group">
            <div className="text-center mb-4">
              <h4 className="text-xl font-bold text-gray-900 dark:text-white">{ticket.name}</h4>
              <p className="text-3xl font-bold text-amber-600 dark:text-amber-400 mt-2">
                KES {ticket.price.toLocaleString()}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{ticket.description}</p>
            </div>

            <div className="space-y-2 mb-4">
              {ticket.features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-2 text-sm">
                  <Star className="w-4 h-4 text-amber-400 fill-current" />
                  <span className="text-gray-600 dark:text-gray-400">{feature}</span>
                </div>
              ))}
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                <span>Available</span>
                <span>{ticket.available} of {ticket.total}</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-amber-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((ticket.total - ticket.available) / ticket.total) * 100}%` }}
                />
              </div>
            </div>

            <button
              onClick={() => handleBooking(ticket.id)}
              disabled={ticket.available === 0}
              className={`w-full py-3 px-4 rounded-lg font-medium transition-all duration-300 ${
                ticket.available === 0
                  ? 'bg-gray-100 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600 group-hover:scale-105 group-hover:shadow-lg'
              }`}
            >
              {ticket.available === 0 ? 'Sold Out' : 'Book Now'}
            </button>
          </div>
        ))}
      </div>

      {/* Event Features */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 text-center">
          Why Attend the KTA 2025 Gala?
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
            <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Network with Industry Leaders</h4>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Connect with over 1,200 tourism stakeholders, government officials, and industry pioneers
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-purple-600 dark:text-purple-400" />
            </div>
            <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Celebrate Excellence</h4>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Witness the recognition of outstanding achievements across 28 tourism categories
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Calendar className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
            <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Exclusive Experience</h4>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Enjoy premium dining, entertainment, and the most prestigious tourism event in Kenya
            </p>
          </div>
        </div>
      </div>

      {showBookingForm && <BookingForm />}
      
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        amount={paymentData.amount}
        currency="KES"
        orderId={paymentData.orderId}
        orderDetails={paymentData.orderDetails}
        onPaymentSuccess={handlePaymentSuccess}
        onPaymentError={handlePaymentError}
      />
    </div>
  );
};

export default GalaBookingSystem;