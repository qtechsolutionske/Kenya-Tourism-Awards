import React, { useState } from 'react';
import { MessageSquare, Send, Search, Users, Mail, Clock, Star, Reply, Forward, Trash2, Archive } from 'lucide-react';
import { TeamMember, TeamMessage } from '../../types/team';
import { teamMembers } from '../../data/teamMembers';
import { useAuth } from '../../hooks/useAuth';

const TeamMessaging: React.FC = () => {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewMessage, setShowNewMessage] = useState(false);

  // Mock messages data
  const [messages] = useState<TeamMessage[]>([
    {
      id: '1',
      senderId: '2',
      receiverId: user?.id || '1',
      subject: 'Jury Evaluation Update',
      message: 'Hi, I wanted to update you on the progress of the jury evaluations. We have completed 75% of the categories and are on track to finish by the deadline.',
      isRead: false,
      sentAt: new Date(Date.now() - 1000 * 60 * 30)
    },
    {
      id: '2', 
      senderId: '3',
      receiverId: user?.id || '1',
      subject: 'Gala Event Planning',
      message: 'The venue has been confirmed for March 15th. We need to finalize the guest list and catering arrangements. Can we schedule a meeting this week?',
      isRead: true,
      sentAt: new Date(Date.now() - 1000 * 60 * 60 * 2)
    }
  ]);

  const conversations = messages.reduce((acc, message) => {
    const conversationId = message.senderId === user?.id ? message.receiverId : message.senderId;
    if (!acc[conversationId]) {
      acc[conversationId] = [];
    }
    acc[conversationId].push(message);
    return acc;
  }, {} as { [key: string]: TeamMessage[] });

  const getMemberById = (memberId: string) => {
    return teamMembers.find(m => m.id === memberId);
  };

  const getLatestMessage = (memberId: string) => {
    const memberMessages = conversations[memberId] || [];
    return memberMessages.sort((a, b) => b.sentAt.getTime() - a.sentAt.getTime())[0];
  };

  const NewMessageForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">New Message</h3>
            <button
              onClick={() => setShowNewMessage(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              To
            </label>
            <select className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
              <option value="">Select recipient...</option>
              {teamMembers
                .filter(m => m.id !== user?.id)
                .map(member => (
                  <option key={member.id} value={member.id}>
                    {member.name} - {member.role}
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Subject
            </label>
            <input
              type="text"
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Enter message subject"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Message
            </label>
            <textarea
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Type your message here..."
            />
          </div>

          <div className="flex justify-end space-x-4">
            <button
              onClick={() => setShowNewMessage(false)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button className="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2">
              <Send className="w-4 h-4" />
              <span>Send Message</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Team Messages</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Internal communication between team members
          </p>
        </div>
        <button
          onClick={() => setShowNewMessage(true)}
          className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
        >
          <MessageSquare className="w-4 h-4" />
          <span>New Message</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Conversations List */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search conversations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
          </div>

          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {Object.keys(conversations).map(memberId => {
              const member = getMemberById(memberId);
              const latestMessage = getLatestMessage(memberId);
              
              if (!member || !latestMessage) return null;

              return (
                <button
                  key={memberId}
                  onClick={() => setSelectedConversation(memberId)}
                  className={`w-full text-left p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors ${
                    selectedConversation === memberId ? 'bg-amber-50 dark:bg-amber-900/20' : ''
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-gray-900 dark:text-white truncate">
                          {member.name}
                        </h4>
                        <span className="text-xs text-gray-500 dark:text-gray-500">
                          {latestMessage.sentAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{member.role}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-500 truncate mt-1">
                        {latestMessage.subject}
                      </p>
                    </div>
                    {!latestMessage.isRead && latestMessage.receiverId === user?.id && (
                      <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Message View */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
          {selectedConversation ? (
            <div className="h-[600px] flex flex-col">
              {/* Conversation Header */}
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                {(() => {
                  const member = getMemberById(selectedConversation);
                  return member ? (
                    <div className="flex items-center space-x-3">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div>
                        <h3 className="font-medium text-gray-900 dark:text-white">{member.name}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{member.role}</p>
                      </div>
                    </div>
                  ) : null;
                })()}
              </div>

              {/* Messages */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {conversations[selectedConversation]?.map(message => {
                  const isFromUser = message.senderId === user?.id;
                  return (
                    <div key={message.id} className={`flex ${isFromUser ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-xl ${
                        isFromUser 
                          ? 'bg-amber-500 text-white' 
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                      }`}>
                        <p className="font-medium text-sm mb-1">{message.subject}</p>
                        <p className="text-sm">{message.message}</p>
                        <p className={`text-xs mt-2 ${
                          isFromUser ? 'text-amber-100' : 'text-gray-500 dark:text-gray-400'
                        }`}>
                          {message.sentAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Message Input */}
              <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-end space-x-2">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        // Handle send message
                        setNewMessage('');
                      }
                    }}
                  />
                  <button className="p-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors">
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-[600px] flex items-center justify-center">
              <div className="text-center">
                <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                  Select a conversation
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Choose a team member to start messaging
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {showNewMessage && <NewMessageForm />}
    </div>
  );
};

export default TeamMessaging;