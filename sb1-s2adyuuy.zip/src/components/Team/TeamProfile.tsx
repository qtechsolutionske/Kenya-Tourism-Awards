import React, { useState } from 'react';
import { ArrowLeft, Mail, Phone, Globe, ExternalLink, Calendar, Award, Users, Star, Download, Share2, MessageSquare, Edit, Eye, Camera, Video, FileText, Link } from 'lucide-react';
import { TeamMember } from '../../types/team';
import { useAuth } from '../../hooks/useAuth';

interface TeamProfileProps {
  member: TeamMember;
  onBack: () => void;
}

const TeamProfile: React.FC<TeamProfileProps> = ({ member, onBack }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'portfolio' | 'achievements' | 'gallery' | 'endorsements'>('overview');
  const [showEditMode, setShowEditMode] = useState(false);

  const canEdit = user && (
    user.id === member.id || 
    user.role === 'superadmin' || 
    user.role === 'admin' ||
    user.permissions?.includes('edit_team_profiles')
  );

  const getSocialIcon = (platform: string) => {
    const iconMap: { [key: string]: React.ComponentType<any> } = {
      linkedin: ({ className }: { className?: string }) => <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>,
      twitter: ({ className }: { className?: string }) => <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>,
      facebook: ({ className }: { className?: string }) => <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>,
      instagram: ({ className }: { className?: string }) => <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.624 5.367 11.99 11.988 11.99s11.99-5.366 11.99-11.99C24.007 5.367 18.641.001 12.017.001zM18.68 9.464c.023.27.023.542.023.814 0 8.31-6.324 17.897-17.897 17.897-3.558 0-6.87-1.042-9.657-2.827.497.058.997.087 1.512.087 2.967 0 5.697-.996 7.849-2.687-2.785-.058-5.125-1.882-5.93-4.404.388.077.785.124 1.199.124.566 0 1.131-.077 1.66-.214-2.903-.581-5.088-3.15-5.088-6.233v-.078c.854.473 1.831.758 2.874.792-1.704-1.136-2.828-3.078-2.828-5.281 0-1.163.31-2.251.853-3.189 3.132 3.83 7.802 6.347 13.075 6.608-.108-.473-.166-.966-.166-1.477 0-3.558 2.886-6.445 6.445-6.445 1.854 0 3.527.785 4.704 2.041 1.466-.289 2.845-.827 4.089-1.564-.482 1.512-1.512 2.785-2.849 3.589 1.302-.155 2.547-.5 3.706-.996-.87 1.297-1.95 2.438-3.202 3.35z"/></svg>
    };
    return iconMap[platform] || Globe;
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'portfolio':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Portfolio & Contributions</h3>
              {canEdit && (
                <button className="flex items-center space-x-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors">
                  <FileText className="w-4 h-4" />
                  <span>Add Entry</span>
                </button>
              )}
            </div>

            {member.portfolio.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">No portfolio entries yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {member.portfolio.map(entry => (
                  <div key={entry.id} className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        {entry.type === 'pdf' && <FileText className="w-5 h-5 text-red-500" />}
                        {entry.type === 'link' && <Link className="w-5 h-5 text-blue-500" />}
                        {entry.type === 'article' && <FileText className="w-5 h-5 text-green-500" />}
                        {entry.type === 'image' && <Camera className="w-5 h-5 text-purple-500" />}
                        <h4 className="font-medium text-gray-900 dark:text-white">{entry.title}</h4>
                      </div>
                      <ExternalLink className="w-4 h-4 text-gray-400" />
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{entry.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-1">
                        {entry.tags.slice(0, 3).map(tag => (
                          <span key={tag} className="px-2 py-1 bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-400 text-xs rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                      {entry.publishedDate && (
                        <span className="text-xs text-gray-500 dark:text-gray-500">
                          {entry.publishedDate.toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Event Responsibilities for Staff */}
            {member.eventResponsibilities && member.eventResponsibilities.length > 0 && (
              <div className="mt-8">
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Event Responsibilities</h4>
                <div className="space-y-4">
                  {member.eventResponsibilities.map((responsibility, index) => (
                    <div key={index} className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 border border-blue-200 dark:border-blue-800">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="font-medium text-blue-900 dark:text-blue-400">{responsibility.eventName}</h5>
                        <span className="text-sm text-blue-600 dark:text-blue-500">{responsibility.year}</span>
                      </div>
                      <p className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-1">{responsibility.role}</p>
                      <p className="text-sm text-blue-700 dark:text-blue-400">{responsibility.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Judging History for Jury */}
            {member.judgingHistory && member.judgingHistory.length > 0 && (
              <div className="mt-8">
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Judging History</h4>
                <div className="space-y-4">
                  {member.judgingHistory.map((history, index) => (
                    <div key={index} className="bg-purple-50 dark:bg-purple-900/20 rounded-xl p-4 border border-purple-200 dark:border-purple-800">
                      <div className="flex items-center justify-between mb-3">
                        <h5 className="font-medium text-purple-900 dark:text-purple-400">KTA {history.year}</h5>
                        <div className="text-sm text-purple-600 dark:text-purple-500">
                          Average Score: {history.averageScore}/10
                        </div>
                      </div>
                      <p className="text-sm text-purple-800 dark:text-purple-300 mb-2">
                        Evaluated {history.totalNominations} nominations across {history.categories.length} categories
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {history.categories.map(category => (
                          <span key={category} className="px-2 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-400 text-xs rounded-full">
                            {category.replace('-', ' ')}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );

      case 'achievements':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Achievements & Recognition</h3>
              {canEdit && (
                <button className="flex items-center space-x-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors">
                  <Award className="w-4 h-4" />
                  <span>Add Achievement</span>
                </button>
              )}
            </div>

            {/* Badges */}
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white mb-4">Badges & Recognition</h4>
              <div className="flex flex-wrap gap-3">
                {member.badges.map(badge => (
                  <div key={badge.id} className={`px-4 py-2 bg-${badge.color}-100 dark:bg-${badge.color}-900/20 text-${badge.color}-800 dark:text-${badge.color}-400 rounded-full flex items-center space-x-2`}>
                    <Star className="w-4 h-4" />
                    <span className="font-medium">{badge.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Achievements Timeline */}
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white mb-4">Career Timeline</h4>
              <div className="space-y-4">
                {member.achievements.map(achievement => (
                  <div key={achievement.id} className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <Award className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-medium text-gray-900 dark:text-white">{achievement.title}</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">{achievement.description}</p>
                      <div className="flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-500">
                        <span>{achievement.date.toLocaleDateString()}</span>
                        {achievement.organization && <span>{achievement.organization}</span>}
                        <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full capitalize">
                          {achievement.type}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'gallery':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Media Gallery</h3>
              {canEdit && (
                <button className="flex items-center space-x-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors">
                  <Camera className="w-4 h-4" />
                  <span>Add Media</span>
                </button>
              )}
            </div>

            {/* Photos */}
            {member.gallery.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-4">Photos</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {member.gallery.map(item => (
                    <div key={item.id} className="group relative aspect-square bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden">
                      <img 
                        src={item.thumbnail}
                        alt={item.caption}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-colors flex items-center justify-center">
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity text-white text-center">
                          <p className="text-sm font-medium">{item.caption}</p>
                          {item.event && (
                            <p className="text-xs text-gray-300">{item.event}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Videos */}
            {member.videos.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-4">Videos</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {member.videos.map(video => (
                    <div key={video.id} className="bg-gray-50 dark:bg-gray-700 rounded-xl overflow-hidden">
                      <div className="relative aspect-video">
                        <img 
                          src={video.thumbnail}
                          alt={video.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                          <Video className="w-12 h-12 text-white" />
                        </div>
                        <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                          {video.platform}
                        </div>
                      </div>
                      <div className="p-4">
                        <h5 className="font-medium text-gray-900 dark:text-white mb-1">{video.title}</h5>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{video.description}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-500">
                          {video.publishedDate.toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );

      case 'endorsements':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Endorsements & Testimonials</h3>
              {user && user.id !== member.id && (
                <button className="flex items-center space-x-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors">
                  <Star className="w-4 h-4" />
                  <span>Add Endorsement</span>
                </button>
              )}
            </div>
            <div className="text-center py-8">
              <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500 dark:text-gray-400">No endorsements yet</p>
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-6">
            {/* Bio */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">About</h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                {member.bio}
              </p>
            </div>

            {/* Organization Details */}
            {member.organization && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">Organization</h4>
                <p className="text-gray-600 dark:text-gray-400">{member.organization}</p>
              </div>
            )}

            {/* Specialization */}
            {member.specialization && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">Specialization</h4>
                <p className="text-gray-600 dark:text-gray-400">{member.specialization}</p>
              </div>
            )}

            {/* Featured Categories for Jury */}
            {member.juryCategories && member.juryCategories.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">Featured in Award Categories</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {member.juryCategories.map(categoryId => (
                    <div key={categoryId} className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                      <div className="flex items-center space-x-2">
                        <Award className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        <span className="font-medium text-blue-900 dark:text-blue-400 capitalize">
                          {categoryId.replace('-', ' ')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <Calendar className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                <div className="text-lg font-bold text-gray-900 dark:text-white">
                  {new Date().getFullYear() - member.joinedYear + 1}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Years with KTA</div>
              </div>
              
              <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <Award className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                <div className="text-lg font-bold text-gray-900 dark:text-white">
                  {member.achievements.length}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Achievements</div>
              </div>

              <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <FileText className="w-6 h-6 text-green-500 mx-auto mb-2" />
                <div className="text-lg font-bold text-gray-900 dark:text-white">
                  {member.portfolio.length}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Portfolio Items</div>
              </div>

              <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <Eye className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                <div className="text-lg font-bold text-gray-900 dark:text-white">
                  {member.profileViews || 0}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Profile Views</div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Directory</span>
        </button>
        
        <div className="flex items-center space-x-3">
          {canEdit && (
            <button
              onClick={() => setShowEditMode(!showEditMode)}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Edit className="w-4 h-4" />
              <span>Edit Profile</span>
            </button>
          )}
          <button className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
            <Share2 className="w-4 h-4" />
            <span>Share</span>
          </button>
        </div>
      </div>

      {/* Profile Header */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg border border-gray-200 dark:border-gray-700">
        {/* Banner */}
        <div className="relative h-48 bg-gradient-to-r from-amber-500 to-orange-500">
          {member.banner && (
            <img 
              src={member.banner}
              alt={`${member.name} banner`}
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          
          {/* Badges */}
          <div className="absolute top-4 right-4 flex space-x-2">
            {member.badges.map(badge => (
              <div key={badge.id} className={`px-3 py-1 bg-${badge.color}-500 text-white text-sm font-medium rounded-full`}>
                {badge.name}
              </div>
            ))}
          </div>
        </div>

        {/* Profile Info */}
        <div className="relative px-8 pb-8">
          {/* Avatar */}
          <div className="flex justify-center -mt-12 mb-6">
            <img 
              src={member.avatar}
              alt={member.name}
              className="w-24 h-24 rounded-2xl border-4 border-white dark:border-gray-800 shadow-lg object-cover"
            />
          </div>

          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {member.name}
            </h1>
            <p className="text-xl text-amber-600 dark:text-amber-400 font-medium mb-1">
              {member.role}
            </p>
            <p className="text-gray-500 dark:text-gray-500">
              {member.department} • {member.experience}+ years experience
            </p>
          </div>

          {/* Contact & Social */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
            <div className="flex items-center space-x-4">
              <a 
                href={`mailto:${member.email}`}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Mail className="w-4 h-4" />
                <span>Email</span>
              </a>
              
              {member.phone && (
                <a 
                  href={`tel:${member.phone}`}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call</span>
                </a>
              )}

              {member.website && (
                <a 
                  href={member.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Globe className="w-4 h-4" />
                  <span>Website</span>
                </a>
              )}
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-3">
              {Object.entries(member.socialLinks).map(([platform, url]) => {
                if (!url) return null;
                const SocialIcon = getSocialIcon(platform);
                return (
                  <a 
                    key={platform}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-amber-500 hover:text-white transition-all"
                  >
                    <SocialIcon className="w-5 h-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Download CV */}
          {member.downloadableCV && (
            <div className="text-center mb-6">
              <a 
                href={member.downloadableCV}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download CV/Portfolio</span>
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', label: 'Overview', icon: User },
              { id: 'portfolio', label: 'Portfolio', icon: FileText },
              { id: 'achievements', label: 'Achievements', icon: Award },
              { id: 'gallery', label: 'Gallery', icon: Camera },
              { id: 'endorsements', label: 'Endorsements', icon: Star }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default TeamProfile;