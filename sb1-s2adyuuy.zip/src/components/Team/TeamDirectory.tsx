import React, { useState } from 'react';
import { Search, Filter, Users, Award, Calendar, MapPin, Eye, Mail, Phone, ExternalLink, Globe, Linkedin, Twitter, Facebook, Instagram, Star, Trophy, User } from 'lucide-react';
import { teamMembers, teamDepartments, teamRoles } from '../../data/teamMembers';
import { TeamMember } from '../../types/team';
import { useAuth } from '../../hooks/useAuth';

interface TeamDirectoryProps {
  onMemberSelect?: (member: TeamMember) => void;
  viewMode?: 'directory' | 'jury';
}

const TeamDirectory: React.FC<TeamDirectoryProps> = ({ onMemberSelect, viewMode = 'directory' }) => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [yearFilter, setYearFilter] = useState('all');
  const [viewType, setViewType] = useState<'grid' | 'list'>('grid');
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  // Filter members based on view mode
  const membersToShow = viewMode === 'jury' 
    ? teamMembers.filter(member => member.juryCategories && member.juryCategories.length > 0)
    : teamMembers.filter(member => member.isActive && member.isPublic);

  const filteredMembers = membersToShow.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.specialization?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || member.role === roleFilter;
    const matchesDepartment = departmentFilter === 'all' || member.department === departmentFilter;
    const matchesYear = yearFilter === 'all' || member.joinedYear.toString() === yearFilter;
    return matchesSearch && matchesRole && matchesDepartment && matchesYear;
  });

  const getSocialIcon = (platform: string) => {
    switch (platform) {
      case 'linkedin': return <Linkedin className="w-4 h-4" />;
      case 'twitter': return <Twitter className="w-4 h-4" />;
      case 'facebook': return <Facebook className="w-4 h-4" />;
      case 'instagram': return <Instagram className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  const MemberCard = ({ member }: { member: TeamMember }) => (
    <div 
      className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-200 dark:border-gray-700"
      onClick={() => {
        setSelectedMember(member);
        onMemberSelect?.(member);
      }}
    >
      {/* Banner */}
      <div className="relative h-32 bg-gradient-to-r from-amber-500 to-orange-500 overflow-hidden">
        {member.banner && (
          <img 
            src={member.banner} 
            alt={`${member.name} banner`}
            className="w-full h-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        
        {/* Badges */}
        <div className="absolute top-3 right-3 flex space-x-2">
          {member.badges.slice(0, 2).map(badge => (
            <div key={badge.id} className={`px-2 py-1 bg-${badge.color}-500 text-white text-xs font-medium rounded-full`}>
              {badge.name}
            </div>
          ))}
        </div>
      </div>

      {/* Profile Info */}
      <div className="relative px-6 pb-6">
        {/* Avatar */}
        <div className="flex justify-center -mt-8 mb-4">
          <img 
            src={member.avatar}
            alt={member.name}
            className="w-16 h-16 rounded-full border-4 border-white dark:border-gray-800 shadow-lg object-cover"
          />
        </div>

        <div className="text-center">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
            {member.name}
          </h3>
          <p className="text-amber-600 dark:text-amber-400 font-medium text-sm mb-1">
            {member.role}
          </p>
          <p className="text-gray-500 dark:text-gray-500 text-xs mb-3">
            {member.department} • {member.experience}+ years
          </p>
        </div>

        <p className="text-gray-600 dark:text-gray-400 text-sm text-center mb-4 line-clamp-2">
          {member.bio}
        </p>

        {/* Jury Categories */}
        {member.juryCategories && member.juryCategories.length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">Assigned Categories:</p>
            <div className="flex flex-wrap gap-1">
              {member.juryCategories.slice(0, 2).map(categoryId => (
                <span key={categoryId} className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 text-xs rounded-full">
                  {categoryId.replace('-', ' ')}
                </span>
              ))}
              {member.juryCategories.length > 2 && (
                <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs rounded-full">
                  +{member.juryCategories.length - 2} more
                </span>
              )}
            </div>
          </div>
        )}

        {/* Social Links */}
        <div className="flex justify-center space-x-3 mb-4">
          {Object.entries(member.socialLinks).map(([platform, url]) => (
            url && (
              <a 
                key={platform}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-amber-500 hover:text-white transition-all"
                onClick={(e) => e.stopPropagation()}
              >
                {getSocialIcon(platform)}
              </a>
            )
          ))}
        </div>

        {/* Contact Actions */}
        <div className="flex space-x-2">
          <button 
            className="flex-1 flex items-center justify-center space-x-1 px-3 py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors text-sm"
            onClick={(e) => e.stopPropagation()}
          >
            <Eye className="w-3 h-3" />
            <span>View Profile</span>
          </button>
          {user && (
            <a 
              href={`mailto:${member.email}`}
              className="p-2 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              onClick={(e) => e.stopPropagation()}
            >
              <Mail className="w-4 h-4 text-gray-600 dark:text-gray-400" />
            </a>
          )}
        </div>
      </div>
    </div>
  );

  const MemberListItem = ({ member }: { member: TeamMember }) => (
    <div 
      className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all cursor-pointer"
      onClick={() => {
        setSelectedMember(member);
        onMemberSelect?.(member);
      }}
    >
      <div className="flex items-center space-x-4">
        <img 
          src={member.avatar}
          alt={member.name}
          className="w-20 h-20 rounded-xl object-cover"
        />
        
        <div className="flex-1">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                {member.name}
              </h3>
              <p className="text-amber-600 dark:text-amber-400 font-medium">
                {member.role}
              </p>
              <p className="text-gray-500 dark:text-gray-500 text-sm">
                {member.department} • {member.experience}+ years • Joined {member.joinedYear}
              </p>
            </div>
            
            <div className="flex items-center space-x-2">
              {member.badges.slice(0, 2).map(badge => (
                <div key={badge.id} className={`px-2 py-1 bg-${badge.color}-100 dark:bg-${badge.color}-900/20 text-${badge.color}-800 dark:text-${badge.color}-400 text-xs font-medium rounded-full`}>
                  {badge.name}
                </div>
              ))}
            </div>
          </div>
          
          <p className="text-gray-600 dark:text-gray-400 text-sm mt-2 line-clamp-2">
            {member.bio}
          </p>
          
          {/* Jury Categories for list view */}
          {member.juryCategories && member.juryCategories.length > 0 && (
            <div className="mt-3">
              <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Jury Categories:</p>
              <div className="flex flex-wrap gap-1">
                {member.juryCategories.map(categoryId => (
                  <span key={categoryId} className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 text-xs rounded-full">
                    {categoryId.replace('-', ' ')}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col items-end space-y-2">
          <div className="flex items-center space-x-2">
            {Object.entries(member.socialLinks).slice(0, 3).map(([platform, url]) => (
              url && (
                <a 
                  key={platform}
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-6 h-6 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-amber-500 hover:text-white transition-all text-xs"
                  onClick={(e) => e.stopPropagation()}
                >
                  {getSocialIcon(platform)}
                </a>
              )
            ))}
          </div>
          
          <div className="text-right text-xs text-gray-500 dark:text-gray-500">
            <div className="flex items-center space-x-1">
              <Eye className="w-3 h-3" />
              <span>{member.profileViews || 0} views</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">
              {viewMode === 'jury' ? 'Jury Members' : 'Team Directory'}
            </h2>
            <p className="text-amber-100 text-lg">
              {viewMode === 'jury' 
                ? 'Meet our expert jury panel evaluating nominations'
                : 'Meet the dedicated team behind Kenya Tourism Awards'
              }
            </p>
          </div>
          <div className="hidden md:block">
            <Users className="w-24 h-24 text-amber-200" />
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search members..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">All Roles</option>
                {teamRoles.map(role => (
                  <option key={role} value={role}>{role}</option>
                ))}
              </select>
            </div>
            
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Departments</option>
              {teamDepartments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>

            <select
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Years</option>
              <option value="2025">2025</option>
              <option value="2024">2024</option>
              <option value="2023">2023</option>
              <option value="2022">2022</option>
              <option value="2021">2021</option>
              <option value="2020">2020</option>
            </select>

            {/* View Toggle */}
            <div className="flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
              <button
                onClick={() => setViewType('grid')}
                className={`p-2 rounded-md transition-colors ${
                  viewType === 'grid' 
                    ? 'bg-white dark:bg-gray-600 shadow-sm' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <div className="grid grid-cols-2 gap-1 w-4 h-4">
                  <div className="w-1 h-1 bg-current rounded"></div>
                  <div className="w-1 h-1 bg-current rounded"></div>
                  <div className="w-1 h-1 bg-current rounded"></div>
                  <div className="w-1 h-1 bg-current rounded"></div>
                </div>
              </button>
              <button
                onClick={() => setViewType('list')}
                className={`p-2 rounded-md transition-colors ${
                  viewType === 'list' 
                    ? 'bg-white dark:bg-gray-600 shadow-sm' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <div className="space-y-1 w-4 h-4">
                  <div className="w-full h-0.5 bg-current rounded"></div>
                  <div className="w-full h-0.5 bg-current rounded"></div>
                  <div className="w-full h-0.5 bg-current rounded"></div>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Results Info */}
        <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
          <span>Showing {filteredMembers.length} of {membersToShow.length} members</span>
          {viewMode === 'jury' && (
            <span>{membersToShow.length} jury members assigned</span>
          )}
        </div>
      </div>

      {/* Members Grid/List */}
      <div className={
        viewType === 'grid' 
          ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          : "space-y-4"
      }>
        {filteredMembers.map((member) => 
          viewType === 'grid' ? (
            <MemberCard key={member.id} member={member} />
          ) : (
            <MemberListItem key={member.id} member={member} />
          )
        )}
      </div>

      {filteredMembers.length === 0 && (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700">
          <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No members found</h3>
          <p className="text-gray-600 dark:text-gray-400">
            Try adjusting your search or filter criteria.
          </p>
        </div>
      )}
    </div>
  );
};

export default TeamDirectory;