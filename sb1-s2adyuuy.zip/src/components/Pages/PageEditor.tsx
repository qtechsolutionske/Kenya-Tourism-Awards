import React, { useState, useEffect } from 'react';
import { 
  Save, X, Eye, Plus, Edit, Trash2, ArrowUp, ArrowDown, 
  Layout, Type, Image, Users, Star, BarChart3, Video,
  Globe, Mail, HelpCircle, Target, Settings, Code
} from 'lucide-react';
import { usePageManagement } from '../../hooks/usePageManagement';
import { Page, PageSection, SectionTemplate } from '../../types/pages';
import { useAuth } from '../../hooks/useAuth';

interface PageEditorProps {
  page: Page;
  onSave: (pageUpdates: Partial<Page>, sections: PageSection[]) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

const sectionTemplates: SectionTemplate[] = [
  {
    type: 'hero',
    name: 'Hero Section',
    description: 'Large banner with title, subtitle, and call-to-action',
    icon: 'Layout',
    defaultContent: {
      title: 'Welcome to Our Site',
      subtitle: 'Subtitle description here',
      backgroundImage: '',
      ctaText: 'Get Started',
      ctaLink: '#',
      overlay: 50
    },
    fields: [
      { name: 'title', type: 'text', label: 'Title', required: true },
      { name: 'subtitle', type: 'textarea', label: 'Subtitle' },
      { name: 'backgroundImage', type: 'image', label: 'Background Image' },
      { name: 'ctaText', type: 'text', label: 'Button Text' },
      { name: 'ctaLink', type: 'url', label: 'Button Link' },
      { name: 'overlay', type: 'number', label: 'Overlay Opacity (%)', validation: { min: 0, max: 100 } }
    ]
  },
  {
    type: 'text',
    name: 'Text Content',
    description: 'Rich text content with formatting',
    icon: 'Type',
    defaultContent: {
      title: 'Section Title',
      content: '<p>Your content goes here...</p>',
      alignment: 'left'
    },
    fields: [
      { name: 'title', type: 'text', label: 'Section Title' },
      { name: 'content', type: 'richtext', label: 'Content', required: true },
      { name: 'alignment', type: 'select', label: 'Text Alignment', options: [
        { value: 'left', label: 'Left' },
        { value: 'center', label: 'Center' },
        { value: 'right', label: 'Right' }
      ]}
    ]
  },
  {
    type: 'image',
    name: 'Image Block',
    description: 'Single image with optional caption',
    icon: 'Image',
    defaultContent: {
      src: '',
      alt: '',
      caption: '',
      layout: 'full'
    },
    fields: [
      { name: 'src', type: 'image', label: 'Image', required: true },
      { name: 'alt', type: 'text', label: 'Alt Text', required: true },
      { name: 'caption', type: 'text', label: 'Caption' },
      { name: 'layout', type: 'select', label: 'Layout', options: [
        { value: 'full', label: 'Full Width' },
        { value: 'contained', label: 'Contained' },
        { value: 'left', label: 'Left Aligned' },
        { value: 'right', label: 'Right Aligned' }
      ]}
    ]
  },
  {
    type: 'gallery',
    name: 'Image Gallery',
    description: 'Grid of images with lightbox',
    icon: 'Camera',
    defaultContent: {
      title: 'Gallery',
      columns: 3,
      images: []
    },
    fields: [
      { name: 'title', type: 'text', label: 'Gallery Title' },
      { name: 'columns', type: 'select', label: 'Columns', options: [
        { value: '2', label: '2 Columns' },
        { value: '3', label: '3 Columns' },
        { value: '4', label: '4 Columns' }
      ]},
      { name: 'images', type: 'array', label: 'Images' }
    ]
  },
  {
    type: 'stats',
    name: 'Statistics',
    description: 'Number highlights with icons',
    icon: 'BarChart3',
    defaultContent: {
      title: 'Our Impact',
      stats: [
        { number: '100+', label: 'Customers', icon: 'Users' },
        { number: '50+', label: 'Projects', icon: 'Award' }
      ]
    },
    fields: [
      { name: 'title', type: 'text', label: 'Section Title' },
      { name: 'stats', type: 'array', label: 'Statistics' }
    ]
  },
  {
    type: 'team',
    name: 'Team Members',
    description: 'Team member profiles with photos',
    icon: 'Users',
    defaultContent: {
      title: 'Meet Our Team',
      subtitle: 'The people behind our success',
      members: []
    },
    fields: [
      { name: 'title', type: 'text', label: 'Section Title' },
      { name: 'subtitle', type: 'text', label: 'Subtitle' },
      { name: 'members', type: 'array', label: 'Team Members' }
    ]
  },
  {
    type: 'testimonials',
    name: 'Testimonials',
    description: 'Customer testimonials and reviews',
    icon: 'Star',
    defaultContent: {
      title: 'What People Say',
      testimonials: []
    },
    fields: [
      { name: 'title', type: 'text', label: 'Section Title' },
      { name: 'testimonials', type: 'array', label: 'Testimonials' }
    ]
  }
];

const PageEditor: React.FC<PageEditorProps> = ({ page, onSave, onCancel, isLoading = false }) => {
  const { user } = useAuth();
  const { fetchPageSections, createSection, updateSection, deleteSection } = usePageManagement();
  const [pageData, setPageData] = useState<Page>(page);
  const [sections, setSections] = useState<PageSection[]>([]);
  const [activeTab, setActiveTab] = useState<'content' | 'sections' | 'seo' | 'settings'>('content');
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [showSectionSelector, setShowSectionSelector] = useState(false);
  const [sectionsLoading, setSectionsLoading] = useState(true);

  useEffect(() => {
    loadPageSections();
  }, [page.id]);

  const loadPageSections = async () => {
    setSectionsLoading(true);
    const sectionsData = await fetchPageSections(page.id);
    setSections(sectionsData);
    setSectionsLoading(false);
  };

  const handleSave = async () => {
    await onSave(pageData, sections);
  };

  const addSection = async (template: SectionTemplate) => {
    try {
      const newSection = await createSection({
        pageId: page.id,
        sectionType: template.type,
        sectionName: template.name,
        content: template.defaultContent,
        isVisible: true,
        sectionOrder: sections.length,
        createdBy: user!.id
      } as any);
      
      setSections(prev => [...prev, newSection]);
      setShowSectionSelector(false);
    } catch (err) {
      console.error('Failed to add section:', err);
    }
  };

  const moveSection = async (sectionId: string, direction: 'up' | 'down') => {
    const sectionIndex = sections.findIndex(s => s.id === sectionId);
    if (sectionIndex === -1) return;

    const targetIndex = direction === 'up' ? sectionIndex - 1 : sectionIndex + 1;
    if (targetIndex < 0 || targetIndex >= sections.length) return;

    const newSections = [...sections];
    [newSections[sectionIndex], newSections[targetIndex]] = [newSections[targetIndex], newSections[sectionIndex]];
    
    // Update section orders
    newSections.forEach(async (section, index) => {
      await updateSection(section.id, { sectionOrder: index, updatedBy: user!.id });
    });

    setSections(newSections);
  };

  const handleDeleteSection = async (sectionId: string) => {
    if (window.confirm('Are you sure you want to delete this section?')) {
      try {
        await deleteSection(sectionId);
        setSections(prev => prev.filter(s => s.id !== sectionId));
      } catch (err) {
        console.error('Failed to delete section:', err);
      }
    }
  };

  const SectionEditor = ({ section }: { section: PageSection }) => {
    const [sectionContent, setSectionContent] = useState(section.content);
    const template = sectionTemplates.find(t => t.type === section.sectionType);

    const handleUpdateSection = async () => {
      try {
        await updateSection(section.id, {
          content: sectionContent,
          updatedBy: user!.id
        });
        setSections(prev => prev.map(s => 
          s.id === section.id ? { ...s, content: sectionContent } : s
        ));
        setEditingSection(null);
      } catch (err) {
        console.error('Failed to update section:', err);
      }
    };

    return (
      <div className="border-2 border-blue-500 rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-medium text-gray-900 dark:text-white">
            Editing: {section.sectionName}
          </h4>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleUpdateSection}
              className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700 transition-colors"
            >
              <Save className="w-4 h-4" />
            </button>
            <button
              onClick={() => setEditingSection(null)}
              className="px-3 py-1 bg-gray-600 text-white text-sm rounded hover:bg-gray-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {template?.fields.map((field) => (
            <div key={field.name}>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {field.label} {field.required && '*'}
              </label>
              
              {field.type === 'text' && (
                <input
                  type="text"
                  value={sectionContent[field.name] || ''}
                  onChange={(e) => setSectionContent(prev => ({
                    ...prev,
                    [field.name]: e.target.value
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder={field.placeholder}
                />
              )}

              {field.type === 'textarea' && (
                <textarea
                  value={sectionContent[field.name] || ''}
                  onChange={(e) => setSectionContent(prev => ({
                    ...prev,
                    [field.name]: e.target.value
                  }))}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder={field.placeholder}
                />
              )}

              {field.type === 'richtext' && (
                <div className="border border-gray-300 dark:border-gray-600 rounded-lg">
                  <div className="bg-gray-50 dark:bg-gray-700 border-b border-gray-300 dark:border-gray-600 p-2 flex items-center space-x-2">
                    <button className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <Type className="w-4 h-4" />
                    </button>
                    <button className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <Image className="w-4 h-4" />
                    </button>
                    <button className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <Globe className="w-4 h-4" />
                    </button>
                  </div>
                  <textarea
                    value={sectionContent[field.name] || ''}
                    onChange={(e) => setSectionContent(prev => ({
                      ...prev,
                      [field.name]: e.target.value
                    }))}
                    rows={6}
                    className="w-full p-3 border-0 rounded-b-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none focus:ring-0 focus:outline-none"
                    placeholder="Enter your content here..."
                  />
                </div>
              )}

              {field.type === 'select' && (
                <select
                  value={sectionContent[field.name] || ''}
                  onChange={(e) => setSectionContent(prev => ({
                    ...prev,
                    [field.name]: e.target.value
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  {field.options?.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              )}

              {field.type === 'image' && (
                <div>
                  <input
                    type="url"
                    value={sectionContent[field.name] || ''}
                    onChange={(e) => setSectionContent(prev => ({
                      ...prev,
                      [field.name]: e.target.value
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Enter image URL"
                  />
                  {sectionContent[field.name] && (
                    <div className="mt-2">
                      <img 
                        src={sectionContent[field.name]} 
                        alt="Preview" 
                        className="h-20 w-auto object-cover rounded"
                      />
                    </div>
                  )}
                </div>
              )}

              {field.type === 'number' && (
                <input
                  type="number"
                  value={sectionContent[field.name] || ''}
                  onChange={(e) => setSectionContent(prev => ({
                    ...prev,
                    [field.name]: parseInt(e.target.value) || 0
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  {...(field.validation || {})}
                />
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const SectionCard = ({ section }: { section: PageSection }) => {
    const template = sectionTemplates.find(t => t.type === section.sectionType);
    
    return (
      <div className="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            {template?.icon && (
              <div className="p-2 bg-amber-100 dark:bg-amber-900/20 rounded-lg">
                <Type className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              </div>
            )}
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white">{section.sectionName}</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">{section.sectionType}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-1">
            <button
              onClick={() => moveSection(section.id, 'up')}
              className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
            <button
              onClick={() => moveSection(section.id, 'down')}
              className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded"
            >
              <ArrowDown className="w-4 h-4" />
            </button>
            <button
              onClick={() => setEditingSection(section.id)}
              className="p-1 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded"
            >
              <Edit className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleDeleteSection(section.id)}
              className="p-1 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Section Preview */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded p-3 text-sm">
          {section.sectionType === 'hero' && (
            <div>
              <h5 className="font-medium text-gray-900 dark:text-white">{section.content.title}</h5>
              <p className="text-gray-600 dark:text-gray-400">{section.content.subtitle}</p>
            </div>
          )}
          {section.sectionType === 'text' && (
            <div>
              <h5 className="font-medium text-gray-900 dark:text-white">{section.content.title}</h5>
              <div className="text-gray-600 dark:text-gray-400" dangerouslySetInnerHTML={{ __html: section.content.content?.substring(0, 100) + '...' }} />
            </div>
          )}
          {section.sectionType === 'stats' && (
            <div>
              <h5 className="font-medium text-gray-900 dark:text-white">{section.content.title}</h5>
              <p className="text-gray-600 dark:text-gray-400">
                {section.content.stats?.length || 0} statistics
              </p>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'content':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Page Title
                </label>
                <input
                  type="text"
                  value={pageData.title}
                  onChange={(e) => setPageData(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  URL Slug
                </label>
                <input
                  type="text"
                  value={pageData.slug}
                  onChange={(e) => setPageData(prev => ({ ...prev, slug: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Page Excerpt
              </label>
              <textarea
                value={pageData.excerpt || ''}
                onChange={(e) => setPageData(prev => ({ ...prev, excerpt: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="Brief description of this page..."
              />
            </div>
          </div>
        );

      case 'sections':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Page Sections</h3>
              <button
                onClick={() => setShowSectionSelector(true)}
                className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add Section</span>
              </button>
            </div>

            {sectionsLoading ? (
              <div className="text-center py-8">
                <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-600 dark:text-gray-400">Loading sections...</p>
              </div>
            ) : (
              <div className="space-y-4">
                {sections.length === 0 ? (
                  <div className="text-center py-8 border border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                    <Layout className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No sections yet</h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      Start building your page by adding content sections.
                    </p>
                    <button
                      onClick={() => setShowSectionSelector(true)}
                      className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors"
                    >
                      Add First Section
                    </button>
                  </div>
                ) : (
                  sections
                    .sort((a, b) => a.sectionOrder - b.sectionOrder)
                    .map((section) => 
                      editingSection === section.id ? (
                        <SectionEditor key={section.id} section={section} />
                      ) : (
                        <SectionCard key={section.id} section={section} />
                      )
                    )
                )}
              </div>
            )}
          </div>
        );

      case 'seo':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Meta Title
                </label>
                <input
                  type="text"
                  value={pageData.metaTitle || ''}
                  onChange={(e) => setPageData(prev => ({ ...prev, metaTitle: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="SEO title for search engines"
                />
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                  {(pageData.metaTitle || '').length}/60 characters
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Meta Keywords
                </label>
                <input
                  type="text"
                  value={pageData.metaKeywords || ''}
                  onChange={(e) => setPageData(prev => ({ ...prev, metaKeywords: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="keyword1, keyword2, keyword3"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Meta Description
              </label>
              <textarea
                value={pageData.metaDescription || ''}
                onChange={(e) => setPageData(prev => ({ ...prev, metaDescription: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="Brief description for search results (150-160 characters)"
              />
              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                {(pageData.metaDescription || '').length}/160 characters
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Open Graph Title
                </label>
                <input
                  type="text"
                  value={pageData.ogTitle || ''}
                  onChange={(e) => setPageData(prev => ({ ...prev, ogTitle: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Title for social sharing"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Open Graph Image
                </label>
                <input
                  type="url"
                  value={pageData.ogImage || ''}
                  onChange={(e) => setPageData(prev => ({ ...prev, ogImage: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Image URL for social sharing"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Open Graph Description
              </label>
              <textarea
                value={pageData.ogDescription || ''}
                onChange={(e) => setPageData(prev => ({ ...prev, ogDescription: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="Description for social media sharing"
              />
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Template Type
                </label>
                <select
                  value={pageData.templateType}
                  onChange={(e) => setPageData(prev => ({ ...prev, templateType: e.target.value as Page['templateType'] }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="default">Default</option>
                  <option value="landing">Landing Page</option>
                  <option value="blog">Blog Post</option>
                  <option value="gallery">Gallery</option>
                  <option value="contact">Contact</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Status
                </label>
                <select
                  value={pageData.status}
                  onChange={(e) => setPageData(prev => ({ 
                    ...prev, 
                    status: e.target.value as Page['status'],
                    publishedAt: e.target.value === 'published' ? new Date() : prev.publishedAt
                  }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="archived">Archived</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Visibility
                </label>
                <select
                  value={pageData.visibility}
                  onChange={(e) => setPageData(prev => ({ ...prev, visibility: e.target.value as Page['visibility'] }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="public">Public</option>
                  <option value="authenticated">Authenticated Users Only</option>
                  {user?.role === 'superadmin' && <option value="admin_only">Admin Only</option>}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Navigation Order
                </label>
                <input
                  type="number"
                  value={pageData.navigationOrder}
                  onChange={(e) => setPageData(prev => ({ ...prev, navigationOrder: parseInt(e.target.value) || 0 }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Featured Image
              </label>
              <input
                type="url"
                value={pageData.featuredImage || ''}
                onChange={(e) => setPageData(prev => ({ ...prev, featuredImage: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="Featured image URL"
              />
            </div>

            <div className="flex items-center space-x-6">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={pageData.showInNavigation}
                  onChange={(e) => setPageData(prev => ({ ...prev, showInNavigation: e.target.checked }))}
                  className="text-amber-500 focus:ring-amber-500"
                />
                <span className="text-gray-900 dark:text-white">Show in navigation menu</span>
              </label>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={onCancel}
              className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                Edit Page: {pageData.title}
              </h2>
              <p className="text-gray-600 dark:text-gray-400">/{pageData.slug}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2">
              <Eye className="w-4 h-4" />
              <span>Preview</span>
            </button>
            <button
              onClick={handleSave}
              disabled={isLoading}
              className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              <span>{isLoading ? 'Saving...' : 'Save Page'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'content', label: 'Content', icon: Type },
              { id: 'sections', label: 'Sections', icon: Layout },
              { id: 'seo', label: 'SEO', icon: Globe },
              { id: 'settings', label: 'Settings', icon: Settings }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>

      {/* Section Selector Modal */}
      {showSectionSelector && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Add Section</h3>
                <button
                  onClick={() => setShowSectionSelector(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {sectionTemplates.map((template) => (
                  <button
                    key={template.type}
                    onClick={() => addSection(template)}
                    className="p-6 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors text-left group"
                  >
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="p-2 bg-amber-100 dark:bg-amber-900/20 rounded-lg group-hover:bg-amber-200 dark:group-hover:bg-amber-900/40 transition-colors">
                        <Layout className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                      </div>
                      <h4 className="font-medium text-gray-900 dark:text-white">{template.name}</h4>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{template.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PageEditor;