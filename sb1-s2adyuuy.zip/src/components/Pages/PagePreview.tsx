import React, { useState, useEffect } from 'react';
import { X, Edit, Monitor, Smartphone, Tablet, ExternalLink } from 'lucide-react';
import { Page, PageSection } from '../../types/pages';
import { usePageManagement } from '../../hooks/usePageManagement';
import SectionRenderer from './SectionRenderer';

interface PagePreviewProps {
  page: Page;
  onClose: () => void;
  onEdit?: () => void;
}

const PagePreview: React.FC<PagePreviewProps> = ({ page, onClose, onEdit }) => {
  const { fetchPageSections } = usePageManagement();
  const [sections, setSections] = useState<PageSection[]>([]);
  const [viewMode, setViewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSections();
  }, [page.id]);

  const loadSections = async () => {
    setIsLoading(true);
    const sectionsData = await fetchPageSections(page.id);
    setSections(sectionsData.filter((section: PageSection) => section.isVisible));
    setIsLoading(false);
  };

  const getViewportClasses = () => {
    switch (viewMode) {
      case 'mobile':
        return 'max-w-sm mx-auto';
      case 'tablet':
        return 'max-w-2xl mx-auto';
      default:
        return 'max-w-full';
    }
  };

  return (
    <div className="fixed inset-0 bg-white dark:bg-gray-900 z-50">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">{page.title}</h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">Preview Mode</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Viewport Toggles */}
            <div className="flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
              <button
                onClick={() => setViewMode('desktop')}
                className={`p-2 rounded transition-colors ${
                  viewMode === 'desktop' ? 'bg-white dark:bg-gray-600 shadow' : 'hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <Monitor className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('tablet')}
                className={`p-2 rounded transition-colors ${
                  viewMode === 'tablet' ? 'bg-white dark:bg-gray-600 shadow' : 'hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <Tablet className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('mobile')}
                className={`p-2 rounded transition-colors ${
                  viewMode === 'mobile' ? 'bg-white dark:bg-gray-600 shadow' : 'hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <Smartphone className="w-4 h-4" />
              </button>
            </div>

            <a
              href={`/${page.slug}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Open Live</span>
            </a>

            {onEdit && (
              <button
                onClick={onEdit}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors"
              >
                <Edit className="w-4 h-4" />
                <span>Edit Page</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Preview Content */}
      <div className="h-full overflow-y-auto bg-gray-100 dark:bg-gray-900">
        <div className={`transition-all duration-300 ${getViewportClasses()}`}>
          {isLoading ? (
            <div className="flex items-center justify-center min-h-screen">
              <div className="text-center">
                <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-600 dark:text-gray-400">Loading preview...</p>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 min-h-screen">
              {/* Page Header */}
              <div className="bg-gray-50 dark:bg-gray-700 p-4 border-b border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{page.title}</h1>
                  {page.excerpt && (
                    <p className="text-gray-600 dark:text-gray-400 mt-2">{page.excerpt}</p>
                  )}
                </div>
              </div>

              {/* Render Sections */}
              <div>
                {sections.length === 0 ? (
                  <div className="text-center py-20">
                    <div className="w-16 h-16 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Layout className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No content sections</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      This page doesn't have any content sections yet.
                    </p>
                    {onEdit && (
                      <button
                        onClick={onEdit}
                        className="mt-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors"
                      >
                        Add Sections
                      </button>
                    )}
                  </div>
                ) : (
                  sections
                    .sort((a, b) => a.sectionOrder - b.sectionOrder)
                    .map((section) => (
                      <SectionRenderer key={section.id} section={section} />
                    ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PagePreview;