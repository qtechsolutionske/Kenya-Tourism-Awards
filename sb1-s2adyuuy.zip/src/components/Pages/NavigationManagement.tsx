import React, { useState, useEffect } from 'react';
import { 
  Plus, Edit, Trash2, ArrowUp, ArrowDown, Eye, EyeOff,
  Save, X, Menu, ExternalLink, Globe, Link
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { NavigationItem } from '../../types/pages';

const NavigationManagement: React.FC = () => {
  const { user } = useAuth();
  const [navigationItems, setNavigationItems] = useState<NavigationItem[]>([]);
  const [editingItem, setEditingItem] = useState<string | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadNavigationItems();
  }, []);

  const loadNavigationItems = async () => {
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(
        `${supabaseUrl}/rest/v1/navigation_items?order=menu_location,order_position`,
        {
          headers: {
            'apikey': supabaseAnonKey,
            'Authorization': `Bearer ${supabaseAnonKey}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        // Convert snake_case to camelCase
        const items = data.map((item: any) => ({
          id: item.id,
          pageId: item.page_id,
          label: item.label,
          url: item.url,
          isExternal: item.is_external,
          targetBlank: item.target_blank,
          parentId: item.parent_id,
          menuLocation: item.menu_location,
          orderPosition: item.order_position,
          isVisible: item.is_visible,
          requiredRole: item.required_role,
          iconClass: item.icon_class,
          cssClasses: item.css_classes,
          createdBy: item.created_by,
          updatedBy: item.updated_by,
          createdAt: new Date(item.created_at),
          updatedAt: new Date(item.updated_at)
        }));
        setNavigationItems(items);
      }
    } catch (err) {
      console.error('Failed to load navigation items:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const updateNavigationItem = async (itemId: string, updates: Partial<NavigationItem>) => {
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      await fetch(`${supabaseUrl}/rest/v1/navigation_items?id=eq.${itemId}`, {
        method: 'PATCH',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          label: updates.label,
          url: updates.url,
          is_external: updates.isExternal,
          target_blank: updates.targetBlank,
          parent_id: updates.parentId,
          order_position: updates.orderPosition,
          is_visible: updates.isVisible,
          required_role: updates.requiredRole,
          icon_class: updates.iconClass,
          css_classes: updates.cssClasses,
          updated_by: user?.id
        })
      });

      // Update local state
      setNavigationItems(prev => prev.map(item => 
        item.id === itemId ? { ...item, ...updates } : item
      ));
    } catch (err) {
      console.error('Failed to update navigation item:', err);
    }
  };

  const moveItem = async (itemId: string, direction: 'up' | 'down') => {
    const item = navigationItems.find(i => i.id === itemId);
    if (!item) return;

    const siblingItems = navigationItems
      .filter(i => i.menuLocation === item.menuLocation && i.parentId === item.parentId)
      .sort((a, b) => a.orderPosition - b.orderPosition);

    const currentIndex = siblingItems.findIndex(i => i.id === itemId);
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;

    if (targetIndex >= 0 && targetIndex < siblingItems.length) {
      const targetItem = siblingItems[targetIndex];
      
      await updateNavigationItem(itemId, { orderPosition: targetItem.orderPosition });
      await updateNavigationItem(targetItem.id, { orderPosition: item.orderPosition });
    }
  };

  const toggleVisibility = async (itemId: string) => {
    const item = navigationItems.find(i => i.id === itemId);
    if (item) {
      await updateNavigationItem(itemId, { isVisible: !item.isVisible });
    }
  };

  // Check permissions
  const canManageNavigation = user && ['superadmin', 'admin', 'manager'].includes(user.role);
  
  if (!canManageNavigation) {
    return (
      <div className="p-6 text-center">
        <Menu className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Navigation management is only available to administrators and managers.
        </p>
      </div>
    );
  }

  const mainMenuItems = navigationItems.filter(item => item.menuLocation === 'main');

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Navigation Management</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Manage website navigation menus and structure
          </p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add Menu Item</span>
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Main Navigation</h3>
        
        {isLoading ? (
          <div className="text-center py-8">
            <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-400">Loading navigation...</p>
          </div>
        ) : (
          <div className="space-y-3">
            {mainMenuItems
              .sort((a, b) => a.orderPosition - b.orderPosition)
              .map((item) => (
                <div key={item.id} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => toggleVisibility(item.id)}
                        className={`p-1 rounded transition-colors ${
                          item.isVisible 
                            ? 'text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20' 
                            : 'text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                        }`}
                      >
                        {item.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      {item.isExternal && <ExternalLink className="w-4 h-4 text-blue-500" />}
                    </div>
                    
                    <div>
                      <div className="font-medium text-gray-900 dark:text-white">{item.label}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {item.url || (item.pageId ? 'Internal Page' : 'No URL')}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => moveItem(item.id, 'up')}
                      className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded"
                      disabled={item.orderPosition === 0}
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => moveItem(item.id, 'down')}
                      className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setEditingItem(item.id)}
                      className="p-1 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-1 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Create Form Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Add Navigation Item</h3>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Label *
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Menu item label"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Link Type
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <label className="flex items-center space-x-2 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                    <input type="radio" name="linkType" value="internal" defaultChecked className="text-amber-500" />
                    <Globe className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-white">Internal Page</span>
                  </label>
                  <label className="flex items-center space-x-2 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                    <input type="radio" name="linkType" value="external" className="text-amber-500" />
                    <ExternalLink className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-white">External URL</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button className="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors">
                  Add Menu Item
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NavigationManagement;