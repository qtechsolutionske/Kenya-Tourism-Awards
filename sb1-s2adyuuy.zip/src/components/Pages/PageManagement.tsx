import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Filter, Eye, Edit, Trash2, Copy, Globe, 
  FileText, Layout, Camera, Mail, Save, X, Calendar,
  Settings, BarChart3, Users, Award
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { usePageManagement } from '../../hooks/usePageManagement';
import { Page } from '../../types/pages';
import PageEditor from './PageEditor';
import PagePreview from './PagePreview';

const PageManagement: React.FC = () => {
  const { user } = useAuth();
  const { pages, isLoading, error, fetchPages, createPage, updatePage, deletePage } = usePageManagement();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [templateFilter, setTemplateFilter] = useState('all');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingPage, setEditingPage] = useState<Page | null>(null);
  const [previewPage, setPreviewPage] = useState<Page | null>(null);

  useEffect(() => {
    fetchPages();
  }, [fetchPages]);

  // Check permissions
  const canManagePages = user && ['superadmin', 'admin', 'manager'].includes(user.role);
  const isSuperAdmin = user?.role === 'superadmin';

  if (!canManagePages) {
    return (
      <div className="p-6 text-center">
        <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <FileText className="w-8 h-8 text-red-600 dark:text-red-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Page management is only available to administrators and managers.
        </p>
      </div>
    );
  }

  const filteredPages = pages.filter(page => {
    const matchesSearch = page.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         page.slug.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || page.status === statusFilter;
    const matchesTemplate = templateFilter === 'all' || page.templateType === templateFilter;
    return matchesSearch && matchesStatus && matchesTemplate;
  });

  const getStatusColor = (status: Page['status']) => {
    switch (status) {
      case 'published':
        return 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400';
      case 'draft':
        return 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-400';
      case 'archived':
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
      case 'scheduled':
        return 'bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
    }
  };

  const getTemplateIcon = (template: Page['templateType']) => {
    switch (template) {
      case 'landing':
        return <Layout className="w-4 h-4" />;
      case 'blog':
        return <FileText className="w-4 h-4" />;
      case 'gallery':
        return <Camera className="w-4 h-4" />;
      case 'contact':
        return <Mail className="w-4 h-4" />;
      default:
        return <Globe className="w-4 h-4" />;
    }
  };

  const handleCreatePage = async (formData: FormData) => {
    const pageData = Object.fromEntries(formData.entries());
    
    try {
      await createPage({
        title: pageData.title as string,
        slug: pageData.slug as string,
        templateType: pageData.templateType as Page['templateType'],
        status: pageData.status as Page['status'],
        visibility: pageData.visibility as Page['visibility'],
        metaTitle: pageData.metaTitle as string,
        metaDescription: pageData.metaDescription as string,
        metaKeywords: pageData.metaKeywords as string,
        featuredImage: pageData.featuredImage as string,
        excerpt: pageData.excerpt as string,
        isSystemPage: false,
        showInNavigation: pageData.showInNavigation === 'true',
        navigationOrder: parseInt(pageData.navigationOrder as string) || 0,
        createdBy: user!.id,
        publishedAt: pageData.status === 'published' ? new Date() : undefined,
        createdAt: new Date(),
        updatedAt: new Date()
      } as any);
      
      setShowCreateForm(false);
      fetchPages(); // Refresh the list
    } catch (err) {
      console.error('Failed to create page:', err);
    }
  };

  const handleDeletePage = async (page: Page) => {
    if (page.isSystemPage && !isSuperAdmin) {
      alert('System pages can only be deleted by Super Administrators');
      return;
    }

    if (window.confirm(`Are you sure you want to delete "${page.title}"? This action cannot be undone.`)) {
      try {
        await deletePage(page.id);
      } catch (err) {
        console.error('Failed to delete page:', err);
      }
    }
  };

  const duplicatePage = async (page: Page) => {
    try {
      const newTitle = `${page.title} (Copy)`;
      const newSlug = `${page.slug}-copy-${Date.now()}`;
      
      await createPage({
        ...page,
        title: newTitle,
        slug: newSlug,
        status: 'draft',
        isSystemPage: false,
        publishedAt: undefined,
        createdBy: user!.id,
        createdAt: new Date(),
        updatedAt: new Date()
      } as any);
      
      fetchPages();
    } catch (err) {
      console.error('Failed to duplicate page:', err);
    }
  };

  if (editingPage) {
    return (
      <PageEditor
        page={editingPage}
        onSave={async (pageUpdates, sections) => {
          await updatePage(editingPage.id, { ...pageUpdates, updatedBy: user!.id });
          setEditingPage(null);
          fetchPages();
        }}
        onCancel={() => setEditingPage(null)}
        isLoading={isLoading}
      />
    );
  }

  if (previewPage) {
    return (
      <PagePreview 
        page={previewPage}
        onClose={() => setPreviewPage(null)}
        onEdit={() => {
          setPreviewPage(null);
          setEditingPage(previewPage);
        }}
      />
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Page Management</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Create, edit, and manage all website pages and content sections
          </p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Create Page</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Pages</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{pages.length}</p>
            </div>
            <Globe className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Published</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {pages.filter(p => p.status === 'published').length}
              </p>
            </div>
            <Eye className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Drafts</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {pages.filter(p => p.status === 'draft').length}
              </p>
            </div>
            <Edit className="w-8 h-8 text-yellow-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">System Pages</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {pages.filter(p => p.isSystemPage).length}
              </p>
            </div>
            <Settings className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search pages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">All Status</option>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
                <option value="scheduled">Scheduled</option>
                <option value="archived">Archived</option>
              </select>
            </div>
            <select
              value={templateFilter}
              onChange={(e) => setTemplateFilter(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Templates</option>
              <option value="default">Default</option>
              <option value="landing">Landing Page</option>
              <option value="blog">Blog</option>
              <option value="gallery">Gallery</option>
              <option value="contact">Contact</option>
            </select>
          </div>
        </div>
      </div>

      {/* Pages Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-400">Loading pages...</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Page</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Template</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Status</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Visibility</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Updated</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredPages.map((page) => (
                  <tr key={page.id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        {page.featuredImage && (
                          <img 
                            src={page.featuredImage} 
                            alt=""
                            className="w-12 h-8 object-cover rounded"
                          />
                        )}
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium text-gray-900 dark:text-white">{page.title}</h3>
                            {page.isSystemPage && (
                              <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 text-xs rounded-full">
                                System
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">/{page.slug}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        {getTemplateIcon(page.templateType)}
                        <span className="text-sm text-gray-900 dark:text-white capitalize">
                          {page.templateType}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(page.status)}`}>
                        {page.status.charAt(0).toUpperCase() + page.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-sm text-gray-900 dark:text-white capitalize">
                        {page.visibility}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {page.updatedAt.toLocaleDateString()}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setPreviewPage(page)}
                          className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                          title="Preview page"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setEditingPage(page)}
                          className="p-2 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                          title="Edit page"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => duplicatePage(page)}
                          className="p-2 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 rounded-lg transition-colors"
                          title="Duplicate page"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        {(!page.isSystemPage || isSuperAdmin) && (
                          <button
                            onClick={() => handleDeletePage(page)}
                            className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                            title="Delete page"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {filteredPages.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No pages found</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {searchTerm || statusFilter !== 'all' || templateFilter !== 'all'
                ? 'Try adjusting your search or filter criteria.'
                : 'Get started by creating your first page.'
              }
            </p>
            <button
              onClick={() => setShowCreateForm(true)}
              className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors"
            >
              Create First Page
            </button>
          </div>
        )}
      </div>

      {/* Create Page Form */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Create New Page</h3>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <form 
              onSubmit={(e) => {
                e.preventDefault();
                handleCreatePage(new FormData(e.currentTarget));
              }}
              className="p-6 space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Page Title *
                  </label>
                  <input
                    name="title"
                    type="text"
                    required
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Enter page title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    URL Slug *
                  </label>
                  <input
                    name="slug"
                    type="text"
                    required
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="page-url-slug"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Template Type
                  </label>
                  <select
                    name="templateType"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="default">Default Page</option>
                    <option value="landing">Landing Page</option>
                    <option value="blog">Blog Post</option>
                    <option value="gallery">Gallery</option>
                    <option value="contact">Contact Page</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Status
                  </label>
                  <select
                    name="status"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="draft">Draft</option>
                    <option value="published">Published</option>
                    <option value="scheduled">Scheduled</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Visibility
                  </label>
                  <select
                    name="visibility"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="public">Public</option>
                    <option value="authenticated">Authenticated Only</option>
                    {isSuperAdmin && <option value="admin_only">Admin Only</option>}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Navigation Order
                  </label>
                  <input
                    name="navigationOrder"
                    type="number"
                    min="0"
                    defaultValue="0"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Meta Description
                </label>
                <textarea
                  name="metaDescription"
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Brief description for search engines (150-160 characters)"
                />
              </div>

              <div className="flex items-center space-x-3">
                <input
                  name="showInNavigation"
                  type="checkbox"
                  defaultChecked
                  value="true"
                  className="text-amber-500 focus:ring-amber-500"
                />
                <label className="text-sm text-gray-700 dark:text-gray-300">
                  Show in navigation menu
                </label>
              </div>

              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  <span>{isLoading ? 'Creating...' : 'Create Page'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
          <p className="text-red-700 dark:text-red-400">{error}</p>
        </div>
      )}
    </div>
  );
};

export default PageManagement;