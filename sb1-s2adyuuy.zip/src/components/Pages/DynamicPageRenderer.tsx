import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Page, PageSection } from '../../types/pages';
import { usePageManagement } from '../../hooks/usePageManagement';
import SectionRenderer from './SectionRenderer';
import { AlertCircle } from 'lucide-react';

const DynamicPageRenderer: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { fetchPageSections } = usePageManagement();
  const [page, setPage] = useState<Page | null>(null);
  const [sections, setSections] = useState<PageSection[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadPage();
  }, [slug]);

  const loadPage = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Fetch page by slug
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const pageResponse = await fetch(
        `${supabaseUrl}/rest/v1/pages?slug=eq.${slug}&status=eq.published&select=*`,
        {
          headers: {
            'apikey': supabaseAnonKey,
            'Authorization': `Bearer ${supabaseAnonKey}`
          }
        }
      );

      if (!pageResponse.ok) {
        throw new Error('Page not found');
      }

      const pageData = await pageResponse.json();
      
      if (pageData.length === 0) {
        throw new Error('Page not found');
      }

      const pageInfo = pageData[0];
      
      // Convert snake_case to camelCase
      const page: Page = {
        id: pageInfo.id,
        title: pageInfo.title,
        slug: pageInfo.slug,
        templateType: pageInfo.template_type,
        status: pageInfo.status,
        visibility: pageInfo.visibility,
        metaTitle: pageInfo.meta_title,
        metaDescription: pageInfo.meta_description,
        metaKeywords: pageInfo.meta_keywords,
        ogTitle: pageInfo.og_title,
        ogDescription: pageInfo.og_description,
        ogImage: pageInfo.og_image,
        featuredImage: pageInfo.featured_image,
        excerpt: pageInfo.excerpt,
        isSystemPage: pageInfo.is_system_page,
        showInNavigation: pageInfo.show_in_navigation,
        navigationParentId: pageInfo.navigation_parent_id,
        navigationOrder: pageInfo.navigation_order,
        publishedAt: pageInfo.published_at ? new Date(pageInfo.published_at) : undefined,
        createdBy: pageInfo.created_by,
        updatedBy: pageInfo.updated_by,
        createdAt: new Date(pageInfo.created_at),
        updatedAt: new Date(pageInfo.updated_at)
      };

      setPage(page);

      // Fetch page sections
      const sectionsData = await fetchPageSections(page.id);
      setSections(sectionsData.filter((section: PageSection) => section.isVisible));

      // Update page title and meta tags
      document.title = page.metaTitle || page.title;
      
      if (page.metaDescription) {
        let metaDesc = document.querySelector('meta[name="description"]');
        if (!metaDesc) {
          metaDesc = document.createElement('meta');
          metaDesc.setAttribute('name', 'description');
          document.head.appendChild(metaDesc);
        }
        metaDesc.setAttribute('content', page.metaDescription);
      }

      if (page.ogImage) {
        let ogImageMeta = document.querySelector('meta[property="og:image"]');
        if (!ogImageMeta) {
          ogImageMeta = document.createElement('meta');
          ogImageMeta.setAttribute('property', 'og:image');
          document.head.appendChild(ogImageMeta);
        }
        ogImageMeta.setAttribute('content', page.ogImage);
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load page');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading page...</p>
        </div>
      </div>
    );
  }

  if (error || !page) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Page Not Found</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            {error || 'The page you are looking for does not exist or has been moved.'}
          </p>
          <a
            href="/"
            className="inline-block bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors"
          >
            Go Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      {/* Render page sections */}
      {sections.length === 0 ? (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              {page.title}
            </h1>
            {page.excerpt && (
              <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                {page.excerpt}
              </p>
            )}
          </div>
        </div>
      ) : (
        sections
          .sort((a, b) => a.sectionOrder - b.sectionOrder)
          .map((section) => (
            <SectionRenderer key={section.id} section={section} />
          ))
      )}
    </div>
  );
};

export default DynamicPageRenderer;