import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, Settings, Calendar, Clock, Users, 
  FileText, Trophy, CheckCircle, AlertTriangle,
  Edit, Save, X, Eye, BarChart3, Target, Zap,
  Lock, Unlock, ArrowRight, Download, Upload
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useEntries } from '../../hooks/useEntries';
import { ProcessState } from '../../types/entries';

const EntriesSystemManager: React.FC = () => {
  const { user } = useAuth();
  const { 
    processState, 
    fetchProcessState, 
    updateProcessState,
    submissions,
    fetchSubmissions,
    formDefinitions,
    fetchFormDefinitions
  } = useEntries();
  
  const [editingStage, setEditingStage] = useState(false);
  const [stageForm, setStageForm] = useState({
    stage: '',
    startDate: '',
    endDate: '',
    autoTransition: false,
    delayHours: 0
  });

  useEffect(() => {
    fetchProcessState();
    fetchSubmissions();
    fetchFormDefinitions();
  }, []);

  // Check if user has permission
  if (user?.role !== 'superadmin' && user?.role !== 'admin') {
    return (
      <div className="p-6 text-center">
        <Lock className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Entry system management is only available to super administrators and administrators.
        </p>
      </div>
    );
  }

  const stageConfigurations = [
    {
      id: 'setup',
      name: 'System Setup',
      description: 'Configure forms, categories, and system settings',
      icon: Settings,
      color: 'gray',
      features: ['Form creation', 'Category setup', 'User management'],
      nextStage: 'entries_open'
    },
    {
      id: 'entries_open',
      name: 'Entries Open',
      description: 'Accept entry submissions from participants',
      icon: FileText,
      color: 'green',
      features: ['Public submission forms', 'File uploads', 'Email notifications'],
      nextStage: 'entries_closed'
    },
    {
      id: 'entries_closed',
      name: 'Entries Closed',
      description: 'Entry submission period has ended',
      icon: Lock,
      color: 'orange',
      features: ['Submission review', 'Data validation', 'Initial screening'],
      nextStage: 'jury_vetting'
    },
    {
      id: 'jury_vetting',
      name: 'Jury Vetting',
      description: 'Expert jury reviews and scores submissions',
      icon: Users,
      color: 'blue',
      features: ['Jury portal access', 'Scoring system', 'Review management'],
      nextStage: 'vetting_closed'
    },
    {
      id: 'vetting_closed',
      name: 'Vetting Complete',
      description: 'Jury evaluation completed, shortlist finalized',
      icon: CheckCircle,
      color: 'purple',
      features: ['Shortlist generation', 'Results preparation', 'Notification system'],
      nextStage: 'voting_open'
    },
    {
      id: 'voting_open',
      name: 'Public Voting',
      description: 'Public votes for shortlisted entries',
      icon: Trophy,
      color: 'teal',
      features: ['Voting portal', 'Real-time counting', 'Fraud prevention'],
      nextStage: 'voting_closed'
    },
    {
      id: 'voting_closed',
      name: 'Voting Closed',
      description: 'Voting period ended, results being calculated',
      icon: Clock,
      color: 'indigo',
      features: ['Final calculations', 'Result verification', 'Winner determination'],
      nextStage: 'results_announced'
    },
    {
      id: 'results_announced',
      name: 'Results Announced',
      description: 'Winners announced, awards ceremony preparation',
      icon: Trophy,
      color: 'amber',
      features: ['Winner notifications', 'Certificate generation', 'Gala preparation']
    }
  ];

  const getCurrentStageIndex = () => {
    return stageConfigurations.findIndex(s => s.id === processState?.currentStage);
  };

  const handleStageTransition = async (newStage: string) => {
    try {
      await updateProcessState({
        currentStage: newStage as ProcessState['currentStage'],
        stageStart: new Date(),
        updatedBy: user?.id
      });
      
      fetchProcessState();
    } catch (error) {
      console.error('Failed to transition stage:', error);
    }
  };

  const handleScheduleTransition = async () => {
    if (!stageForm.stage || !stageForm.startDate) return;

    try {
      const autoTransition = {
        ...processState?.autoTransition,
        [`${processState?.currentStage}_to_${stageForm.stage}`]: {
          enabled: stageForm.autoTransition,
          scheduled_time: stageForm.startDate,
          delay_hours: stageForm.delayHours
        }
      };

      await updateProcessState({
        autoTransition,
        stageEnd: stageForm.endDate ? new Date(stageForm.endDate) : undefined,
        updatedBy: user?.id
      });

      setEditingStage(false);
      fetchProcessState();
    } catch (error) {
      console.error('Failed to schedule transition:', error);
    }
  };

  const exportSubmissions = async () => {
    // Implement CSV export
    const csvData = submissions.map(sub => ({
      'Nominee Name': sub.nomineeName,
      'Category': sub.category,
      'Status': sub.status,
      'Contact Email': sub.contactEmail,
      'Contact Phone': sub.contactPhone,
      'County': sub.county,
      'Submitted Date': sub.createdAt.toISOString(),
      'Jury Score': sub.juryScore || 'N/A',
      'Public Votes': sub.publicVotes
    }));

    const csv = [
      Object.keys(csvData[0] || {}).join(','),
      ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kta-submissions-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const currentStageIndex = getCurrentStageIndex();
  const currentStageConfig = stageConfigurations[currentStageIndex];

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Entries System Manager</h2>
            <p className="text-blue-100 text-lg">
              Control entry submission stages and process automation
            </p>
          </div>
          <div className="hidden md:block">
            <Settings className="w-24 h-24 text-blue-200" />
          </div>
        </div>
      </div>

      {/* Current Stage Status */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Current Stage Status</h3>
          {processState?.stageStart && (
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Started: {processState.stageStart.toLocaleString()}
            </div>
          )}
        </div>

        {currentStageConfig && (
          <div className={`bg-${currentStageConfig.color}-50 dark:bg-${currentStageConfig.color}-900/20 border border-${currentStageConfig.color}-200 dark:border-${currentStageConfig.color}-800 rounded-xl p-6`}>
            <div className="flex items-center space-x-4 mb-4">
              <div className={`p-4 bg-${currentStageConfig.color}-100 dark:bg-${currentStageConfig.color}-900/30 rounded-xl`}>
                <currentStageConfig.icon className={`w-8 h-8 text-${currentStageConfig.color}-600 dark:text-${currentStageConfig.color}-400`} />
              </div>
              <div className="flex-1">
                <h4 className={`text-xl font-bold text-${currentStageConfig.color}-900 dark:text-${currentStageConfig.color}-400`}>
                  {currentStageConfig.name}
                </h4>
                <p className={`text-${currentStageConfig.color}-700 dark:text-${currentStageConfig.color}-500`}>
                  {currentStageConfig.description}
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setEditingStage(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                >
                  <Edit className="w-4 h-4" />
                  <span>Manage</span>
                </button>
                {currentStageConfig.nextStage && (
                  <button
                    onClick={() => handleStageTransition(currentStageConfig.nextStage!)}
                    className={`bg-${currentStageConfig.color}-600 text-white px-4 py-2 rounded-lg hover:bg-${currentStageConfig.color}-700 transition-colors flex items-center space-x-2`}
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>Advance</span>
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <h5 className={`font-medium text-${currentStageConfig.color}-900 dark:text-${currentStageConfig.color}-400`}>
                Active Features:
              </h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {currentStageConfig.features.map((feature, index) => (
                  <div key={index} className={`flex items-center space-x-2 text-${currentStageConfig.color}-700 dark:text-${currentStageConfig.color}-500`}>
                    <CheckCircle className="w-4 h-4" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* System Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Entries</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{submissions.length}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Published Forms</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {formDefinitions.filter(f => f.published).length}
              </p>
            </div>
            <Eye className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Pending Review</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {submissions.filter(s => s.status === 'pending').length}
              </p>
            </div>
            <Clock className="w-8 h-8 text-amber-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Shortlisted</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {submissions.filter(s => s.status === 'shortlisted').length}
              </p>
            </div>
            <Trophy className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Stage Flow Visualization */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Process Flow</h3>
          <div className="flex items-center space-x-4">
            <button
              onClick={exportSubmissions}
              className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2"
            >
              <Download className="w-4 h-4" />
              <span>Export Data</span>
            </button>
            <button
              onClick={() => setEditingStage(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <Settings className="w-4 h-4" />
              <span>Configure</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stageConfigurations.map((stage, index) => {
            const Icon = stage.icon;
            const isCurrentStage = processState?.currentStage === stage.id;
            const isPastStage = currentStageIndex > index;
            const isFutureStage = !isCurrentStage && !isPastStage;
            
            return (
              <div key={stage.id} className="relative">
                <div className={`border-2 rounded-xl p-6 transition-all cursor-pointer hover:shadow-md ${
                  isCurrentStage 
                    ? `border-${stage.color}-500 bg-${stage.color}-50 dark:bg-${stage.color}-900/20` 
                    : isPastStage
                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                    : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700'
                }`}>
                  <div className="text-center mb-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${
                      isCurrentStage 
                        ? `bg-${stage.color}-500 text-white`
                        : isPastStage
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-300 dark:bg-gray-600 text-gray-600 dark:text-gray-400'
                    }`}>
                      {isPastStage ? (
                        <CheckCircle className="w-6 h-6" />
                      ) : (
                        <Icon className="w-6 h-6" />
                      )}
                    </div>
                    
                    <h4 className={`font-semibold mb-2 ${
                      isCurrentStage 
                        ? `text-${stage.color}-900 dark:text-${stage.color}-400`
                        : isPastStage
                        ? 'text-green-900 dark:text-green-400'
                        : 'text-gray-600 dark:text-gray-400'
                    }`}>
                      {stage.name}
                    </h4>
                    <p className={`text-sm ${
                      isCurrentStage 
                        ? `text-${stage.color}-700 dark:text-${stage.color}-500`
                        : isPastStage
                        ? 'text-green-700 dark:text-green-500'
                        : 'text-gray-500 dark:text-gray-500'
                    }`}>
                      {stage.description}
                    </p>
                  </div>

                  {/* Stage Actions */}
                  {isCurrentStage && (
                    <div className="space-y-2">
                      {stage.nextStage && (
                        <button
                          onClick={() => handleStageTransition(stage.nextStage!)}
                          className={`w-full bg-${stage.color}-600 text-white py-2 px-3 rounded-lg hover:bg-${stage.color}-700 transition-colors text-sm font-medium flex items-center justify-center space-x-2`}
                        >
                          <Play className="w-4 h-4" />
                          <span>Advance</span>
                        </button>
                      )}
                    </div>
                  )}
                  
                  {/* Emergency Controls for Superadmin */}
                  {user?.role === 'superadmin' && (
                    <div className="pt-2 border-t border-gray-200 dark:border-gray-600">
                      <button
                        onClick={() => {
                          if (window.confirm('Are you sure you want to reset to setup stage? This will affect all users.')) {
                            handleStageTransition('setup');
                          }
                        }}
                        className="w-full bg-red-600 text-white py-1 px-3 rounded text-xs font-medium hover:bg-red-700 transition-colors"
                      >
                        Emergency Reset
                      </button>
                    </div>
                  )}

                  {/* Stage Features */}
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                    <div className="space-y-1">
                      {stage.features.slice(0, 2).map((feature, idx) => (
                        <div key={idx} className="flex items-center space-x-2 text-xs">
                          <CheckCircle className={`w-3 h-3 ${
                            isCurrentStage ? `text-${stage.color}-600 dark:text-${stage.color}-400` : 'text-gray-400'
                          }`} />
                          <span className={`${
                            isCurrentStage ? `text-${stage.color}-700 dark:text-${stage.color}-500` : 'text-gray-500 dark:text-gray-500'
                          }`}>
                            {feature}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Arrow to next stage */}
                {index < stageConfigurations.length - 1 && (
                  <div className="hidden lg:block absolute -right-2 top-1/2 transform -translate-y-1/2">
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Stage Configuration Modal */}
      {editingStage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                  Configure Stage Transition
                </h3>
                <button
                  onClick={() => setEditingStage(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Target Stage
                </label>
                <select
                  value={stageForm.stage}
                  onChange={(e) => setStageForm(prev => ({ ...prev, stage: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="">Select target stage</option>
                  {stageConfigurations
                    .slice(currentStageIndex + 1)
                    .map(stage => (
                      <option key={stage.id} value={stage.id}>
                        {stage.name}
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Start Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={stageForm.startDate}
                    onChange={(e) => setStageForm(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    min={new Date().toISOString().slice(0, 16)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    End Date & Time (Optional)
                  </label>
                  <input
                    type="datetime-local"
                    value={stageForm.endDate}
                    onChange={(e) => setStageForm(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    min={stageForm.startDate}
                  />
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={stageForm.autoTransition}
                    onChange={(e) => setStageForm(prev => ({ ...prev, autoTransition: e.target.checked }))}
                    className="text-blue-500 focus:ring-blue-500"
                  />
                  <span className="text-gray-900 dark:text-white">Enable automatic transition</span>
                </label>
                
                {stageForm.autoTransition && (
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      value={stageForm.delayHours}
                      onChange={(e) => setStageForm(prev => ({ ...prev, delayHours: parseInt(e.target.value) || 0 }))}
                      className="w-20 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      min="0"
                      placeholder="0"
                    />
                    <span className="text-sm text-gray-600 dark:text-gray-400">hours after end</span>
                  </div>
                )}
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 dark:text-blue-400 mb-2">Transition Effects</h4>
                <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
                  <li>• All users will receive stage transition notifications</li>
                  <li>• System permissions and access will be updated</li>
                  <li>• Entry forms will be enabled/disabled accordingly</li>
                  <li>• Email campaigns will be triggered automatically</li>
                  <li>• Public CTAs will reflect the new stage status</li>
                </ul>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setEditingStage(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleScheduleTransition}
                  disabled={!stageForm.stage || !stageForm.startDate}
                  className="flex-1 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Configuration</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Warning */}
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-6">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-6 h-6 text-amber-600 dark:text-amber-400 mt-1" />
          <div>
            <h4 className="font-medium text-amber-900 dark:text-amber-400 mb-2">Important Notice</h4>
            <div className="text-sm text-amber-800 dark:text-amber-500 space-y-2">
              <p>
                Changing system stages affects the entire platform. Make sure you understand the implications:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Entry submissions will be enabled/disabled based on the current stage</li>
                <li>Jury portal access is controlled by vetting stages</li>
                <li>Public voting is only available during the voting stage</li>
                <li>All users receive automated stage transition notifications</li>
                <li>Site-wide CTAs automatically reflect the current stage status</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EntriesSystemManager;