import React, { useState } from 'react';
import { 
  Save, Upload, X, Eye, EyeOff, Palette, Type, Image, Settings, 
  Monitor, Smartphone, Tablet, RotateCcw, Download, Copy, 
  Zap, Star, Trophy, Award, Play, Pause, Volume2, VolumeX, Plus
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface BrandSettings {
  primaryLogo: string;
  secondaryLogo: string;
  favicon: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    success: string;
    warning: string;
    error: string;
    neutral: string;
  };
  fonts: {
    primary: string;
    secondary: string;
    size: {
      base: number;
      scale: number;
    };
  };
  preloader: {
    enabled: boolean;
    type: 'logo' | 'video';
    logoUrl: string;
    videoUrl: string;
    videoPoster: string;
    duration: number;
    effects: {
      sparkles: boolean;
      pulse: boolean;
      rotation: boolean;
      particles: boolean;
    };
    text: {
      title: string;
      subtitle: string;
      loadingText: string;
    };
  };
  ticker: {
    enabled: boolean;
    speed: number;
    messages: Array<{
      id: string;
      text: string;
      icon: string;
      isActive: boolean;
    }>;
  };
}

const defaultSettings: BrandSettings = {
  primaryLogo: '/Kenya Tourism Awards Gold Logo.svg',
  secondaryLogo: '/Kenya Tourism Awards Black Logo.svg',
  favicon: '/vite.svg',
  colors: {
    primary: '#f59e0b',
    secondary: '#ea580c',
    accent: '#dc2626',
    success: '#10b981',
    warning: '#f59e0b',
    error: '#ef4444',
    neutral: '#6b7280'
  },
  fonts: {
    primary: 'Inter',
    secondary: 'Poppins',
    size: {
      base: 16,
      scale: 1.125
    }
  },
  preloader: {
    enabled: true,
    type: 'logo',
    logoUrl: '/Kenya Tourism Awards Gold Logo.svg',
    videoUrl: '',
    videoPoster: '',
    duration: 3000,
    effects: {
      sparkles: true,
      pulse: true,
      rotation: false,
      particles: true
    },
    text: {
      title: 'Kenya Tourism Awards',
      subtitle: 'Celebrating Excellence in Tourism',
      loadingText: 'Loading...'
    }
  },
  ticker: {
    enabled: true,
    speed: 60,
    messages: [
      { id: '1', text: 'Voting closes in 7 days - Cast your votes now!', icon: 'Star', isActive: true },
      { id: '2', text: 'Gala Night: March 15, 2025 at KICC Nairobi', icon: 'Calendar', isActive: true },
      { id: '3', text: '247 nominations received across 28 categories', icon: 'Award', isActive: true },
      { id: '4', text: 'Join 12,000+ voters in celebrating excellence', icon: 'Trophy', isActive: true }
    ]
  }
};

const BrandingSettings: React.FC = () => {
  const { user } = useAuth();
  const [settings, setSettings] = useState<BrandSettings>(defaultSettings);
  const [activeTab, setActiveTab] = useState<'logos' | 'colors' | 'fonts' | 'preloader' | 'ticker'>('logos');
  const [previewMode, setPreviewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [showPreview, setShowPreview] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Check if user is superadmin
  const canManageBranding = user?.role === 'superadmin' || user?.role === 'admin';
  const hasFullAccess = user?.role === 'superadmin';
  
  if (!canManageBranding) {
    return (
      <div className="p-6 text-center">
        <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Settings className="w-8 h-8 text-red-600 dark:text-red-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Branding settings are available to super administrators and administrators.
          {!hasFullAccess && (
            <>
              <br />
              <span className="text-amber-600 dark:text-amber-400 text-sm">
                Note: Limited access - some advanced features require superadmin.
              </span>
            </>
          )}
        </p>
      </div>
    );
  }

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API save
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Apply settings to the application
    document.documentElement.style.setProperty('--color-primary', settings.colors.primary);
    document.documentElement.style.setProperty('--color-secondary', settings.colors.secondary);
    document.documentElement.style.setProperty('--color-accent', settings.colors.accent);
    
    // Update favicon
    const favicon = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
    if (favicon) {
      favicon.href = settings.favicon;
    }
    
    setIsSaving(false);
  };

  const handleColorChange = (colorKey: keyof BrandSettings['colors'], value: string) => {
    setSettings(prev => ({
      ...prev,
      colors: {
        ...prev.colors,
        [colorKey]: value
      }
    }));
  };

  const handlePreloaderChange = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      preloader: {
        ...prev.preloader,
        [key]: value
      }
    }));
  };

  const addTickerMessage = () => {
    setSettings(prev => ({
      ...prev,
      ticker: {
        ...prev.ticker,
        messages: [
          ...prev.ticker.messages,
          { id: Date.now().toString(), text: '', icon: 'Star', isActive: true }
        ]
      }
    }));
  };

  const removeTickerMessage = (messageId: string) => {
    setSettings(prev => ({
      ...prev,
      ticker: {
        ...prev.ticker,
        messages: prev.ticker.messages.filter(msg => msg.id !== messageId)
      }
    }));
  };

  const updateTickerMessage = (messageId: string, field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      ticker: {
        ...prev.ticker,
        messages: prev.ticker.messages.map(msg => 
          msg.id === messageId ? { ...msg, [field]: value } : msg
        )
      }
    }));
  };

  const PreviewModal = () => (
    showPreview && (
      <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-7xl w-full max-h-[90vh] overflow-hidden">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Brand Preview</h3>
              <div className="flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                <button
                  onClick={() => setPreviewMode('desktop')}
                  className={`p-2 rounded transition-colors ${previewMode === 'desktop' ? 'bg-white dark:bg-gray-600 shadow' : ''}`}
                >
                  <Monitor className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setPreviewMode('tablet')}
                  className={`p-2 rounded transition-colors ${previewMode === 'tablet' ? 'bg-white dark:bg-gray-600 shadow' : ''}`}
                >
                  <Tablet className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setPreviewMode('mobile')}
                  className={`p-2 rounded transition-colors ${previewMode === 'mobile' ? 'bg-white dark:bg-gray-600 shadow' : ''}`}
                >
                  <Smartphone className="w-4 h-4" />
                </button>
              </div>
            </div>
            <button
              onClick={() => setShowPreview(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X className="w-6 h-6" />
            </button>
            {!hasFullAccess && (
              <div className="text-xs text-amber-600 dark:text-amber-400">
                Some settings require superadmin access
              </div>
            )}
          </div>
          <div className="p-6 overflow-y-auto">
            <div className={`mx-auto transition-all ${
              previewMode === 'mobile' ? 'max-w-sm' : 
              previewMode === 'tablet' ? 'max-w-2xl' : 
              'max-w-full'
            }`}>
              {/* Preview content would go here */}
              <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-8 text-center">
                <p className="text-gray-600 dark:text-gray-400">
                  Live preview would be displayed here with your brand settings applied
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'logos':
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Primary Logo */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900 dark:text-white">Primary Logo</h4>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center hover:border-amber-500 transition-colors">
                  {settings.primaryLogo ? (
                    <div className="space-y-4">
                      <img
                        src={settings.primaryLogo}
                        alt="Primary Logo"
                        className="h-16 w-auto mx-auto"
                      />
                      <button
                        onClick={() => setSettings(prev => ({ ...prev, primaryLogo: '' }))}
                        className="text-red-600 dark:text-red-400 text-sm hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">Upload Primary Logo</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">SVG, PNG (Recommended: 200px height)</p>
                    </>
                  )}
                  <input type="file" accept="image/*,.svg" className="hidden" />
                </div>
              </div>

              {/* Secondary Logo */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900 dark:text-white">Secondary Logo (Dark Mode)</h4>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center hover:border-amber-500 transition-colors">
                  {settings.secondaryLogo ? (
                    <div className="space-y-4">
                      <div className="bg-gray-900 rounded-lg p-4">
                        <img
                          src={settings.secondaryLogo}
                          alt="Secondary Logo"
                          className="h-16 w-auto mx-auto filter brightness-0 invert"
                        />
                      </div>
                      <button
                        onClick={() => setSettings(prev => ({ ...prev, secondaryLogo: '' }))}
                        className="text-red-600 dark:text-red-400 text-sm hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">Upload Secondary Logo</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">For dark backgrounds</p>
                    </>
                  )}
                  <input type="file" accept="image/*,.svg" className="hidden" />
                </div>
              </div>

              {/* Favicon */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900 dark:text-white">Favicon</h4>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center hover:border-amber-500 transition-colors">
                  {settings.favicon ? (
                    <div className="space-y-4">
                      <img
                        src={settings.favicon}
                        alt="Favicon"
                        className="h-8 w-8 mx-auto"
                      />
                      <button
                        onClick={() => setSettings(prev => ({ ...prev, favicon: '' }))}
                        className="text-red-600 dark:text-red-400 text-sm hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">Upload Favicon</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">ICO, PNG (32x32px)</p>
                    </>
                  )}
                  <input type="file" accept=".ico,.png" className="hidden" />
                </div>
              </div>
            </div>
          </div>
        );

      case 'colors':
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Color Palette */}
              <div className="space-y-6">
                <h4 className="font-medium text-gray-900 dark:text-white">Brand Colors</h4>
                {Object.entries(settings.colors).map(([colorKey, colorValue]) => (
                  <div key={colorKey} className="flex items-center space-x-4">
                    <div className="w-20 text-sm font-medium text-gray-700 dark:text-gray-300 capitalize">
                      {colorKey}
                    </div>
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-12 h-12 rounded-lg border border-gray-300 dark:border-gray-600 cursor-pointer"
                        style={{ backgroundColor: colorValue }}
                        onClick={() => document.getElementById(`color-${colorKey}`)?.click()}
                      />
                      <input
                        id={`color-${colorKey}`}
                        type="color"
                        value={colorValue}
                        onChange={(e) => handleColorChange(colorKey as keyof BrandSettings['colors'], e.target.value)}
                        className="w-0 h-0 opacity-0"
                      />
                      <input
                        type="text"
                        value={colorValue}
                        onChange={(e) => handleColorChange(colorKey as keyof BrandSettings['colors'], e.target.value)}
                        className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-mono text-sm"
                      />
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(colorValue);
                        }}
                        className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                      >
                        readOnly={!hasFullAccess}
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Color Preview */}
              <div className="space-y-6">
                <h4 className="font-medium text-gray-900 dark:text-white">Color Preview</h4>
                <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-6 space-y-4">
                  <div 
                    className="w-full h-16 rounded-lg flex items-center justify-center text-white font-bold"
                    style={{ background: `linear-gradient(135deg, ${settings.colors.primary}, ${settings.colors.secondary})` }}
                  >
                    Primary Gradient
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {Object.entries(settings.colors).slice(0, 6).map(([key, color]) => (
                      <div key={key} className="text-center">
                        <div 
                          className="w-full h-12 rounded-lg mb-2"
                          style={{ backgroundColor: color }}
                        />
                        <p className="text-xs text-gray-600 dark:text-gray-400 capitalize">{key}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'fonts':
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <h4 className="font-medium text-gray-900 dark:text-white">Typography Settings</h4>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Primary Font
                  </label>
                  <select
                    value={settings.fonts.primary}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      fonts: { ...prev.fonts, primary: e.target.value }
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="Inter">Inter (Recommended)</option>
                    <option value="Poppins">Poppins</option>
                    <option value="Roboto">Roboto</option>
                    <option value="Open Sans">Open Sans</option>
                    <option value="Lato">Lato</option>
                    <option value="Montserrat">Montserrat</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Secondary Font
                  </label>
                  <select
                    value={settings.fonts.secondary}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      fonts: { ...prev.fonts, secondary: e.target.value }
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="Poppins">Poppins (Recommended)</option>
                    <option value="Inter">Inter</option>
                    <option value="Playfair Display">Playfair Display</option>
                    <option value="Merriweather">Merriweather</option>
                    <option value="Source Serif Pro">Source Serif Pro</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Base Font Size (px)
                    </label>
                    <input
                      type="number"
                      value={settings.fonts.size.base}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        fonts: { 
                          ...prev.fonts, 
                          size: { ...prev.fonts.size, base: parseInt(e.target.value) }
                        }
                      }))}
                      min="12"
                      max="20"
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Type Scale
                    </label>
                    <input
                      type="number"
                      value={settings.fonts.size.scale}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        fonts: { 
                          ...prev.fonts, 
                          size: { ...prev.fonts.size, scale: parseFloat(e.target.value) }
                        }
                      }))}
                      min="1.1"
                      max="1.5"
                      step="0.025"
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h4 className="font-medium text-gray-900 dark:text-white">Typography Preview</h4>
                <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-6 space-y-4">
                  <div style={{ fontFamily: settings.fonts.primary }}>
                    <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                      Heading 1 - {settings.fonts.primary}
                    </h1>
                    <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-2">
                      Heading 2 - Primary Font
                    </h2>
                    <p className="text-gray-600 dark:text-gray-400">
                      Body text using the primary font family. This is how your content will appear.
                    </p>
                  </div>
                  <div style={{ fontFamily: settings.fonts.secondary }} className="pt-4 border-t border-gray-200 dark:border-gray-600">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      Secondary Font - {settings.fonts.secondary}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      This font is used for special headings and accent text.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'preloader':
        return (
          <div className="space-y-8">
            {/* Preloader Settings */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-gray-900 dark:text-white">Preloader Configuration</h4>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={settings.preloader.enabled}
                      onChange={(e) => handlePreloaderChange('enabled', e.target.checked)}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-sm text-gray-700 dark:text-gray-300">Enable Preloader</span>
                  </label>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Preloader Type
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <label className="flex items-center space-x-2 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                      <input
                        type="radio"
                        name="preloaderType"
                        value="logo"
                        checked={settings.preloader.type === 'logo'}
                        onChange={(e) => handlePreloaderChange('type', e.target.value)}
                        className="text-amber-500"
                      />
                      <Image className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      <span className="text-sm text-gray-900 dark:text-white">Logo</span>
                    </label>
                    <label className="flex items-center space-x-2 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                      <input
                        type="radio"
                        name="preloaderType"
                        value="video"
                        checked={settings.preloader.type === 'video'}
                        onChange={(e) => handlePreloaderChange('type', e.target.value)}
                        className="text-amber-500"
                      />
                      <Play className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      <span className="text-sm text-gray-900 dark:text-white">Video</span>
                    </label>
                  </div>
                </div>

                {settings.preloader.type === 'video' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Video URL
                      </label>
                      <input
                        type="url"
                        value={settings.preloader.videoUrl}
                        onChange={(e) => handlePreloaderChange('videoUrl', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        placeholder="https://example.com/video.mp4"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Video Poster Image
                      </label>
                      <input
                        type="url"
                        value={settings.preloader.videoPoster}
                        onChange={(e) => handlePreloaderChange('videoPoster', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        placeholder="https://example.com/poster.jpg"
                      />
                    </div>
                  </>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Duration (milliseconds)
                  </label>
                  <input
                    type="number"
                    value={settings.preloader.duration}
                    onChange={(e) => handlePreloaderChange('duration', parseInt(e.target.value))}
                    min="1000"
                    max="10000"
                    step="500"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>

                {/* Text Settings */}
                <div className="space-y-4">
                  <h5 className="font-medium text-gray-900 dark:text-white">Text Content</h5>
                  <input
                    type="text"
                    value={settings.preloader.text.title}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      preloader: {
                        ...prev.preloader,
                        text: { ...prev.preloader.text, title: e.target.value }
                      }
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Main title"
                  />
                  <input
                    type="text"
                    value={settings.preloader.text.subtitle}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      preloader: {
                        ...prev.preloader,
                        text: { ...prev.preloader.text, subtitle: e.target.value }
                      }
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Subtitle"
                  />
                  <input
                    type="text"
                    value={settings.preloader.text.loadingText}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      preloader: {
                        ...prev.preloader,
                        text: { ...prev.preloader.text, loadingText: e.target.value }
                      }
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Loading text"
                  />
                </div>
              </div>

              <div className="space-y-6">
                <h4 className="font-medium text-gray-900 dark:text-white">Visual Effects</h4>
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(settings.preloader.effects).map(([effectKey, isEnabled]) => (
                    <label key={effectKey} className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                      <input
                        type="checkbox"
                        checked={isEnabled as boolean}
                        onChange={(e) => setSettings(prev => ({
                          ...prev,
                          preloader: {
                            ...prev.preloader,
                            effects: {
                              ...prev.preloader.effects,
                              [effectKey]: e.target.checked
                            }
                          }
                        }))}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                      <span className="text-sm text-gray-900 dark:text-white capitalize">
                        {effectKey}
                      </span>
                      {effectKey === 'sparkles' && <Star className="w-4 h-4 text-amber-500" />}
                      {effectKey === 'pulse' && <Zap className="w-4 h-4 text-blue-500" />}
                      {effectKey === 'rotation' && <RotateCcw className="w-4 h-4 text-purple-500" />}
                      {effectKey === 'particles' && <Trophy className="w-4 h-4 text-green-500" />}
                    </label>
                  ))}
                </div>
                
                {/* Preview Button */}
                <button 
                  onClick={() => setShowPreview(true)}
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white py-3 px-4 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center justify-center space-x-2"
                >
                  <Play className="w-4 h-4" />
                  <span>Preview Preloader</span>
                </button>
              </div>
            </div>
          </div>
        );

      case 'ticker':
        return (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-gray-900 dark:text-white">Ticker Configuration</h4>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={settings.ticker.enabled}
                  onChange={(e) => setSettings(prev => ({
                    ...prev,
                    ticker: { ...prev.ticker, enabled: e.target.checked }
                  }))}
                  className="text-amber-500 focus:ring-amber-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">Enable Ticker</span>
              </label>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Animation Speed (seconds for full cycle)
              </label>
              <input
                type="number"
                value={settings.ticker.speed}
                onChange={(e) => setSettings(prev => ({
                  ...prev,
                  ticker: { ...prev.ticker, speed: parseInt(e.target.value) }
                }))}
                min="30"
                max="120"
                step="5"
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <h5 className="font-medium text-gray-900 dark:text-white">Ticker Messages</h5>
                <button
                  onClick={addTickerMessage}
                  className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Message</span>
                </button>
              </div>
              
              <div className="space-y-4">
                {settings.ticker.messages.map((message) => (
                  <div key={message.id} className="flex items-center space-x-3 p-4 border border-gray-300 dark:border-gray-600 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={message.isActive}
                        onChange={(e) => updateTickerMessage(message.id, 'isActive', e.target.checked)}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                      {message.isActive ? <Eye className="w-4 h-4 text-green-500" /> : <EyeOff className="w-4 h-4 text-gray-400" />}
                    </div>
                    
                    <select
                      value={message.icon}
                      onChange={(e) => updateTickerMessage(message.id, 'icon', e.target.value)}
                      className="border border-gray-300 dark:border-gray-600 rounded px-3 py-2 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    >
                      <option value="Star">Star</option>
                      <option value="Calendar">Calendar</option>
                      <option value="Award">Award</option>
                      <option value="Trophy">Trophy</option>
                      <option value="Bell">Bell</option>
                      <option value="Zap">Zap</option>
                    </select>
                    
                    <input
                      type="text"
                      value={message.text}
                      onChange={(e) => updateTickerMessage(message.id, 'text', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Enter ticker message..."
                    />
                    
                    <button
                      onClick={() => removeTickerMessage(message.id)}
                      className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Branding Settings</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Customize logos, colors, fonts, and visual elements across the platform
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setShowPreview(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Eye className="w-4 h-4" />
            <span>Preview</span>
          </button>
          
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSaving ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'logos', label: 'Logos & Assets', icon: Image },
              { id: 'colors', label: 'Color Palette', icon: Palette },
              { id: 'fonts', label: 'Typography', icon: Type },
              { id: 'preloader', label: 'Preloader', icon: Zap },
              { id: 'ticker', label: 'Ticker', icon: Settings }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-8">
          {renderTabContent()}
        </div>
      </div>

      <PreviewModal />
    </div>
  );
};

export default BrandingSettings;