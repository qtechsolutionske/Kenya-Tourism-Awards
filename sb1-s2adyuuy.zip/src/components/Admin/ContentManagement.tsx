import React, { useState } from 'react';
import { Edit, Save, X, Plus, Trash2, Image, Type, Link, Video, FileText, Globe, Palette, Layout, Settings, Eye, Users, BarChart3, Mail } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface ContentBlock {
  id: string;
  type: 'text' | 'image' | 'video' | 'link' | 'hero' | 'stats';
  page: string;
  section: string;
  content: any;
  order: number;
  isActive: boolean;
}

const ContentManagement: React.FC = () => {
  const { user } = useAuth();
  const [selectedPage, setSelectedPage] = useState('homepage');
  const [editingBlock, setEditingBlock] = useState<string | null>(null);
  const [showAddBlock, setShowAddBlock] = useState(false);

  // Mock content blocks
  const [contentBlocks, setContentBlocks] = useState<ContentBlock[]>([
    {
      id: '1',
      type: 'hero',
      page: 'homepage',
      section: 'hero',
      content: {
        title: 'Kenya Tourism Awards 2025',
        subtitle: 'Celebrating excellence, innovation, and sustainability in Kenya\'s tourism industry',
        backgroundImage: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg',
        ctaText: 'Vote Now',
        ctaLink: '/voting'
      },
      order: 1,
      isActive: true
    },
    {
      id: '2',
      type: 'stats',
      page: 'homepage',
      section: 'statistics',
      content: {
        stats: [
          { number: '28', label: 'Award Categories', icon: 'Award' },
          { number: '247', label: 'Nominations', icon: 'Star' },
          { number: '12K+', label: 'Votes Cast', icon: 'Trophy' },
          { number: '1.8K', label: 'Participants', icon: 'Users' }
        ]
      },
      order: 2,
      isActive: true
    },
    {
      id: '3',
      type: 'text',
      page: 'about',
      section: 'mission',
      content: {
        title: 'Our Mission',
        text: 'To recognize, celebrate, and promote excellence in Kenya\'s tourism sector while fostering sustainable practices that benefit local communities, preserve our natural heritage, and enhance visitor experiences.'
      },
      order: 1,
      isActive: true
    }
  ]);

  const pages = [
    { id: 'homepage', name: 'Homepage', icon: Globe },
    { id: 'about', name: 'About Page', icon: FileText },
    { id: 'nominees', name: 'Nominees Page', icon: Users },
    { id: 'contact', name: 'Contact Page', icon: Mail }
  ];

  const blockTypes = [
    { type: 'text', name: 'Text Block', icon: Type, description: 'Add headings, paragraphs, and formatted text' },
    { type: 'image', name: 'Image Block', icon: Image, description: 'Add single images with captions' },
    { type: 'video', name: 'Video Block', icon: Video, description: 'Embed videos from YouTube, Vimeo, or upload' },
    { type: 'hero', name: 'Hero Section', icon: Layout, description: 'Large banner with background image and CTA' },
    { type: 'stats', name: 'Statistics', icon: BarChart3, description: 'Display numerical data with icons' },
    { type: 'link', name: 'Link Block', icon: Link, description: 'Create buttons or text links' }
  ];

  const filteredBlocks = contentBlocks.filter(block => block.page === selectedPage);

  const handleSaveBlock = (blockId: string, newContent: any) => {
    setContentBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? { ...block, content: newContent }
        : block
    ));
    setEditingBlock(null);
  };

  const handleDeleteBlock = (blockId: string) => {
    if (window.confirm('Are you sure you want to delete this content block?')) {
      setContentBlocks(prev => prev.filter(block => block.id !== blockId));
    }
  };

  const handleAddBlock = (type: string, section: string) => {
    const newBlock: ContentBlock = {
      id: Date.now().toString(),
      type: type as any,
      page: selectedPage,
      section,
      content: getDefaultContent(type),
      order: filteredBlocks.length + 1,
      isActive: true
    };
    setContentBlocks(prev => [...prev, newBlock]);
    setShowAddBlock(false);
  };

  const getDefaultContent = (type: string) => {
    switch (type) {
      case 'text':
        return { title: 'New Title', text: 'Enter your content here...' };
      case 'image':
        return { src: '', alt: '', caption: '' };
      case 'video':
        return { url: '', title: '', description: '' };
      case 'hero':
        return { title: 'Hero Title', subtitle: 'Hero subtitle', backgroundImage: '', ctaText: 'Call to Action', ctaLink: '#' };
      case 'stats':
        return { stats: [{ number: '0', label: 'New Stat', icon: 'Award' }] };
      default:
        return {};
    }
  };

  const renderBlockEditor = (block: ContentBlock) => {
    if (editingBlock !== block.id) {
      return (
        <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-medium text-gray-900 dark:text-white capitalize">
                {block.type} Block
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{block.section}</p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setEditingBlock(block.id)}
                className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDeleteBlock(block.id)}
                className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {/* Block Preview */}
          <div className="bg-gray-50 dark:bg-gray-800 rounded p-3 text-sm">
            {block.type === 'text' && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">{block.content.title}</h4>
                <p className="text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">{block.content.text}</p>
              </div>
            )}
            {block.type === 'hero' && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">{block.content.title}</h4>
                <p className="text-gray-600 dark:text-gray-400 text-xs">{block.content.subtitle}</p>
              </div>
            )}
            {block.type === 'stats' && (
              <div className="grid grid-cols-2 gap-2">
                {block.content.stats.slice(0, 4).map((stat: any, idx: number) => (
                  <div key={idx} className="text-center">
                    <div className="text-lg font-bold text-gray-900 dark:text-white">{stat.number}</div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">{stat.label}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      );
    }

    // Edit mode
    return (
      <div className="p-4 border-2 border-blue-500 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900 dark:text-white">
            Editing {block.type} Block
          </h3>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleSaveBlock(block.id, block.content)}
              className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
            >
              <Save className="w-4 h-4" />
            </button>
            <button
              onClick={() => setEditingBlock(null)}
              className="px-3 py-1 bg-gray-600 text-white text-sm rounded hover:bg-gray-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {block.type === 'text' && (
          <div className="space-y-4">
            <input
              type="text"
              value={block.content.title}
              onChange={(e) => setContentBlocks(prev => prev.map(b => 
                b.id === block.id 
                  ? { ...b, content: { ...b.content, title: e.target.value } }
                  : b
              ))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Title"
            />
            <textarea
              value={block.content.text}
              onChange={(e) => setContentBlocks(prev => prev.map(b => 
                b.id === block.id 
                  ? { ...b, content: { ...b.content, text: e.target.value } }
                  : b
              ))}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Content text"
            />
          </div>
        )}

        {block.type === 'hero' && (
          <div className="space-y-4">
            <input
              type="text"
              value={block.content.title}
              onChange={(e) => setContentBlocks(prev => prev.map(b => 
                b.id === block.id 
                  ? { ...b, content: { ...b.content, title: e.target.value } }
                  : b
              ))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Hero title"
            />
            <input
              type="text"
              value={block.content.subtitle}
              onChange={(e) => setContentBlocks(prev => prev.map(b => 
                b.id === block.id 
                  ? { ...b, content: { ...b.content, subtitle: e.target.value } }
                  : b
              ))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Hero subtitle"
            />
            <input
              type="url"
              value={block.content.backgroundImage}
              onChange={(e) => setContentBlocks(prev => prev.map(b => 
                b.id === block.id 
                  ? { ...b, content: { ...b.content, backgroundImage: e.target.value } }
                  : b
              ))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Background image URL"
            />
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                value={block.content.ctaText}
                onChange={(e) => setContentBlocks(prev => prev.map(b => 
                  b.id === block.id 
                    ? { ...b, content: { ...b.content, ctaText: e.target.value } }
                    : b
                ))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="CTA text"
              />
              <input
                type="text"
                value={block.content.ctaLink}
                onChange={(e) => setContentBlocks(prev => prev.map(b => 
                  b.id === block.id 
                    ? { ...b, content: { ...b.content, ctaLink: e.target.value } }
                    : b
                ))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="CTA link"
              />
            </div>
          </div>
        )}

        {block.type === 'stats' && (
          <div className="space-y-4">
            {block.content.stats.map((stat: any, index: number) => (
              <div key={index} className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  value={stat.number}
                  onChange={(e) => {
                    const newStats = [...block.content.stats];
                    newStats[index] = { ...stat, number: e.target.value };
                    setContentBlocks(prev => prev.map(b => 
                      b.id === block.id 
                        ? { ...b, content: { ...b.content, stats: newStats } }
                        : b
                    ));
                  }}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                  placeholder="Number"
                />
                <input
                  type="text"
                  value={stat.label}
                  onChange={(e) => {
                    const newStats = [...block.content.stats];
                    newStats[index] = { ...stat, label: e.target.value };
                    setContentBlocks(prev => prev.map(b => 
                      b.id === block.id 
                        ? { ...b, content: { ...b.content, stats: newStats } }
                        : b
                    ));
                  }}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                  placeholder="Label"
                />
                <select
                  value={stat.icon}
                  onChange={(e) => {
                    const newStats = [...block.content.stats];
                    newStats[index] = { ...stat, icon: e.target.value };
                    setContentBlocks(prev => prev.map(b => 
                      b.id === block.id 
                        ? { ...b, content: { ...b.content, stats: newStats } }
                        : b
                    ));
                  }}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                >
                  <option value="Award">Award</option>
                  <option value="Star">Star</option>
                  <option value="Trophy">Trophy</option>
                  <option value="Users">Users</option>
                </select>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  // Check if user has super admin access
  if (user?.role !== 'superadmin') {
    return (
      <div className="p-6 text-center">
        <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Settings className="w-8 h-8 text-red-600 dark:text-red-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Content management is only available to super administrators.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Content Management</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Edit and manage all front-end content across the website
          </p>
        </div>
        <button
          onClick={() => setShowAddBlock(true)}
          className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add Content Block</span>
        </button>
      </div>

      {/* Page Selection */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Select Page to Edit</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {pages.map((page) => {
            const Icon = page.icon;
            return (
              <button
                key={page.id}
                onClick={() => setSelectedPage(page.id)}
                className={`p-4 rounded-lg border-2 transition-colors flex flex-col items-center space-y-2 ${
                  selectedPage === page.id
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-900/20'
                    : 'border-gray-300 dark:border-gray-600 hover:border-amber-300'
                }`}
              >
                <Icon className={`w-8 h-8 ${
                  selectedPage === page.id 
                    ? 'text-amber-600 dark:text-amber-400' 
                    : 'text-gray-600 dark:text-gray-400'
                }`} />
                <span className={`font-medium ${
                  selectedPage === page.id
                    ? 'text-amber-900 dark:text-amber-400'
                    : 'text-gray-900 dark:text-white'
                }`}>
                  {page.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content Blocks */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Content Blocks - {pages.find(p => p.id === selectedPage)?.name}
          </h3>
          <button className="flex items-center space-x-2 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
            <Eye className="w-4 h-4" />
            <span>Preview Page</span>
          </button>
        </div>

        <div className="space-y-4">
          {filteredBlocks.length === 0 ? (
            <div className="text-center py-12">
              <Layout className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No content blocks</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Start by adding content blocks to this page.
              </p>
              <button
                onClick={() => setShowAddBlock(true)}
                className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors"
              >
                Add First Block
              </button>
            </div>
          ) : (
            filteredBlocks
              .sort((a, b) => a.order - b.order)
              .map((block) => (
                <div key={block.id}>
                  {renderBlockEditor(block)}
                </div>
              ))
          )}
        </div>
      </div>

      {/* Add Block Modal */}
      {showAddBlock && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Add Content Block</h3>
                <button
                  onClick={() => setShowAddBlock(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {blockTypes.map((blockType) => {
                  const Icon = blockType.icon;
                  return (
                    <button
                      key={blockType.type}
                      onClick={() => handleAddBlock(blockType.type, 'main')}
                      className="p-6 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-amber-500 transition-colors text-left"
                    >
                      <div className="flex items-center space-x-3 mb-3">
                        <Icon className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                        <h4 className="font-medium text-gray-900 dark:text-white">{blockType.name}</h4>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{blockType.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ContentManagement;