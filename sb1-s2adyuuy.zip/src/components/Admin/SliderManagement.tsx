import React from 'react';
import SliderManagement from '../Slider/SliderManagement';

const AdminSliderManagement: React.FC = () => {
  return <SliderManagement />;
};

export default AdminSliderManagement;