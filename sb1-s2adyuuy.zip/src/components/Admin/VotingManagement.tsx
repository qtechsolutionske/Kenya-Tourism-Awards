import React, { useState, useEffect } from 'react';
import { 
  Settings, Play, Pause, DollarSign, Heart, Shield, Users, 
  Mail, Clock, BarChart3, AlertTriangle, CheckCircle, 
  Save, Edit, Eye, Download, RefreshCw, Target, Zap,
  CreditCard, Smartphone, Globe, Lock, Unlock, Star
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useVoting, useVotingAnalytics } from '../../hooks/useVoting';
import { VotingSettings } from '../../types/voting';

const VotingManagement: React.FC = () => {
  const { user } = useAuth();
  const { 
    fetchVotingSettings, 
    updateVotingSettings, 
    getVotingAnalytics,
    isLoading, 
    error 
  } = useVoting();
  const { analytics, fetchAnalytics } = useVotingAnalytics();
  
  const [settings, setSettings] = useState<VotingSettings | null>(null);
  const [editingSettings, setEditingSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'settings' | 'security' | 'analytics'>('overview');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadSettings();
    fetchAnalytics();
  }, []);

  const loadSettings = async () => {
    const votingSettings = await fetchVotingSettings();
    setSettings(votingSettings);
  };

  // Check permissions
  const canManageVoting = user?.role === 'superadmin' || user?.role === 'admin';
  const hasFullAccess = user?.role === 'superadmin';
  
  if (!canManageVoting) {
    return (
      <div className="p-6 text-center">
        <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Voting system management is available to super administrators and administrators.
          {user?.role === 'admin' && !hasFullAccess && (
            <>
              <br />
              <span className="text-amber-600 dark:text-amber-400 text-sm">
                Note: You have monitoring and basic configuration access. Critical settings require superadmin.
              </span>
            </>
          )}
        </p>
      </div>
    );
  }

  const handleSaveSettings = async () => {
    if (!settings) return;
    
    setIsSaving(true);
    const success = await updateVotingSettings(settings);
    if (success) {
      setEditingSettings(false);
    }
    setIsSaving(false);
  };

  const toggleVoting = async () => {
    if (!settings) return;
    
    const updated = await updateVotingSettings({
      isVotingOpen: !settings.isVotingOpen
    });
    
    if (updated) {
      setSettings(prev => prev ? { ...prev, isVotingOpen: !prev.isVotingOpen } : null);
    }
  };

  const switchVotingMode = async (mode: 'free' | 'paid') => {
    if (!settings) return;
    
    const updated = await updateVotingSettings({ votingMode: mode });
    
    if (updated) {
      setSettings(prev => prev ? { ...prev, votingMode: mode } : null);
    }
  };

  const renderTabContent = () => {
    if (!settings) return null;

    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Voting Status Control */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Voting Control</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Current status: {settings.isVotingOpen ? 'Open' : 'Closed'}
                  </p>
                </div>
                {/* Only allow voting state changes for superadmin, admins can view only */}
                {hasFullAccess ? (
                  <button
                    onClick={toggleVoting}
                    className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-colors ${
                      settings.isVotingOpen
                        ? 'bg-red-600 text-white hover:bg-red-700'
                        : 'bg-green-600 text-white hover:bg-green-700'
                    }`}
                  >
                    {settings.isVotingOpen ? (
                      <>
                        <Pause className="w-4 h-4" />
                        <span>Close Voting</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" />
                        <span>Open Voting</span>
                      </>
                    )}
                  </button>
                ) : (
                  <div className="bg-gray-100 dark:bg-gray-600 px-6 py-3 rounded-lg">
                    <span className="text-gray-600 dark:text-gray-400 text-sm">
                      Voting controls require superadmin access
                    </span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Voting Mode Toggle */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 dark:text-white">Voting Mode</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => hasFullAccess && switchVotingMode('free')}
                      disabled={!hasFullAccess}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        settings.votingMode === 'free'
                          ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                          : hasFullAccess 
                          ? 'border-gray-300 dark:border-gray-600 hover:border-green-300'
                          : 'border-gray-300 dark:border-gray-600 opacity-50 cursor-not-allowed'
                      } ${!hasFullAccess ? 'cursor-not-allowed' : ''}`}
                    >
                      <Heart className={`w-8 h-8 mx-auto mb-2 ${
                        settings.votingMode === 'free' ? 'text-green-600' : 'text-gray-400'
                      }`} />
                      <div className="text-center">
                        <h5 className={`font-semibold ${
                          settings.votingMode === 'free' ? 'text-green-900 dark:text-green-400' : 'text-gray-700 dark:text-gray-300'
                        }`}>
                          Free Voting
                        </h5>
                        <p className="text-xs text-gray-600 dark:text-gray-400">No charge per vote</p>
                      </div>
                    </button>

                    <button
                      onClick={() => hasFullAccess && switchVotingMode('paid')}
                      disabled={!hasFullAccess}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        settings.votingMode === 'paid'
                          ? 'border-amber-500 bg-amber-50 dark:bg-amber-900/20'
                          : hasFullAccess
                          ? 'border-gray-300 dark:border-gray-600 hover:border-amber-300'
                          : 'border-gray-300 dark:border-gray-600 opacity-50 cursor-not-allowed'
                      } ${!hasFullAccess ? 'cursor-not-allowed' : ''}`}
                    >
                      <DollarSign className={`w-8 h-8 mx-auto mb-2 ${
                        settings.votingMode === 'paid' ? 'text-amber-600' : 'text-gray-400'
                      }`} />
                      <div className="text-center">
                        <h5 className={`font-semibold ${
                          settings.votingMode === 'paid' ? 'text-amber-900 dark:text-amber-400' : 'text-gray-700 dark:text-gray-300'
                        }`}>
                          Paid Voting
                        </h5>
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                          KSh {settings.feePerVote} per vote
                        </p>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 dark:text-white">Current Session Stats</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                      <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                        {analytics?.totalVotes || 0}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Total Votes</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                      <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {analytics?.uniqueVoters || 0}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Unique Voters</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                      <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                        KSh {analytics?.totalRevenue || 0}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Revenue</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                      <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                        {analytics?.fraudAttempts || 0}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Fraud Attempts</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bundle Pricing for Paid Mode */}
            {settings.votingMode === 'paid' && (
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Vote Bundle Pricing</h3>
                  <button
                    onClick={() => setEditingSettings(!editingSettings)}
                    className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {Object.entries(settings.bundleOptions).map(([bundleId, bundle]) => (
                    <div key={bundleId} className="border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4 text-center">
                      {editingSettings ? (
                        <div className="space-y-2">
                          <input
                            type="text"
                            value={bundle.label}
                            onChange={(e) => setSettings(prev => prev ? {
                              ...prev,
                              bundleOptions: {
                                ...prev.bundleOptions,
                                [bundleId]: { ...bundle, label: e.target.value }
                              }
                            } : prev)}
                            className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          />
                          <input
                            type="number"
                            value={bundle.votes}
                            onChange={(e) => setSettings(prev => prev ? {
                              ...prev,
                              bundleOptions: {
                                ...prev.bundleOptions,
                                [bundleId]: { ...bundle, votes: parseInt(e.target.value) }
                              }
                            } : prev)}
                            className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          />
                          <input
                            type="number"
                            value={bundle.price}
                            onChange={(e) => setSettings(prev => prev ? {
                              ...prev,
                              bundleOptions: {
                                ...prev.bundleOptions,
                                [bundleId]: { ...bundle, price: parseFloat(e.target.value) }
                              }
                            } : prev)}
                            className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          />
                        </div>
                      ) : (
                        <>
                          <h4 className="font-bold text-amber-900 dark:text-amber-400">{bundle.label}</h4>
                          <div className="text-2xl font-bold text-amber-600 dark:text-amber-400 my-2">
                            KSh {bundle.price}
                          </div>
                          <p className="text-sm text-amber-700 dark:text-amber-500">
                            {bundle.votes} vote{bundle.votes > 1 ? 's' : ''}
                          </p>
                          {bundle.savings && (
                            <div className="text-xs text-green-600 dark:text-green-400 mt-1">
                              Save KSh {bundle.savings}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  ))}
                </div>
                
                {editingSettings && (
                  <div className="flex justify-end space-x-4 mt-4">
                    <button
                      onClick={() => setEditingSettings(false)}
                      className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveSettings}
                      disabled={isSaving}
                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors flex items-center space-x-2"
                    >
                      {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                      <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-6">
            {/* Basic Settings */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Basic Settings</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Fee Per Vote (KSh)
                  </label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <input
                      type="number"
                      value={settings.feePerVote}
                      onChange={(e) => setSettings(prev => prev ? { ...prev, feePerVote: parseFloat(e.target.value) } : null)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      min="0"
                      step="0.50"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Max Votes Per Email Per Day
                  </label>
                  <input
                    type="number"
                    value={settings.maxVotesPerEmailPerDay}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, maxVotesPerEmailPerDay: parseInt(e.target.value) } : null)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    min="1"
                    max="50"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Max Votes Per IP Per Day
                  </label>
                  <input
                    type="number"
                    value={settings.maxVotesPerIpPerDay}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, maxVotesPerIpPerDay: parseInt(e.target.value) } : null)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    min="1"
                    max="100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Voting Deadline
                  </label>
                  <input
                    type="datetime-local"
                    value={settings.votingDeadline?.toISOString().slice(0, 16) || ''}
                    onChange={(e) => setSettings(prev => prev ? { 
                      ...prev, 
                      votingDeadline: e.target.value ? new Date(e.target.value) : undefined 
                    } : null)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <input
                    type="checkbox"
                    checked={settings.allowNomineeVoting}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, allowNomineeVoting: e.target.checked } : null)}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">Allow Nominee Voting</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Let nominees vote for themselves or others</div>
                  </div>
                </label>

                <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <input
                    type="checkbox"
                    checked={settings.requireEmailVerification}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, requireEmailVerification: e.target.checked } : null)}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">Require Email Verification</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Verify voter email addresses</div>
                  </div>
                </label>

                <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <input
                    type="checkbox"
                    checked={settings.enableCaptcha}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, enableCaptcha: e.target.checked } : null)}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">Enable CAPTCHA</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Prevent bot voting</div>
                  </div>
                </label>

                <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <input
                    type="checkbox"
                    checked={settings.emailConfirmationEnabled}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, emailConfirmationEnabled: e.target.checked } : null)}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">Email Confirmations</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Send vote confirmation emails</div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        );

      case 'security':
        return (
          <div className="space-y-6">
            {/* Fraud Detection */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Fraud Detection & Prevention</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Fraud Detection Threshold
                  </label>
                  <input
                    type="number"
                    value={settings.fraudThresholdScore}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, fraudThresholdScore: parseInt(e.target.value) } : null)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    min="1"
                    max="100"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                    Score above which votes are flagged as suspicious (1-100)
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Rate Limit Window (minutes)
                  </label>
                  <input
                    type="number"
                    value={settings.rateLimitWindowMinutes}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, rateLimitWindowMinutes: parseInt(e.target.value) } : null)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    min="5"
                    max="1440"
                  />
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Blocked Email Domains
                </label>
                <textarea
                  value={settings.blockedEmailDomains.join('\n')}
                  onChange={(e) => setSettings(prev => prev ? { 
                    ...prev, 
                    blockedEmailDomains: e.target.value.split('\n').filter(d => d.trim())
                  } : null)}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  rows={3}
                  placeholder="mailinator.com&#10;10minutemail.com&#10;temp-mail.org"
                />
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                  One domain per line. These domains will be blocked from voting.
                </p>
              </div>

              <div className="mt-6 space-y-4">
                <label className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={settings.fraudDetectionEnabled}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, fraudDetectionEnabled: e.target.checked } : null)}
                    className="text-red-500 focus:ring-red-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">Enable Fraud Detection</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Automatically detect and block suspicious voting patterns</div>
                  </div>
                </label>

                <label className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={settings.auditLoggingEnabled}
                    onChange={(e) => setSettings(prev => prev ? { ...prev, auditLoggingEnabled: e.target.checked } : null)}
                    className="text-blue-500 focus:ring-blue-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">Audit Logging</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Log all voting activities for transparency</div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        );

      case 'analytics':
        return (
          <div className="space-y-6">
            {/* Analytics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600 text-center">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                  {analytics?.totalVotes || 0}
                </div>
                <p className="text-gray-600 dark:text-gray-400">Total Votes</p>
                <p className="text-sm text-green-600 dark:text-green-400">
                  {analytics ? `${analytics.paidVotes} paid, ${analytics.freeVotes} free` : ''}
                </p>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600 text-center">
                <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                  KSh {analytics?.totalRevenue.toLocaleString() || 0}
                </div>
                <p className="text-gray-600 dark:text-gray-400">Revenue Generated</p>
                <p className="text-sm text-blue-600 dark:text-blue-400">
                  {analytics?.conversionRate.toFixed(1)}% conversion rate
                </p>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600 text-center">
                <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                  {analytics?.uniqueVoters || 0}
                </div>
                <p className="text-gray-600 dark:text-gray-400">Unique Voters</p>
                <p className="text-sm text-amber-600 dark:text-amber-400">
                  {analytics?.averageVotesPerUser.toFixed(1)} avg votes/user
                </p>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600 text-center">
                <div className="text-3xl font-bold text-red-600 dark:text-red-400 mb-2">
                  {analytics?.fraudAttempts || 0}
                </div>
                <p className="text-gray-600 dark:text-gray-400">Fraud Attempts</p>
                <p className="text-sm text-green-600 dark:text-green-400">
                  {analytics?.blockedVotes || 0} blocked
                </p>
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Votes by Category</h3>
                <button className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2">
                  <Download className="w-4 h-4" />
                  <span>Export</span>
                </button>
              </div>
              
              <div className="space-y-3">
                {Object.entries(analytics?.votingsByCategory || {}).map(([category, count]) => (
                  <div key={category} className="flex items-center justify-between">
                    <span className="font-medium text-gray-900 dark:text-white">{category}</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-amber-500 to-orange-500 h-2 rounded-full"
                          style={{ width: `${(count / (analytics?.totalVotes || 1)) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-400 w-12 text-right">{count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Voting System Management
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Configure voting modes, security settings, and monitor voting activities
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${settings?.isVotingOpen ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {settings?.isVotingOpen ? 'Voting Open' : 'Voting Closed'}
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${
              settings?.votingMode === 'free' ? 'bg-green-500' : 'bg-amber-500'
            }`}></div>
            <span className="text-sm text-gray-600 dark:text-gray-400 capitalize">
              {settings?.votingMode} Mode
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'settings', label: 'Configuration', icon: Settings },
              { id: 'security', label: 'Security', icon: Shield },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>

      {/* Save Button (for settings changes) */}
      {(activeTab === 'settings' || activeTab === 'security') && (
        <div className="flex justify-end">
          <button
            onClick={handleSaveSettings}
            disabled={isSaving}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
          >
            {isSaving ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <Save className="w-5 h-5" />
            )}
            <span>{isSaving ? 'Saving...' : 'Save All Settings'}</span>
          </button>
        </div>
      )}

      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400" />
            <p className="text-red-700 dark:text-red-400">{error}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default VotingManagement;