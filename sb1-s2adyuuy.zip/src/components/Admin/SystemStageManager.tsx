import React, { useState, useEffect } from 'react';
import {
  Play, Pause, Square, Clock, Calendar, Settings, 
  AlertTriangle, CheckCircle, ArrowRight, Edit, Save,
  FileText, Users, Vote, Trophy, Lock, Unlock, X
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useProcessState } from '../../hooks/useSubmissions';
import { ProcessState } from '../../types/submissions';

interface StageConfig {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  features: string[];
  nextStage?: string;
  autoTransitionAvailable: boolean;
}

const stageConfigurations: StageConfig[] = [
  {
    id: 'setup',
    name: 'System Setup',
    description: 'Configure forms, categories, and system settings',
    icon: Settings,
    color: 'gray',
    features: ['Form creation', 'Category setup', 'User management'],
    nextStage: 'entries_open',
    autoTransitionAvailable: false
  },
  {
    id: 'entries_open',
    name: 'Entries Open',
    description: 'Accept entry submissions from participants',
    icon: FileText,
    color: 'blue',
    features: ['Public submission forms', 'File uploads', 'Email notifications'],
    nextStage: 'entries_closed',
    autoTransitionAvailable: true
  },
  {
    id: 'entries_closed',
    name: 'Entries Closed',
    description: 'Entry submission period has ended',
    icon: Lock,
    color: 'orange',
    features: ['Submission review', 'Data validation', 'Initial screening'],
    nextStage: 'jury_vetting',
    autoTransitionAvailable: true
  },
  {
    id: 'jury_vetting',
    name: 'Jury Vetting',
    description: 'Expert jury reviews and scores submissions',
    icon: Users,
    color: 'purple',
    features: ['Jury portal access', 'Scoring system', 'Review management'],
    nextStage: 'vetting_closed',
    autoTransitionAvailable: true
  },
  {
    id: 'vetting_closed',
    name: 'Vetting Complete',
    description: 'Jury evaluation completed, shortlist finalized',
    icon: CheckCircle,
    color: 'green',
    features: ['Shortlist generation', 'Results preparation', 'Notification system'],
    nextStage: 'voting_open',
    autoTransitionAvailable: true
  },
  {
    id: 'voting_open',
    name: 'Public Voting',
    description: 'Public votes for shortlisted entries',
    icon: Vote,
    color: 'teal',
    features: ['Voting portal', 'Real-time counting', 'Fraud prevention'],
    nextStage: 'voting_closed',
    autoTransitionAvailable: true
  },
  {
    id: 'voting_closed',
    name: 'Voting Closed',
    description: 'Voting period ended, results being calculated',
    icon: Square,
    color: 'indigo',
    features: ['Final calculations', 'Result verification', 'Winner determination'],
    nextStage: 'results_announced',
    autoTransitionAvailable: true
  },
  {
    id: 'results_announced',
    name: 'Results Announced',
    description: 'Winners announced, awards ceremony preparation',
    icon: Trophy,
    color: 'amber',
    features: ['Winner notifications', 'Certificate generation', 'Gala preparation'],
    autoTransitionAvailable: false
  }
];

const SystemStageManager: React.FC = () => {
  const { user } = useAuth();
  const { state, isLoading, fetchProcessState, updateProcessState } = useProcessState();
  const [editingTransitions, setEditingTransitions] = useState(false);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);

  useEffect(() => {
    fetchProcessState();
  }, [fetchProcessState]);

  // Check permissions
  if (user?.role !== 'superadmin' && user?.role !== 'admin') {
    return (
      <div className="p-6 text-center">
        <Lock className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          System stage management is only available to super administrators and administrators.
        </p>
      </div>
    );
  }

  const getCurrentStageConfig = () => {
    return stageConfigurations.find(s => s.id === state?.currentStage);
  };

  const handleStageTransition = async (newStage: string) => {
    if (!state) return;

    try {
      await updateProcessState({
        currentStage: newStage as any,
        stageStart: new Date(),
        updatedBy: user?.id
      });
      
      fetchProcessState();
    } catch (error) {
      console.error('Failed to transition stage:', error);
    }
  };

  const handleScheduleTransition = async (stage: string, scheduledTime: Date) => {
    if (!state) return;

    try {
      const autoTransition = {
        ...state.autoTransition,
        [`${state.currentStage}_to_${stage}`]: {
          enabled: true,
          scheduled_time: scheduledTime.toISOString()
        }
      };

      await updateProcessState({
        autoTransition,
        updatedBy: user?.id
      });

      setScheduleModalOpen(false);
      fetchProcessState();
    } catch (error) {
      console.error('Failed to schedule transition:', error);
    }
  };

  const ScheduleModal = () => (
    scheduleModalOpen && selectedStage && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Schedule Stage Transition
              </h3>
              <button
                onClick={() => setScheduleModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <div>
              <p className="text-gray-600 dark:text-gray-400">
                Schedule automatic transition from{' '}
                <strong>{getCurrentStageConfig()?.name}</strong> to{' '}
                <strong>{stageConfigurations.find(s => s.id === selectedStage)?.name}</strong>
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Transition Date & Time
              </label>
              <input
                type="datetime-local"
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                min={new Date().toISOString().slice(0, 16)}
              />
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 dark:text-blue-400 mb-2">Automated Actions</h4>
              <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
                <li>• Send transition notifications to all users</li>
                <li>• Update system permissions and access</li>
                <li>• Trigger relevant email campaigns</li>
                <li>• Log transition in audit trail</li>
              </ul>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setScheduleModalOpen(false)}
                className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const input = document.querySelector('input[type="datetime-local"]') as HTMLInputElement;
                  if (input?.value) {
                    handleScheduleTransition(selectedStage, new Date(input.value));
                  }
                }}
                className="flex-1 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Schedule Transition
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  );

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-gray-600 dark:text-gray-400">Loading system state...</p>
      </div>
    );
  }

  const currentStageConfig = getCurrentStageConfig();

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-500 to-pink-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">System Stage Manager</h2>
            <p className="text-red-100 text-lg">
              Control award process stages and automated transitions
            </p>
          </div>
          <div className="hidden md:block">
            <Settings className="w-24 h-24 text-red-200" />
          </div>
        </div>
      </div>

      {/* Current Stage Status */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Current Stage</h3>
          {state?.stageStart && (
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Started: {state.stageStart.toLocaleString()}
            </div>
          )}
        </div>

        {currentStageConfig && (
          <div className={`bg-${currentStageConfig.color}-50 dark:bg-${currentStageConfig.color}-900/20 border border-${currentStageConfig.color}-200 dark:border-${currentStageConfig.color}-800 rounded-xl p-6`}>
            <div className="flex items-center space-x-4 mb-4">
              <div className={`p-4 bg-${currentStageConfig.color}-100 dark:bg-${currentStageConfig.color}-900/30 rounded-xl`}>
                <currentStageConfig.icon className={`w-8 h-8 text-${currentStageConfig.color}-600 dark:text-${currentStageConfig.color}-400`} />
              </div>
              <div>
                <h4 className={`text-xl font-bold text-${currentStageConfig.color}-900 dark:text-${currentStageConfig.color}-400`}>
                  {currentStageConfig.name}
                </h4>
                <p className={`text-${currentStageConfig.color}-700 dark:text-${currentStageConfig.color}-500`}>
                  {currentStageConfig.description}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <h5 className={`font-medium text-${currentStageConfig.color}-900 dark:text-${currentStageConfig.color}-400`}>
                Active Features:
              </h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {currentStageConfig.features.map((feature, index) => (
                  <div key={index} className={`flex items-center space-x-2 text-${currentStageConfig.color}-700 dark:text-${currentStageConfig.color}-500`}>
                    <CheckCircle className="w-4 h-4" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Stage Flow */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Award Process Flow</h3>
          <button
            onClick={() => setEditingTransitions(!editingTransitions)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Edit className="w-4 h-4" />
            <span>{editingTransitions ? 'Save Changes' : 'Edit Transitions'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stageConfigurations.map((stage, index) => {
            const Icon = stage.icon;
            const isCurrentStage = state?.currentStage === stage.id;
            const isPastStage = state && stageConfigurations.findIndex(s => s.id === state.currentStage) > index;
            const isFutureStage = !isCurrentStage && !isPastStage;
            
            return (
              <div key={stage.id} className="relative">
                <div className={`border-2 rounded-xl p-6 transition-all ${
                  isCurrentStage 
                    ? `border-${stage.color}-500 bg-${stage.color}-50 dark:bg-${stage.color}-900/20` 
                    : isPastStage
                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                    : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700'
                }`}>
                  <div className="text-center mb-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${
                      isCurrentStage 
                        ? `bg-${stage.color}-500 text-white`
                        : isPastStage
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-300 dark:bg-gray-600 text-gray-600 dark:text-gray-400'
                    }`}>
                      {isPastStage ? (
                        <CheckCircle className="w-6 h-6" />
                      ) : (
                        <Icon className="w-6 h-6" />
                      )}
                    </div>
                    
                    <h4 className={`font-semibold mb-1 ${
                      isCurrentStage 
                        ? `text-${stage.color}-900 dark:text-${stage.color}-400`
                        : isPastStage
                        ? 'text-green-900 dark:text-green-400'
                        : 'text-gray-600 dark:text-gray-400'
                    }`}>
                      {stage.name}
                    </h4>
                    <p className={`text-sm ${
                      isCurrentStage 
                        ? `text-${stage.color}-700 dark:text-${stage.color}-500`
                        : isPastStage
                        ? 'text-green-700 dark:text-green-500'
                        : 'text-gray-500 dark:text-gray-500'
                    }`}>
                      {stage.description}
                    </p>
                  </div>

                  {isCurrentStage && (
                    <div className="space-y-3">
                      {stage.nextStage && (
                        <button
                          onClick={() => handleStageTransition(stage.nextStage!)}
                          className={`w-full bg-${stage.color}-600 text-white py-2 px-4 rounded-lg hover:bg-${stage.color}-700 transition-colors flex items-center justify-center space-x-2`}
                        >
                          <Play className="w-4 h-4" />
                          <span>Advance Stage</span>
                        </button>
                      )}
                      
                      {stage.autoTransitionAvailable && (
                        <button
                          onClick={() => {
                            setSelectedStage(stage.nextStage || '');
                            setScheduleModalOpen(true);
                          }}
                          className="w-full border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 py-2 px-4 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-center space-x-2"
                        >
                          <Calendar className="w-4 h-4" />
                          <span>Schedule</span>
                        </button>
                      )}
                      
                      {(user?.role === 'superadmin' || user?.role === 'admin') && (
                        <button
                          onClick={() => {
                            setEditingTransitions(true);
                          }}
                          className="w-full border border-amber-300 dark:border-amber-600 text-amber-700 dark:text-amber-300 py-2 px-4 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors flex items-center justify-center space-x-2"
                        >
                          <Settings className="w-4 h-4" />
                          <span>Edit Transitions</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Arrow to next stage */}
                {index < stageConfigurations.length - 1 && (
                  <div className="hidden lg:block absolute -right-2 top-1/2 transform -translate-y-1/2">
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Auto-Transition Settings */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Auto-Transition Settings</h3>
          <button
            onClick={() => setEditingTransitions(!editingTransitions)}
            className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
          >
            {editingTransitions ? <Save className="w-5 h-5" /> : <Edit className="w-5 h-5" />}
          </button>
        </div>

        <div className="space-y-4">
          {Object.entries(state?.autoTransition || {}).map(([transitionKey, transitionConfig]) => {
            const [fromStage, toStage] = transitionKey.replace(/(_to_)/g, '|').split('|');
            const fromConfig = stageConfigurations.find(s => s.id === fromStage);
            const toConfig = stageConfigurations.find(s => s.id === toStage);
            
            if (!fromConfig || !toConfig) return null;

            return (
              <div key={transitionKey} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {fromConfig.name}
                    </span>
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {toConfig.name}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  {editingTransitions ? (
                    <>
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={(transitionConfig as any).enabled || false}
                          className="text-amber-500 focus:ring-amber-500"
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">Enabled</span>
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="number"
                          value={(transitionConfig as any).delay_hours || 0}
                          placeholder="Hours"
                          className="w-20 px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm"
                          min="0"
                        />
                        <span className="text-sm text-gray-600 dark:text-gray-400">hours delay</span>
                      </div>
                    </>
                  ) : (
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      (transitionConfig as any).enabled 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {(transitionConfig as any).enabled ? 'Auto' : 'Manual'}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* System Impact Warning */}
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-6">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-6 h-6 text-amber-600 dark:text-amber-400 mt-1" />
          <div>
            <h4 className="font-medium text-amber-900 dark:text-amber-400 mb-2">Important Notice</h4>
            <div className="text-sm text-amber-800 dark:text-amber-500 space-y-2">
              <p>
                Changing system stages will affect user access and functionality across the entire platform:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Entry submissions will be enabled/disabled based on the current stage</li>
                <li>Jury portal access will be controlled by vetting stages</li>
                <li>Public voting will only be available during the voting stage</li>
                <li>Automated emails and notifications will be triggered</li>
                <li>All users will receive stage transition notifications</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <ScheduleModal />
    </div>
  );
};

export default SystemStageManager;