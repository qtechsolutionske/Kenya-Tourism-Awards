import React, { useState, useEffect } from 'react';
import { 
  Users, CheckCircle, XCircle, Clock, Eye, Edit, Shield, 
  UserCheck, Search, Filter, AlertTriangle, Info, Award,
  User, Phone, Mail, MapPin, Calendar, Briefcase
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { teamMembers } from '../../data/teamMembers';
import { TeamMember } from '../../types/team';

const TeamApprovalManager: React.FC = () => {
  const { user } = useAuth();
  const [pendingMembers, setPendingMembers] = useState<TeamMember[]>([]);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');

  useEffect(() => {
    // Load pending team members (those with isPublic = false) 
    // Note: Since all members are now approved, this will show empty list
    const pending = teamMembers.filter(member => !member.isPublic && member.isActive);
    setPendingMembers(pending);
  }, []);

  // Check if user has approval permissions
  if (user?.role !== 'superadmin' && user?.role !== 'admin') {
    return (
      <div className="p-6 text-center">
        <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Team approval management is only available to administrators.
        </p>
      </div>
    );
  }

  const filteredMembers = pendingMembers.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = departmentFilter === 'all' || member.department === departmentFilter;
    return matchesSearch && matchesDepartment;
  });

  const handleApproval = (memberId: string, approved: boolean) => {
    if (approved) {
      // Approve member and make public
      setPendingMembers(prev => prev.map(member => 
        member.id === memberId 
          ? { ...member, isPublic: true, isActive: true }
          : member
      ));
      
      // Also update the main teamMembers data source
      // In production, this would be a database update
      alert(`Member approved and made public! Admins can now assign system roles.`);
    } else {
      // Reject member
      setPendingMembers(prev => prev.filter(member => member.id !== memberId));
      alert(`Member rejected. They can resubmit their profile with improvements.`);
    }
  };

  const assignRole = (memberId: string, role: string) => {
    setPendingMembers(prev => prev.map(member => 
      member.id === memberId 
        ? { ...member, role: role }
        : member
    ));
    console.log(`Role ${role} assigned to member ${memberId}`);
  };

  const MemberDetailsModal = () => {
    if (!selectedMember) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Team Member Review
              </h3>
              <button
                onClick={() => setSelectedMember(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Member Profile */}
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <img
                      src={selectedMember.avatar}
                      alt={selectedMember.name}
                      className="w-20 h-20 rounded-xl object-cover"
                    />
                    <div>
                      <h4 className="text-xl font-bold text-gray-900 dark:text-white">
                        {selectedMember.name}
                      </h4>
                      <p className="text-amber-600 dark:text-amber-400 font-medium">
                        {selectedMember.role}
                      </p>
                      <p className="text-gray-500 dark:text-gray-500">
                        {selectedMember.department} • {selectedMember.experience}+ years
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-2">Biography</h5>
                      <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                        {selectedMember.bio}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h6 className="font-medium text-gray-900 dark:text-white mb-1">Contact</h6>
                        <div className="space-y-1 text-sm">
                          <div className="flex items-center space-x-2">
                            <Mail className="w-4 h-4 text-gray-400" />
                            <span className="text-gray-600 dark:text-gray-400">{selectedMember.email}</span>
                          </div>
                          {selectedMember.phone && (
                            <div className="flex items-center space-x-2">
                              <Phone className="w-4 h-4 text-gray-400" />
                              <span className="text-gray-600 dark:text-gray-400">{selectedMember.phone}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div>
                        <h6 className="font-medium text-gray-900 dark:text-white mb-1">Organization</h6>
                        <div className="space-y-1 text-sm">
                          {selectedMember.organization && (
                            <div className="flex items-center space-x-2">
                              <Briefcase className="w-4 h-4 text-gray-400" />
                              <span className="text-gray-600 dark:text-gray-400">{selectedMember.organization}</span>
                            </div>
                          )}
                          <div className="flex items-center space-x-2">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            <span className="text-gray-600 dark:text-gray-400">Joined {selectedMember.joinedYear}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {selectedMember.specialization && (
                      <div>
                        <h6 className="font-medium text-gray-900 dark:text-white mb-1">Specialization</h6>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{selectedMember.specialization}</p>
                      </div>
                    )}

                    {/* Achievements */}
                    {selectedMember.achievements.length > 0 && (
                      <div>
                        <h6 className="font-medium text-gray-900 dark:text-white mb-2">Achievements</h6>
                        <div className="space-y-2">
                          {selectedMember.achievements.map(achievement => (
                            <div key={achievement.id} className="flex items-start space-x-3 p-3 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-600">
                              <Award className="w-4 h-4 text-amber-500 mt-1" />
                              <div>
                                <h7 className="font-medium text-gray-900 dark:text-white text-sm">
                                  {achievement.title}
                                </h7>
                                <p className="text-xs text-gray-600 dark:text-gray-400">
                                  {achievement.description}
                                </p>
                                <p className="text-xs text-gray-500 dark:text-gray-500">
                                  {achievement.date.toLocaleDateString()} • {achievement.organization}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Approval Actions */}
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                  <h5 className="font-semibold text-gray-900 dark:text-white mb-4">Approval Status</h5>
                  
                  <div className="space-y-4">
                    <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                        <span className="font-medium text-amber-900 dark:text-amber-400">Pending Approval</span>
                      </div>
                      <p className="text-sm text-amber-700 dark:text-amber-500">
                        This team member is awaiting admin approval to be made public.
                      </p>
                    </div>

                    {/* Role Assignment */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Assign System Role
                      </label>
                      <select
                        defaultValue=""
                        onChange={(e) => assignRole(selectedMember.id, e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      >
                        <option value="">Select Role</option>
                        <option value="admin">Administrator</option>
                        <option value="manager">Content Manager</option>
                        <option value="jury">Jury Member</option>
                        <option value="editor">Content Editor</option>
                        <option value="viewer">Viewer</option>
                      </select>
                    </div>

                    {/* Approval Actions */}
                    <div className="space-y-3">
                      <button
                        onClick={() => {
                          handleApproval(selectedMember.id, true);
                          setSelectedMember(null);
                        }}
                        className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Approve & Make Public</span>
                      </button>
                      
                      <button
                        onClick={() => {
                          handleApproval(selectedMember.id, false);
                          setSelectedMember(null);
                        }}
                        className="w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition-colors flex items-center justify-center space-x-2"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Reject Application</span>
                      </button>

                      <button className="w-full border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 py-3 px-4 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-center space-x-2">
                        <Edit className="w-4 h-4" />
                        <span>Request Changes</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Member Stats */}
                <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                  <h5 className="font-semibold text-gray-900 dark:text-white mb-4">Profile Stats</h5>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Experience</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {selectedMember.experience}+ years
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Achievements</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {selectedMember.achievements.length}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Portfolio Items</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {selectedMember.portfolio.length}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Badges</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {selectedMember.badges.length}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Team Member Approvals
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Review and approve new team member profiles before they go public
          </p>
        </div>
        <div className="bg-amber-100 dark:bg-amber-900/20 px-4 py-2 rounded-lg">
          <span className="text-amber-800 dark:text-amber-400 font-medium">
            {pendingMembers.length} Pending Approval
          </span>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Pending Approval</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{pendingMembers.length}</p>
            </div>
            <Clock className="w-8 h-8 text-amber-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Approved Members</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {teamMembers.filter(m => m.isPublic).length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Active Members</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {teamMembers.filter(m => m.isActive).length}
              </p>
            </div>
            <Users className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Members</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{teamMembers.length}</p>
            </div>
            <UserCheck className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search pending members..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Departments</option>
              <option value="Leadership">Leadership</option>
              <option value="Operations">Operations</option>
              <option value="Media">Media</option>
              <option value="Partnerships">Partnerships</option>
              <option value="Technology">Technology</option>
              <option value="Administration">Administration</option>
            </select>
          </div>
        </div>
      </div>

      {/* Pending Members */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        {filteredMembers.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              {pendingMembers.length === 0 ? 'No Pending Approvals' : 'No Members Found'}
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {pendingMembers.length === 0 
                ? 'All team members have been reviewed and approved.'
                : 'Try adjusting your search or filter criteria.'
              }
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Member</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Role & Department</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Experience</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Status</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredMembers.map((member) => (
                  <tr key={member.id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        <img
                          src={member.avatar}
                          alt={member.name}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{member.name}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">{member.email}</div>
                          {member.organization && (
                            <div className="text-xs text-gray-500 dark:text-gray-500">{member.organization}</div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div>
                        <div className="text-sm font-medium text-gray-900 dark:text-white">{member.role}</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">{member.department}</div>
                        {member.specialization && (
                          <div className="text-xs text-gray-500 dark:text-gray-500">{member.specialization}</div>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm text-gray-900 dark:text-white">
                        {member.experience}+ years
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-500">
                        Joined {member.joinedYear}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="px-2 py-1 text-xs font-medium bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-400 rounded-full">
                        Pending Review
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedMember(member)}
                          className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                          title="Review details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleApproval(member.id, true)}
                          className="p-2 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                          title="Quick approve"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleApproval(member.id, false)}
                          className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                          title="Quick reject"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6">
        <div className="flex items-start space-x-3">
          <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
          <div>
            <h4 className="font-medium text-blue-900 dark:text-blue-400 mb-2">Approval Process</h4>
            <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
              <li>• Review each team member's biography, experience, and qualifications</li>
              <li>• Assign appropriate system roles (admin, manager, jury, etc.)</li>
              <li>• Approve to make profile public on the Team page</li>
              <li>• Rejected members will be notified and can resubmit with changes</li>
              <li>• Approved members will receive access credentials and onboarding</li>
            </ul>
          </div>
        </div>
      </div>

      {selectedMember && <MemberDetailsModal />}
    </div>
  );
};

export default TeamApprovalManager;