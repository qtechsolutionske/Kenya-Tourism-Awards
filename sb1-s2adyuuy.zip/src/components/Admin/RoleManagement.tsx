import React, { useState, useEffect } from 'react';
import {
  Shield, Users, Plus, Edit, Trash2, Save, X, Eye, EyeOff,
  UserCheck, Settings, Award, Vote, FileText, BarChart3,
  Mail, Layout, CreditCard, AlertTriangle, CheckCircle
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useUserPrivileges } from '../../hooks/useSubmissions';
import { PRIVILEGE_TYPES, RESOURCE_TYPES, UserPrivilege } from '../../types/submissions';

interface RoleTemplate {
  id: string;
  name: string;
  description: string;
  privileges: string[];
  color: string;
  icon: React.ComponentType<any>;
}

const roleTemplates: RoleTemplate[] = [
  {
    id: 'superadmin',
    name: 'Super Administrator',
    description: 'Full system access and control',
    privileges: [PRIVILEGE_TYPES.FULL_ACCESS],
    color: 'red',
    icon: Shield
  },
  {
    id: 'admin',
    name: 'Administrator',
    description: 'General administrative access',
    privileges: [
      PRIVILEGE_TYPES.MANAGE_SYSTEM,
      PRIVILEGE_TYPES.CREATE_FORMS,
      PRIVILEGE_TYPES.EDIT_FORMS,
      PRIVILEGE_TYPES.PUBLISH_FORMS,
      PRIVILEGE_TYPES.VIEW_SUBMISSIONS,
      PRIVILEGE_TYPES.EDIT_SUBMISSIONS,
      PRIVILEGE_TYPES.APPROVE_SUBMISSIONS,
      PRIVILEGE_TYPES.MANAGE_USERS,
      PRIVILEGE_TYPES.VIEW_ANALYTICS
    ],
    color: 'blue',
    icon: UserCheck
  },
  {
    id: 'manager',
    name: 'Content Manager',
    description: 'Content and form management',
    privileges: [
      PRIVILEGE_TYPES.CREATE_FORMS,
      PRIVILEGE_TYPES.EDIT_FORMS,
      PRIVILEGE_TYPES.VIEW_SUBMISSIONS,
      PRIVILEGE_TYPES.EDIT_SUBMISSIONS,
      PRIVILEGE_TYPES.MANAGE_CONTENT,
      PRIVILEGE_TYPES.MANAGE_PAGES
    ],
    color: 'purple',
    icon: Layout
  },
  {
    id: 'jury',
    name: 'Jury Member',
    description: 'Review and score submissions',
    privileges: [
      PRIVILEGE_TYPES.VIEW_SUBMISSIONS,
      PRIVILEGE_TYPES.REVIEW_SUBMISSIONS,
      PRIVILEGE_TYPES.SCORE_SUBMISSIONS,
      PRIVILEGE_TYPES.VIEW_ASSIGNED_CATEGORIES
    ],
    color: 'green',
    icon: Award
  },
  {
    id: 'reviewer',
    name: 'Content Reviewer',
    description: 'Review submissions without scoring',
    privileges: [
      PRIVILEGE_TYPES.VIEW_SUBMISSIONS,
      PRIVILEGE_TYPES.REVIEW_SUBMISSIONS
    ],
    color: 'teal',
    icon: Eye
  },
  {
    id: 'analytics',
    name: 'Analytics Viewer',
    description: 'View reports and analytics',
    privileges: [
      PRIVILEGE_TYPES.VIEW_ANALYTICS,
      PRIVILEGE_TYPES.VIEW_SUBMISSIONS
    ],
    color: 'indigo',
    icon: BarChart3
  }
];

const RoleManagement: React.FC = () => {
  const { user } = useAuth();
  const { grantPrivilege, revokePrivilege, fetchUserPrivileges } = useUserPrivileges();
  const [users, setUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [userPrivileges, setUserPrivileges] = useState<UserPrivilege[]>([]);
  const [showRoleAssignment, setShowRoleAssignment] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      // This would fetch from your users table
      // For now, using mock data
      setUsers([
        { id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', name: 'John Doe', email: 'john@admin.com', role: 'admin' },
        { id: 'b1ffcc88-8b1a-5df7-aa5c-5aa8bd381b22', name: 'Jane Smith', email: 'jane@jury.com', role: 'jury' },
        { id: 'c2eedd77-7a2b-6ee6-995b-699abd382c33', name: 'Alice Johnson', email: 'alice@manager.com', role: 'manager' }
      ]);
    } catch (error) {
      console.error('Failed to load users:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadUserPrivileges = async (userId: string) => {
    try {
      const privileges = await fetchUserPrivileges(userId);
      setUserPrivileges(privileges);
    } catch (error) {
      console.error('Failed to load user privileges:', error);
    }
  };

  const assignRole = async (userId: string, roleTemplate: RoleTemplate) => {
    // Prevent regular admins from assigning superadmin role
    if (user?.role === 'admin' && roleTemplate.id === 'superadmin') {
      alert('Only super administrators can assign superadmin role.');
      return;
    }
    
    try {
      // Remove existing privileges for this user
      for (const privilege of userPrivileges || []) {
        if (privilege.userId === userId) {
          await revokePrivilege(privilege.id, user?.accessToken);
        }
      }

      // Grant new role privileges
      for (const privilegeType of roleTemplate.privileges) {
        await grantPrivilege(
          userId,
          privilegeType,
          RESOURCE_TYPES.SYSTEM,
          undefined,
          user?.id,
          undefined,
          user?.accessToken
        );
      }

      setShowRoleAssignment(false);
      loadUserPrivileges(userId);
    } catch (error) {
      console.error('Failed to assign role:', error);
    }
  };

  const togglePrivilege = async (userId: string, privilegeType: string, currentlyGranted: boolean) => {
    // Prevent regular admins from modifying superadmin privileges
    if (user?.role === 'admin' && privilegeType === PRIVILEGE_TYPES.FULL_ACCESS) {
      alert('Only super administrators can manage full access privileges.');
      return;
    }
    
    try {
      if (currentlyGranted) {
        const privilege = (userPrivileges || []).find(p => 
          p.userId === userId && p.privilegeType === privilegeType
        );
        if (privilege) {
          await revokePrivilege(privilege.id, user?.accessToken);
        }
      } else {
        await grantPrivilege(userId, privilegeType, RESOURCE_TYPES.SYSTEM, undefined, user?.id, undefined, user?.accessToken);
      }
      
      loadUserPrivileges(userId);
    } catch (error) {
      console.error('Failed to toggle privilege:', error);
    }
  };

  // Check if current user is superadmin
  if (user?.role !== 'superadmin' && user?.role !== 'admin') {
    return (
      <div className="p-6 text-center">
        <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Role management is available to super administrators and administrators.
          {user?.role === 'admin' && (
            <>
              <br />
              <span className="text-amber-600 dark:text-amber-400 text-sm">
                Note: Administrators can assign most roles, but cannot modify superadmin privileges.
              </span>
            </>
          )}
        </p>
      </div>
    );
  }

  const RoleAssignmentModal = () => (
    showRoleAssignment && selectedUser && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Assign Role</h3>
              <button
                onClick={() => setShowRoleAssignment(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="mb-6">
              <h4 className="font-medium text-gray-900 dark:text-white mb-4">Role Templates</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {roleTemplates.map((role) => {
                  const Icon = role.icon;
                  return (
                    <button
                      key={role.id}
                      onClick={() => assignRole(selectedUser, role)}
                      className={`p-6 border-2 border-gray-300 dark:border-gray-600 rounded-xl hover:border-${role.color}-500 hover:bg-${role.color}-50 dark:hover:bg-${role.color}-900/20 transition-colors text-left`}
                    >
                      <div className="flex items-center space-x-3 mb-3">
                        <div className={`p-2 bg-${role.color}-100 dark:bg-${role.color}-900/20 rounded-lg`}>
                          <Icon className={`w-5 h-5 text-${role.color}-600 dark:text-${role.color}-400`} />
                        </div>
                        <h5 className="font-medium text-gray-900 dark:text-white">{role.name}</h5>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{role.description}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">
                        {role.privileges.length} privileges
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-900 dark:text-white mb-4">Custom Privileges</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(PRIVILEGE_TYPES).map(([key, privilegeType]) => {
                  const isGranted = (userPrivileges || []).some(p => 
                    p.userId === selectedUser && p.privilegeType === privilegeType && p.isActive
                  );
                  
                  return (
                    <label
                      key={privilegeType}
                      className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700"
                    >
                      <input
                        type="checkbox"
                        checked={isGranted}
                        onChange={() => togglePrivilege(selectedUser, privilegeType, isGranted)}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white capitalize">
                          {key.replace(/_/g, ' ').toLowerCase()}
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">
                          {privilegeType}
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  );

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Role & Privilege Management
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Assign roles and manage user privileges across the system
          </p>
        </div>
      </div>

      {/* Role Templates */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Available Role Templates</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {roleTemplates.map((role) => {
            const Icon = role.icon;
            return (
              <div
                key={role.id}
                className={`border border-${role.color}-200 dark:border-${role.color}-800 bg-${role.color}-50 dark:bg-${role.color}-900/20 rounded-xl p-6`}
              >
                <div className="flex items-center space-x-3 mb-4">
                  <div className={`p-3 bg-${role.color}-100 dark:bg-${role.color}-900/30 rounded-lg`}>
                    <Icon className={`w-6 h-6 text-${role.color}-600 dark:text-${role.color}-400`} />
                  </div>
                  <div>
                    <h4 className={`font-semibold text-${role.color}-900 dark:text-${role.color}-400`}>
                      {role.name}
                    </h4>
                  </div>
                </div>
                <p className={`text-sm text-${role.color}-700 dark:text-${role.color}-500 mb-4`}>
                  {role.description}
                </p>
                <div className="space-y-1">
                  {role.privileges.slice(0, 3).map((priv) => (
                    <div key={priv} className={`text-xs text-${role.color}-600 dark:text-${role.color}-400`}>
                      • {priv.replace(/_/g, ' ')}
                    </div>
                  ))}
                  {role.privileges.length > 3 && (
                    <div className={`text-xs text-${role.color}-500 dark:text-${role.color}-500`}>
                      +{role.privileges.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Users Management */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">User Privileges</h3>
          <button
            onClick={() => setShowRoleAssignment(true)}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Assign Role</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">User</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Current Role</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Privileges</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((userItem) => {
                const userRole = roleTemplates.find(r => r.id === userItem.role);
                const Icon = userRole?.icon || Users;
                
                return (
                  <tr key={userItem.id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg flex items-center justify-center">
                          <span className="text-white font-bold text-sm">
                            {userItem.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{userItem.name}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">{userItem.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      {userRole ? (
                        <div className="flex items-center space-x-2">
                          <div className={`p-2 bg-${userRole.color}-100 dark:bg-${userRole.color}-900/20 rounded-lg`}>
                            <Icon className={`w-4 h-4 text-${userRole.color}-600 dark:text-${userRole.color}-400`} />
                          </div>
                          <div>
                            <div className="font-medium text-gray-900 dark:text-white">{userRole.name}</div>
                            <div className="text-xs text-gray-600 dark:text-gray-400">{userRole.description}</div>
                          </div>
                        </div>
                      ) : (
                        <span className="text-gray-500 dark:text-gray-500">No role assigned</span>
                      )}
                    </td>
                    <td className="py-4 px-4">
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {userRole?.privileges.length || 0} privileges
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400">
                        Active
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            setSelectedUser(userItem.id);
                            loadUserPrivileges(userItem.id);
                            setShowRoleAssignment(true);
                          }}
                          className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                          title="Manage privileges"
                        >
                          <Settings className="w-4 h-4" />
                        </button>
                        <button
                          className="p-2 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                          title="View details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <RoleAssignmentModal />
    </div>
  );
};

export default RoleManagement;