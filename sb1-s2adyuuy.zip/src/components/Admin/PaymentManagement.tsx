import React, { useState } from 'react';
import { 
  CreditCard, Settings, Eye, EyeOff, Save, Edit, TestTube, 
  Shield, Key, DollarSign, BarChart3, RefreshCw, AlertTriangle,
  CheckCircle, Clock, Smartphone, Users, Download, Filter
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { PaymentMethod } from '../../types/payment';

interface PaymentConfig {
  mpesa: {
    enabled: boolean;
    isLive: boolean;
    businessShortCode: string;
    consumerKey: string;
    consumerSecret: string;
    passkey: string;
    resultUrl: string;
    confirmationUrl: string;
  };
  paystack: {
    enabled: boolean;
    isLive: boolean;
    publicKey: string;
    secretKey: string;
    webhookSecret: string;
  };
}

const PaymentManagement: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'configuration' | 'transactions' | 'analytics'>('overview');
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [testMode, setTestMode] = useState(true);

  const [config, setConfig] = useState<PaymentConfig>({
    mpesa: {
      enabled: true,
      isLive: false,
      businessShortCode: '',
      consumerKey: '',
      consumerSecret: '',
      passkey: '',
      resultUrl: '',
      confirmationUrl: ''
    },
    paystack: {
      enabled: true,
      isLive: false,
      publicKey: '',
      secretKey: '',
      webhookSecret: ''
    }
  });

  // Mock transaction data
  const mockTransactions = [
    {
      id: '1',
      method: 'mpesa',
      reference: 'KTA202412120001',
      amount: 35000,
      currency: 'KES',
      status: 'success',
      customerName: 'John Doe',
      customerPhone: '+254712345678',
      createdAt: new Date('2024-12-12'),
      verifiedAt: new Date('2024-12-12')
    },
    {
      id: '2',
      method: 'paystack',
      reference: 'KTA202412120002',
      amount: 15000,
      currency: 'KES',
      status: 'success',
      customerName: 'Jane Smith',
      customerEmail: 'jane@example.com',
      createdAt: new Date('2024-12-12'),
      verifiedAt: new Date('2024-12-12')
    },
    {
      id: '3',
      method: 'mpesa',
      reference: 'KTA202412120003',
      amount: 75000,
      currency: 'KES',
      status: 'pending',
      customerName: 'Peter Kimani',
      customerPhone: '+254722345678',
      createdAt: new Date('2024-12-12')
    }
  ];

  // Check if user has super admin access
  const canManagePayments = user?.role === 'superadmin' || user?.role === 'admin';
  const hasFullAccess = user?.role === 'superadmin';
  
  if (!canManagePayments) {
    return (
      <div className="p-6 text-center">
        <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-8 h-8 text-red-600 dark:text-red-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Payment management is only available to super administrators and administrators.
          {user?.role === 'admin' && !hasFullAccess && (
            <>
              <br />
              <span className="text-amber-600 dark:text-amber-400 text-sm">
                Note: You have view and basic management access. API key management requires superadmin.
              </span>
            </>
          )}
        </p>
      </div>
    );
  }

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API save
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsSaving(false);
  };

  const toggleSecret = (key: string) => {
    setShowSecrets(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleTest = async (method: 'mpesa' | 'paystack') => {
    // Implement test transaction logic
    console.log(`Testing ${method} integration...`);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400';
      case 'failed':
        return 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-400';
      default:
        return 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-400';
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Payment Methods Status */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* MPESA Status */}
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-lg">
                      <Smartphone className="w-6 h-6 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">M-Pesa</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Mobile Money</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      config.mpesa.enabled 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                        : 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
                    }`}>
                      {config.mpesa.enabled ? 'Enabled' : 'Disabled'}
                    </span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      config.mpesa.isLive
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {config.mpesa.isLive ? 'Live' : 'Sandbox'}
                    </span>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Transactions (24h)</span>
                    <span className="font-medium text-gray-900 dark:text-white">47</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Success Rate</span>
                    <span className="font-medium text-green-600 dark:text-green-400">94.5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Volume (24h)</span>
                    <span className="font-medium text-gray-900 dark:text-white">KES 1.2M</span>
                  </div>
                </div>
                <button
                  onClick={() => handleTest('mpesa')}
                  className="w-full mt-4 bg-green-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                >
                  Test Integration
                </button>
              </div>

              {/* Paystack Status */}
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                      <CreditCard className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">Paystack</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Cards & Banking</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      config.paystack.enabled 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                        : 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
                    }`}>
                      {config.paystack.enabled ? 'Enabled' : 'Disabled'}
                    </span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      config.paystack.isLive
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {config.paystack.isLive ? 'Live' : 'Test'}
                    </span>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Transactions (24h)</span>
                    <span className="font-medium text-gray-900 dark:text-white">23</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Success Rate</span>
                    <span className="font-medium text-green-600 dark:text-green-400">98.2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Volume (24h)</span>
                    <span className="font-medium text-gray-900 dark:text-white">KES 845K</span>
                  </div>
                </div>
                <button
                  onClick={() => handleTest('paystack')}
                  className="w-full mt-4 bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
                >
                  Test Integration
                </button>
              </div>
            </div>

            {/* Recent Transactions */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Transactions</h3>
                <button className="text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 text-sm font-medium">
                  View All
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-600">
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Reference</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Method</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Amount</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Status</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockTransactions.slice(0, 5).map((transaction) => (
                      <tr key={transaction.id} className="border-b border-gray-100 dark:border-gray-700">
                        <td className="py-3 font-mono text-xs text-gray-900 dark:text-white">
                          {transaction.reference}
                        </td>
                        <td className="py-3">
                          <div className="flex items-center space-x-2">
                            {transaction.method === 'mpesa' ? (
                              <Smartphone className="w-4 h-4 text-green-500" />
                            ) : (
                              <CreditCard className="w-4 h-4 text-blue-500" />
                            )}
                            <span className="text-gray-900 dark:text-white capitalize">{transaction.method}</span>
                          </div>
                        </td>
                        <td className="py-3 font-medium text-gray-900 dark:text-white">
                          {new Intl.NumberFormat('en-KE', {
                            style: 'currency',
                            currency: transaction.currency
                          }).format(transaction.amount)}
                        </td>
                        <td className="py-3">
                          <div className="flex items-center space-x-2">
                            {getStatusIcon(transaction.status)}
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(transaction.status)}`}>
                              {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 text-gray-600 dark:text-gray-400">
                          {transaction.createdAt.toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'configuration':
        return (
          <div className="space-y-8">
            {/* Environment Toggle */}
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                  <div>
                    <h4 className="font-medium text-yellow-900 dark:text-yellow-400">Environment Mode</h4>
                    <p className="text-sm text-yellow-800 dark:text-yellow-500">
                      Currently using {testMode ? 'Test/Sandbox' : 'Live/Production'} environment
                    </p>
                  </div>
                </div>
                <label className="flex items-center space-x-2">
                  <span className="text-sm text-yellow-800 dark:text-yellow-400">Test Mode</span>
                  <input
                    type="checkbox"
                    checked={testMode}
                    onChange={(e) => setTestMode(e.target.checked)}
                    className="text-yellow-500 focus:ring-yellow-500"
                  />
                </label>
              </div>
            </div>

            {/* MPESA Configuration */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <Smartphone className="w-6 h-6 text-green-600 dark:text-green-400" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">M-Pesa Configuration</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Safaricom Daraja API settings</p>
                  </div>
                </div>
                <label className="flex items-center space-x-2">
                  <span className="text-sm text-gray-700 dark:text-gray-300">Enabled</span>
                  <input
                    type="checkbox"
                    checked={config.mpesa.enabled}
                    onChange={(e) => setConfig(prev => ({
                      ...prev,
                      mpesa: { ...prev.mpesa, enabled: e.target.checked }
                    }))}
                    className="text-green-500 focus:ring-green-500"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Business Short Code
                  </label>
                  <input
                    type="text"
                    value={config.mpesa.businessShortCode}
                    onChange={(e) => setConfig(prev => ({
                      ...prev,
                      mpesa: { ...prev.mpesa, businessShortCode: e.target.value }
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="174379"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Consumer Key
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.mpesaConsumerKey ? 'text' : 'password'}
                      value={config.mpesa.consumerKey}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        mpesa: { ...prev.mpesa, consumerKey: e.target.value }
                      }))}
                      className="w-full px-4 py-3 pr-12 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono"
                      placeholder="Enter consumer key"
                      readOnly={!hasFullAccess}
                    />
                    <button
                      type="button"
                      onClick={() => toggleSecret('mpesaConsumerKey')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      {showSecrets.mpesaConsumerKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {!hasFullAccess && (
                    <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                      API key editing restricted to superadmin
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Consumer Secret
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.mpesaConsumerSecret ? 'text' : 'password'}
                      value={config.mpesa.consumerSecret}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        mpesa: { ...prev.mpesa, consumerSecret: e.target.value }
                      }))}
                      className="w-full px-4 py-3 pr-12 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono"
                      placeholder="Enter consumer secret"
                    />
                    <button
                      type="button"
                      onClick={() => toggleSecret('mpesaConsumerSecret')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      {showSecrets.mpesaConsumerSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Passkey
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.mpesaPasskey ? 'text' : 'password'}
                      value={config.mpesa.passkey}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        mpesa: { ...prev.mpesa, passkey: e.target.value }
                      }))}
                      className="w-full px-4 py-3 pr-12 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono"
                      placeholder="Enter passkey"
                    />
                    <button
                      type="button"
                      onClick={() => toggleSecret('mpesaPasskey')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      {showSecrets.mpesaPasskey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Paystack Configuration */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <CreditCard className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Paystack Configuration</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">API keys and webhook settings</p>
                  </div>
                </div>
                <label className="flex items-center space-x-2">
                  <span className="text-sm text-gray-700 dark:text-gray-300">Enabled</span>
                  <input
                    type="checkbox"
                    checked={config.paystack.enabled}
                    onChange={(e) => setConfig(prev => ({
                      ...prev,
                      paystack: { ...prev.paystack, enabled: e.target.checked }
                    }))}
                    className="text-blue-500 focus:ring-blue-500"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Public Key
                  </label>
                  <input
                    type="text"
                    value={config.paystack.publicKey}
                    onChange={(e) => setConfig(prev => ({
                      ...prev,
                      paystack: { ...prev.paystack, publicKey: e.target.value }
                    }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono"
                    placeholder="pk_test_..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Secret Key
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.paystackSecret ? 'text' : 'password'}
                      value={config.paystack.secretKey}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        paystack: { ...prev.paystack, secretKey: e.target.value }
                      }))}
                      className="w-full px-4 py-3 pr-12 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono"
                      placeholder="sk_test_..."
                    />
                    <button
                      type="button"
                      onClick={() => toggleSecret('paystackSecret')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      {showSecrets.paystackSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Webhook Secret
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.paystackWebhook ? 'text' : 'password'}
                      value={config.paystack.webhookSecret}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        paystack: { ...prev.paystack, webhookSecret: e.target.value }
                      }))}
                      className="w-full px-4 py-3 pr-12 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-mono"
                      placeholder="whsec_..."
                    />
                    <button
                      type="button"
                      onClick={() => toggleSecret('paystackWebhook')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      {showSecrets.paystackWebhook ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="flex justify-end">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
              >
                {isSaving ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                <span>{isSaving ? 'Saving...' : 'Save Configuration'}</span>
              </button>
            </div>
          </div>
        );

      case 'transactions':
        return (
          <div className="space-y-6">
            {/* Transaction Filters */}
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Search transactions..."
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                />
              </div>
              <div className="flex items-center space-x-4">
                <select className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                  <option value="all">All Methods</option>
                  <option value="mpesa">M-Pesa</option>
                  <option value="paystack">Paystack</option>
                </select>
                <select className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                  <option value="all">All Status</option>
                  <option value="success">Success</option>
                  <option value="pending">Pending</option>
                  <option value="failed">Failed</option>
                </select>
                <button className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-3 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2">
                  <Download className="w-4 h-4" />
                  <span>Export</span>
                </button>
              </div>
            </div>

            {/* Transactions Table */}
            <div className="bg-white dark:bg-gray-700 rounded-xl border border-gray-200 dark:border-gray-600 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-600">
                    <tr>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Reference</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Customer</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Method</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Amount</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Date</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {mockTransactions.map((transaction) => (
                      <tr key={transaction.id} className="hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                        <td className="py-4 px-4">
                          <span className="font-mono text-sm text-gray-900 dark:text-white">
                            {transaction.reference}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <div>
                            <div className="font-medium text-gray-900 dark:text-white">
                              {transaction.customerName}
                            </div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">
                              {transaction.method === 'mpesa' 
                                ? transaction.customerPhone 
                                : (transaction as any).customerEmail}
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center space-x-2">
                            {transaction.method === 'mpesa' ? (
                              <Smartphone className="w-4 h-4 text-green-500" />
                            ) : (
                              <CreditCard className="w-4 h-4 text-blue-500" />
                            )}
                            <span className="text-gray-900 dark:text-white capitalize">{transaction.method}</span>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <span className="font-medium text-gray-900 dark:text-white">
                            {new Intl.NumberFormat('en-KE', {
                              style: 'currency',
                              currency: transaction.currency
                            }).format(transaction.amount)}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center space-x-2">
                            {getStatusIcon(transaction.status)}
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(transaction.status)}`}>
                              {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                            </span>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {transaction.createdAt.toLocaleDateString()}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center space-x-2">
                            <button className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors">
                              <Eye className="w-4 h-4" />
                            </button>
                            <button className="p-2 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 rounded-lg transition-colors">
                              <RefreshCw className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'analytics':
        return (
          <div className="space-y-6">
            {/* Payment Analytics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                    KES 2.1M
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Total Revenue</p>
                  <p className="text-sm text-green-600 dark:text-green-400">+12% vs last month</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                    96.3%
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Success Rate</p>
                  <p className="text-sm text-green-600 dark:text-green-400">+2.1% vs last month</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                    847
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Transactions</p>
                  <p className="text-sm text-green-600 dark:text-green-400">+45 today</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-amber-600 dark:text-amber-400 mb-2">
                    KES 2,478
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Avg. Transaction</p>
                  <p className="text-sm text-blue-600 dark:text-blue-400">Stable</p>
                </div>
              </div>
            </div>

            {/* Method Performance */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Payment Method Performance</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Smartphone className="w-5 h-5 text-green-500" />
                      <span className="font-medium text-gray-900 dark:text-white">M-Pesa</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-gray-900 dark:text-white">65.2%</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">of volume</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <CreditCard className="w-5 h-5 text-blue-500" />
                      <span className="font-medium text-gray-900 dark:text-white">Paystack</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-gray-900 dark:text-white">34.8%</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">of volume</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Success Rates</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600 dark:text-gray-400">M-Pesa STK Push</span>
                    <span className="font-bold text-green-600 dark:text-green-400">94.5%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Paystack Cards</span>
                    <span className="font-bold text-green-600 dark:text-green-400">98.1%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Paystack Bank Transfer</span>
                    <span className="font-bold text-green-600 dark:text-green-400">99.2%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Payment Management</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Configure and monitor M-Pesa and Paystack payment integrations
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-sm">
            <div className={`w-3 h-3 rounded-full ${testMode ? 'bg-yellow-500' : 'bg-green-500'}`}></div>
            <span className="text-gray-600 dark:text-gray-400">
              {testMode ? 'Test Mode' : 'Live Mode'}
            </span>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Revenue</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">KES 2.1M</p>
            </div>
            <DollarSign className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Transactions</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">847</p>
            </div>
            <BarChart3 className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Success Rate</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">96.3%</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Active Users</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">1,247</p>
            </div>
            <Users className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'configuration', label: 'Configuration', icon: Settings },
              { id: 'transactions', label: 'Transactions', icon: CreditCard },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default PaymentManagement;