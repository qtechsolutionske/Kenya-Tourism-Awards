import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, Award, ArrowRight, Shield, Users, Star, Trophy } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface LoginFormProps {
  onSwitchToSignup: () => void;
  onClose?: () => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onSwitchToSignup, onClose }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    try {
      await login(email, password);
    } catch (error) {
      setError('Invalid email or password. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const demoAccounts = [
    { role: 'SuperAdmin', email: 'superadmin@kta.com', icon: Shield, color: 'from-red-500 to-pink-500' },
    { role: 'Admin', email: 'admin@kta.com', icon: Users, color: 'from-purple-500 to-indigo-500' },
    { role: 'Jury', email: 'jury@kta.com', icon: Award, color: 'from-blue-500 to-cyan-500' },
    { role: 'Voter', email: 'voter@kta.com', icon: Star, color: 'from-green-500 to-emerald-500' },
    { role: 'Nominee', email: 'nominee@kta.com', icon: Trophy, color: 'from-blue-500 to-indigo-500' }
  ];

  return (
    <div className="min-h-screen flex">
      {/* Close button for modal mode */}
      {onClose && (
        <button
          onClick={onClose}
          className="fixed top-4 right-4 z-50 w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-colors"
        >
          ×
        </button>
      )}
      
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-slate-900 via-amber-900 to-slate-900 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23ffffff%22 fill-opacity=%220.05%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-20 w-32 h-32 bg-amber-400/10 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-32 right-16 w-24 h-24 bg-orange-400/10 rounded-full blur-lg animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-8 w-16 h-16 bg-red-400/10 rounded-full blur-md animate-pulse delay-500"></div>

        <div className="relative z-10 flex flex-col justify-center px-8 lg:px-12 text-white">
          {/* Logo */}
          <div className="mb-8">
            <img 
              src="/Kenya Tourism Awards Gold Logo.svg" 
              alt="Kenya Tourism Awards" 
              className="h-20 lg:h-24 w-auto mb-6 filter brightness-0 invert"
              onError={(e) => {
                e.currentTarget.src = "/Kenya Tourism Awards Black Logo.svg";
              }}
            />
            <h1 className="text-3xl lg:text-4xl font-bold mb-2">Kenya Tourism Awards</h1>
            <p className="text-lg lg:text-xl text-amber-200">Celebrating Excellence in Tourism</p>
          </div>

          {/* Features */}
          <div className="space-y-4 lg:space-y-6">
            <div className="flex items-center space-x-4">
              <div className="w-10 lg:w-12 h-10 lg:h-12 bg-white/10 rounded-lg flex items-center justify-center">
                <Award className="w-5 lg:w-6 h-5 lg:h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-sm lg:text-base">28 Award Categories</h3>
                <p className="text-amber-200 text-xs lg:text-sm">Recognizing excellence across tourism sectors</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="w-10 lg:w-12 h-10 lg:h-12 bg-white/10 rounded-lg flex items-center justify-center">
                <Users className="w-5 lg:w-6 h-5 lg:h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-sm lg:text-base">Industry Participation</h3>
                <p className="text-amber-200 text-xs lg:text-sm">Connecting tourism stakeholders nationwide</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="w-10 lg:w-12 h-10 lg:h-12 bg-white/10 rounded-lg flex items-center justify-center">
                <Star className="w-5 lg:w-6 h-5 lg:h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-sm lg:text-base">Prestigious Recognition</h3>
                <p className="text-amber-200 text-xs lg:text-sm">Kenya's premier tourism excellence awards</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="flex-1 flex flex-col justify-center px-4 sm:px-8 lg:px-16 bg-white dark:bg-slate-900 relative">
        <div className="max-w-md mx-auto w-full">
          {/* Mobile Logo */}
          <div className="lg:hidden text-center mb-6">
            <img 
              src="/Kenya Tourism Awards Gold Logo.svg" 
              alt="Kenya Tourism Awards" 
              className="h-16 w-auto mx-auto mb-4"
              onError={(e) => {
                e.currentTarget.src = "/Kenya Tourism Awards Black Logo.svg";
              }}
            />
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">Kenya Tourism Awards</h1>
            <p className="text-sm text-amber-600 dark:text-amber-400 mt-1">Excellence • Innovation • Sustainability</p>
          </div>

          {/* Header */}
          <div className="text-center mb-6 lg:mb-8">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white mb-2">Welcome Back</h2>
            <p className="text-gray-600 dark:text-gray-400">Sign in to access your dashboard</p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-4 lg:mb-6 p-3 lg:p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4 lg:space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 lg:w-5 h-4 lg:h-5" />
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 lg:pl-12 pr-4 py-2.5 lg:py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors text-sm lg:text-base"
                  placeholder="Enter your email"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 lg:w-5 h-4 lg:h-5" />
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 lg:pl-12 pr-12 py-2.5 lg:py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors text-sm lg:text-base"
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 lg:w-5 h-4 lg:h-5" /> : <Eye className="w-4 lg:w-5 h-4 lg:h-5" />}
                </button>
              </div>
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 text-amber-500 bg-gray-100 border-gray-300 rounded focus:ring-amber-500 dark:focus:ring-amber-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
                <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">Remember me</span>
              </label>
              <button
                type="button"
                className="text-sm text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 font-medium transition-colors"
              >
                Forgot password?
              </button>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white py-2.5 lg:py-3 px-4 rounded-lg font-medium shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <div className="w-4 lg:w-5 h-4 lg:h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Demo Accounts */}
          <div className="mt-6 lg:mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300 dark:border-gray-600" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-slate-900 text-gray-500 dark:text-gray-400">Demo Accounts</span>
              </div>
            </div>
            <div className="mt-4 lg:mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {demoAccounts.map((account) => {
                const Icon = account.icon;
                return (
                  <button
                    key={account.role}
                    onClick={() => {
                      setEmail(account.email);
                      setPassword('demo123');
                    }}
                    className="flex items-center space-x-2 p-2 sm:p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-left w-full"
                  >
                    <div className={`w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8 bg-gradient-to-r ${account.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-3 sm:w-3 lg:w-4 h-3 sm:h-3 lg:h-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0 overflow-hidden">
                      <div className="text-xs sm:text-sm font-medium text-gray-900 dark:text-white truncate">{account.role}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">Demo</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sign Up Link */}
          <div className="mt-6 lg:mt-8 text-center">
            <p className="text-gray-600 dark:text-gray-400">
              Don't have an account?{' '}
              <button
                onClick={onSwitchToSignup}
                className="text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 font-medium transition-colors"
              >
                Sign up here
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;