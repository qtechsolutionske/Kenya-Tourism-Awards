import React from 'react';
import { Award, Users, Vote, Calendar, Trophy, TrendingUp, Clock, Star, ArrowRight, BarChart3, FileText, UserCheck, Settings, Bell, Activity, Target, Zap, Shield, Globe } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  const getDashboardStats = () => {
    if (user?.role === 'superadmin' || user?.role === 'admin') {
      return [
        {
          title: 'Total Entries',
          value: 247,
          change: '247 entries submitted',
          changeType: 'positive' as const,
          icon: Award,
          color: 'from-amber-500 to-orange-500'
        },
        {
          title: 'Active Voters',
          value: 1842,
          change: '+156 today',
          changeType: 'positive' as const,
          icon: Users,
          color: 'from-blue-500 to-indigo-500'
        },
        {
          title: 'Votes Cast',
          value: 12847,
          change: '78% participation',
          changeType: 'positive' as const,
          icon: Vote,
          color: 'from-green-500 to-emerald-500'
        },
        {
          title: 'System Health',
          value: '99.9%',
          change: 'All systems operational',
          changeType: 'positive' as const,
          icon: Shield,
          color: 'from-purple-500 to-pink-500'
        }
      ];
    } else if (user?.role === 'jury') {
      return [
        {
          title: 'Assigned Categories',
          value: 8,
          change: '6 completed',
          changeType: 'positive' as const,
          icon: Award,
          color: 'from-amber-500 to-orange-500'
        },
        {
          title: 'Pending Reviews',
          value: 15,
          change: '23 total nominations',
          changeType: 'neutral' as const,
          icon: Clock,
          color: 'from-orange-500 to-red-500'
        },
        {
          title: 'Evaluations Complete',
          value: 45,
          change: '75% progress',
          changeType: 'positive' as const,
          icon: Trophy,
          color: 'from-green-500 to-emerald-500'
        },
        {
          title: 'Average Score',
          value: 8.2,
          change: 'Out of 10',
          changeType: 'neutral' as const,
          icon: Star,
          color: 'from-blue-500 to-indigo-500'
        }
      ];
    } else {
      return [
        {
          title: 'Available Categories',
          value: 28,
          change: 'Vote in all',
          changeType: 'neutral' as const,
          icon: Award,
          color: 'from-amber-500 to-orange-500'
        },
        {
          title: 'Your Votes',
          value: 12,
          change: '16 remaining',
          changeType: 'neutral' as const,
          icon: Vote,
          color: 'from-green-500 to-emerald-500'
        },
        {
          title: 'Voting Ends In',
          value: '7 days',
          change: 'Don\'t miss out!',
          changeType: 'negative' as const,
          icon: Clock,
          color: 'from-red-500 to-pink-500'
        },
        {
          title: 'Total Participants',
          value: 1842,
          change: 'Join the community',
          changeType: 'positive' as const,
          icon: Users,
          color: 'from-teal-500 to-cyan-500'
        }
      ];
    }
  };

  const getRecentActivity = () => {
    if (user?.role === 'superadmin' || user?.role === 'admin') {
      return [
        { action: 'New entry submitted', details: 'Best Luxury Hotel - Hemingways Nairobi', time: '2 minutes ago', type: 'entry' },
        { action: 'Entry evaluation completed', details: 'Safari Lodge category - Dr. Sarah Mwangi', time: '15 minutes ago', type: 'evaluation' },
        { action: 'System backup completed', details: 'All data successfully backed up', time: '1 hour ago', type: 'system' },
        { action: 'New user registered', details: 'Tourism operator from Mombasa', time: '3 hours ago', type: 'user' }
      ];
    } else if (user?.role === 'jury') {
      return [
        { action: 'Evaluation submitted', details: 'Best Beach Resort - Alfajiri Villas (Score: 8.5)', time: '30 minutes ago', type: 'evaluation' },
        { action: 'New nomination assigned', details: 'Best Safari Lodge - Angama Mara', time: '2 hours ago', type: 'assignment' },
        { action: 'Evaluation reminder', details: '3 nominations pending review', time: '1 day ago', type: 'reminder' }
      ];
    } else {
      return [
        { action: 'Vote cast', details: 'Best Luxury Hotel category', time: '1 hour ago', type: 'vote' },
        { action: 'Profile updated', details: 'Contact information updated', time: '2 days ago', type: 'profile' },
        { action: 'Welcome message', details: 'Thank you for joining KTA 2025', time: '1 week ago', type: 'welcome' }
      ];
    }
  };

  const stats = getDashboardStats();
  const recentActivity = getRecentActivity();

  const getRoleTitle = () => {
    switch (user?.role) {
      case 'superadmin':
        return 'Super Administrator Dashboard';
      case 'admin':
        return 'Administrator Dashboard';
      case 'jury':
        return 'Jury Member Portal';
      default:
        return 'Voter Dashboard';
    }
  };

  const getRoleDescription = () => {
    switch (user?.role) {
      case 'superadmin':
        return 'Complete system oversight and management capabilities for Kenya Tourism Awards 2025.';
      case 'admin':
        return 'Manage nominations, users, and oversee the awards process with comprehensive administrative tools.';
      case 'jury':
        return 'Evaluate nominations and provide expert assessment for award categories in your expertise area.';
      case 'nominee':
        return 'Manage your nomination profile, track voting progress, and share your voting link with supporters.';
      default:
        return 'Participate in voting and celebrate excellence in Kenya\'s tourism industry.';
    }
  };

  return (
    <>
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
        {/* Header Section */}
        <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 shadow-sm pt-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 overflow-x-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 sm:space-x-4 min-w-0">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-amber-400 via-orange-500 to-red-500 rounded-xl sm:rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0">
                <Trophy className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white truncate">
                  {getRoleTitle()}
                </h1>
                <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">
                  {getRoleDescription()}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4 flex-shrink-0">
              <div className="text-right">
                <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">Welcome back,</p>
                <p className="text-sm sm:text-lg font-semibold text-gray-900 dark:text-white truncate max-w-32 sm:max-w-none">{user?.name}</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm sm:text-lg">
                  {user?.name?.charAt(0) || 'U'}
                </span>
              </div>
            </div>
          </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 overflow-x-hidden">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 mb-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white dark:bg-slate-800 rounded-lg sm:rounded-xl shadow-sm border border-gray-200 dark:border-slate-700 p-3 sm:p-4 lg:p-6 hover:shadow-md transition-all duration-300">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-2 sm:p-3 rounded-lg sm:rounded-xl bg-gradient-to-r ${stat.color} shadow-lg`}>
                    <Icon className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-white" />
                  </div>
                  <div className="text-right">
                    <div className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</div>
                    <div className={`text-xs sm:text-sm font-medium ${
                      stat.changeType === 'positive' 
                        ? 'text-green-600 dark:text-green-400' 
                        : stat.changeType === 'negative'
                        ? 'text-red-600 dark:text-red-400'
                        : 'text-gray-600 dark:text-gray-400'
                    }`}>
                      {stat.change}
                    </div>
                  </div>
                </div>
                <h3 className="text-sm sm:text-base lg:text-lg font-semibold text-gray-900 dark:text-white line-clamp-2">{stat.title}</h3>
              </div>
            );
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Actions */}
            <div className="bg-white dark:bg-slate-800 rounded-lg sm:rounded-xl shadow-sm border border-gray-200 dark:border-slate-700 p-4 sm:p-6">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white mb-4 sm:mb-6 flex items-center space-x-2">
                <Zap className="w-5 h-5 text-amber-500" />
                <span>Quick Actions</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                {user?.role === 'superadmin' || user?.role === 'admin' ? (
                  <>
                    <button className="group bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 hover:from-amber-100 hover:to-orange-100 dark:hover:from-amber-900/30 dark:hover:to-orange-900/30 border border-amber-200 dark:border-amber-800 rounded-lg sm:rounded-xl p-4 sm:p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Award className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                          <div>
                            <div className="text-sm sm:text-base font-semibold text-amber-900 dark:text-amber-400">Review Entries</div>
                            <div className="text-xs sm:text-sm text-amber-700 dark:text-amber-500">247 submissions</div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600 dark:text-amber-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                    <button className="group bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 hover:from-blue-100 hover:to-indigo-100 dark:hover:from-blue-900/30 dark:hover:to-indigo-900/30 border border-blue-200 dark:border-blue-800 rounded-xl p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                          <div>
                            <div className="font-semibold text-blue-900 dark:text-blue-400">Manage Users</div>
                            <div className="text-sm text-blue-700 dark:text-blue-500">1,842 active users</div>
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                    <button className="group bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 hover:from-green-100 hover:to-emerald-100 dark:hover:from-green-900/30 dark:hover:to-emerald-900/30 border border-green-200 dark:border-green-800 rounded-xl p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <BarChart3 className="w-6 h-6 text-green-600 dark:text-green-400" />
                          <div>
                            <div className="font-semibold text-green-900 dark:text-green-400">View Analytics</div>
                            <div className="text-sm text-green-700 dark:text-green-500">Performance insights</div>
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-green-600 dark:text-green-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                    <button className="group bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 hover:from-purple-100 hover:to-pink-100 dark:hover:from-purple-900/30 dark:hover:to-pink-900/30 border border-purple-200 dark:border-purple-800 rounded-xl p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Settings className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                          <div>
                            <div className="font-semibold text-purple-900 dark:text-purple-400">System Settings</div>
                            <div className="text-sm text-purple-700 dark:text-purple-500">Configure platform</div>
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-purple-600 dark:text-purple-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  </>
                ) : user?.role === 'jury' ? (
                  <>
                    <button className="group bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 hover:from-amber-100 hover:to-orange-100 dark:hover:from-amber-900/30 dark:hover:to-orange-900/30 border border-amber-200 dark:border-amber-800 rounded-lg sm:rounded-xl p-4 sm:p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Award className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                          <div>
                            <div className="text-sm sm:text-base font-semibold text-amber-900 dark:text-amber-400">Continue Evaluations</div>
                            <div className="text-xs sm:text-sm text-amber-700 dark:text-amber-500">15 entries pending</div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600 dark:text-amber-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                    <button className="group bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 hover:from-blue-100 hover:to-indigo-100 dark:hover:from-blue-900/30 dark:hover:to-indigo-900/30 border border-blue-200 dark:border-blue-800 rounded-xl p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                          <div>
                            <div className="font-semibold text-blue-900 dark:text-blue-400">View Guidelines</div>
                            <div className="text-sm text-blue-700 dark:text-blue-500">Evaluation criteria</div>
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  </>
                ) : (
                  <>
                    <button className="group bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 hover:from-green-100 hover:to-emerald-100 dark:hover:from-green-900/30 dark:hover:to-emerald-900/30 border border-green-200 dark:border-green-800 rounded-lg sm:rounded-xl p-4 sm:p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Vote className="w-6 h-6 text-green-600 dark:text-green-400" />
                          <div>
                            <div className="text-sm sm:text-base font-semibold text-green-900 dark:text-green-400">Cast Your Votes</div>
                            <div className="text-xs sm:text-sm text-green-700 dark:text-green-500">16 categories remaining</div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 text-green-600 dark:text-green-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                    <button className="group bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 hover:from-blue-100 hover:to-indigo-100 dark:hover:from-blue-900/30 dark:hover:to-indigo-900/30 border border-blue-200 dark:border-blue-800 rounded-xl p-6 text-left transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Calendar className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                          <div>
                            <div className="font-semibold text-blue-900 dark:text-blue-400">View Vote History</div>
                            <div className="text-sm text-blue-700 dark:text-blue-500">Track your voting</div>
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white dark:bg-slate-800 rounded-lg sm:rounded-xl shadow-sm border border-gray-200 dark:border-slate-700 p-4 sm:p-6">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white mb-4 sm:mb-6 flex items-center space-x-2">
                <Activity className="w-5 h-5 text-blue-500" />
                <span>Recent Activity</span>
              </h2>
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start space-x-3 sm:space-x-4 p-3 sm:p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm sm:text-base font-medium text-gray-900 dark:text-white truncate">{activity.action}</p>
                      <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 line-clamp-2">{activity.details}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4 sm:space-y-6">
            {/* Profile Card */}
            <div className="bg-white dark:bg-slate-800 rounded-lg sm:rounded-xl shadow-sm border border-gray-200 dark:border-slate-700 p-4 sm:p-6">
              <div className="text-center">
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-lg sm:text-xl lg:text-2xl">
                    {user?.name?.charAt(0) || 'U'}
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white truncate">{user?.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">{user?.role}</p>
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-1 truncate">{user?.email}</p>
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-slate-700">
                  <button className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white py-2 px-4 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors text-sm sm:text-base">
                    Edit Profile
                  </button>
                </div>
              </div>
            </div>

            {/* Important Dates */}
            <div className="bg-white dark:bg-slate-800 rounded-lg sm:rounded-xl shadow-sm border border-gray-200 dark:border-slate-700 p-4 sm:p-6">
              <h3 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center space-x-2">
                <Target className="w-5 h-5 text-red-500" />
                <span>Important Dates</span>
              </h3>
              <div className="space-y-3">
                {[
                  { event: 'Nominations Close', date: 'Feb 15', urgent: true },
                  { event: 'Jury Evaluation', date: 'Feb 28', urgent: false },
                  { event: 'Public Voting', date: 'Mar 1-10', urgent: false },
                  { event: 'Gala Ceremony', date: 'Mar 15', urgent: false }
                ].map((deadline, index) => (
                  <div key={index} className={`flex items-center justify-between p-2 sm:p-3 rounded-lg ${
                    deadline.urgent 
                      ? 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800' 
                      : 'bg-gray-50 dark:bg-slate-700/50'
                  }`}>
                    <span className={`text-sm sm:text-base font-medium ${
                      deadline.urgent 
                        ? 'text-red-900 dark:text-red-400' 
                        : 'text-gray-900 dark:text-white'
                    }`}>
                      {deadline.event}
                    </span>
                    <span className={`text-xs sm:text-sm ${
                      deadline.urgent 
                        ? 'text-red-600 dark:text-red-500' 
                        : 'text-gray-600 dark:text-gray-400'
                    }`}>
                      {deadline.date}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* System Status */}
            <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg sm:rounded-xl shadow-sm p-4 sm:p-6 text-white">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-2 bg-white/20 rounded-lg flex-shrink-0">
                  <Shield className="w-5 h-5" />
                </div>
                <h3 className="text-base sm:text-lg font-bold">System Status</h3>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-green-100 text-sm sm:text-base">Server Uptime</span>
                  <span className="font-bold text-sm sm:text-base">99.9%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-green-100 text-sm sm:text-base">Response Time</span>
                  <span className="font-bold text-sm sm:text-base">245ms</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-green-100 text-sm sm:text-base">Active Users</span>
                  <span className="font-bold text-sm sm:text-base">1,842</span>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="flex items-center space-x-2 text-green-100">
                  <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
                  <span className="text-xs sm:text-sm">All systems operational</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;