import React, { useState, useEffect } from 'react';
import { CreditCard, Loader2, CheckCircle, ExternalLink, ArrowLeft, DollarSign, Shield } from 'lucide-react';
import { usePayments } from '../../hooks/usePayments';

interface PaystackPaymentProps {
  amount: number;
  currency: string;
  orderId: string;
  orderDescription: string;
  onSuccess: (paymentData: any) => void;
  onError: (error: string) => void;
  onCancel: () => void;
}

declare global {
  interface Window {
    PaystackPop: {
      setup: (config: any) => {
        openIframe: () => void;
      };
    };
  }
}

const PaystackPayment: React.FC<PaystackPaymentProps> = ({
  amount,
  currency,
  orderId,
  orderDescription,
  onSuccess,
  onError,
  onCancel
}) => {
  const [email, setEmail] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState<'email' | 'loading' | 'paying'>('email');
  const [authorizationUrl, setAuthorizationUrl] = useState<string>('');
  const [paymentId, setPaymentId] = useState<string>('');
  const [useInline, setUseInline] = useState(true);
  const [paystackLoaded, setPaystackLoaded] = useState(false);
  const { initiatePaystackPayment, verifyPaystackPayment } = usePayments();

  useEffect(() => {
    // Load Paystack inline script
    const script = document.createElement('script');
    script.src = 'https://js.paystack.co/v1/inline.js';
    script.onload = () => setPaystackLoaded(true);
    script.onerror = () => {
      console.warn('Failed to load Paystack inline script, will use redirect');
      setUseInline(false);
    };
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setCurrentStep('loading');

    try {
      const response = await initiatePaystackPayment(
        email,
        amount,
        orderId,
        currency,
        {
          order_description: orderDescription,
          customer_email: email
        }
      );

      if (response.success && response.data) {
        setAuthorizationUrl(response.data.authorizationUrl);
        setPaymentId(response.data.paymentId);
        
        if (useInline && paystackLoaded && window.PaystackPop) {
          openInlinePayment(response.data);
        } else {
          setCurrentStep('paying');
        }
      } else {
        throw new Error(response.error || 'Failed to initialize payment');
      }
    } catch (error) {
      onError(error instanceof Error ? error.message : 'Payment initialization failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const openInlinePayment = (paymentData: any) => {
    const popup = window.PaystackPop.setup({
      key: paymentData.publicKey,
      email: email,
      amount: amount * 100, // Convert to kobo/cents
      currency: currency,
      ref: paymentData.reference,
      callback: function(response: any) {
        console.log('Paystack callback:', response);
        verifyPayment(response.reference);
      },
      onClose: function() {
        onCancel();
      }
    });

    popup.openIframe();
  };

  const verifyPayment = async (reference: string) => {
    setCurrentStep('loading');
    setIsProcessing(true);

    try {
      const response = await verifyPaystackPayment(reference);
      
      if (response.success && response.data) {
        if (response.data.status === 'success') {
          onSuccess(response.data);
        } else {
          onError(response.data.failedReason || 'Payment verification failed');
        }
      } else {
        throw new Error(response.error || 'Payment verification failed');
      }
    } catch (error) {
      onError(error instanceof Error ? error.message : 'Payment verification failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRedirectPayment = () => {
    if (authorizationUrl) {
      window.open(authorizationUrl, '_blank');
      setCurrentStep('paying');
    }
  };

  const formatAmount = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      {currentStep === 'email' && (
        <form onSubmit={handleEmailSubmit} className="space-y-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-blue-100 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <CreditCard className="w-10 h-10 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              Pay with Paystack
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Secure payment with card, bank transfer, or mobile money
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="your@email.com"
              required
            />
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
              Receipt will be sent to this email address
            </p>
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 dark:text-blue-400 mb-2">
              Supported Payment Methods:
            </h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-blue-800 dark:text-blue-300">
              <div>✓ Visa & Mastercard</div>
              <div>✓ Verve Cards</div>
              <div>✓ Bank Transfer</div>
              <div>✓ M-Pesa (via Paystack)</div>
              <div>✓ Airtel Money</div>
              <div>✓ USSD</div>
            </div>
          </div>

          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <span className="font-medium text-gray-900 dark:text-white">Total Amount</span>
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {formatAmount(amount, currency)}
              </span>
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!email || isProcessing}
              className="flex-1 bg-blue-600 text-white px-4 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
            >
              {isProcessing ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Shield className="w-5 h-5" />
              )}
              <span>{isProcessing ? 'Initializing...' : 'Continue to Payment'}</span>
            </button>
          </div>
        </form>
      )}

      {currentStep === 'loading' && (
        <div className="text-center py-12">
          <Loader2 className="w-16 h-16 text-blue-500 animate-spin mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            {useInline ? 'Loading Payment Form' : 'Processing Payment'}
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Please wait while we set up your secure payment...
          </p>
        </div>
      )}

      {currentStep === 'paying' && !useInline && (
        <div className="text-center space-y-6">
          <div className="w-20 h-20 bg-blue-100 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center mx-auto">
            <ExternalLink className="w-10 h-10 text-blue-600 dark:text-blue-400" />
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              Complete Payment
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Click the button below to open the secure Paystack payment page
            </p>
          </div>

          <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4 mb-6">
            <p className="text-sm text-yellow-800 dark:text-yellow-300">
              <strong>Important:</strong> After completing payment on Paystack, 
              return to this page to verify your transaction status.
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={handleRedirectPayment}
              className="w-full bg-blue-600 text-white px-4 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <ExternalLink className="w-5 h-5" />
              <span>Open Paystack Payment Page</span>
            </button>

            <button
              onClick={() => paymentId && verifyPayment(paymentId)}
              disabled={isProcessing}
              className="w-full border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-center space-x-2"
            >
              {isProcessing ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <CheckCircle className="w-5 h-5" />
              )}
              <span>{isProcessing ? 'Verifying...' : 'I\'ve Completed Payment'}</span>
            </button>

            <button
              onClick={onCancel}
              className="w-full text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
            >
              Cancel Payment
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaystackPayment;