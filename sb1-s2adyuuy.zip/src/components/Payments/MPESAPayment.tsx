import React, { useState, useEffect } from 'react';
import { Smartphone, Loader2, CheckCircle, AlertCircle, Phone, Info } from 'lucide-react';
import { usePayments } from '../../hooks/usePayments';

interface MPESAPaymentProps {
  amount: number;
  currency: string;
  orderId: string;
  orderDescription: string;
  onSuccess: (paymentData: any) => void;
  onError: (error: string) => void;
  onCancel: () => void;
}

const MPESAPayment: React.FC<MPESAPaymentProps> = ({
  amount,
  currency,
  orderId,
  orderDescription,
  onSuccess,
  onError,
  onCancel
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState<'phone' | 'confirm' | 'waiting' | 'checking'>('phone');
  const [paymentId, setPaymentId] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes timeout
  const { initiateMPESAPayment, checkPaymentStatus } = usePayments();

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (currentStep === 'waiting' && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            onError('Payment timeout. Please try again.');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [currentStep, timeLeft, onError]);

  useEffect(() => {
    let statusCheckInterval: NodeJS.Timeout;

    if (currentStep === 'checking' && paymentId) {
      statusCheckInterval = setInterval(async () => {
        try {
          const statusResponse = await checkPaymentStatus(paymentId);
          
          if (statusResponse.success && statusResponse.data) {
            const { status } = statusResponse.data;
            
            if (status === 'success') {
              clearInterval(statusCheckInterval);
              onSuccess(statusResponse.data);
            } else if (status === 'failed') {
              clearInterval(statusCheckInterval);
              onError(statusResponse.data.failedReason || 'Payment failed');
            }
          }
        } catch (error) {
          console.error('Status check error:', error);
        }
      }, 3000); // Check every 3 seconds
    }

    return () => {
      if (statusCheckInterval) clearInterval(statusCheckInterval);
    };
  }, [currentStep, paymentId, checkPaymentStatus, onSuccess, onError]);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      const response = await initiateMPESAPayment(
        phoneNumber,
        amount,
        orderId,
        'KTA2025',
        orderDescription
      );

      if (response.success && response.data) {
        setPaymentId(response.data.paymentId);
        setCurrentStep('waiting');
      } else {
        throw new Error(response.error || 'Failed to initiate payment');
      }
    } catch (error) {
      onError(error instanceof Error ? error.message : 'Payment initiation failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmPayment = () => {
    setCurrentStep('checking');
  };

  const formatPhone = (phone: string) => {
    // Remove non-digits and format for display
    const digits = phone.replace(/\D/g, '');
    if (digits.startsWith('254')) {
      return digits.replace(/(\d{3})(\d{3})(\d{3})(\d{3})/, '+$1 $2 $3 $4');
    } else if (digits.startsWith('0')) {
      return digits.replace(/(\d{1})(\d{3})(\d{3})(\d{3})/, '$1$2 $3 $4');
    }
    return digits;
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {currentStep === 'phone' && (
        <form onSubmit={handlePhoneSubmit} className="space-y-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-green-100 dark:bg-green-900/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Smartphone className="w-10 h-10 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              Pay with M-Pesa
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Enter your M-Pesa number to receive a payment prompt
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              M-Pesa Number
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full pl-11 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="0712345678 or +254712345678"
                required
              />
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
              Enter the phone number registered with M-Pesa
            </p>
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
              <div className="text-sm text-blue-800 dark:text-blue-300">
                <p className="font-medium mb-1">How M-Pesa payment works:</p>
                <ol className="list-decimal list-inside space-y-1 text-blue-700 dark:text-blue-400">
                  <li>Enter your M-Pesa registered number</li>
                  <li>You'll receive an STK push notification</li>
                  <li>Enter your M-Pesa PIN to complete payment</li>
                  <li>Payment confirmation will be instant</li>
                </ol>
              </div>
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!phoneNumber || isProcessing}
              className="flex-1 bg-green-600 text-white px-4 py-3 rounded-lg font-medium hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
            >
              {isProcessing ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Smartphone className="w-5 h-5" />
              )}
              <span>{isProcessing ? 'Sending...' : 'Send M-Pesa Prompt'}</span>
            </button>
          </div>
        </form>
      )}

      {currentStep === 'waiting' && (
        <div className="text-center space-y-6">
          <div className="w-20 h-20 bg-green-100 dark:bg-green-900/20 rounded-2xl flex items-center justify-center mx-auto">
            <Smartphone className="w-10 h-10 text-green-600 dark:text-green-400" />
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              Check Your Phone
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              We've sent an M-Pesa payment request to <strong>{formatPhone(phoneNumber)}</strong>
            </p>
            <p className="text-sm text-amber-600 dark:text-amber-400">
              Time remaining: {formatTime(timeLeft)}
            </p>
          </div>

          <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6">
            <h4 className="font-semibold text-green-900 dark:text-green-400 mb-3">
              Complete your payment:
            </h4>
            <ol className="text-sm text-green-800 dark:text-green-300 space-y-2 text-left max-w-sm mx-auto">
              <li className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold">1</div>
                <span>Check your phone for the M-Pesa prompt</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold">2</div>
                <span>Enter your M-Pesa PIN</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold">3</div>
                <span>Confirm the transaction</span>
              </li>
            </ol>
          </div>

          <div className="space-y-3">
            <button
              onClick={handleConfirmPayment}
              className="w-full bg-green-600 text-white px-4 py-3 rounded-lg font-medium hover:bg-green-700 transition-colors"
            >
              I've Completed Payment
            </button>
            <button
              onClick={onCancel}
              className="w-full border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel Payment
            </button>
          </div>
        </div>
      )}

      {currentStep === 'checking' && (
        <div className="text-center py-12">
          <Loader2 className="w-16 h-16 text-green-500 animate-spin mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            Verifying Payment
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Please wait while we confirm your M-Pesa payment...
          </p>
        </div>
      )}
    </div>
  );
};

export default MPESAPayment;