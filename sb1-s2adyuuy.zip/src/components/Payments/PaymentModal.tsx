import React, { useState, useEffect } from 'react';
import { X, CreditCard, Smartphone, Loader2, CheckCircle, AlertCircle, ArrowLeft } from 'lucide-react';
import { usePayments } from '../../hooks/usePayments';
import { PaymentMethod } from '../../types/payment';
import MPESAPayment from './MPESAPayment';
import PaystackPayment from './PaystackPayment';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  currency?: string;
  orderId: string;
  orderDetails: {
    description: string;
    items: Array<{
      name: string;
      quantity: number;
      price: number;
    }>;
  };
  onPaymentSuccess: (paymentData: any) => void;
  onPaymentError: (error: string) => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  amount,
  currency = 'KES',
  orderId,
  orderDetails,
  onPaymentSuccess,
  onPaymentError
}) => {
  const { getPaymentMethods, isLoading: methodsLoading } = usePayments();
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);
  const [step, setStep] = useState<'select' | 'pay' | 'processing' | 'success' | 'error'>('select');

  useEffect(() => {
    if (isOpen) {
      loadPaymentMethods();
      setStep('select');
      setSelectedMethod(null);
    }
  }, [isOpen]);

  const loadPaymentMethods = async () => {
    const methods = await getPaymentMethods();
    setPaymentMethods(methods);
  };

  const handleMethodSelect = (method: string) => {
    setSelectedMethod(method);
    setStep('pay');
  };

  const handlePaymentSuccess = (paymentData: any) => {
    setStep('success');
    setTimeout(() => {
      onPaymentSuccess(paymentData);
      onClose();
    }, 2000);
  };

  const handlePaymentError = (error: string) => {
    setStep('error');
    onPaymentError(error);
  };

  const handleBack = () => {
    if (step === 'pay') {
      setStep('select');
      setSelectedMethod(null);
    } else if (step === 'error') {
      setStep('select');
      setSelectedMethod(null);
    }
  };

  const formatAmount = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {step !== 'select' && (
                <button
                  onClick={handleBack}
                  className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {step === 'select' && 'Choose Payment Method'}
                  {step === 'pay' && 'Complete Payment'}
                  {step === 'processing' && 'Processing Payment'}
                  {step === 'success' && 'Payment Successful'}
                  {step === 'error' && 'Payment Failed'}
                </h2>
                <p className="text-gray-600 dark:text-gray-400">
                  {formatAmount(amount, currency)} • {orderDetails.description}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {step === 'select' && (
            <div className="space-y-6">
              {/* Order Summary */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-3">Order Summary</h3>
                <div className="space-y-2">
                  {orderDetails.items.map((item, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">
                        {item.name} (x{item.quantity})
                      </span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {formatAmount(item.price * item.quantity, currency)}
                      </span>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-gray-200 dark:border-gray-600">
                    <div className="flex items-center justify-between font-bold text-lg">
                      <span className="text-gray-900 dark:text-white">Total</span>
                      <span className="text-amber-600 dark:text-amber-400">
                        {formatAmount(amount, currency)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Select Payment Method</h3>
                {methodsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
                    <span className="ml-2 text-gray-600 dark:text-gray-400">Loading payment methods...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {paymentMethods.map((method) => (
                      <button
                        key={method.id}
                        onClick={() => handleMethodSelect(method.method)}
                        className="w-full p-4 border-2 border-gray-200 dark:border-gray-600 rounded-xl hover:border-amber-500 dark:hover:border-amber-400 transition-colors text-left group"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center group-hover:bg-amber-50 dark:group-hover:bg-amber-900/20 transition-colors">
                            {method.method === 'mpesa' ? (
                              <Smartphone className="w-6 h-6 text-green-600" />
                            ) : (
                              <CreditCard className="w-6 h-6 text-blue-600" />
                            )}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-900 dark:text-white group-hover:text-amber-900 dark:group-hover:text-amber-400 transition-colors">
                              {method.displayName}
                            </h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {method.description}
                            </p>
                            {method.fees.percentageFee > 0 || method.fees.transactionFee > 0 ? (
                              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                                Fee: {method.fees.percentageFee > 0 && `${method.fees.percentageFee}%`}
                                {method.fees.transactionFee > 0 && ` + ${formatAmount(method.fees.transactionFee, currency)}`}
                              </p>
                            ) : (
                              <p className="text-xs text-green-600 dark:text-green-400 mt-1">No additional fees</p>
                            )}
                          </div>
                          <div className="text-amber-600 dark:text-amber-400 group-hover:translate-x-1 transition-transform">
                            →
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {step === 'pay' && selectedMethod && (
            <div>
              {selectedMethod === 'mpesa' ? (
                <MPESAPayment
                  amount={amount}
                  currency={currency}
                  orderId={orderId}
                  orderDescription={orderDetails.description}
                  onSuccess={handlePaymentSuccess}
                  onError={handlePaymentError}
                  onCancel={() => setStep('select')}
                />
              ) : (
                <PaystackPayment
                  amount={amount}
                  currency={currency}
                  orderId={orderId}
                  orderDescription={orderDetails.description}
                  onSuccess={handlePaymentSuccess}
                  onError={handlePaymentError}
                  onCancel={() => setStep('select')}
                />
              )}
            </div>
          )}

          {step === 'processing' && (
            <div className="text-center py-12">
              <Loader2 className="w-16 h-16 text-amber-500 animate-spin mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                Processing Payment
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Please wait while we process your payment...
              </p>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                Payment Successful!
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Your payment has been processed successfully.
              </p>
            </div>
          )}

          {step === 'error' && (
            <div className="text-center py-12">
              <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                Payment Failed
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                {error || 'Something went wrong with your payment.'}
              </p>
              <button
                onClick={handleBack}
                className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors"
              >
                Try Again
              </button>
            </div>
          )}
        </div>

        {/* Footer - Payment Security */}
        {step === 'select' && (
          <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600">
            <div className="flex items-center justify-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span>256-bit SSL encrypted</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span>PCI DSS compliant</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                <span>Secure payments</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentModal;