import React, { useState, useEffect } from 'react';
import { Award, Calendar, Clock, ArrowRight, Lock, Unlock, Bell } from 'lucide-react';
import { useEntries } from '../../hooks/useEntries';
import { ProcessState } from '../../types/entries';

interface EntryCTAProps {
  variant?: 'hero' | 'banner' | 'card' | 'inline';
  category?: string;
  showCountdown?: boolean;
  className?: string;
}

const EntryCTA: React.FC<EntryCTAProps> = ({ 
  variant = 'card', 
  category,
  showCountdown = false,
  className = ''
}) => {
  const { processState, fetchProcessState } = useEntries();
  const [timeRemaining, setTimeRemaining] = useState<{
    days: number;
    hours: number;
    minutes: number;
  } | null>(null);

  useEffect(() => {
    fetchProcessState();
  }, [fetchProcessState]);

  useEffect(() => {
    if (!processState?.stageEnd || !showCountdown) return;

    const updateCountdown = () => {
      const now = new Date().getTime();
      const end = new Date(processState.stageEnd!).getTime();
      const difference = end - now;

      if (difference > 0) {
        setTimeRemaining({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
        });
      } else {
        setTimeRemaining(null);
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000 * 60); // Update every minute

    return () => clearInterval(interval);
  }, [processState?.stageEnd, showCountdown]);

  const getStageConfig = () => {
    switch (processState?.currentStage) {
      case 'setup':
        return {
          title: 'System Ready - Entries Opening Soon!',
          description: 'Entry forms are prepared and the system is ready to accept submissions.',
          buttonText: 'Preview Categories',
          buttonIcon: Award,
          isActive: true,
          urgency: 'info' as const,
          color: 'blue' as const
        };
      case 'entries_open':
        return {
          title: 'Entries Now Open!',
          description: 'Submit your entry for Kenya Tourism Awards 2025',
          buttonText: 'Submit Entry',
          buttonIcon: Award,
          isActive: true,
          urgency: 'normal' as const,
          color: 'green' as const
        };
      case 'entries_closed':
        return {
          title: 'Entry Submissions Closed',
          description: 'Entry period has ended. Jury review in progress.',
          buttonText: 'View Timeline',
          buttonIcon: Lock,
          isActive: false,
          urgency: 'closed' as const,
          color: 'red' as const
        };
      case 'jury_vetting':
        return {
          title: 'Jury Review Phase',
          description: 'Expert evaluation of all submissions is underway.',
          buttonText: 'View Process',
          buttonIcon: Clock,
          isActive: false,
          urgency: 'info' as const,
          color: 'blue' as const
        };
      case 'voting_open':
        return {
          title: 'Public Voting Open',
          description: 'Vote for your favorite nominees in each category.',
          buttonText: 'Vote Now',
          buttonIcon: Award,
          isActive: true,
          urgency: 'normal' as const,
          color: 'purple' as const
        };
      case 'voting_closed':
        return {
          title: 'Voting Closed',
          description: 'Voting has ended. Winners will be announced soon.',
          buttonText: 'View Results',
          buttonIcon: Trophy,
          isActive: false,
          urgency: 'info' as const,
          color: 'gray' as const
        };
      case 'results_announced':
        return {
          title: 'Winners Announced!',
          description: 'Congratulations to all winners and participants.',
          buttonText: 'View Winners',
          buttonIcon: Trophy,
          isActive: true,
          urgency: 'celebration' as const,
          color: 'amber' as const
        };
      default:
        return {
          title: 'Kenya Tourism Awards 2025',
          description: 'Celebrating excellence in tourism.',
          buttonText: 'Learn More',
          buttonIcon: Award,
          isActive: false,
          urgency: 'info' as const,
          color: 'gray' as const
        };
    }
  };

  const config = getStageConfig();
  const ButtonIcon = config.buttonIcon;

  const handleCTAClick = () => {
    if (!config.isActive) {
      // Redirect to timeline or status page
      window.location.href = '/about';
      return;
    }

    if (processState?.currentStage === 'entries_open') {
      if (category) {
        window.location.href = `/entry-form/${category}`;
      } else {
        window.location.href = '/entries';
      }
    } else if (processState?.currentStage === 'voting_open') {
      window.location.href = '/voting';
    } else if (processState?.currentStage === 'results_announced') {
      window.location.href = '/winners';
    }
  };

  // Hero variant - large banner style
  if (variant === 'hero') {
    return (
      <div className={`relative overflow-hidden rounded-2xl ${className}`}>
        <div className={`bg-gradient-to-r from-${config.color}-500 to-${config.color}-600 px-8 py-12 text-white`}>
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                <ButtonIcon className="w-10 h-10" />
              </div>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold mb-4">{config.title}</h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">{config.description}</p>
            
            {showCountdown && timeRemaining && (
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto mb-8">
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <div className="text-2xl font-bold">{timeRemaining.days}</div>
                  <div className="text-sm">Days</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <div className="text-2xl font-bold">{timeRemaining.hours}</div>
                  <div className="text-sm">Hours</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <div className="text-2xl font-bold">{timeRemaining.minutes}</div>
                  <div className="text-sm">Minutes</div>
                </div>
              </div>
            )}
            
            <button
              onClick={handleCTAClick}
              className={`bg-white text-${config.color}-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-50 transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-xl flex items-center space-x-3 mx-auto`}
            >
              <ButtonIcon className="w-6 h-6" />
              <span>{config.buttonText}</span>
              {config.isActive && <ArrowRight className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Banner variant - header/notification style
  if (variant === 'banner') {
    return (
      <div className={`${className} ${
        config.urgency === 'normal' ? `bg-${config.color}-600` :
        config.urgency === 'urgent' ? 'bg-red-600' :
        config.urgency === 'celebration' ? 'bg-gradient-to-r from-amber-500 to-orange-500' :
        'bg-gray-600'
      } text-white`}>
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <ButtonIcon className="w-5 h-5" />
              <div>
                <span className="font-medium">{config.title}</span>
                {timeRemaining && showCountdown && (
                  <span className="ml-4 text-white/80">
                    {timeRemaining.days}d {timeRemaining.hours}h {timeRemaining.minutes}m left
                  </span>
                )}
              </div>
            </div>
            <button
              onClick={handleCTAClick}
              className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2"
            >
              <span>{config.buttonText}</span>
              {config.isActive && <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Card variant - compact card style
  if (variant === 'card') {
    return (
      <div className={`${className} bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow`}>
        <div className={`bg-gradient-to-r from-${config.color}-500 to-${config.color}-600 p-4 text-white`}>
          <div className="flex items-center space-x-3">
            <ButtonIcon className="w-6 h-6" />
            <div>
              <h3 className="font-bold text-lg">{config.title}</h3>
              <p className="text-white/90 text-sm">{config.description}</p>
            </div>
          </div>
        </div>
        
        <div className="p-4">
          {showCountdown && timeRemaining && (
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                <div className="font-bold text-gray-900 dark:text-white">{timeRemaining.days}</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Days</div>
              </div>
              <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                <div className="font-bold text-gray-900 dark:text-white">{timeRemaining.hours}</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Hours</div>
              </div>
              <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                <div className="font-bold text-gray-900 dark:text-white">{timeRemaining.minutes}</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Min</div>
              </div>
            </div>
          )}
          
          <button
            onClick={handleCTAClick}
            disabled={!config.isActive && config.urgency === 'closed'}
            className={`w-full py-3 px-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center space-x-2 ${
              config.isActive
                ? `bg-gradient-to-r from-${config.color}-500 to-${config.color}-600 text-white hover:from-${config.color}-600 hover:to-${config.color}-700 transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl`
                : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
            }`}
          >
            <ButtonIcon className="w-5 h-5" />
            <span>{config.buttonText}</span>
            {config.isActive && <ArrowRight className="w-4 h-4" />}
          </button>
        </div>
      </div>
    );
  }

  // Inline variant - minimal inline style
  return (
    <button
      onClick={handleCTAClick}
      disabled={!config.isActive && config.urgency === 'closed'}
      className={`${className} inline-flex items-center space-x-2 font-medium transition-colors ${
        config.isActive
          ? `text-${config.color}-600 dark:text-${config.color}-400 hover:text-${config.color}-700 dark:hover:text-${config.color}-300`
          : 'text-gray-500 dark:text-gray-400 cursor-not-allowed'
      }`}
    >
      <ButtonIcon className="w-5 h-5" />
      <span>{config.buttonText}</span>
      {config.isActive && <ArrowRight className="w-4 h-4" />}
    </button>
  );
};

export default EntryCTA;