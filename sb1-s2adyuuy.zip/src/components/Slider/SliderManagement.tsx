import React, { useState } from 'react';
import { 
  Play, Pause, Edit, Save, Trash2, Plus, Eye, EyeOff, Upload, 
  Image, Video, Type, Layout, Settings, Monitor, Smartphone, 
  Tablet, Copy, ExternalLink, BarChart3, Target, Calendar, 
  ArrowUp, ArrowDown, RotateCcw, Zap, Star
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Slide, SliderSettings, Slider } from '../../types/slider';
import { mockSlides, defaultSliderSettings } from '../../data/sliderData';

const SliderManagement: React.FC = () => {
  const { user } = useAuth();
  const [slides, setSlides] = useState<Slide[]>(mockSlides);
  const [settings, setSettings] = useState<SliderSettings>(defaultSliderSettings);
  const [activeTab, setActiveTab] = useState<'slides' | 'settings' | 'analytics'>('slides');
  const [editingSlide, setEditingSlide] = useState<string | null>(null);
  const [showCreateSlide, setShowCreateSlide] = useState(false);
  const [previewMode, setPreviewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');

  // Check if user has permission
  if (user?.role !== 'superadmin' && user?.role !== 'admin') {
    return (
      <div className="p-6 text-center">
        <Layout className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Slider management is only available to administrators.
        </p>
      </div>
    );
  }

  const toggleSlideVisibility = (slideId: string) => {
    setSlides(prev => prev.map(slide => 
      slide.id === slideId 
        ? { 
            ...slide, 
            status: slide.status === 'published' ? 'archived' : 'published'
          }
        : slide
    ));
  };

  const moveSlide = (slideId: string, direction: 'up' | 'down') => {
    const slideIndex = slides.findIndex(s => s.id === slideId);
    if (slideIndex === -1) return;

    const newSlides = [...slides];
    const targetIndex = direction === 'up' ? slideIndex - 1 : slideIndex + 1;

    if (targetIndex >= 0 && targetIndex < slides.length) {
      [newSlides[slideIndex], newSlides[targetIndex]] = [newSlides[targetIndex], newSlides[slideIndex]];
      setSlides(newSlides);
    }
  };

  const deleteSlide = (slideId: string) => {
    if (window.confirm('Are you sure you want to delete this slide?')) {
      setSlides(prev => prev.filter(slide => slide.id !== slideId));
    }
  };

  const duplicateSlide = (slideId: string) => {
    const slide = slides.find(s => s.id === slideId);
    if (!slide) return;

    const newSlide: Slide = {
      ...slide,
      id: `${slide.id}_copy_${Date.now()}`,
      title: `${slide.title} (Copy)`,
      status: 'draft',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setSlides(prev => [...prev, newSlide]);
  };

  const CreateSlideModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">Create New Slide</h3>
            <button
              onClick={() => setShowCreateSlide(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Slide Types */}
            <div className="lg:col-span-3">
              <h4 className="font-medium text-gray-900 dark:text-white mb-4">Choose Slide Type</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {[
                  { type: 'hero', name: 'Hero Slide', icon: Layout, description: 'Full-screen hero with CTA' },
                  { type: 'video', name: 'Video Slide', icon: Video, description: 'Background video with overlay' },
                  { type: 'split', name: 'Split Layout', icon: Layout, description: 'Text and image side-by-side' },
                  { type: 'testimonial', name: 'Testimonial', icon: Type, description: 'Customer testimonial quote' },
                  { type: 'countdown', name: 'Countdown', icon: Calendar, description: 'Countdown timer slide' },
                  { type: 'lottie', name: 'Animation', icon: Star, description: 'Animated Lottie graphics' }
                ].map((slideType) => {
                  const Icon = slideType.icon;
                  return (
                    <button
                      key={slideType.type}
                      onClick={() => {
                        // Create new slide logic here
                        setShowCreateSlide(false);
                      }}
                      className="p-4 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors text-center"
                    >
                      <Icon className="w-8 h-8 text-amber-600 dark:text-amber-400 mx-auto mb-2" />
                      <h5 className="font-medium text-gray-900 dark:text-white text-sm mb-1">{slideType.name}</h5>
                      <p className="text-xs text-gray-600 dark:text-gray-400">{slideType.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'slides':
        return (
          <div className="space-y-6">
            {/* Slide List */}
            <div className="space-y-4">
              {slides.map((slide, index) => (
                <div key={slide.id} className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                          {slide.title}
                        </h3>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          slide.status === 'published' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                            : slide.status === 'scheduled'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400'
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                        }`}>
                          {slide.status}
                        </span>
                        <span className="px-2 py-1 text-xs font-medium bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400 rounded-full capitalize">
                          {slide.type}
                        </span>
                      </div>
                      <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                        {slide.content.headline}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">
                        Priority: {slide.priority} • Created: {slide.createdAt.toLocaleDateString()}
                      </p>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => moveSlide(slide.id, 'up')}
                        disabled={index === 0}
                        className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => moveSlide(slide.id, 'down')}
                        disabled={index === slides.length - 1}
                        className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => toggleSlideVisibility(slide.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          slide.status === 'published'
                            ? 'text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20' 
                            : 'text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-600'
                        }`}
                      >
                        {slide.status === 'published' ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => duplicateSlide(slide.id)}
                        className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingSlide(slide.id)}
                        className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteSlide(slide.id)}
                        className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-8">
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <h4 className="font-medium text-gray-900 dark:text-white mb-4">Autoplay Settings</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.autoplay.enabled}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        autoplay: { ...prev.autoplay, enabled: e.target.checked }
                      }))}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-gray-900 dark:text-white">Enable Autoplay</span>
                  </label>
                  
                  <div>
                    <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
                      Interval (ms)
                    </label>
                    <input
                      type="number"
                      value={settings.autoplay.interval}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        autoplay: { ...prev.autoplay, interval: parseInt(e.target.value) }
                      }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.autoplay.pauseOnHover}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        autoplay: { ...prev.autoplay, pauseOnHover: e.target.checked }
                      }))}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-gray-900 dark:text-white">Pause on Hover</span>
                  </label>
                  
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.autoplay.disableOnMobile}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        autoplay: { ...prev.autoplay, disableOnMobile: e.target.checked }
                      }))}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-gray-900 dark:text-white">Disable on Mobile</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <h4 className="font-medium text-gray-900 dark:text-white mb-4">Navigation Settings</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.navigation.arrows}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        navigation: { ...prev.navigation, arrows: e.target.checked }
                      }))}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-gray-900 dark:text-white">Show Arrows</span>
                  </label>
                  
                  <div>
                    <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
                      Arrow Style
                    </label>
                    <select
                      value={settings.navigation.arrowsStyle}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        navigation: { ...prev.navigation, arrowsStyle: e.target.value as any }
                      }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    >
                      <option value="default">Default</option>
                      <option value="minimal">Minimal</option>
                      <option value="rounded">Rounded</option>
                      <option value="square">Square</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.navigation.bullets}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        navigation: { ...prev.navigation, bullets: e.target.checked }
                      }))}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-gray-900 dark:text-white">Show Bullets</span>
                  </label>
                  
                  <div>
                    <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
                      Bullet Style
                    </label>
                    <select
                      value={settings.navigation.bulletsStyle}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        navigation: { ...prev.navigation, bulletsStyle: e.target.value as any }
                      }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    >
                      <option value="dots">Dots</option>
                      <option value="lines">Lines</option>
                      <option value="numbers">Numbers</option>
                      <option value="progress">Progress</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.navigation.pausePlay}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        navigation: { ...prev.navigation, pausePlay: e.target.checked }
                      }))}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-gray-900 dark:text-white">Pause/Play Button</span>
                  </label>
                  
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.navigation.progressBar}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        navigation: { ...prev.navigation, progressBar: e.target.checked }
                      }))}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-gray-900 dark:text-white">Progress Bar</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        );

      case 'analytics':
        return (
          <div className="space-y-6">
            {/* Slider Analytics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">12.4K</div>
                  <p className="text-gray-600 dark:text-gray-400">Total Views</p>
                  <p className="text-sm text-green-600 dark:text-green-400">+15% this week</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">8.7%</div>
                  <p className="text-gray-600 dark:text-gray-400">Click Rate</p>
                  <p className="text-sm text-green-600 dark:text-green-400">+2.1% this week</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">4.2s</div>
                  <p className="text-gray-600 dark:text-gray-400">Avg. View Time</p>
                  <p className="text-sm text-blue-600 dark:text-blue-400">Stable</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                <div className="text-center">
                  <div className="text-3xl font-bold text-amber-600 dark:text-amber-400 mb-2">156</div>
                  <p className="text-gray-600 dark:text-gray-400">CTA Clicks</p>
                  <p className="text-sm text-green-600 dark:text-green-400">+8% this week</p>
                </div>
              </div>
            </div>

            {/* Slide Performance */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Slide Performance</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-600">
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Slide</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Views</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Clicks</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">CTR</th>
                      <th className="text-left py-2 font-medium text-gray-900 dark:text-white">Avg. Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {slides.map((slide) => (
                      <tr key={slide.id} className="border-b border-gray-100 dark:border-gray-600">
                        <td className="py-3">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-6 bg-gray-200 dark:bg-gray-600 rounded overflow-hidden">
                              {slide.media.src && (
                                <img 
                                  src={slide.media.src} 
                                  alt=""
                                  className="w-full h-full object-cover"
                                />
                              )}
                            </div>
                            <span className="font-medium text-gray-900 dark:text-white">{slide.title}</span>
                          </div>
                        </td>
                        <td className="py-3 text-gray-900 dark:text-white">
                          {Math.floor(Math.random() * 5000 + 1000).toLocaleString()}
                        </td>
                        <td className="py-3 text-gray-900 dark:text-white">
                          {Math.floor(Math.random() * 200 + 50)}
                        </td>
                        <td className="py-3 text-gray-900 dark:text-white">
                          {(Math.random() * 10 + 2).toFixed(1)}%
                        </td>
                        <td className="py-3 text-gray-900 dark:text-white">
                          {(Math.random() * 5 + 2).toFixed(1)}s
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Homepage Slider Management</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Manage homepage slider content, settings, and analytics
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
            <button
              onClick={() => setPreviewMode('desktop')}
              className={`p-2 rounded transition-colors ${previewMode === 'desktop' ? 'bg-white dark:bg-gray-600 shadow' : ''}`}
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPreviewMode('tablet')}
              className={`p-2 rounded transition-colors ${previewMode === 'tablet' ? 'bg-white dark:bg-gray-600 shadow' : ''}`}
            >
              <Tablet className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPreviewMode('mobile')}
              className={`p-2 rounded transition-colors ${previewMode === 'mobile' ? 'bg-white dark:bg-gray-600 shadow' : ''}`}
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>
          <button
            onClick={() => setShowCreateSlide(true)}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Slide</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'slides', label: 'Slides', icon: Layout },
              { id: 'settings', label: 'Settings', icon: Settings },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>

      {showCreateSlide && <CreateSlideModal />}
    </div>
  );
};

export default SliderManagement;