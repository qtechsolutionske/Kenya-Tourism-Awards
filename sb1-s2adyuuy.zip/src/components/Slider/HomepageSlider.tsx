import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { Slide, SliderSettings, SliderEvent } from '../../types/slider';

interface HomepageSliderProps {
  slides: Slide[];
  settings: SliderSettings;
  onEvent?: (event: SliderEvent) => void;
  experimentVariant?: string;
}

const HomepageSlider: React.FC<HomepageSliderProps> = ({ 
  slides, 
  settings, 
  onEvent,
  experimentVariant 
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(() => {
    const isMobile = window.innerWidth < 768;
    return settings.autoplay.enabled && (!isMobile || !settings.autoplay.disableOnMobile);
  });
  const [isHovered, setIsHovered] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [loadedSlides, setLoadedSlides] = useState<Set<number>>(new Set([0]));
  const [progress, setProgress] = useState(0);
  const [reduceMotion, setReduceMotion] = useState(false);
  
  const sliderRef = useRef<HTMLDivElement>(null);
  const autoplayTimerRef = useRef<NodeJS.Timeout>();
  const progressTimerRef = useRef<NodeJS.Timeout>();
  const sessionIdRef = useRef<string>(Math.random().toString(36).substr(2, 9));
  
  // Check for reduced motion preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReduceMotion(mediaQuery.matches);
    
    const handler = (e: MediaQueryListEvent) => setReduceMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  // Analytics event tracking
  const trackEvent = useCallback((event: string, meta: any = {}) => {
    if (onEvent && slides[currentSlide]) {
      onEvent({
        id: Math.random().toString(36),
        sliderId: slides[currentSlide].sliderId,
        slideId: slides[currentSlide].id,
        sessionId: sessionIdRef.current,
        event: event as any,
        meta: {
          device: window.innerWidth < 768 ? 'mobile' : window.innerWidth < 1024 ? 'tablet' : 'desktop',
          variant: experimentVariant,
          position: currentSlide,
          ...meta
        },
        occurredAt: new Date()
      });
    }
  }, [currentSlide, slides, onEvent, experimentVariant]);

  // Intersection Observer for visibility tracking
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            trackEvent('impression');
          }
        });
      },
      { threshold: 0.5 }
    );

    if (sliderRef.current) {
      observer.observe(sliderRef.current);
    }

    return () => observer.disconnect();
  }, [trackEvent]);

  // Preload adjacent slides
  useEffect(() => {
    const toLoad = new Set([currentSlide]);
    
    if (settings.performance.preloadAdjacent) {
      // Preload previous slide
      const prevSlide = currentSlide === 0 
        ? (settings.interaction.loop ? slides.length - 1 : currentSlide)
        : currentSlide - 1;
      toLoad.add(prevSlide);
      
      // Preload next slide  
      const nextSlide = currentSlide === slides.length - 1
        ? (settings.interaction.loop ? 0 : currentSlide)
        : currentSlide + 1;
      toLoad.add(nextSlide);
    }
    
    setLoadedSlides(toLoad);
  }, [currentSlide, slides.length, settings.interaction.loop, settings.performance.preloadAdjacent]);

  // Autoplay logic
  useEffect(() => {
    const shouldAutoplay = isPlaying && 
      settings.autoplay.enabled && 
      !isHovered && 
      !isFocused &&
      slides.length > 1;

    if (shouldAutoplay) {
      autoplayTimerRef.current = setTimeout(() => {
        nextSlide();
      }, settings.autoplay.interval);

      // Progress bar animation
      if (settings.navigation.progressBar) {
        const startTime = Date.now();
        const duration = settings.autoplay.interval;
        
        const updateProgress = () => {
          const elapsed = Date.now() - startTime;
          const newProgress = Math.min(100, (elapsed / duration) * 100);
          setProgress(newProgress);
          
          if (newProgress < 100) {
            progressTimerRef.current = setTimeout(updateProgress, 50);
          }
        };
        updateProgress();
      }
    } else {
      if (autoplayTimerRef.current) {
        clearTimeout(autoplayTimerRef.current);
      }
      if (progressTimerRef.current) {
        clearTimeout(progressTimerRef.current);
      }
    }

    return () => {
      if (autoplayTimerRef.current) clearTimeout(autoplayTimerRef.current);
      if (progressTimerRef.current) clearTimeout(progressTimerRef.current);
    };
  }, [isPlaying, isHovered, isFocused, currentSlide, slides.length, settings]);

  const nextSlide = useCallback(() => {
    const nextIndex = currentSlide === slides.length - 1 
      ? (settings.interaction.loop ? 0 : currentSlide)
      : currentSlide + 1;
    
    if (nextIndex !== currentSlide) {
      setCurrentSlide(nextIndex);
      setProgress(0);
      trackEvent('next');
    }
  }, [currentSlide, slides.length, settings.interaction.loop, trackEvent]);

  const prevSlide = useCallback(() => {
    const prevIndex = currentSlide === 0 
      ? (settings.interaction.loop ? slides.length - 1 : currentSlide)
      : currentSlide - 1;
    
    if (prevIndex !== currentSlide) {
      setCurrentSlide(prevIndex);
      setProgress(0);
      trackEvent('prev');
    }
  }, [currentSlide, slides.length, settings.interaction.loop, trackEvent]);

  const goToSlide = useCallback((index: number) => {
    if (index !== currentSlide && index >= 0 && index < slides.length) {
      setCurrentSlide(index);
      setProgress(0);
      trackEvent('bullet', { targetSlide: index });
    }
  }, [currentSlide, slides.length, trackEvent]);

  const togglePlayback = useCallback(() => {
    setIsPlaying(prev => {
      const newState = !prev;
      trackEvent(newState ? 'play' : 'pause');
      return newState;
    });
  }, [trackEvent]);

  // Keyboard navigation
  useEffect(() => {
    if (!settings.interaction.keyboardEnabled) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!sliderRef.current?.contains(document.activeElement)) return;
      
      switch (e.code) {
        case 'ArrowLeft':
          e.preventDefault();
          prevSlide();
          break;
        case 'ArrowRight':
          e.preventDefault();
          nextSlide();
          break;
        case 'Space':
          e.preventDefault();
          if (settings.autoplay.enabled) {
            togglePlayback();
          }
          break;
        case 'Home':
          e.preventDefault();
          goToSlide(0);
          break;
        case 'End':
          e.preventDefault();
          goToSlide(slides.length - 1);
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [settings.interaction.keyboardEnabled, settings.autoplay.enabled, prevSlide, nextSlide, togglePlayback, goToSlide]);

  // Touch/Swipe handling
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (!settings.interaction.swipeEnabled) return;
    
    const touch = e.touches[0];
    sliderRef.current?.setAttribute('data-touch-start-x', touch.clientX.toString());
  }, [settings.interaction.swipeEnabled]);

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    if (!settings.interaction.swipeEnabled) return;
    
    const touchStartX = parseInt(sliderRef.current?.getAttribute('data-touch-start-x') || '0');
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;
    
    if (Math.abs(diff) > settings.interaction.touchThreshold) {
      if (diff > 0) {
        nextSlide();
      } else {
        prevSlide();
      }
    }
  }, [settings.interaction.swipeEnabled, settings.interaction.touchThreshold, nextSlide, prevSlide]);

  const renderSlideContent = (slide: Slide, index: number) => {
    const isActive = index === currentSlide;
    const shouldLoad = loadedSlides.has(index);
    
    if (!shouldLoad && settings.performance.lazyLoading) {
      return (
        <div className="w-full h-full bg-gray-200 dark:bg-gray-700 animate-pulse" />
      );
    }

    switch (slide.type) {
      case 'hero':
        return (
          <HeroSlide 
            slide={slide} 
            isActive={isActive}
            onCTAClick={(url) => trackEvent('cta_click', { url })}
          />
        );
      case 'video':
        return (
          <VideoSlide 
            slide={slide} 
            isActive={isActive}
            onCTAClick={(url) => trackEvent('cta_click', { url })}
          />
        );
      case 'split':
        return (
          <SplitSlide 
            slide={slide} 
            isActive={isActive}
            onCTAClick={(url) => trackEvent('cta_click', { url })}
          />
        );
      case 'testimonial':
        return (
          <TestimonialSlide 
            slide={slide} 
            isActive={isActive}
            onCTAClick={(url) => trackEvent('cta_click', { url })}
          />
        );
      case 'countdown':
        return (
          <CountdownSlide 
            slide={slide} 
            isActive={isActive}
            onCTAClick={(url) => trackEvent('cta_click', { url })}
          />
        );
      case 'lottie':
        return (
          <LottieSlide 
            slide={slide} 
            isActive={isActive}
            onCTAClick={(url) => trackEvent('cta_click', { url })}
          />
        );
      default:
        return (
          <HeroSlide 
            slide={slide} 
            isActive={isActive}
            onCTAClick={(url) => trackEvent('cta_click', { url })}
          />
        );
    }
  };

  if (slides.length === 0) {
    return null;
  }

  const transitionClass = reduceMotion && settings.transitions.respectReducedMotion 
    ? 'transition-opacity duration-300'
    : `transition-all duration-${settings.transitions.duration}`;

  return (
    <div
      ref={sliderRef}
      className={`relative overflow-hidden bg-gray-900 ${
        settings.layout.heightMode === 'fixed' ? 'h-screen' : 
        settings.layout.heightMode === 'responsive' ? 'h-screen sm:h-[70vh] lg:h-screen' :
        'h-auto'
      }`}
      style={{
        aspectRatio: settings.layout.aspectRatio,
        maxHeight: settings.layout.maxHeight ? `${settings.layout.maxHeight}px` : undefined
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsFocused(true)}
      onBlur={() => setIsFocused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      role="region"
      aria-roledescription="carousel"
      aria-label={settings.accessibility.ariaLabels.slider}
      tabIndex={0}
    >
      {/* Progress Bar */}
      {settings.navigation.progressBar && settings.autoplay.enabled && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-black/20 z-50">
          <div 
            className="h-full bg-white/80 transition-all duration-75 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Slides Container */}
      <div className="relative w-full h-full">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 ${transitionClass} ${
              index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
            }`}
            style={{
              transform: settings.transitions.type === 'slide' 
                ? `translateX(${(index - currentSlide) * 100}%)` 
                : undefined
            }}
            aria-hidden={index !== currentSlide}
          >
            {renderSlideContent(slide, index)}
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      {settings.navigation.arrows && slides.length > 1 && (
        <>
          <button
            onClick={prevSlide}
            className={`absolute left-4 top-1/2 -translate-y-1/2 z-40 ${getArrowStyles()} group`}
            aria-label={settings.accessibility.ariaLabels.prevButton}
            disabled={!settings.interaction.loop && currentSlide === 0}
          >
            <ChevronLeft className="w-6 h-6 group-hover:scale-110 transition-transform" />
          </button>
          <button
            onClick={nextSlide}
            className={`absolute right-4 top-1/2 -translate-y-1/2 z-40 ${getArrowStyles()} group`}
            aria-label={settings.accessibility.ariaLabels.nextButton}
            disabled={!settings.interaction.loop && currentSlide === slides.length - 1}
          >
            <ChevronRight className="w-6 h-6 group-hover:scale-110 transition-transform" />
          </button>
        </>
      )}

      {/* Pagination Bullets */}
      {settings.navigation.bullets && slides.length > 1 && (
        <div className={`absolute ${getBulletsPosition()} left-1/2 -translate-x-1/2 z-40 flex items-center space-x-2`}>
          {settings.navigation.bulletsStyle === 'numbers' && (
            <div className="bg-black/50 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
              {currentSlide + 1} / {slides.length}
            </div>
          )}
          {settings.navigation.bulletsStyle === 'dots' && slides.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide
                  ? 'bg-white scale-125'
                  : 'bg-white/50 hover:bg-white/80'
              }`}
              aria-label={`${settings.accessibility.ariaLabels.slide} ${index + 1}`}
            />
          ))}
          {settings.navigation.bulletsStyle === 'progress' && (
            <div className="bg-black/50 backdrop-blur-sm px-4 py-2 rounded-full">
              <div className="w-32 h-1 bg-white/30 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-white transition-all duration-300"
                  style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Pause/Play Control */}
      {settings.navigation.pausePlay && settings.autoplay.enabled && (
        <button
          onClick={togglePlayback}
          className="absolute top-4 right-4 z-40 w-12 h-12 bg-black/50 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-black/60 transition-colors"
          aria-label={isPlaying ? settings.accessibility.ariaLabels.pauseButton : settings.accessibility.ariaLabels.playButton}
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
        </button>
      )}

      {/* Screen Reader Announcements */}
      <div className="sr-only" aria-live="polite" aria-atomic="true">
        {settings.accessibility.announceSlides && 
          `Slide ${currentSlide + 1} of ${slides.length}: ${slides[currentSlide]?.content.headline}`
        }
      </div>
    </div>
  );

  function getArrowStyles() {
    const baseStyles = "w-12 h-12 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed focus:ring-2 focus:ring-white/50 focus:outline-none";
    
    switch (settings.navigation.arrowsStyle) {
      case 'minimal':
        return "w-10 h-10 bg-transparent text-white hover:bg-white/20 transition-colors focus:ring-2 focus:ring-white/50 focus:outline-none";
      case 'square':
        return baseStyles.replace('rounded-full', 'rounded-lg');
      case 'rounded':
        return baseStyles.replace('rounded-full', 'rounded-xl');
      default:
        return baseStyles;
    }
  }

  function getBulletsPosition() {
    return settings.navigation.bulletsPosition === 'top' ? 'top-4' : 'bottom-4';
  }
};

// Slide Type Components
const HeroSlide: React.FC<{ 
  slide: Slide; 
  isActive: boolean; 
  onCTAClick: (url: string) => void; 
}> = ({ slide, isActive, onCTAClick }) => (
  <div className="relative w-full h-full">
    {slide.media.type === 'image' && slide.media.src && (
      <img
        src={slide.media.src}
        alt={slide.media.alt || slide.accessibility.altText || ''}
        className="w-full h-full object-cover"
        loading={isActive ? 'eager' : 'lazy'}
        decoding="async"
      />
    )}
    
    <div className={`absolute inset-0 ${
      slide.content.overlay.type === 'auto' 
        ? 'bg-black/40' 
        : slide.content.overlay.color 
          ? `bg-${slide.content.overlay.color}/${slide.content.overlay.opacity || 40}`
          : ''
    }`} />
    
    <div className={`absolute inset-0 flex items-center justify-center text-white z-20`}>
      <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full text-${slide.content.textAlignment}`}>
        <div className="max-w-4xl">
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 leading-tight">
            {slide.content.headline}
          </h2>
          {slide.content.subhead && (
            <p className="text-xl md:text-2xl text-white/90 mb-8 leading-relaxed">
              {slide.content.subhead}
            </p>
          )}
          {slide.content.body && (
            <p className="text-lg text-white/80 mb-8 max-w-2xl leading-relaxed">
              {slide.content.body}
            </p>
          )}
          
          <div className="flex flex-col sm:flex-row items-start space-y-4 sm:space-y-0 sm:space-x-6">
            {slide.content.primaryCTA && (
              <button
                onClick={() => onCTAClick(slide.content.primaryCTA!.url)}
                className="group bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-3xl transform hover:-translate-y-2 transition-all duration-300"
              >
                {slide.content.primaryCTA.label}
              </button>
            )}
            {slide.content.secondaryCTA && (
              <a
                href={slide.content.secondaryCTA.url}
                target={slide.content.secondaryCTA.target}
                className="text-white/90 hover:text-white font-medium text-lg hover:underline transition-colors"
              >
                {slide.content.secondaryCTA.label}
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  </div>
);

const VideoSlide: React.FC<{ 
  slide: Slide; 
  isActive: boolean; 
  onCTAClick: (url: string) => void; 
}> = ({ slide, isActive, onCTAClick }) => {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const toggleVideo = () => {
    if (videoRef.current) {
      if (isVideoPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsVideoPlaying(!isVideoPlaying);
    }
  };

  return (
    <div className="relative w-full h-full">
      {!isVideoPlaying && slide.media.poster ? (
        <>
          <img
            src={slide.media.poster}
            alt={slide.media.alt || ''}
            className="w-full h-full object-cover"
          />
          <button
            onClick={toggleVideo}
            className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-colors group z-20"
          >
            <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center group-hover:bg-white group-hover:scale-110 transition-all duration-300">
              <Play className="w-8 h-8 text-slate-900 ml-1" />
            </div>
          </button>
        </>
      ) : (
        <video
          ref={videoRef}
          src={slide.media.videoSrc}
          poster={slide.media.poster}
          autoPlay={isActive}
          muted={slide.media.muted !== false}
          loop={slide.media.loop !== false}
          playsInline={slide.media.playsinline !== false}
          controls={slide.media.controls === true}
          className="w-full h-full object-cover"
          onEnded={() => setIsVideoPlaying(false)}
        />
      )}
      
      <div className="absolute inset-0 bg-black/40 z-10" />
      
      <div className="absolute inset-0 flex items-center justify-center text-white z-20">
        <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full text-${slide.content.textAlignment}`}>
          <div className="max-w-4xl">
            <h2 className="text-4xl md:text-6xl font-bold mb-4">
              {slide.content.headline}
            </h2>
            {slide.content.subhead && (
              <p className="text-xl md:text-2xl text-white/90 mb-8">
                {slide.content.subhead}
              </p>
            )}
            
            {slide.content.primaryCTA && (
              <button
                onClick={() => onCTAClick(slide.content.primaryCTA!.url)}
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-3xl transform hover:-translate-y-2 transition-all duration-300"
              >
                {slide.content.primaryCTA.label}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const SplitSlide: React.FC<{ 
  slide: Slide; 
  isActive: boolean; 
  onCTAClick: (url: string) => void; 
}> = ({ slide, isActive, onCTAClick }) => (
  <div className="w-full h-full grid grid-cols-1 lg:grid-cols-2">
    <div className="flex items-center justify-center p-8 bg-gradient-to-r from-amber-500 to-orange-500 text-white">
      <div className="max-w-lg">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          {slide.content.headline}
        </h2>
        {slide.content.subhead && (
          <p className="text-xl text-amber-100 mb-6">
            {slide.content.subhead}
          </p>
        )}
        {slide.content.body && (
          <p className="text-amber-50 mb-8">
            {slide.content.body}
          </p>
        )}
        
        {slide.content.primaryCTA && (
          <button
            onClick={() => onCTAClick(slide.content.primaryCTA!.url)}
            className="bg-white text-amber-600 px-8 py-4 rounded-2xl font-bold hover:bg-gray-50 transition-colors"
          >
            {slide.content.primaryCTA.label}
          </button>
        )}
      </div>
    </div>
    
    <div className="relative">
      {slide.media.src && (
        <img
          src={slide.media.src}
          alt={slide.media.alt || ''}
          className="w-full h-full object-cover"
          loading={isActive ? 'eager' : 'lazy'}
        />
      )}
    </div>
  </div>
);

const TestimonialSlide: React.FC<{ 
  slide: Slide; 
  isActive: boolean; 
  onCTAClick: (url: string) => void; 
}> = ({ slide, isActive, onCTAClick }) => (
  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-800 to-slate-900 text-white">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <blockquote className="text-2xl md:text-3xl font-light italic mb-8">
        "{slide.content.headline}"
      </blockquote>
      {slide.content.subhead && (
        <cite className="text-amber-400 font-semibold text-lg">
          {slide.content.subhead}
        </cite>
      )}
      {slide.content.body && (
        <p className="text-gray-300 mt-2">
          {slide.content.body}
        </p>
      )}
    </div>
  </div>
);

const CountdownSlide: React.FC<{ 
  slide: Slide; 
  isActive: boolean; 
  onCTAClick: (url: string) => void; 
}> = ({ slide, isActive, onCTAClick }) => {
  const [timeLeft, setTimeLeft] = useState({ days: 7, hours: 12, minutes: 34, seconds: 56 });

  useEffect(() => {
    if (!isActive) return;
    
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive]);

  return (
    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-red-500 to-pink-600 text-white relative">
      {slide.media.src && (
        <>
          <img
            src={slide.media.src}
            alt={slide.media.alt || ''}
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-red-500/80" />
        </>
      )}
      
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
        <h2 className="text-4xl md:text-6xl font-bold mb-4">
          {slide.content.headline}
        </h2>
        {slide.content.subhead && (
          <p className="text-xl md:text-2xl text-red-100 mb-8">
            {slide.content.subhead}
          </p>
        )}
        
        <div className="grid grid-cols-4 gap-4 mb-8 max-w-md mx-auto">
          {Object.entries(timeLeft).map(([unit, value]) => (
            <div key={unit} className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
              <div className="text-3xl font-bold">{value.toString().padStart(2, '0')}</div>
              <div className="text-sm uppercase">{unit}</div>
            </div>
          ))}
        </div>
        
        {slide.content.primaryCTA && (
          <button
            onClick={() => onCTAClick(slide.content.primaryCTA!.url)}
            className="bg-white text-red-600 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-gray-50 transition-colors"
          >
            {slide.content.primaryCTA.label}
          </button>
        )}
      </div>
    </div>
  );
};

const LottieSlide: React.FC<{ 
  slide: Slide; 
  isActive: boolean; 
  onCTAClick: (url: string) => void; 
}> = ({ slide, isActive, onCTAClick }) => (
  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-500 to-indigo-600 text-white">
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
      <div>
        <h2 className="text-4xl md:text-5xl font-bold mb-4">
          {slide.content.headline}
        </h2>
        {slide.content.subhead && (
          <p className="text-xl text-purple-100 mb-6">
            {slide.content.subhead}
          </p>
        )}
        {slide.content.body && (
          <p className="text-purple-50 mb-8">
            {slide.content.body}
          </p>
        )}
        
        {slide.content.primaryCTA && (
          <button
            onClick={() => onCTAClick(slide.content.primaryCTA!.url)}
            className="bg-white text-purple-600 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-gray-50 transition-colors"
          >
            {slide.content.primaryCTA.label}
          </button>
        )}
      </div>
      
      <div className="flex items-center justify-center">
        {/* Lottie animation would be rendered here */}
        <div className="w-64 h-64 bg-white/10 rounded-full flex items-center justify-center">
          <div className="text-center">
            <div className="w-32 h-32 bg-white/20 rounded-full mx-auto mb-4"></div>
            <p className="text-purple-200">Lottie Animation</p>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default HomepageSlider;