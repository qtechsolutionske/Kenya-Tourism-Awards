import React, { useState } from 'react';
import { 
  Users, Award, Calendar, MapPin, Eye, Mail, Phone, 
  ExternalLink, Globe, Linkedin, Twitter, Facebook, 
  Instagram, Star, Trophy, User, Search, Filter,
  Building, Clock, Target, Heart, Shield, Palette,
  Code, Mic, Zap, Settings, Handshake
} from 'lucide-react';
import { teamMembers, teamDepartments } from '../../data/teamMembers';
import { TeamMember } from '../../types/team';

const PublicTeam: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  // Only show public team members
  const publicMembers = teamMembers.filter(member => member.isPublic && member.isActive);

  const filteredMembers = publicMembers.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.specialization?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = departmentFilter === 'all' || member.department === departmentFilter;
    return matchesSearch && matchesDepartment;
  });

  const getSocialIcon = (platform: string) => {
    switch (platform) {
      case 'linkedin': return <Linkedin className="w-4 h-4" />;
      case 'twitter': return <Twitter className="w-4 h-4" />;
      case 'facebook': return <Facebook className="w-4 h-4" />;
      case 'instagram': return <Instagram className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  const getDepartmentIcon = (department: string) => {
    switch (department) {
      case 'Leadership': return Trophy;
      case 'Operations': return Settings;
      case 'Media': return Mic;
      case 'Marketing': return Zap;
      case 'Technology': return Code;
      case 'Partnerships': return Handshake;
      case 'Administration': return Shield;
      case 'Evaluation': return Star;
      default: return User;
    }
  };

  const MemberModal = () => {
    if (!selectedMember) return null;

    const getSocialIconComponent = (platform: string) => {
      switch (platform) {
        case 'linkedin': return Linkedin;
        case 'twitter': return Twitter;
        case 'facebook': return Facebook;
        case 'instagram': return Instagram;
        default: return Globe;
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-slate-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Team Member Profile</h3>
              <button
                onClick={() => setSelectedMember(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                ×
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="flex items-center space-x-4 mb-6">
                  <img
                    src={selectedMember.avatar}
                    alt={selectedMember.name}
                    className="w-24 h-24 rounded-xl object-cover"
                  />
                  <div>
                    <h4 className="text-2xl font-bold text-gray-900 dark:text-white">
                      {selectedMember.name}
                    </h4>
                    <p className="text-xl text-amber-600 dark:text-amber-400 font-medium">
                      {selectedMember.role}
                    </p>
                    <p className="text-gray-500 dark:text-gray-500">
                      {selectedMember.department} • {selectedMember.experience}+ years
                    </p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h5 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">About</h5>
                    <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                      {selectedMember.bio}
                    </p>
                  </div>

                  {selectedMember.specialization && (
                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-2">Specialization</h5>
                      <p className="text-gray-600 dark:text-gray-400">{selectedMember.specialization}</p>
                    </div>
                  )}

                  {selectedMember.achievements.length > 0 && (
                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-3">Achievements</h5>
                      <div className="space-y-3">
                        {selectedMember.achievements.map(achievement => (
                          <div key={achievement.id} className="flex items-start space-x-3 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                            <Award className="w-5 h-5 text-amber-500 mt-1" />
                            <div>
                              <h6 className="font-medium text-gray-900 dark:text-white">
                                {achievement.title}
                              </h6>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                                {achievement.description}
                              </p>
                              <p className="text-xs text-gray-500 dark:text-gray-500">
                                {achievement.date.toLocaleDateString()} • {achievement.organization}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-6">
                {/* Contact */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4">
                  <h5 className="font-medium text-gray-900 dark:text-white mb-3">Contact</h5>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <a 
                        href={`mailto:${selectedMember.email}`}
                        className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
                      >
                        {selectedMember.email}
                      </a>
                    </div>
                    {selectedMember.phone && (
                      <div className="flex items-center space-x-2">
                        <Phone className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-600 dark:text-gray-400 text-sm">{selectedMember.phone}</span>
                      </div>
                    )}
                    {selectedMember.organization && (
                      <div className="flex items-center space-x-2">
                        <Building className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-600 dark:text-gray-400 text-sm">{selectedMember.organization}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Social Links */}
                {Object.keys(selectedMember.socialLinks).some(platform => selectedMember.socialLinks[platform as keyof typeof selectedMember.socialLinks]) && (
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4">
                    <h5 className="font-medium text-gray-900 dark:text-white mb-3">Connect</h5>
                    <div className="flex flex-wrap gap-2">
                      {Object.entries(selectedMember.socialLinks).map(([platform, url]) => {
                        if (!url) return null;
                        const SocialIcon = getSocialIconComponent(platform);
                        return (
                          <a 
                            key={platform}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-2 px-3 py-2 bg-white dark:bg-gray-600 border border-gray-200 dark:border-gray-500 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-500 transition-colors"
                          >
                            {React.createElement(SocialIcon, { className: "w-4 h-4" })}
                            <span className="text-sm text-gray-700 dark:text-gray-300 capitalize">{platform}</span>
                          </a>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Badges */}
                {selectedMember.badges.length > 0 && (
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4">
                    <h5 className="font-medium text-gray-900 dark:text-white mb-3">Badges</h5>
                    <div className="space-y-2">
                      {selectedMember.badges.map(badge => (
                        <div key={badge.id} className={`px-3 py-2 bg-${badge.color}-100 dark:bg-${badge.color}-900/20 text-${badge.color}-800 dark:text-${badge.color}-400 rounded-lg flex items-center space-x-2`}>
                          <Star className="w-4 h-4" />
                          <span className="font-medium text-sm">{badge.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-500 to-indigo-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="section-title-animated section-title-large font-bold text-white mb-6">
            Meet Our Team
          </h1>
          <p className="text-xl text-blue-100 max-w-4xl mx-auto">
            Our team is a dynamic group of professionals united by a shared passion for excellence, 
            innovation, and impact in the tourism and hospitality sector.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-gray-50 dark:bg-slate-800 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search team members..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={departmentFilter}
                onChange={(e) => setDepartmentFilter(e.target.value)}
                className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">All Departments</option>
                {teamDepartments.map(dept => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Team Members Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredMembers.map((member) => (
              <div 
                key={member.id}
                className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-200 dark:border-slate-700 group"
                onClick={() => setSelectedMember(member)}
              >
                {/* Banner */}
                <div className="relative h-32 bg-gradient-to-r from-blue-500 to-indigo-600 overflow-hidden">
                  {member.banner && (
                    <img 
                      src={member.banner} 
                      alt={`${member.name} banner`}
                      className="w-full h-full object-cover"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  
                  {/* Department Badge */}
                  <div className="absolute top-3 right-3">
                    <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
                      {React.createElement(getDepartmentIcon(member.department), { className: "w-5 h-5" })}
                      <span className="text-white text-xs font-medium">{member.department}</span>
                    </div>
                  </div>
                </div>

                {/* Profile Info */}
                <div className="relative px-6 pb-6">
                  {/* Avatar */}
                  <div className="flex justify-center -mt-10 mb-4">
                    <img 
                      src={member.avatar}
                      alt={member.name}
                      className="w-20 h-20 rounded-xl border-4 border-white dark:border-gray-800 shadow-lg object-cover"
                    />
                  </div>

                  <div className="text-center">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                      {member.name}
                    </h3>
                    <p className="text-blue-600 dark:text-blue-400 font-medium text-sm mb-1">
                      {member.role}
                    </p>
                    <p className="text-gray-500 dark:text-gray-500 text-xs mb-3">
                      {member.experience}+ years experience
                    </p>
                  </div>

                  <p className="text-gray-600 dark:text-gray-400 text-sm text-center mb-4 line-clamp-3 leading-relaxed">
                    {member.bio.substring(0, 120)}...
                  </p>

                  {/* Specialization */}
                  {member.specialization && (
                    <div className="mb-4">
                      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-2 text-center">
                        <p className="text-xs text-blue-800 dark:text-blue-400 font-medium">
                          {member.specialization}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Social Links */}
                  <div className="flex justify-center space-x-3 mb-4">
                    {Object.entries(member.socialLinks).map(([platform, url]) => (
                      url && (
                        <a 
                          key={platform}
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-8 h-8 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-blue-500 hover:text-white transition-all"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {React.createElement(getSocialIcon(platform), { className: "w-4 h-4" })}
                        </a>
                      )
                    ))}
                  </div>

                  {/* View Profile Button */}
                  <button 
                    className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-3 px-4 rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-300 font-medium transform group-hover:-translate-y-0.5 shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
                  >
                    <Eye className="w-4 h-4" />
                    <span>View Profile</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredMembers.length === 0 && (
            <div className="text-center py-12">
              <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No team members found</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Our Team by Numbers
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              The diverse expertise driving Kenya Tourism Awards forward
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                {publicMembers.length}
              </div>
              <div className="text-gray-600 dark:text-gray-400 font-medium">Team Members</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                {teamDepartments.length}
              </div>
              <div className="text-gray-600 dark:text-gray-400 font-medium">Departments</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 dark:text-green-400 mb-2">
                {Math.round(publicMembers.reduce((sum, member) => sum + member.experience, 0) / publicMembers.length)}
              </div>
              <div className="text-gray-600 dark:text-gray-400 font-medium">Avg. Experience</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-bold text-amber-600 dark:text-amber-400 mb-2">
                {publicMembers.reduce((sum, member) => sum + member.achievements.length, 0)}
              </div>
              <div className="text-gray-600 dark:text-gray-400 font-medium">Total Achievements</div>
            </div>
          </div>
        </div>
      </section>

      {/* Department Breakdown */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Department Breakdown
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Specialized teams working together for tourism excellence
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {teamDepartments.map(department => {
              const deptMembers = publicMembers.filter(m => m.department === department);
              const IconComponent = getDepartmentIcon(department);
              
              return (
                <div key={department} className="bg-white dark:bg-slate-800 rounded-xl p-6 text-center shadow-lg border border-gray-200 dark:border-slate-700">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{department}</h3>
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{deptMembers.length}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">team members</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {selectedMember && <MemberModal />}
    </div>
  );
};

export default PublicTeam;