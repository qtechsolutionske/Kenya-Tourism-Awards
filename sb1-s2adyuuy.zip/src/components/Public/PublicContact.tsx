import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, MessageSquare, Users, Award } from 'lucide-react';

const PublicContact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    type: 'general'
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Contact form submitted:', formData);
  };

  const contactInfo = [
    {
      icon: Mail,
      title: 'Email Us',
      details: 'info@kenyatourismawards.com',
      description: 'Send us an email and we\'ll respond within 24 hours'
    },
    {
      icon: Phone,
      title: 'Call Us',
      details: '+254 707 242620',
      description: 'Monday to Friday, 9:00 AM to 5:00 PM EAT'
    },
    {
      icon: MapPin,
      title: 'Visit Us',
      details: 'Tourism House, Nairobi',
      description: 'Uhuru Highway, Nairobi, Kenya'
    },
    {
      icon: Clock,
      title: 'Office Hours',
      details: 'Mon - Fri: 9:00 AM - 5:00 PM',
      description: 'Saturday: 9:00 AM - 1:00 PM'
    }
  ];

  const departments = [
    {
      name: 'General Inquiries',
      email: 'info@kenyatourismawards.com',
      description: 'General questions about the awards'
    },
    {
      name: 'Nominations',
      email: 'nominations@kenyatourismawards.com',
      description: 'Questions about nomination process'
    },
    {
      name: 'Voting Support',
      email: 'voting@kenyatourismawards.com',
      description: 'Help with voting process'
    },
    {
      name: 'Gala Events',
      email: 'events@kenyatourismawards.com',
      description: 'Gala tickets and event information'
    },
    {
      name: 'Media & Press',
      email: 'media@kenyatourismawards.com',
      description: 'Press releases and media inquiries'
    },
    {
      name: 'Partnerships',
      email: 'partnerships@kenyatourismawards.com',
      description: 'Sponsorship and partnership opportunities'
    }
  ];

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="section-title-animated section-title-large font-bold text-white mb-6">
            Contact Us
          </h1>
          <p className="text-xl text-amber-100 max-w-3xl mx-auto">
            Get in touch with the Kenya Tourism Awards team. We're here to help with any questions or inquiries.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {info.title}
                  </h3>
                  <p className="text-lg font-medium text-amber-600 dark:text-amber-400 mb-2">
                    {info.details}
                  </p>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {info.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Form & Departments */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 shadow-lg">
              <h2 className="section-title-animated text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Send us a Message
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Inquiry Type *
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) => handleInputChange('type', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="general">General Inquiry</option>
                    <option value="nominations">Nominations</option>
                    <option value="voting">Voting Support</option>
                    <option value="events">Gala Events</option>
                    <option value="media">Media & Press</option>
                    <option value="partnerships">Partnerships</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Subject *
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => handleInputChange('subject', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Message *
                  </label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => handleInputChange('message', e.target.value)}
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Please provide details about your inquiry..."
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white py-3 px-6 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center justify-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Message</span>
                </button>
              </form>
            </div>

            {/* Departments */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 section-title">
                Department Contacts
              </h2>
              <div className="space-y-4">
                {departments.map((dept, index) => (
                  <div key={index} className="bg-white dark:bg-slate-900 rounded-lg p-6 shadow-lg">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      {dept.name}
                    </h3>
                    <p className="text-amber-600 dark:text-amber-400 font-medium mb-2">
                      {dept.email}
                    </p>
                    <p className="text-gray-600 dark:text-gray-400 text-sm">
                      {dept.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Quick answers to common questions
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="space-y-6">
              {[
                {
                  question: 'How do I submit a nomination?',
                  answer: 'You can submit nominations through our online portal during the nomination period (January 15 - February 15). Create an account, select your category, and complete the nomination form with all required documents.'
                },
                {
                  question: 'When is the voting period?',
                  answer: 'Public voting opens on March 1st and closes on March 10th, 2025. All registered users can vote once per category during this period.'
                },
                {
                  question: 'How can I attend the gala ceremony?',
                  answer: 'Gala tickets are available for purchase through our website. We offer different ticket categories including Standard, VIP, VVIP, and Corporate tables. Early bird discounts are available.'
                },
                {
                  question: 'Who can vote in the awards?',
                  answer: 'Any registered user can participate in public voting. This includes tourism stakeholders, industry professionals, and the general public interested in Kenya\'s tourism sector.'
                },
                {
                  question: 'How are winners selected?',
                  answer: 'Winners are selected through a combination of expert jury evaluation (70%) and public voting (30%). Our jury consists of tourism industry experts and professionals.'
                }
              ].map((faq, index) => (
                <div key={index} className="bg-white dark:bg-slate-800 rounded-lg p-6 shadow-lg">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                    {faq.question}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-500 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title-animated text-3xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-amber-100 mb-8 max-w-2xl mx-auto">
            Join the Kenya Tourism Awards community and be part of celebrating excellence in tourism.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <button className="bg-white text-amber-600 px-8 py-3 rounded-lg font-medium hover:bg-gray-50 transition-colors flex items-center space-x-2">
              <Award className="w-5 h-5" />
              <span>Submit Nomination</span>
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-medium hover:bg-white hover:text-amber-600 transition-colors flex items-center space-x-2">
              <Users className="w-5 h-5" />
              <span>Join Community</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PublicContact;