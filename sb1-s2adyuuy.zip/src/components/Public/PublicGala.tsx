import React, { useState } from 'react';
import { Calendar, MapPin, Clock, Users, CreditCard, QrCode, Star, Trophy, Ticket, Edit, Save, X, Plus, Trash2, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface TicketType {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  available: number;
  total: number;
  isVisible: boolean;
}

interface EventProgram {
  id: string;
  time: string;
  event: string;
  description: string;
  isVisible: boolean;
}

const PublicGala: React.FC = () => {
  const { user } = useAuth();
  const [ticketTypes, setTicketTypes] = useState<TicketType[]>([
    {
      id: 'standard',
      name: 'Standard',
      price: 15000,
      description: 'General admission to the gala event',
      features: ['Event access', 'Welcome drink', 'Dinner', 'Awards ceremony'],
      available: 150,
      total: 200,
      isVisible: true
    },
    {
      id: 'vip',
      name: 'VIP',
      price: 35000,
      description: 'Premium experience with exclusive benefits',
      features: ['Priority seating', 'VIP lounge access', 'Premium dinner', 'Meet & greet', 'Gift bag'],
      available: 45,
      total: 50,
      isVisible: true
    },
    {
      id: 'vvip',
      name: 'VVIP',
      price: 75000,
      description: 'Ultimate luxury experience',
      features: ['Front row seating', 'Private reception', 'Gourmet dinner', 'Photo opportunities', 'Exclusive gifts', 'After-party access'],
      available: 8,
      total: 10,
      isVisible: true
    },
    {
      id: 'corporate',
      name: 'Corporate Table',
      price: 250000,
      description: 'Table for 8 with corporate branding',
      features: ['Reserved table for 8', 'Corporate branding', 'Networking opportunities', 'Premium service', 'Marketing materials'],
      available: 5,
      total: 15,
      isVisible: false
    }
  ]);

  const [eventProgram, setEventProgram] = useState<EventProgram[]>([
    { id: '1', time: '6:00 PM', event: 'Registration & Welcome Reception', description: 'Guest check-in and networking', isVisible: true },
    { id: '2', time: '7:00 PM', event: 'Opening Ceremony', description: 'Welcome address and cultural performance', isVisible: true },
    { id: '3', time: '7:30 PM', event: 'Dinner Service', description: 'Gourmet dinner and entertainment', isVisible: true },
    { id: '4', time: '8:30 PM', event: 'Awards Ceremony', description: 'Category-by-category winner announcements', isVisible: true },
    { id: '5', time: '10:30 PM', event: 'Closing & After Party', description: 'Celebration and networking continues', isVisible: true }
  ]);

  const [showTicketManagement, setShowTicketManagement] = useState(false);
  const [showProgramManagement, setShowProgramManagement] = useState(false);
  const [editingTicket, setEditingTicket] = useState<string | null>(null);
  const [editingProgram, setEditingProgram] = useState<string | null>(null);

  // Check if user can edit (admin or staff with permissions)
  const canEdit = user && (
    user.role === 'superadmin' || 
    user.role === 'admin' || 
    user.role === 'manager' || 
    user.role === 'operations_manager' ||
    user.permissions?.includes('edit_gala_content')
  );

  const visibleTickets = ticketTypes.filter(ticket => ticket.isVisible);
  const visibleProgram = eventProgram.filter(program => program.isVisible);

  const toggleTicketVisibility = (ticketId: string) => {
    setTicketTypes(prev => prev.map(ticket => 
      ticket.id === ticketId 
        ? { ...ticket, isVisible: !ticket.isVisible }
        : ticket
    ));
  };

  const toggleProgramVisibility = (programId: string) => {
    setEventProgram(prev => prev.map(program => 
      program.id === programId 
        ? { ...program, isVisible: !program.isVisible }
        : program
    ));
  };

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center overflow-x-hidden">
          <h1 className="section-title-animated section-title-large font-bold text-white mb-4 sm:mb-6 px-4">
            Kenya Tourism Awards Gala 2025
          </h1>
          <p className="text-lg sm:text-xl text-amber-100 max-w-3xl mx-auto mb-6 sm:mb-8 px-4">
            Join us for an unforgettable evening celebrating excellence in tourism
          </p>
          <div className="flex flex-col sm:flex-row flex-wrap justify-center items-center gap-3 sm:gap-6 text-amber-100">
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5" />
              <span>March 15, 2025</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span>6:00 PM - 11:00 PM</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5" />
              <span className="text-center sm:text-left">KICC, Nairobi</span>
            </div>
          </div>
        </div>
      </section>

      {/* Admin Controls */}
      {canEdit && (
        <section className="py-6 bg-gray-100 dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Gala Management</h3>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setShowTicketManagement(!showTicketManagement)}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Ticket className="w-4 h-4" />
                  <span>Manage Tickets</span>
                </button>
                <button
                  onClick={() => setShowProgramManagement(!showProgramManagement)}
                  className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Clock className="w-4 h-4" />
                  <span>Manage Program</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Event Program */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white">Event Program</h2>
            {canEdit && (
              <button
                onClick={() => setShowProgramManagement(!showProgramManagement)}
                className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
              >
                <Edit className="w-5 h-5" />
              </button>
            )}
          </div>

          {showProgramManagement && canEdit && (
            <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6 mb-8">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Program Management</h3>
              <div className="space-y-4">
                {eventProgram.map((program) => (
                  <div key={program.id} className="flex items-center justify-between p-4 bg-white dark:bg-gray-700 rounded-lg">
                    <div className="flex-1">
                      {editingProgram === program.id ? (
                        <div className="grid grid-cols-3 gap-4">
                          <input
                            type="text"
                            value={program.time}
                            onChange={(e) => setEventProgram(prev => prev.map(p => 
                              p.id === program.id ? { ...p, time: e.target.value } : p
                            ))}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                          <input
                            type="text"
                            value={program.event}
                            onChange={(e) => setEventProgram(prev => prev.map(p => 
                              p.id === program.id ? { ...p, event: e.target.value } : p
                            ))}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                          <input
                            type="text"
                            value={program.description}
                            onChange={(e) => setEventProgram(prev => prev.map(p => 
                              p.id === program.id ? { ...p, description: e.target.value } : p
                            ))}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                        </div>
                      ) : (
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{program.time} - {program.event}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">{program.description}</div>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => toggleProgramVisibility(program.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          program.isVisible 
                            ? 'text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20' 
                            : 'text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                        }`}
                      >
                        {program.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => setEditingProgram(editingProgram === program.id ? null : program.id)}
                        className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg"
                      >
                        {editingProgram === program.id ? <Save className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => setEventProgram(prev => prev.filter(p => p.id !== program.id))}
                        className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4">
            {visibleProgram.map((item, index) => (
              <div key={index} className="flex items-start space-x-4 p-6 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-gray-200 dark:border-slate-700">
                <div className="flex-shrink-0 w-20 text-sm font-medium text-amber-600 dark:text-amber-400">
                  {item.time}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 dark:text-white">{item.event}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ticket Categories */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-hidden">
          <div className="flex items-center justify-between mb-8">
            <h2 className="section-title-animated text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">Ticket Categories</h2>
            {canEdit && (
              <button
                onClick={() => setShowTicketManagement(!showTicketManagement)}
                className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
              >
                <Edit className="w-5 h-5" />
              </button>
            )}
          </div>

          {showTicketManagement && canEdit && (
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 mb-8">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Ticket Management</h3>
              <div className="space-y-4">
                {ticketTypes.map((ticket) => (
                  <div key={ticket.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex-1">
                      {editingTicket === ticket.id ? (
                        <div className="grid grid-cols-6 gap-4">
                          <input
                            type="text"
                            value={ticket.name}
                            onChange={(e) => setTicketTypes(prev => prev.map(t => 
                              t.id === ticket.id ? { ...t, name: e.target.value } : t
                            ))}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                          <input
                            type="number"
                            value={ticket.price}
                            onChange={(e) => setTicketTypes(prev => prev.map(t => 
                              t.id === ticket.id ? { ...t, price: parseInt(e.target.value) } : t
                            ))}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                          <input
                            type="text"
                            value={ticket.description}
                            onChange={(e) => setTicketTypes(prev => prev.map(t => 
                              t.id === ticket.id ? { ...t, description: e.target.value } : t
                            ))}
                            className="col-span-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                          <input
                            type="number"
                            value={ticket.available}
                            onChange={(e) => setTicketTypes(prev => prev.map(t => 
                              t.id === ticket.id ? { ...t, available: parseInt(e.target.value) } : t
                            ))}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                          <input
                            type="number"
                            value={ticket.total}
                            onChange={(e) => setTicketTypes(prev => prev.map(t => 
                              t.id === ticket.id ? { ...t, total: parseInt(e.target.value) } : t
                            ))}
                            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                          />
                        </div>
                      ) : (
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">
                            {ticket.name} - KES {ticket.price.toLocaleString()}
                          </div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">{ticket.description}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-500">
                            {ticket.available} of {ticket.total} available
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => toggleTicketVisibility(ticket.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          ticket.isVisible 
                            ? 'text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20' 
                            : 'text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                        }`}
                      >
                        {ticket.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => setEditingTicket(editingTicket === ticket.id ? null : ticket.id)}
                        className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg"
                      >
                        {editingTicket === ticket.id ? <Save className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => setTicketTypes(prev => prev.filter(t => t.id !== ticket.id))}
                        className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {visibleTickets.map((ticket) => (
              <div key={ticket.id} className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg sm:rounded-xl p-4 sm:p-6 hover:shadow-lg transition-shadow">
                <div className="text-center mb-4">
                  <h4 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">{ticket.name}</h4>
                  <p className="text-2xl sm:text-3xl font-bold text-amber-600 dark:text-amber-400 mt-2">
                    KES {ticket.price.toLocaleString()}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{ticket.description}</p>
                </div>

                <div className="space-y-1.5 sm:space-y-2 mb-4">
                  {ticket.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <Star className="w-4 h-4 text-amber-400 fill-current" />
                      <span className="text-gray-600 dark:text-gray-400">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <span>Available</span>
                    <span>{ticket.available} of {ticket.total}</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-amber-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${((ticket.total - ticket.available) / ticket.total) * 100}%` }}
                    />
                  </div>
                </div>

                <button
                  disabled={ticket.available === 0}
                  className={`w-full py-2.5 sm:py-3 px-3 sm:px-4 rounded-lg font-medium transition-colors text-sm sm:text-base ${
                    ticket.available === 0
                      ? 'bg-gray-100 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600'
                  }`}
                >
                  {ticket.available === 0 ? 'Sold Out' : 'Book Now'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default PublicGala;