import React from 'react';
import { Trophy, Award, Users, Calendar, Star, ArrowRight, Play, MapPin, Clock, CheckCircle } from 'lucide-react';
import EntryCTA from '../Shared/EntryCTA';

const PublicHomepage: React.FC = () => {
  const stats = [
    { number: '28', label: 'Award Categories', icon: Award },
    { number: '247', label: 'Entries Submitted', icon: Star },
    { number: '12K+', label: 'Votes Cast', icon: Trophy },
    { number: '1.8K', label: 'Participants', icon: Users }
  ];

  const categories = [
    { name: 'Best Luxury Hotel', entries: 23, image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Best Safari Lodge', entries: 18, image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Best Beach Resort', entries: 15, image: 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Best Tourism Personality', entries: 12, image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400' }
  ];

  const timeline = [
    { phase: 'Nominations Open', date: 'Sep 1 - Feb 15', status: 'active' },
    { phase: 'Jury Evaluation', date: 'Feb 16 - Feb 28', status: 'active' },
    { phase: 'Public Voting', date: 'Mar 1 - Mar 10', status: 'upcoming' },
    { phase: 'Gala Ceremony', date: 'Mar 15, 2025', status: 'upcoming' }
  ];

  return (
    <div className="bg-white dark:bg-slate-900">
      {/* Stats Section */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-hidden">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Kenya Tourism Awards 2025
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto px-4">
              Celebrating excellence, innovation, and sustainability in Kenya's tourism industry
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 shadow-lg">
                    <Icon className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                  </div>
                  <div className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white mb-1 sm:mb-2">{stat.number}</div>
                  <div className="text-sm sm:text-base text-gray-600 dark:text-gray-400 font-medium">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-hidden">
          {/* Entry CTA */}
          <div className="mb-16">
            <EntryCTA 
              variant="hero" 
              showCountdown={true}
              className="mb-8"
            />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div>
              <h2 className="section-title-animated text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-4 sm:mb-6">
                Recognizing Tourism Excellence
              </h2>
              <p className="text-base sm:text-lg text-gray-600 dark:text-gray-400 mb-4 sm:mb-6">
                The Kenya Tourism Awards celebrate outstanding achievements in the tourism sector, 
                recognizing businesses, individuals, and organizations that have demonstrated excellence, 
                innovation, and commitment to sustainable tourism practices.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm sm:text-base text-gray-700 dark:text-gray-300">28 comprehensive award categories</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm sm:text-base text-gray-700 dark:text-gray-300">Expert jury evaluation process</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm sm:text-base text-gray-700 dark:text-gray-300">Public voting participation</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm sm:text-base text-gray-700 dark:text-gray-300">Prestigious gala ceremony</span>
                </div>
              </div>
            </div>
            <div className="relative mt-8 lg:mt-0">
              <img
                src="https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Kenya Tourism"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-2xl hidden sm:block"></div>
              <button className="absolute inset-0 flex items-center justify-center group">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-white/90 rounded-full flex items-center justify-center group-hover:bg-white group-hover:scale-110 transition-all duration-300">
                  <Play className="w-5 h-5 sm:w-6 sm:h-6 text-slate-900 ml-1" />
                </div>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-hidden">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Award Categories
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-400 px-4">
              Explore the diverse categories celebrating tourism excellence
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {categories.map((category, index) => (
              <div key={index} className="bg-white dark:bg-slate-900 rounded-xl sm:rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-40 sm:h-48 object-cover"
                />
                <div className="p-4 sm:p-6">
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
                    {category.name}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                    {category.entries} entries submitted
                  </p>
                  <button className="flex items-center space-x-2 text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 font-medium">
                    <span>View Entries</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <button className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 sm:px-8 py-3 rounded-lg font-medium hover:from-blue-600 hover:to-indigo-600 transition-colors text-sm sm:text-base">
              View All Categories
            </button>
          </div>
        </div>
      </section>

      {/* CEO's Gala Speech Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 rounded-2xl overflow-hidden shadow-xl border border-amber-200 dark:border-amber-800">
            <div className="grid grid-cols-1 lg:grid-cols-20 gap-0 lg:gap-8">
              {/* Text Content - 65% */}
              <div className="lg:col-span-13 p-8 lg:p-12 relative z-10">
                <div className="max-w-none">
                  <span className="inline-block px-4 py-2 bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-400 text-sm font-semibold rounded-full mb-6">
                    CEO's Address
                  </span>
                  <h2 className="section-title-animated text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
                    Celebrating Kenya's Tourism Trailblazers
                  </h2>
                  <p className="text-lg lg:text-xl text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
                    A heartfelt celebration speech honoring Kenya's top tourism and hospitality achievers, 
                    highlighting industry growth, innovation, and the pioneering spirit that drives our sector forward.
                  </p>
                </div>
                
                <div className="prose prose-lg max-w-none text-gray-700 dark:text-gray-300">
                  <p className="text-base leading-relaxed mb-4">
                    "Distinguished guests, esteemed nominees, corporate partners, tourism and hospitality industry 
                    leaders—good evening and welcome to the Kenya Tourism Awards Gala. Tonight, we celebrate 
                    excellence, innovation and resilience in our country's tourism and hospitality industry."
                  </p>
                  <p className="text-base leading-relaxed mb-4">
                    "Since our National Breakfast Launch, we received over 3,000 entries across 30 categories. 
                    From hoteliers to conservationists, from airlines to influencers—all eager to showcase 
                    their efforts in making Kenya a world-class tourism destination."
                  </p>
                  <p className="text-base leading-relaxed">
                    "Tourism is more than an industry—it's about the passionate people who craft unforgettable experiences. 
                    From the tour guides who bring our rich history to life, to the dedicated hotel staff who create 
                    memorable stays, and the brave conservationists protecting our precious wildlife heritage."
                  </p>
                  <p className="text-base leading-relaxed mb-6">
                    "These are Kenya's tourism trailblazers—visionaries who don't just follow industry standards 
                    but set new benchmarks for excellence, sustainability, and innovation..."
                  </p>
                </div>
                
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 mt-8">
                  <button 
                    className="group bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center justify-center space-x-2"
                    onClick={() => {
                      const fullSpeechModal = document.createElement('div');
                      fullSpeechModal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
                      fullSpeechModal.innerHTML = `
                        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[80vh] overflow-y-auto">
                          <div class="p-6 border-b border-gray-200 dark:border-gray-700">
                            <div class="flex items-center justify-between">
                              <h3 class="text-xl font-bold text-gray-900 dark:text-white">CEO's Complete Gala Speech</h3>
                              <button onclick="this.parentElement.parentElement.parentElement.parentElement.remove()" class="text-gray-400 hover:text-gray-600">×</button>
                            </div>
                          </div>
                          <div class="p-6 prose prose-lg max-w-none">
                            ${`
                              <p>Distinguished guests, esteemed nominees, corporate partners, tourism and hospitality industry leaders, members of the media and all our honored attendees—good evening and welcome to the Kenya Tourism Awards Gala.</p>
                              
                              <p>It is a great privilege to stand before you tonight as we come together to celebrate excellence, innovation and resilience in our country's tourism and hospitality industry. The Kenya Tourism Awards Gala Dinner Ceremony is a momentous occasion dedicated to recognizing individuals, businesses and organizations that have made significant contributions toward the growth and sustainability of our country's tourism sector.</p>
                              
                              <p>The journey to this night has been remarkable and inspiring. Since the National Breakfast Launch on 12th November 2024, we have witnessed overwhelming industry participation and enthusiasm. We received over 3,000 entries, covering 30 categories, spanning from hoteliers, airlines, tour operators, restaurants, conservationists, influencers and even counties, all eager to showcase their efforts in making Kenya a world-class tourism destination.</p>
                              
                              <p>Our shortlisting process was extensive, conducted by a jury of experienced professionals in the tourism and hospitality industry, ensuring credibility and transparency. The public voting phase followed, drawing incredible engagement across the country and beyond. As of the close of voting, we had received thousands of votes, demonstrating the passion and commitment that Kenyans and industry stakeholders have towards recognizing and celebrating excellence in our sector.</p>
                              
                              <p>Tonight, we crown this journey by celebrating the best among us—the trailblazers, pioneers and game-changers who have continuously elevated the standards of service, sustainability and innovation in our industry.</p>
                              
                              <p>Tourism is a key pillar of our economy, contributing significantly to GDP, employment, and community development. Beyond the numbers, tourism is about people and experiences—it is about the tour guides who bring our history to life, the hotel staff who create memorable stays, the travel companies that showcase our landscapes, the conservationists protecting our wildlife and the content creators who share Kenya's beauty with the world.</p>
                              
                              <p>Through the Kenya Tourism Awards, we aim to set new standards, encourage competition and drive innovation that positions Kenya as a top global destination. These awards are not just about recognition—they are about inspiration, motivation and paving the way for a thriving and sustainable tourism sector.</p>
                              
                              <p>This event would not be possible without the support of our partners, sponsors and stakeholders who have believed in this vision and made tonight a reality. To our esteemed jury members, we thank you for your time and expertise in ensuring fairness and integrity in the selection process. To the media and communication partners, we appreciate your role in amplifying the message of Kenya's tourism excellence.</p>
                              
                              <p>To all the shortlisted nominees, congratulations! Making it to this stage is already a testament to your hard work and dedication. To our soon-to-be winners, this recognition is a celebration of your impact and contribution to the tourism industry.</p>
                              
                              <p>As we honor tonight's winners, let us not forget that the work does not end here. The Kenya Tourism Awards is not just about celebrating the best—it is about inspiring continuous improvement and collaboration. It is about ensuring that our tourism industry remains resilient, innovative, and sustainable for future generations.</p>
                              
                              <p>This Gala Dinner is only the beginning. Throughout the year, we have lined up industry-focused initiatives, capacity-building programs and sustainability-driven projects aimed at fostering growth within the sector. We invite all of you to walk this journey with us as we take Kenya's tourism to even greater heights.</p>
                              
                              <p>As we begin this evening's celebrations, I encourage you all to take this opportunity to network, engage and celebrate the achievements of our industry leaders.</p>
                              
                              <p>Let us raise our glasses to a thriving and dynamic tourism industry, to Kenya and to the bright future that lies ahead!</p>
                              
                              <p><em>Thank you, and I wish you all an incredible evening of celebration and inspiration.</em></p>
                            `.split('\n').map(p => p.trim()).filter(p => p).map(p => `<p class="text-gray-700 dark:text-gray-300 leading-relaxed mb-4">${p}</p>`).join('')}
                          </div>
                        </div>
                      `;
                      document.body.appendChild(fullSpeechModal);
                    }}
                  >
                    <span>Read Full Speech</span>
                    <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                  <a 
                    href="/about"
                    className="px-6 py-3 border-2 border-amber-500 text-amber-600 dark:text-amber-400 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors font-medium text-center"
                  >
                    About Our Vision
                  </a>
                </div>
              </div>
              
              {/* CEO Image - 35% */}
              <div className="lg:col-span-7 relative flex items-center justify-center p-8 lg:p-12">
                <div className="relative">
                  {/* Background decorative elements */}
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-400/20 to-orange-500/20 rounded-2xl blur-xl transform scale-110"></div>
                  <div className="absolute -top-4 -left-4 w-24 h-24 bg-amber-400/10 rounded-full blur-lg animate-pulse"></div>
                  <div className="absolute -bottom-4 -right-4 w-20 h-20 bg-orange-400/10 rounded-full blur-md animate-pulse delay-1000"></div>
                  
                  {/* CEO Portrait with modern frame */}
                  <img
                    src="https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=500"
                    alt="CEO - Kenya Tourism Awards"
                    className="relative z-10 w-56 h-72 lg:w-64 lg:h-80 xl:w-72 xl:h-96 object-cover rounded-2xl shadow-2xl border-4 border-white dark:border-gray-800"
                    style={{ aspectRatio: '3/4' }}
                  />
                  
                  {/* Achievement badge overlay */}
                  <div className="absolute -bottom-6 -right-6 bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl p-4 shadow-2xl border-2 border-white dark:border-gray-800">
                    <svg className="w-8 h-8 lg:w-10 lg:h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L13.5 8.5L20 10L13.5 11.5L12 18L10.5 11.5L4 10L10.5 8.5L12 2Z"/>
                    </svg>
                  </div>
                  
                  {/* Modern geometric accent */}
                  <div className="absolute -top-6 -left-6 w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg shadow-lg transform rotate-12 opacity-80"></div>
                </div>
                
                {/* Additional floating accent elements */}
                <div className="absolute top-8 left-8 w-3 h-3 bg-amber-400 rounded-full opacity-60 animate-pulse"></div>
                <div className="absolute bottom-16 left-8 w-2 h-2 bg-orange-400 rounded-full opacity-40 animate-pulse delay-1000"></div>
                <div className="absolute top-16 right-12 w-4 h-4 bg-red-400 rounded-full opacity-50 animate-pulse delay-500"></div>
              </div>
            </div>
            
            {/* Subtle overlapping effect */}
            <div className="hidden lg:block absolute top-1/2 left-1/2 transform -translate-x-8 -translate-y-1/2 w-16 h-32 bg-gradient-to-r from-amber-100/80 to-orange-100/80 dark:from-amber-800/20 dark:to-orange-800/20 rounded-full blur-sm"></div>
          </div>
        </div>
      </section>

      {/* Key Milestones Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Key Milestones
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Important dates and achievements in our awards journey
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 justify-items-end">
            {timeline.map((item, index) => (
              <div key={index} className="relative w-full max-w-xs ml-auto">
                <div className="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-slate-700 hover:shadow-xl transition-all">
                  <div className="text-center">
                    {/* Icon Upload Area for Admin */}
                    <div className="relative">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                      item.status === 'active'
                        ? 'bg-blue-500'
                        : item.status === 'completed'
                        ? 'bg-green-500'
                        : 'bg-gray-300 dark:bg-gray-600'
                    } shadow-lg`}>
                      {item.status === 'active' ? (
                        <Clock className="w-8 h-8 text-white" />
                      ) : item.status === 'completed' ? (
                        <CheckCircle className="w-8 h-8 text-white" />
                      ) : (
                        <Calendar className="w-8 h-8 text-white" />
                      )}
                    </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      {item.phase}
                    </h3>
                    <p className="text-blue-600 dark:text-blue-400 font-medium text-sm mb-3">{item.date}</p>
                    {item.status === 'active' && (
                      <span className="inline-block px-3 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 text-xs font-medium rounded-full">
                        Currently Active
                      </span>
                    )}
                    {item.status === 'completed' && (
                      <span className="inline-block px-3 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400 text-xs font-medium rounded-full">
                        ✓ Completed
                      </span>
                    )}
                    {item.status === 'upcoming' && (
                      <span className="inline-block px-3 py-1 bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-400 text-xs font-medium rounded-full">
                        Upcoming
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
            
          {/* Extended Timeline Items */}
          <div className="mt-16">
            <div className="text-center mb-8">
              <h3 className="section-title-animated text-2xl font-bold text-gray-900 dark:text-white mb-2">
                Upcoming Initiatives
              </h3>
              <p className="text-lg text-gray-600 dark:text-gray-400">
                Exciting events and activities on the horizon
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 justify-items-end">
              {[
                { phase: 'Winners Spotlight', date: 'Mar 20, 2025', icon: Star, description: 'Showcase and celebrate all award winners' },
                { phase: 'KTA 2025 Documentary', date: 'Apr 2025', icon: Award, description: 'Behind-the-scenes documentary production' },
                { phase: 'Tourism Magazine Edition', date: 'May 2025', icon: Trophy, description: 'Annual publication featuring winners' },
                { phase: 'Badge Issuance Events', date: 'Jul 2025', icon: CheckCircle, description: 'Regional badge presentation events' }
              ].map((item, index) => {
                const Icon = item.icon;
                return (
                  <div key={`extended-${index}`} className="relative w-full max-w-xs ml-auto">
                    <div className="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-slate-700 hover:shadow-xl transition-all">
                      <div className="text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                          <Icon className="w-8 h-8 text-white" />
                        </div>
                        <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          {item.phase}
                        </h4>
                        <p className="text-purple-600 dark:text-purple-400 font-medium text-sm mb-3">{item.date}</p>
                        <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{item.description}</p>
                        <span className="inline-block px-3 py-1 bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-400 text-xs font-medium rounded-full">
                          Future Initiative
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Meet Our Team
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Dedicated professionals committed to celebrating tourism excellence
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                id: '1',
                name: 'Dr. Sarah Mwangi',
                role: 'Awards Director',
                image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
                tagline: 'Leading tourism expert with 15+ years in industry development and strategic planning.',
                department: 'Leadership',
                experience: '15+ years',
                socialLinks: {
                  linkedin: 'https://linkedin.com/in/sarah-mwangi',
                  twitter: 'https://twitter.com/sarahmwangi'
                }
              },
              {
                id: '2',
                name: 'James Kiprotich',
                role: 'Jury Coordinator',
                image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
                tagline: 'Hospitality veteran and former hotel general manager with extensive luxury hospitality experience.',
                department: 'Evaluation',
                experience: '12+ years',
                socialLinks: {
                  linkedin: 'https://linkedin.com/in/james-kiprotich'
                }
              },
              {
                id: '3',
                name: 'Grace Wanjiku',
                role: 'Events Manager',
                image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
                tagline: 'Award-winning event planner specializing in luxury experiences and large-scale corporate events.',
                department: 'Operations',
                experience: '8+ years',
                socialLinks: {
                  linkedin: 'https://linkedin.com/in/grace-wanjiku',
                  instagram: 'https://instagram.com/gracewanjiku'
                }
              },
              {
                id: '4',
                name: 'Michael Ochieng',
                role: 'Marketing Director',
                image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
                tagline: 'Digital marketing strategist with expertise in tourism promotion and brand development.',
                department: 'Marketing',
                experience: '10+ years',
                socialLinks: {
                  linkedin: 'https://linkedin.com/in/michael-ochieng',
                  twitter: 'https://twitter.com/michaelochieng'
                }
              }
            ].map((member, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-slate-700 overflow-hidden">
                  {/* Profile Card Content */}
                  <div className="p-6">
                    {/* Square Profile Photo */}
                    <div className="relative mb-4">
                      <img
                        src={member.image}
                        alt={member.name}
                        className="w-full aspect-square object-cover rounded-xl shadow-md"
                      />
                      {/* Department Badge */}
                      <div className="absolute top-3 right-3">
                        <span className="px-2 py-1 bg-amber-500/90 backdrop-blur-sm text-white text-xs font-medium rounded-full">
                          {member.department}
                        </span>
                      </div>
                    </div>
                    {/* Member Info */}
                    <div className="text-center mb-4">
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                        {member.name}
                      </h3>
                      <p className="text-amber-600 dark:text-amber-400 font-semibold text-sm mb-2">
                        {member.role}
                      </p>
                      <p className="text-gray-500 dark:text-gray-500 text-xs mb-3">
                        {member.experience} experience
                      </p>
                    </div>

                    {/* Bio/Tagline */}
                    <p className="text-gray-600 dark:text-gray-400 text-sm text-center mb-4 line-clamp-3 leading-relaxed">
                      {member.tagline}
                    </p>

                    {/* Social Media Icons */}
                    <div className="flex justify-center space-x-3 mb-4">
                      {member.socialLinks?.linkedin && (
                        <a 
                          href={member.socialLinks.linkedin}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white hover:bg-blue-700 transition-colors"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                          </svg>
                        </a>
                      )}
                      {member.socialLinks?.twitter && (
                        <a 
                          href={member.socialLinks.twitter}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-8 h-8 bg-sky-500 rounded-lg flex items-center justify-center text-white hover:bg-sky-600 transition-colors"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                          </svg>
                        </a>
                      )}
                      {member.socialLinks?.instagram && (
                        <a 
                          href={member.socialLinks.instagram}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-8 h-8 bg-pink-500 rounded-lg flex items-center justify-center text-white hover:bg-pink-600 transition-colors"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.624 5.367 11.99 11.988 11.99s11.99-5.366 11.99-11.99C24.007 5.367 18.641.001 12.017.001zM8.45 19.43c-.883 0-1.595-.712-1.595-1.595V6.165c0-.883.712-1.595 1.595-1.595h7.127c.883 0 1.595.712 1.595 1.595v11.67c0 .883-.712 1.595-1.595 1.595H8.45z"/>
                          </svg>
                        </a>
                      )}
                    </div>

                    {/* View Profile Button */}
                    <div className="text-center">
                      <button 
                        className="w-full px-4 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-all duration-300 font-medium transform group-hover:-translate-y-0.5 shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
                        onClick={() => {
                          // Navigate to team member profile
                          console.log('Navigate to profile:', member.id);
                        }}
                      >
                        <span>View Profile</span>
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <button className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-8 py-4 rounded-xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-colors text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center space-x-3 mx-auto">
              <Users className="w-6 h-6" />
              <span>View Full Team Directory</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Partners & Sponsors Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4 section-title">
              Our Partners & Sponsors
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Supporting excellence in Kenya's tourism industry
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">
            {[
              { name: 'Kenya Tourism Board', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Kenya Airways', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Safaricom', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'KCB Bank', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Coca Cola', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Tusker', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Nation Media', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Standard Group', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'KTDA', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Equity Bank', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Total Kenya', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Nairobi Hotel', logo: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=200' }
            ].map((partner, index) => (
              <div key={index} className="group">
                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-slate-700 hover:shadow-md transition-all duration-300 group-hover:scale-105">
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    className="w-full h-16 object-contain filter grayscale group-hover:grayscale-0 transition-all duration-300"
                  />
                </div>
                <p className="text-center text-xs text-gray-600 dark:text-gray-400 mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  {partner.name}
                </p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Interested in partnering with us?
            </p>
            <button className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors">
              Become a Partner
            </button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-500 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title-animated text-3xl font-bold mb-6">
            Ready to Join the Champions? Be Part of the Excellence
          </h2>
          <p className="text-xl text-amber-100 mb-8 max-w-2xl mx-auto">
            Join thousands of tourism stakeholders in celebrating excellence. Submit your entry or vote for your favorites.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <button 
              onClick={() => window.location.href = '/entries'}
              className="bg-white text-amber-600 px-8 py-3 rounded-lg font-medium hover:bg-gray-50 transition-colors flex items-center space-x-2"
            >
              <Trophy className="w-5 h-5" />
              <span>Submit Entry</span>
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-medium hover:bg-white hover:text-amber-600 transition-colors flex items-center space-x-2">
              <Calendar className="w-5 h-5" />
              <span>Gala Tickets</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PublicHomepage;