import React from 'react';
import { Trophy, Award, Users, Target, Heart, Globe, CheckCircle, Star } from 'lucide-react';

const PublicAbout: React.FC = () => {
  const values = [
    {
      icon: Trophy,
      title: 'Excellence',
      description: 'Recognizing outstanding achievements and setting new standards in tourism'
    },
    {
      icon: Heart,
      title: 'Sustainability',
      description: 'Promoting responsible tourism practices that benefit communities and environment'
    },
    {
      icon: Users,
      title: 'Community',
      description: 'Bringing together stakeholders to celebrate and advance tourism in Kenya'
    },
    {
      icon: Globe,
      title: 'Innovation',
      description: 'Encouraging creative solutions and forward-thinking approaches in tourism'
    }
  ];

  const team = [
    {
      name: 'Dr. Sarah Mwangi',
      role: 'Awards Director',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
      bio: 'Leading tourism expert with 15+ years in industry development'
    },
    {
      name: 'James Kiprotich',
      role: 'Jury Coordinator',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
      bio: 'Hospitality veteran and former hotel general manager'
    },
    {
      name: 'Grace Wanjiku',
      role: 'Events Manager',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
      bio: 'Award-winning event planner specializing in luxury experiences'
    }
  ];

  return (
    <div className="bg-white dark:bg-slate-900">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="section-title-animated section-title-large font-bold text-white mb-6">
            About Kenya Tourism Awards
          </h1>
          <p className="text-xl text-amber-100 max-w-3xl mx-auto">
            Celebrating excellence, innovation, and sustainability in Kenya's vibrant tourism industry since 2020
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-6">
                To recognize, celebrate, and promote excellence in Kenya's tourism sector while fostering 
                sustainable practices that benefit local communities, preserve our natural heritage, and 
                enhance visitor experiences.
              </p>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">Recognition</h3>
                    <p className="text-gray-600 dark:text-gray-400">Honoring outstanding contributions to tourism</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">Standards</h3>
                    <p className="text-gray-600 dark:text-gray-400">Setting benchmarks for industry excellence</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">Growth</h3>
                    <p className="text-gray-600 dark:text-gray-400">Promoting sustainable tourism development</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Kenya Tourism"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-r from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center">
                <Trophy className="w-16 h-16 text-white" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              The principles that guide our mission and vision
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                    {value.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* History Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Our Journey
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Five years of celebrating tourism excellence
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {[
                {
                  year: '2020',
                  title: 'Foundation',
                  description: 'Kenya Tourism Awards launched with 15 categories and 150 nominations'
                },
                {
                  year: '2021',
                  title: 'Growth',
                  description: 'Expanded to 20 categories with over 200 nominations from across Kenya'
                },
                {
                  year: '2022',
                  title: 'Recognition',
                  description: 'Gained national recognition and partnership with Kenya Tourism Board'
                },
                {
                  year: '2023',
                  title: 'Innovation',
                  description: 'Introduced sustainability awards and digital voting platform'
                },
                {
                  year: '2024',
                  title: 'Excellence',
                  description: 'Record-breaking year with 25 categories and 300+ nominations'
                },
                {
                  year: '2025',
                  title: 'Future',
                  description: 'Expanding to 28 categories with enhanced digital experience'
                }
              ].map((milestone, index) => (
                <div key={index} className="flex items-start space-x-6">
                  <div className="flex-shrink-0 w-20 h-20 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-lg">{milestone.year}</span>
                  </div>
                  <div className="pt-2">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                      {milestone.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {milestone.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Meet Our Team
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Dedicated professionals committed to tourism excellence
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white dark:bg-slate-900 rounded-2xl p-6 text-center shadow-lg">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  {member.name}
                </h3>
                <p className="text-amber-600 dark:text-amber-400 font-medium mb-3">
                  {member.role}
                </p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {member.bio}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Our Impact
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Making a difference in Kenya's tourism landscape
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { number: '1,200+', label: 'Nominees Recognized' },
              { number: '50K+', label: 'Votes Cast' },
              { number: '47', label: 'Counties Represented' },
              { number: '95%', label: 'Participant Satisfaction' }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-amber-600 dark:text-amber-400 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default PublicAbout;