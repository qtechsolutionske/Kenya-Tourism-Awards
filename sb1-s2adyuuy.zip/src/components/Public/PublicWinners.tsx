import React, { useState } from 'react';
import { 
  Trophy, Award, Star, Calendar, MapPin, ExternalLink, Download, 
  Share2, Edit, Eye, EyeOff, Save, Plus, Trash2, Filter, Search,
  ChevronDown, ChevronUp, Globe, Building2, Plane, Users,
  Target, Sparkles, Crown, Medal, CheckCircle, ArrowRight,
  Upload, X, Camera, FileText, Building, Heart, Shield,
  Zap, Code, Settings, Handshake
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { winners2024, winnersByGroup, winners2024Stats, Winner2024 } from '../../data/winners2024';

const PublicWinners: React.FC = () => {
  const { user } = useAuth();
  const [selectedYear, setSelectedYear] = useState(2024);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(['Facilities & Establishments']));
  const [searchTerm, setSearchTerm] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [editingWinner, setEditingWinner] = useState<string | null>(null);
  const [winnersData, setWinnersData] = useState(winners2024);
  const [showWinnerForm, setShowWinnerForm] = useState(false);
  const [newWinner, setNewWinner] = useState<Partial<Winner2024>>({
    category: '',
    categoryGroup: 'Facilities & Establishments',
    winner: '',
    organization: '',
    description: '',
    website: '',
    image: '',
    achievements: [],
    location: '',
    yearEstablished: new Date().getFullYear(),
    specialNotes: ''
  });

  const canEdit = user && (
    user.role === 'superadmin' || 
    user.role === 'admin' || 
    user.role === 'manager' ||
    user.permissions?.includes('edit_winners')
  );

  const toggleGroup = (groupName: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupName)) {
        newSet.delete(groupName);
      } else {
        newSet.add(groupName);
      }
      return newSet;
    });
  };

  const expandAll = () => {
    setExpandedGroups(new Set(Object.keys(winnersByGroup)));
  };

  const collapseAll = () => {
    setExpandedGroups(new Set());
  };

  const filteredWinners = searchTerm 
    ? winnersData.filter(winner => 
        winner.winner.toLowerCase().includes(searchTerm.toLowerCase()) ||
        winner.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        winner.organization?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        winner.location.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : null;

  const updateWinner = (winnerId: string, updates: Partial<Winner2024>) => {
    setWinnersData(prev => prev.map(winner => 
      winner.id === winnerId ? { ...winner, ...updates } : winner
    ));
  };

  const deleteWinner = (winnerId: string) => {
    if (window.confirm('Are you sure you want to delete this winner?')) {
      setWinnersData(prev => prev.filter(winner => winner.id !== winnerId));
    }
  };

  const addWinner = () => {
    if (!newWinner.winner || !newWinner.category) return;
    
    const winner: Winner2024 = {
      id: `winner-${Date.now()}`,
      category: newWinner.category!,
      categoryGroup: newWinner.categoryGroup!,
      winner: newWinner.winner!,
      organization: newWinner.organization,
      description: newWinner.description || '',
      website: newWinner.website,
      image: newWinner.image || 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
      achievements: newWinner.achievements || [],
      location: newWinner.location || '',
      yearEstablished: newWinner.yearEstablished,
      specialNotes: newWinner.specialNotes,
      isEditable: true
    };
    
    setWinnersData(prev => [...prev, winner]);
    setNewWinner({
      category: '',
      categoryGroup: 'Facilities & Establishments',
      winner: '',
      organization: '',
      description: '',
      website: '',
      image: '',
      achievements: [],
      location: '',
      yearEstablished: new Date().getFullYear(),
      specialNotes: ''
    });
    setShowWinnerForm(false);
  };

  const getGroupIcon = (groupName: string) => {
    switch (groupName) {
      case 'Facilities & Establishments':
        return Building2;
      case 'Transport & Mobility':
        return Plane;
      case 'Special Recognition':
        return Heart;
      case 'Industry Icons':
        return Crown;
      case 'Trailblazer Counties':
        return Medal;
      case 'Surprise Categories':
        return Sparkles;
      default:
        return Award;
    }
  };

  const getGroupColor = (groupName: string) => {
    switch (groupName) {
      case 'Facilities & Establishments':
        return 'from-blue-500 to-indigo-600';
      case 'Transport & Mobility':
        return 'from-green-500 to-emerald-600';
      case 'Special Recognition':
        return 'from-pink-500 to-purple-600';
      case 'Industry Icons':
        return 'from-amber-500 to-orange-600';
      case 'Trailblazer Counties':
        return 'from-teal-500 to-cyan-600';
      case 'Surprise Categories':
        return 'from-red-500 to-pink-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const WinnerCard: React.FC<{ winner: Winner2024 }> = ({ winner }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editData, setEditData] = useState(winner);

    const handleSave = () => {
      updateWinner(winner.id, editData);
      setIsEditing(false);
    };

    if (isEditing && canEdit) {
      return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-blue-500 shadow-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-blue-600 dark:text-blue-400">Editing Winner</h4>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleSave}
                className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
              >
                <Save className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsEditing(false)}
                className="px-3 py-1 bg-gray-600 text-white text-sm rounded hover:bg-gray-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Winner Name</label>
              <input
                type="text"
                value={editData.winner}
                onChange={(e) => setEditData(prev => ({ ...prev, winner: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Organization</label>
              <input
                type="text"
                value={editData.organization || ''}
                onChange={(e) => setEditData(prev => ({ ...prev, organization: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Description</label>
              <textarea
                value={editData.description}
                onChange={(e) => setEditData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Website URL</label>
              <input
                type="url"
                value={editData.website || ''}
                onChange={(e) => setEditData(prev => ({ ...prev, website: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Image URL</label>
              <input
                type="url"
                value={editData.image}
                onChange={(e) => setEditData(prev => ({ ...prev, image: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-slate-700 group">
        <div className="relative">
          <img
            src={winner.image}
            alt={winner.winner}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              e.currentTarget.src = 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800';
            }}
          />
          <div className="absolute top-4 left-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
            <Trophy className="w-3 h-3" />
            <span>2024 Winner</span>
          </div>
          {winner.specialNotes && (
            <div className="absolute top-4 right-4 bg-purple-500 text-white px-2 py-1 rounded-full text-xs font-medium">
              {winner.specialNotes.includes('UNESCO') ? '🏛️' : 
               winner.specialNotes.includes('Olympic') ? '🥇' : 
               winner.specialNotes.includes('MGallery') ? '✨' : 
               winner.specialNotes.includes('Leading') ? '⭐' : '🏆'}
            </div>
          )}
          
          {canEdit && editMode && (
            <div className="absolute bottom-4 right-4 flex space-x-2">
              <button
                onClick={() => setIsEditing(true)}
                className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={() => deleteWinner(winner.id)}
                className="p-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        <div className="p-6">
          <div className="mb-4">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
              {winner.winner}
            </h3>
            {winner.organization && (
              <p className="text-blue-600 dark:text-blue-400 font-medium mb-2">{winner.organization}</p>
            )}
            <div className="flex items-center space-x-2 mb-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span className="text-sm font-medium text-amber-600 dark:text-amber-400">
                {winner.category}
              </span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
              <MapPin className="w-4 h-4" />
              <span>{winner.location}</span>
              {winner.yearEstablished && (
                <>
                  <span>•</span>
                  <span>Est. {winner.yearEstablished}</span>
                </>
              )}
            </div>
          </div>
          
          <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-3 leading-relaxed">
            {winner.description}
          </p>

          <div className="space-y-3 mb-4">
            <h4 className="font-medium text-gray-900 dark:text-white text-sm">Key Achievements:</h4>
            <ul className="space-y-1">
              {winner.achievements.slice(0, 2).map((achievement: string, i: number) => (
                <li key={i} className="flex items-start space-x-2 text-xs text-gray-600 dark:text-gray-400">
                  <CheckCircle className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="leading-relaxed">{achievement}</span>
                </li>
              ))}
              {winner.achievements.length > 2 && (
                <li className="text-xs text-gray-500 dark:text-gray-500 italic">
                  +{winner.achievements.length - 2} more achievements
                </li>
              )}
            </ul>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3 h-3 text-amber-400 fill-current" />
                ))}
              </div>
              <span className="text-xs text-gray-500 dark:text-gray-500">Excellence Award</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => navigator.share && navigator.share({
                  title: `${winner.winner} - ${winner.category}`,
                  text: winner.description,
                  url: window.location.href
                })}
                className="p-2 text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
              >
                <Share2 className="w-4 h-4" />
              </button>
              {winner.website && (
                <a
                  href={winner.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const AddWinnerModal = () => (
    showWinnerForm && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Add New Winner</h3>
              <button
                onClick={() => setShowWinnerForm(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Winner Name *
                </label>
                <input
                  type="text"
                  value={newWinner.winner || ''}
                  onChange={(e) => setNewWinner(prev => ({ ...prev, winner: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Enter winner name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Organization
                </label>
                <input
                  type="text"
                  value={newWinner.organization || ''}
                  onChange={(e) => setNewWinner(prev => ({ ...prev, organization: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Organization/Company name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Category Group *
                </label>
                <select
                  value={newWinner.categoryGroup || ''}
                  onChange={(e) => setNewWinner(prev => ({ ...prev, categoryGroup: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                >
                  {Object.keys(winnersByGroup).map(group => (
                    <option key={group} value={group}>{group}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Award Category *
                </label>
                <input
                  type="text"
                  value={newWinner.category || ''}
                  onChange={(e) => setNewWinner(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="e.g., Best Luxury Hotel"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Location
                </label>
                <input
                  type="text"
                  value={newWinner.location || ''}
                  onChange={(e) => setNewWinner(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="City, County"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Website URL
                </label>
                <input
                  type="url"
                  value={newWinner.website || ''}
                  onChange={(e) => setNewWinner(prev => ({ ...prev, website: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="https://www.example.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Description
              </label>
              <textarea
                value={newWinner.description || ''}
                onChange={(e) => setNewWinner(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="Describe the winner's achievements and excellence..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Image URL
              </label>
              <input
                type="url"
                value={newWinner.image || ''}
                onChange={(e) => setNewWinner(prev => ({ ...prev, image: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="https://images.example.com/photo.jpg"
              />
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowWinnerForm(false)}
                className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={addWinner}
                disabled={!newWinner.winner || !newWinner.category}
                className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-3 rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Add Winner
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  );

  // Recalculate grouped winners based on current data
  const currentWinnersByGroup = winnersData.reduce((groups, winner) => {
    if (!groups[winner.categoryGroup]) {
      groups[winner.categoryGroup] = [];
    }
    groups[winner.categoryGroup].push(winner);
    return groups;
  }, {} as Record<string, Winner2024[]>);

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <Trophy className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="section-title-animated section-title-large font-bold text-white mb-6">
            Kenya Tourism Awards 2024 Winners
          </h1>
          <p className="text-xl text-amber-100 max-w-4xl mx-auto mb-8">
            Celebrating the champions of Kenya's tourism excellence - the organizations and individuals 
            who set new standards in hospitality, innovation, and service delivery
          </p>
          <div className="flex flex-col sm:flex-row flex-wrap items-center justify-center space-y-4 sm:space-y-0 sm:space-x-8 text-amber-100">
            <div className="flex items-center space-x-2">
              <Trophy className="w-6 h-6" />
              <span className="text-lg font-semibold">{winnersData.length} Winners</span>
            </div>
            <div className="flex items-center space-x-2">
              <Award className="w-6 h-6" />
              <span className="text-lg font-semibold">{Object.keys(currentWinnersByGroup).length} Category Groups</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-6 h-6" />
              <span className="text-lg font-semibold">March 15, 2024</span>
            </div>
          </div>
        </div>
      </section>

      {/* Admin Controls */}
      {canEdit && (
        <section className="py-6 bg-gray-100 dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Winners Management</h3>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setEditMode(!editMode)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                    editMode 
                      ? 'bg-red-600 text-white hover:bg-red-700' 
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {editMode ? <X className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
                  <span>{editMode ? 'Exit Edit Mode' : 'Edit Winners'}</span>
                </button>
                <button
                  onClick={() => setShowWinnerForm(true)}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Winner</span>
                </button>
                <button 
                  onClick={() => {
                    const csvData = winnersData.map(winner => ({
                      'Category': winner.category,
                      'Winner': winner.winner,
                      'Organization': winner.organization || '',
                      'Location': winner.location,
                      'Year Established': winner.yearEstablished || '',
                      'Website': winner.website || '',
                      'Description': winner.description
                    }));
                    
                    const csv = [
                      Object.keys(csvData[0]).join(','),
                      ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
                    ].join('\n');
                    
                    const blob = new Blob([csv], { type: 'text/csv' });
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'kta-winners-2024.csv';
                    a.click();
                  }}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>Export</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Search & Controls */}
      <section className="py-8 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search winners, organizations, or categories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={expandAll}
                className="px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
              >
                <ChevronDown className="w-4 h-4" />
                <span>Expand All</span>
              </button>
              <button
                onClick={collapseAll}
                className="px-4 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2"
              >
                <ChevronUp className="w-4 h-4" />
                <span>Collapse All</span>
              </button>
            </div>
          </div>

          {searchTerm && (
            <div className="mb-6 text-gray-600 dark:text-gray-400">
              Found {filteredWinners?.length || 0} result(s) for "{searchTerm}"
            </div>
          )}
        </div>
      </section>

      {/* Winners by Category Groups */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Display search results if searching */}
          {searchTerm && filteredWinners ? (
            <div className="space-y-6">
              <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-8">
                Search Results
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredWinners.map((winner) => (
                  <WinnerCard key={winner.id} winner={winner} />
                ))}
              </div>
            </div>
          ) : (
            /* Display by category groups */
            <div className="space-y-8">
              {Object.entries(currentWinnersByGroup).map(([groupName, groupWinners]) => {
                const isExpanded = expandedGroups.has(groupName);
                const GroupIcon = getGroupIcon(groupName);
                const groupColor = getGroupColor(groupName);

                return (
                  <div key={groupName} className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-200 dark:border-slate-700 overflow-hidden">
                    <button
                      onClick={() => toggleGroup(groupName)}
                      className={`w-full p-6 bg-gradient-to-r ${groupColor} text-white text-left hover:opacity-90 transition-opacity`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                            <GroupIcon className="w-7 h-7" />
                          </div>
                          <div>
                            <h2 className="section-title-animated text-2xl font-bold">{groupName}</h2>
                            <p className="text-white/90 mt-1">{groupWinners.length} award{groupWinners.length !== 1 ? 's' : ''}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          {canEdit && editMode && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setNewWinner(prev => ({ ...prev, categoryGroup: groupName }));
                                setShowWinnerForm(true);
                              }}
                              className="p-2 bg-white/20 backdrop-blur-sm rounded-lg hover:bg-white/30 transition-colors"
                            >
                              <Plus className="w-5 h-5" />
                            </button>
                          )}
                          <div className="text-right">
                            <div className="text-3xl font-bold">{groupWinners.length}</div>
                            <div className="text-sm text-white/80">Winner{groupWinners.length !== 1 ? 's' : ''}</div>
                          </div>
                          <div className="transform transition-transform duration-200">
                            {isExpanded ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
                          </div>
                        </div>
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="p-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-on-scroll">
                          {groupWinners.map((winner) => (
                            <WinnerCard key={winner.id} winner={winner} />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              2024 Awards by the Numbers
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              A record-breaking year celebrating tourism excellence across Kenya
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 animate-on-scroll">
            <div className="text-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{currentWinnersByGroup['Facilities & Establishments']?.length || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Facilities</div>
            </div>

            <div className="text-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Plane className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{currentWinnersByGroup['Transport & Mobility']?.length || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Transport</div>
            </div>

            <div className="text-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{currentWinnersByGroup['Special Recognition']?.length || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Recognition</div>
            </div>

            <div className="text-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{currentWinnersByGroup['Industry Icons']?.length || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Industry Icons</div>
            </div>

            <div className="text-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-cyan-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Medal className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{currentWinnersByGroup['Trailblazer Counties']?.length || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Counties</div>
            </div>

            <div className="text-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{currentWinnersByGroup['Surprise Categories']?.length || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Surprise</div>
            </div>
          </div>
        </div>
      </section>

      {/* Winners Gallery */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Winners Gallery
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Highlights from the awards ceremony and winner celebrations
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 animate-on-scroll">
            {[
              'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=600',
              'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=600',
              'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=600',
              'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&w=600'
            ].map((image, index) => (
              <div key={index} className="aspect-video rounded-lg overflow-hidden shadow-lg group cursor-pointer">
                <img
                  src={image}
                  alt={`Awards ceremony ${index + 1}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title-animated text-3xl font-bold mb-6">Ready to Join the Champions?</h2>
          <p className="text-xl text-slate-200 max-w-2xl mx-auto mb-8">
            Nominate your business or vote for your favorites in Kenya Tourism Awards 2025
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <button
              onClick={() => window.location.href = '/entries'}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-8 py-4 rounded-xl font-bold text-lg transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center space-x-3"
            >
              <Award className="w-6 h-6" />
              <span>Submit Entry for 2025</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            
            <button
              onClick={() => window.location.href = '/voting'}
              className="border-2 border-white text-white hover:bg-white hover:text-slate-900 px-8 py-4 rounded-xl font-bold text-lg transition-colors flex items-center space-x-3"
            >
              <Trophy className="w-6 h-6" />
              <span>Vote for 2025 Winners</span>
            </button>
          </div>
        </div>
      </section>

      {showWinnerForm && <AddWinnerModal />}
    </div>
  );
};

export default PublicWinners;