import React, { useState } from 'react';
import { 
  Handshake, Star, Trophy, Users, BarChart3, Target, 
  Globe, Award, Calendar, Gift, Crown, Zap, Heart,
  CheckCircle, ArrowRight, Download, Mail, Phone, 
  MapPin, ExternalLink, Play, FileText, Camera, 
  Mic, Building2, Megaphone, TrendingUp
} from 'lucide-react';

interface SponsorPackage {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
  highlight?: boolean;
  color: string;
  icon: React.ComponentType<any>;
}

const sponsorPackages: SponsorPackage[] = [
  {
    id: 'title',
    name: 'Title Sponsor',
    price: 'KES 10M',
    description: 'Exclusive title sponsorship with maximum brand visibility and premium benefits',
    features: [
      'Exclusive Title Sponsor recognition: "Kenya Tourism Awards powered by [Sponsor Name]"',
      'Premium logo placement on all KTA event materials',
      'Co-branded giveaways to KTA events attendees',
      '20 VIP tickets for the KTA Gala event',
      'Full-page ad in the event program',
      'Opportunity to present Awards to up to 10 winners',
      'Run promotional films during Gala ceremony',
      'Exclusive speaking opportunity at KTA Gala',
      'Prime booth location at Annual KTA Gala',
      'Enhanced media coverage and live Gala coverage',
      'Feature in annual KTA documentary',
      'Feature in annual KTA travelogue',
      'Center spread ad in annual KTA Magazine',
      'Comprehensive post-event report with analytics',
      'Invitation to all Annual Calendar Events under KTA Initiatives',
      'Promotional desk at all Calendar Events',
      'Exclusive speaking at all Calendar Events',
      'Knowledge Partner opportunities for thematic months',
      'Participation in charity focused events'
    ],
    highlight: true,
    color: 'from-purple-500 to-pink-500',
    icon: Crown
  },
  {
    id: 'gold',
    name: 'Gold Sponsor',
    price: 'KES 2M',
    description: 'Premium co-sponsor recognition with category ownership and extensive benefits',
    features: [
      'Co-Sponsor Recognition',
      'Ownership of an Award Category (6 categories available)',
      'Premium logo placement on Gala materials',
      '10 VIP tickets for the Gala ceremony',
      'Co-branded giveaways to KTA events attendees',
      'Full page ad in the event program',
      'Run promotional film before Award Category',
      'Branding on stage when presenting Category',
      'Present Awards to up to 5 winners',
      'Prime booth location at Annual KTA Gala',
      'Media coverage in live Gala and post-event',
      'Feature in annual KTA documentary',
      'Full page ad in annual KTA Magazine',
      'Customized post-event report',
      'Invitation to all Annual Calendar Events',
      'Promotional desk at Calendar Events',
      'Speaking opportunity at up to 5 Calendar Events',
      'Knowledge Partner for thematic months',
      'Participation in charity events'
    ],
    highlight: false,
    color: 'from-amber-500 to-orange-500',
    icon: Trophy
  },
  {
    id: 'silver',
    name: 'Silver Sponsor',
    price: 'KES 1M',
    description: 'Co-sponsor recognition with strong visibility and engagement opportunities',
    features: [
      'Co-Sponsor Recognition',
      'Logo placement on event materials',
      '10 VIP tickets for the Gala ceremony',
      'Half-page ad in the event program',
      'Co-branded giveaways to Gala attendees',
      'Booth space at the exhibition',
      'Present Awards to 1 winner at KTA Gala',
      'Media coverage in live Gala coverage',
      'Customized post-event report with metrics',
      'Invitation to up to 3 Annual Calendar Events',
      'Promotional desk at up to 3 Calendar Events',
      'Speaking opportunity at up to 3 Calendar Events',
      'Knowledge Partner for thematic months',
      'Participation in charity events'
    ],
    highlight: false,
    color: 'from-gray-400 to-gray-500',
    icon: Award
  },
  {
    id: 'bronze',
    name: 'Bronze Sponsor',
    price: 'KES 250,000',
    description: 'Support sponsor recognition with essential visibility benefits',
    features: [
      'Support Sponsor recognition',
      'Logo placement on KTA website and select materials',
      'Branded giveaways to Gala attendees',
      '5 VIP tickets for the KTA Gala ceremony',
      'Media mention in press release',
      'Participation in charity focused events'
    ],
    highlight: false,
    color: 'from-orange-600 to-red-500',
    icon: Star
  }
];

const benefits = {
  impact: [
    'Promote and advance Kenya\'s tourism sector',
    'Shape industry standards and policy through thought leadership as Knowledge Partner',
    'Promote innovation and excellence in the tourism sector',
    'Support and participate in initiatives that promote sustainable and ethical tourism',
    'Be part of a legacy that drives growth through collaboration in the tourism sector'
  ],
  visibility: [
    'Gain premium visibility to a local and global trade and consumer audience',
    'Tell your tourism story through our platforms including Annual KTA Magazine and Documentary',
    'Showcase your product at KTA events',
    'Associate with a prestigious, industry defining event that celebrates excellence'
  ],
  engagement: [
    'Personalized engagement with top level industry leaders through Calendar events',
    'Business development opportunities through Masterclasses',
    'Market development opportunities by collaborating as Knowledge Partner',
    'Showcase and promote your product at KTA events'
  ]
};

const PublicSponsors: React.FC = () => {
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const [showContactForm, setShowContactForm] = useState(false);
  const [contactForm, setContactForm] = useState({
    companyName: '',
    contactPerson: '',
    email: '',
    phone: '',
    package: '',
    message: ''
  });

  const handlePackageInquiry = (packageId: string) => {
    const selectedPkg = sponsorPackages.find(pkg => pkg.id === packageId);
    setContactForm(prev => ({ 
      ...prev, 
      package: selectedPkg?.name || '',
      message: `I'm interested in the ${selectedPkg?.name} package for Kenya Tourism Awards 2025. Please provide more information about partnership opportunities.`
    }));
    setShowContactForm(true);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Contact form submitted:', contactForm);
    // Here you would typically send the form data to your backend
    alert('Thank you for your interest! Our partnerships team will contact you within 24 hours.');
    setShowContactForm(false);
    setContactForm({
      companyName: '',
      contactPerson: '',
      email: '',
      phone: '',
      package: '',
      message: ''
    });
  };

  const ContactModal = () => (
    showContactForm && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Partnership Inquiry
              </h3>
              <button
                onClick={() => setShowContactForm(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                ×
              </button>
            </div>
          </div>

          <form onSubmit={handleContactSubmit} className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Company Name *
                </label>
                <input
                  type="text"
                  value={contactForm.companyName}
                  onChange={(e) => setContactForm(prev => ({ ...prev, companyName: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Contact Person *
                </label>
                <input
                  type="text"
                  value={contactForm.contactPerson}
                  onChange={(e) => setContactForm(prev => ({ ...prev, contactPerson: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={contactForm.email}
                  onChange={(e) => setContactForm(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  value={contactForm.phone}
                  onChange={(e) => setContactForm(prev => ({ ...prev, phone: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="+254 700 000 000"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Package of Interest
              </label>
              <select
                value={contactForm.package}
                onChange={(e) => setContactForm(prev => ({ ...prev, package: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                required
              >
                <option value="">Select a package</option>
                {sponsorPackages.map(pkg => (
                  <option key={pkg.id} value={pkg.name}>
                    {pkg.name} - {pkg.price}
                  </option>
                ))}
                <option value="Custom">Custom Package</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Message
              </label>
              <textarea
                value={contactForm.message}
                onChange={(e) => setContactForm(prev => ({ ...prev, message: e.target.value }))}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="Tell us more about your partnership interests..."
                required
              />
            </div>

            <div className="flex space-x-4">
              <button
                type="button"
                onClick={() => setShowContactForm(false)}
                className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-3 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors font-medium"
              >
                Send Inquiry
              </button>
            </div>
          </form>
        </div>
      </div>
    )
  );

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center overflow-x-hidden">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <Handshake className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 section-title">
            Partner with Excellence
          </h1>
          <p className="text-xl text-purple-100 max-w-4xl mx-auto mb-8">
            Join Kenya Tourism Awards 2025 as a sponsor and become part of a prestigious event that celebrates excellence, innovation, and sustainability in tourism
          </p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8 max-w-4xl mx-auto text-white/90">
            <div className="text-center">
              <div className="text-2xl font-bold">1,200+</div>
              <div className="text-sm">Gala Attendees</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">28</div>
              <div className="text-sm">Award Categories</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">50K+</div>
              <div className="text-sm">Media Impressions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">15M+</div>
              <div className="text-sm">Social Reach</div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Partner with KTA */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Why Partner with KTA
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Be part of Kenya's most prestigious tourism event and gain unparalleled access to industry leaders, decision-makers, and stakeholders
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Impact */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-2xl p-8">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mb-6">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Impact</h3>
              <ul className="space-y-4">
                {benefits.impact.map((benefit, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Visibility */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-2xl p-8">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl flex items-center justify-center mb-6">
                <Megaphone className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Visibility</h3>
              <ul className="space-y-4">
                {benefits.visibility.map((benefit, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-blue-500 mt-1 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Engagement */}
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-2xl p-8">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mb-6">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Engage with the Industry</h3>
              <ul className="space-y-4">
                {benefits.engagement.map((benefit, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-purple-500 mt-1 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Sponsor Packages */}
      <section className="py-16 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-hidden">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Our Sponsor Packages
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Choose the perfect sponsorship package that aligns with your business goals and marketing objectives
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {sponsorPackages.map((pkg) => {
              const Icon = pkg.icon;
              return (
                <div 
                  key={pkg.id} 
                  className={`bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-slate-700 ${
                    pkg.highlight ? 'ring-2 ring-purple-500 transform scale-105' : 'hover:-translate-y-1'
                  }`}
                >
                  {/* Package Header */}
                  <div className={`bg-gradient-to-r ${pkg.color} p-6 text-white relative overflow-hidden`}>
                    <div className="absolute top-0 right-0 w-32 h-32 opacity-10">
                      <Icon className="w-32 h-32" />
                    </div>
                    <div className="relative z-10">
                      <div className="flex items-center space-x-3 mb-3">
                        <Icon className="w-8 h-8" />
                        <h3 className="text-xl font-bold">{pkg.name}</h3>
                      </div>
                      <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                      <p className="text-white/90 text-sm">{pkg.description}</p>
                    </div>
                    {pkg.highlight && (
                      <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium">
                        Most Popular
                      </div>
                    )}
                  </div>

                  {/* Package Features */}
                  <div className="p-6">
                    <div className="space-y-3 mb-6">
                      {pkg.features.slice(0, 8).map((feature, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <CheckCircle className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                          <span className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                            {feature}
                          </span>
                        </div>
                      ))}
                      {pkg.features.length > 8 && (
                        <div className="text-center">
                          <button
                            onClick={() => setSelectedPackage(selectedPackage === pkg.id ? null : pkg.id)}
                            className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
                          >
                            {selectedPackage === pkg.id ? 'Show Less' : `+${pkg.features.length - 8} More Benefits`}
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Expanded Features */}
                    {selectedPackage === pkg.id && pkg.features.length > 8 && (
                      <div className="space-y-3 mb-6 pt-4 border-t border-gray-200 dark:border-gray-600">
                        {pkg.features.slice(8).map((feature, index) => (
                          <div key={index} className="flex items-start space-x-3">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                            <span className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                              {feature}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    <button
                      onClick={() => handlePackageInquiry(pkg.id)}
                      className={`w-full py-3 px-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center space-x-2 ${
                        pkg.highlight
                          ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600 transform hover:scale-105'
                          : 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600'
                      }`}
                    >
                      <Handshake className="w-4 h-4" />
                      <span>Partner with Us</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Partnership Opportunities */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Additional Partnership Opportunities
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Explore specialized partnership options beyond standard sponsorship packages
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-slate-700 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-xl flex items-center justify-center mb-4">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                Venue Partnership
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Provide venues for KTA events and receive extensive branding opportunities and recognition.
              </p>
              <ul className="space-y-2 mb-4">
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-teal-500" />
                  <span>Event venue branding</span>
                </li>
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-teal-500" />
                  <span>Media recognition</span>
                </li>
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-teal-500" />
                  <span>Promotional opportunities</span>
                </li>
              </ul>
              <button 
                onClick={() => handlePackageInquiry('venue')}
                className="w-full bg-teal-600 text-white py-3 px-4 rounded-lg hover:bg-teal-700 transition-colors"
              >
                Learn More
              </button>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-slate-700 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-rose-500 rounded-xl flex items-center justify-center mb-4">
                <Camera className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                Media Partnership
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Partner as a media house for extensive coverage and content collaboration opportunities.
              </p>
              <ul className="space-y-2 mb-4">
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-pink-500" />
                  <span>Official media partner status</span>
                </li>
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-pink-500" />
                  <span>Exclusive content access</span>
                </li>
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-pink-500" />
                  <span>Co-branded content</span>
                </li>
              </ul>
              <button 
                onClick={() => handlePackageInquiry('media')}
                className="w-full bg-pink-600 text-white py-3 px-4 rounded-lg hover:bg-pink-700 transition-colors"
              >
                Learn More
              </button>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-slate-700 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center mb-4">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                Knowledge Partnership
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Share expertise and thought leadership through our thematic months and educational initiatives.
              </p>
              <ul className="space-y-2 mb-4">
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-indigo-500" />
                  <span>Thought leadership platform</span>
                </li>
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-indigo-500" />
                  <span>Educational content creation</span>
                </li>
                <li className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <Star className="w-4 h-4 text-indigo-500" />
                  <span>Industry influence</span>
                </li>
              </ul>
              <button 
                onClick={() => handlePackageInquiry('knowledge')}
                className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Current Sponsors */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title-animated text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Our Proud Partners
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Leading organizations that support tourism excellence in Kenya
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {[
              'Kenya Tourism Board', 'Kenya Airways', 'Safaricom', 'KCB Bank', 
              'Equity Bank', 'Coca Cola', 'Tusker', 'Nation Media',
              'Standard Group', 'KTDA', 'Total Kenya', 'Nairobi Hotel'
            ].map((sponsor, index) => (
              <div key={index} className="group">
                <div className="bg-white dark:bg-slate-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-slate-700 hover:shadow-md transition-all duration-300 group-hover:scale-105">
                  <div className="w-full h-16 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                    <Building2 className="w-8 h-8 text-gray-400 group-hover:text-amber-500 transition-colors" />
                  </div>
                  <p className="text-center text-sm font-medium text-gray-900 dark:text-white mt-3">
                    {sponsor}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Join these industry leaders in supporting tourism excellence
            </p>
            <button 
              onClick={() => setShowContactForm(true)}
              className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-8 py-4 rounded-xl font-bold text-lg hover:from-purple-600 hover:to-blue-600 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center space-x-3 mx-auto"
            >
              <Handshake className="w-6 h-6" />
              <span>Become a Partner Today</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title-animated text-3xl font-bold mb-6">Ready to Partner with Us?</h2>
          <p className="text-xl text-slate-200 max-w-2xl mx-auto mb-8">
            Let's discuss how we can create a customized partnership that meets your business objectives
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="font-semibold mb-2">Email Us</h3>
              <p className="text-slate-300">partnerships@kenyatourismawards.com</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="font-semibold mb-2">Call Us</h3>
              <p className="text-slate-300">+254 707 242620</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6" />
              </div>
              <h3 className="font-semibold mb-2">Visit Us</h3>
              <p className="text-slate-300">Tourism House, Nairobi</p>
            </div>
          </div>

          <div className="mt-12">
            <button 
              onClick={() => setShowContactForm(true)}
              className="bg-white text-slate-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-100 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center space-x-3 mx-auto"
            >
              <Download className="w-6 h-6" />
              <span>Download Partnership Brochure</span>
            </button>
          </div>
        </div>
      </section>

      <ContactModal />
    </div>
  );
};

export default PublicSponsors;