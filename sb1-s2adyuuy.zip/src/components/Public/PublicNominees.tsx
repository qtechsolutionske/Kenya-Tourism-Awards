import React, { useState } from 'react';
import { Search, Filter, MapPin, Award, Star, ExternalLink } from 'lucide-react';

const PublicNominees: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [countyFilter, setCountyFilter] = useState('all');

  const nominees = [
    {
      id: '1',
      name: 'Hemingways Nairobi',
      category: 'Best Luxury Hotel',
      county: 'Nairobi',
      image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Exceptional luxury hospitality with world-class amenities and service excellence.',
      votes: 1247,
      isShortlisted: true
    },
    {
      id: '2',
      name: 'Angama Mara',
      category: 'Best Safari Lodge',
      county: 'Narok',
      image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Unparalleled safari experience with breathtaking views of the Maasai Mara.',
      votes: 1089,
      isShortlisted: true
    },
    {
      id: '3',
      name: 'Alfajiri Villas',
      category: 'Best Beach Resort',
      county: 'Kilifi',
      image: 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Exclusive beachfront luxury with personalized service and pristine coastal location.',
      votes: 967,
      isShortlisted: true
    },
    {
      id: '4',
      name: 'Dr. Najib Balala',
      category: 'Best Tourism Personality',
      county: 'Mombasa',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Visionary leadership in transforming Kenya\'s tourism landscape.',
      votes: 2156,
      isShortlisted: true
    },
    {
      id: '5',
      name: 'Sarova Stanley',
      category: 'Best Conference Hotel',
      county: 'Nairobi',
      image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Premier conference facilities with exceptional business hospitality services.',
      votes: 834,
      isShortlisted: false
    },
    {
      id: '6',
      name: 'Diani Beach Resort',
      category: 'Best Beach Resort',
      county: 'Kwale',
      image: 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Tropical paradise offering authentic coastal experiences and water sports.',
      votes: 756,
      isShortlisted: false
    }
  ];

  const categories = [
    'Best Luxury Hotel',
    'Best Safari Lodge',
    'Best Beach Resort',
    'Best Conference Hotel',
    'Best Tourism Personality',
    'Best County to Visit'
  ];

  const counties = [
    'Nairobi', 'Mombasa', 'Kwale', 'Kilifi', 'Narok', 'Kajiado', 'Nakuru', 'Laikipia'
  ];

  const filteredNominees = nominees.filter(nominee => {
    const matchesSearch = nominee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         nominee.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || nominee.category === categoryFilter;
    const matchesCounty = countyFilter === 'all' || nominee.county === countyFilter;
    return matchesSearch && matchesCategory && matchesCounty;
  });

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="section-title-animated section-title-large font-bold text-white mb-6">
            Meet Our Nominees
          </h1>
          <p className="text-xl text-amber-100 max-w-3xl mx-auto">
            Discover the exceptional businesses and individuals nominated for Kenya Tourism Awards 2025
          </p>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-gray-50 dark:bg-slate-800 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search nominees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-400" />
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="all">All Categories</option>
                  {categories.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              <select
                value={countyFilter}
                onChange={(e) => setCountyFilter(e.target.value)}
                className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">All Counties</option>
                {counties.map(county => (
                  <option key={county} value={county}>{county}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Nominees Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <p className="text-gray-600 dark:text-gray-400">
              Showing {filteredNominees.length} of {nominees.length} nominees
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredNominees.map((nominee) => (
              <div key={nominee.id} className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <div className="relative">
                  <img
                    src={nominee.image}
                    alt={nominee.name}
                    className="w-full h-48 object-cover"
                  />
                  {nominee.isShortlisted && (
                    <div className="absolute top-4 left-4 bg-amber-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      Shortlisted
                    </div>
                  )}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-gray-900">
                    {nominee.votes} votes
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="mb-4">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                      {nominee.name}
                    </h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mb-2">
                      <div className="flex items-center space-x-1">
                        <Award className="w-4 h-4 text-amber-500" />
                        <span>{nominee.category}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1 text-sm text-gray-600 dark:text-gray-400">
                      <MapPin className="w-4 h-4" />
                      <span>{nominee.county}</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-3">
                    {nominee.description}
                  </p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 text-amber-400 fill-current" />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Public Rating
                    </span>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white py-2 px-4 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors">
                      Vote Now
                    </button>
                    <button className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                      <ExternalLink className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredNominees.length === 0 && (
            <div className="text-center py-12">
              <Award className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No nominees found</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-500 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title-animated text-3xl font-bold text-white mb-4">
            Support Your Favorites
          </h2>
          <p className="text-xl text-amber-100 mb-8 max-w-2xl mx-auto">
            Your vote matters! Help recognize excellence in Kenya's tourism industry by voting for your favorite nominees.
          </p>
          <button className="bg-white text-amber-600 px-8 py-3 rounded-lg font-medium hover:bg-gray-50 transition-colors">
            Start Voting
          </button>
        </div>
      </section>
    </div>
  );
};

export default PublicNominees;