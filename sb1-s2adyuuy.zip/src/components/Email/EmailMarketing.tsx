import React, { useState } from 'react';
import { 
  Mail, Send, Users, Eye, MousePointer, Calendar, Plus, Edit, Trash2, 
  Settings, UserCheck, Shield, Zap, BarChart3, Target, Clock, 
  Image, Video, FileText, Palette, Code, TestTube, Globe, 
  MessageSquare, Bell, Download, Upload, Filter, Search,
  Play, Pause, RotateCcw, Copy, Share2, ExternalLink
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface EmailCampaign {
  id: string;
  name: string;
  subject: string;
  type: 'voting_reminder' | 'gala_invitation' | 'nominee_spotlight' | 'sponsor_promotion' | 'winner_announcement';
  recipients: number;
  status: 'draft' | 'scheduled' | 'sent' | 'testing';
  openRate?: number;
  clickRate?: number;
  conversionRate?: number;
  revenue?: number;
  sentAt?: Date;
  scheduledAt?: Date;
  createdBy: string;
  lastModified: Date;
}

interface EmailTemplate {
  id: string;
  name: string;
  type: string;
  thumbnail: string;
  description: string;
  isResponsive: boolean;
}

interface UserPermission {
  userId: string;
  userName: string;
  role: string;
  permissions: {
    canCreate: boolean;
    canEdit: boolean;
    canDelete: boolean;
    canSend: boolean;
    canViewAnalytics: boolean;
  };
}

const mockCampaigns: EmailCampaign[] = [
  {
    id: '1',
    name: 'Final Voting Reminder - KTA 2025',
    subject: 'Last 48 hours to vote for your favorite nominees!',
    type: 'voting_reminder',
    recipients: 2847,
    status: 'sent',
    openRate: 72.5,
    clickRate: 18.3,
    conversionRate: 8.7,
    sentAt: new Date('2024-12-10'),
    createdBy: 'admin@kta.com',
    lastModified: new Date('2024-12-10')
  },
  {
    id: '2',
    name: 'Gala Night Invitation - VIP Experience',
    subject: 'You\'re invited to the most prestigious tourism event in Kenya',
    type: 'gala_invitation',
    recipients: 1523,
    status: 'scheduled',
    scheduledAt: new Date('2024-12-15'),
    createdBy: 'events@kta.com',
    lastModified: new Date('2024-12-12')
  },
  {
    id: '3',
    name: 'Nominee Spotlight: Hemingways Nairobi',
    subject: 'Meet the luxury hospitality leaders setting new standards',
    type: 'nominee_spotlight',
    recipients: 3241,
    status: 'draft',
    createdBy: 'marketing@kta.com',
    lastModified: new Date('2024-12-11')
  }
];

const emailTemplates: EmailTemplate[] = [
  {
    id: '1',
    name: 'Voting Reminder',
    type: 'voting_reminder',
    thumbnail: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=300',
    description: 'Encourage participation with countdown timers and nominee highlights',
    isResponsive: true
  },
  {
    id: '2',
    name: 'Gala Invitation',
    type: 'gala_invitation',
    thumbnail: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=300',
    description: 'Elegant invitation with event details and ticket booking',
    isResponsive: true
  },
  {
    id: '3',
    name: 'Nominee Spotlight',
    type: 'nominee_spotlight',
    thumbnail: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=300',
    description: 'Showcase nominees with rich media and social sharing',
    isResponsive: true
  },
  {
    id: '4',
    name: 'Winner Announcement',
    type: 'winner_announcement',
    thumbnail: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=300',
    description: 'Celebrate winners with achievements and photo galleries',
    isResponsive: true
  }
];

const mockPermissions: UserPermission[] = [
  {
    userId: '1',
    userName: 'Marketing Manager',
    role: 'admin',
    permissions: {
      canCreate: true,
      canEdit: true,
      canDelete: true,
      canSend: true,
      canViewAnalytics: true
    }
  },
  {
    userId: '2',
    userName: 'Content Creator',
    role: 'editor',
    permissions: {
      canCreate: true,
      canEdit: true,
      canDelete: false,
      canSend: false,
      canViewAnalytics: true
    }
  },
  {
    userId: '3',
    userName: 'Events Coordinator',
    role: 'contributor',
    permissions: {
      canCreate: true,
      canEdit: false,
      canDelete: false,
      canSend: false,
      canViewAnalytics: false
    }
  }
];

const EmailMarketing: React.FC = () => {
  const { user } = useAuth();
  const [campaigns] = useState<EmailCampaign[]>(mockCampaigns);
  const [activeTab, setActiveTab] = useState<'campaigns' | 'templates' | 'analytics' | 'permissions' | 'automation'>('campaigns');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<EmailCampaign | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredCampaigns = campaigns.filter(campaign => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         campaign.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || campaign.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: EmailCampaign['status']) => {
    switch (status) {
      case 'sent':
        return 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400';
      case 'scheduled':
        return 'bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400';
      case 'testing':
        return 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
    }
  };

  const getTypeIcon = (type: EmailCampaign['type']) => {
    switch (type) {
      case 'voting_reminder':
        return <Target className="w-4 h-4" />;
      case 'gala_invitation':
        return <Calendar className="w-4 h-4" />;
      case 'nominee_spotlight':
        return <Users className="w-4 h-4" />;
      case 'sponsor_promotion':
        return <Zap className="w-4 h-4" />;
      case 'winner_announcement':
        return <Trophy className="w-4 h-4" />;
      default:
        return <Mail className="w-4 h-4" />;
    }
  };

  const CreateCampaignForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">Create Email Campaign</h3>
            <button
              onClick={() => setShowCreateForm(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Campaign Setup */}
            <div className="lg:col-span-2 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Campaign Name
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Enter campaign name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Campaign Type
                  </label>
                  <select className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                    <option value="voting_reminder">Voting Reminder</option>
                    <option value="gala_invitation">Gala Invitation</option>
                    <option value="nominee_spotlight">Nominee Spotlight</option>
                    <option value="sponsor_promotion">Sponsor Promotion</option>
                    <option value="winner_announcement">Winner Announcement</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Subject Line
                </label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Enter email subject"
                  />
                  <button className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-700">
                    <Zap className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  AI will optimize your subject line for better open rates
                </p>
              </div>

              {/* Template Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-4">
                  Choose Template
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {emailTemplates.map((template) => (
                    <div key={template.id} className="border-2 border-gray-300 dark:border-gray-600 rounded-lg p-3 hover:border-amber-500 cursor-pointer transition-colors">
                      <img
                        src={template.thumbnail}
                        alt={template.name}
                        className="w-full h-24 object-cover rounded mb-2"
                      />
                      <h4 className="font-medium text-gray-900 dark:text-white text-sm">{template.name}</h4>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">{template.description}</p>
                      {template.isResponsive && (
                        <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded mt-2">
                          Responsive
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Content Editor */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Email Content
                </label>
                <div className="border border-gray-300 dark:border-gray-600 rounded-lg">
                  <div className="border-b border-gray-300 dark:border-gray-600 p-3 bg-gray-50 dark:bg-gray-700 flex items-center space-x-2">
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <FileText className="w-4 h-4" />
                    </button>
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <Image className="w-4 h-4" />
                    </button>
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <Video className="w-4 h-4" />
                    </button>
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <Clock className="w-4 h-4" />
                    </button>
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <MessageSquare className="w-4 h-4" />
                    </button>
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
                      <Code className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="p-4 min-h-[300px] bg-white dark:bg-gray-700">
                    <p className="text-gray-500 dark:text-gray-400">
                      Drag and drop content blocks here or start typing...
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Audience Selection */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">Target Audience</h4>
                <div className="space-y-2">
                  {[
                    { label: 'All Subscribers', count: 5420, selected: true },
                    { label: 'Nominees', count: 247, selected: false },
                    { label: 'Voters', count: 1842, selected: false },
                    { label: 'Jury Members', count: 25, selected: false },
                    { label: 'Sponsors', count: 45, selected: false },
                    { label: 'Media', count: 78, selected: false }
                  ].map((audience, index) => (
                    <label key={index} className="flex items-center space-x-3 p-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded cursor-pointer">
                      <input type="checkbox" defaultChecked={audience.selected} className="text-amber-500 focus:ring-amber-500" />
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">{audience.label}</div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">{audience.count} recipients</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Personalization */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">Personalization</h4>
                <div className="space-y-2">
                  <button className="w-full text-left p-2 text-sm bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded hover:bg-gray-50 dark:hover:bg-gray-500">
                    {'{{first_name}}'} - Recipient's first name
                  </button>
                  <button className="w-full text-left p-2 text-sm bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded hover:bg-gray-50 dark:hover:bg-gray-500">
                    {'{{category}}'} - Nominee category
                  </button>
                  <button className="w-full text-left p-2 text-sm bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded hover:bg-gray-50 dark:hover:bg-gray-500">
                    {'{{voting_deadline}}'} - Voting end date
                  </button>
                </div>
              </div>

              {/* Testing & Optimization */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">Testing & Optimization</h4>
                <div className="space-y-3">
                  <button className="w-full flex items-center space-x-2 p-2 text-sm bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded hover:bg-gray-50 dark:hover:bg-gray-500">
                    <TestTube className="w-4 h-4" />
                    <span>A/B Test Subject Lines</span>
                  </button>
                  <button className="w-full flex items-center space-x-2 p-2 text-sm bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded hover:bg-gray-50 dark:hover:bg-gray-500">
                    <Clock className="w-4 h-4" />
                    <span>Optimize Send Time</span>
                  </button>
                  <button className="w-full flex items-center space-x-2 p-2 text-sm bg-white dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded hover:bg-gray-50 dark:hover:bg-gray-500">
                    <Shield className="w-4 h-4" />
                    <span>Spam Test</span>
                  </button>
                </div>
              </div>

              {/* Schedule */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">Schedule</h4>
                <div className="space-y-3">
                  <label className="flex items-center space-x-2">
                    <input type="radio" name="schedule" value="now" className="text-amber-500" />
                    <span className="text-sm text-gray-900 dark:text-white">Send Now</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input type="radio" name="schedule" value="later" className="text-amber-500" />
                    <span className="text-sm text-gray-900 dark:text-white">Schedule for Later</span>
                  </label>
                  <input
                    type="datetime-local"
                    className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={() => setShowCreateForm(false)}
              className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
              Save as Draft
            </button>
            <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Send Test Email
            </button>
            <button className="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors">
              Send Campaign
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const PermissionsModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">Email Marketing Permissions</h3>
            <button
              onClick={() => setShowPermissionsModal(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <button className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2">
              <Plus className="w-4 h-4" />
              <span>Add User</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">User</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Role</th>
                  <th className="text-center py-3 px-4 font-medium text-gray-900 dark:text-white">Create</th>
                  <th className="text-center py-3 px-4 font-medium text-gray-900 dark:text-white">Edit</th>
                  <th className="text-center py-3 px-4 font-medium text-gray-900 dark:text-white">Delete</th>
                  <th className="text-center py-3 px-4 font-medium text-gray-900 dark:text-white">Send</th>
                  <th className="text-center py-3 px-4 font-medium text-gray-900 dark:text-white">Analytics</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Actions</th>
                </tr>
              </thead>
              <tbody>
                {mockPermissions.map((permission) => (
                  <tr key={permission.userId} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-bold">
                            {permission.userName.charAt(0)}
                          </span>
                        </div>
                        <span className="font-medium text-gray-900 dark:text-white">{permission.userName}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 capitalize">
                        {permission.role}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <input
                        type="checkbox"
                        defaultChecked={permission.permissions.canCreate}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                    </td>
                    <td className="py-4 px-4 text-center">
                      <input
                        type="checkbox"
                        defaultChecked={permission.permissions.canEdit}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                    </td>
                    <td className="py-4 px-4 text-center">
                      <input
                        type="checkbox"
                        defaultChecked={permission.permissions.canDelete}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                    </td>
                    <td className="py-4 px-4 text-center">
                      <input
                        type="checkbox"
                        defaultChecked={permission.permissions.canSend}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                    </td>
                    <td className="py-4 px-4 text-center">
                      <input
                        type="checkbox"
                        defaultChecked={permission.permissions.canViewAnalytics}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-2">
                        <button className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end space-x-4 mt-6">
            <button
              onClick={() => setShowPermissionsModal(false)}
              className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button className="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors">
              Save Permissions
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'campaigns':
        return (
          <div className="space-y-6">
            {/* Search and Filters */}
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search campaigns..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Filter className="w-4 h-4 text-gray-400" />
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="all">All Status</option>
                    <option value="draft">Draft</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="sent">Sent</option>
                    <option value="testing">Testing</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Campaigns Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700">
                    <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Campaign</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Type</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Recipients</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Performance</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns.map((campaign) => (
                    <tr key={campaign.id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                      <td className="py-4 px-4">
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{campaign.name}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">{campaign.subject}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-500">by {campaign.createdBy}</div>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          {getTypeIcon(campaign.type)}
                          <span className="text-sm text-gray-900 dark:text-white capitalize">
                            {campaign.type.replace('_', ' ')}
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <Users className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-900 dark:text-white">{campaign.recipients.toLocaleString()}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(campaign.status)}`}>
                          {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        {campaign.openRate && campaign.clickRate ? (
                          <div className="text-sm">
                            <div className="text-gray-900 dark:text-white">Open: {campaign.openRate}%</div>
                            <div className="text-gray-600 dark:text-gray-400">Click: {campaign.clickRate}%</div>
                            {campaign.conversionRate && (
                              <div className="text-green-600 dark:text-green-400">Conv: {campaign.conversionRate}%</div>
                            )}
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500 dark:text-gray-500">-</span>
                        )}
                      </td>
                      <td className="py-4 px-4">
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          {campaign.sentAt?.toLocaleDateString() || 
                           campaign.scheduledAt?.toLocaleDateString() || 
                           campaign.lastModified.toLocaleDateString()}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors">
                            <Copy className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'templates':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {emailTemplates.map((template) => (
                <div key={template.id} className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden hover:shadow-lg transition-shadow">
                  <img
                    src={template.thumbnail}
                    alt={template.name}
                    className="w-full h-40 object-cover"
                  />
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-900 dark:text-white">{template.name}</h3>
                      {template.isResponsive && (
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                          Responsive
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{template.description}</p>
                    <div className="flex space-x-2">
                      <button className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white py-2 px-3 rounded-lg text-sm font-medium hover:from-amber-600 hover:to-orange-600 transition-colors">
                        Use Template
                      </button>
                      <button className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <Eye className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'analytics':
        return (
          <div className="space-y-6">
            {/* Analytics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: 'Total Campaigns', value: '24', change: '+3 this month', icon: Mail, color: 'blue' },
                { title: 'Avg. Open Rate', value: '68.5%', change: '+5.2% vs last month', icon: Eye, color: 'green' },
                { title: 'Avg. Click Rate', value: '12.3%', change: '+2.1% vs last month', icon: MousePointer, color: 'amber' },
                { title: 'Revenue Generated', value: 'KES 2.4M', change: '+18% vs last month', icon: BarChart3, color: 'purple' }
              ].map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">{stat.title}</p>
                        <p className="text-3xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                        <p className="text-sm text-green-600 dark:text-green-400 mt-2">{stat.change}</p>
                      </div>
                      <div className={`p-3 rounded-lg bg-${stat.color}-50 dark:bg-${stat.color}-900/20 text-${stat.color}-600 dark:text-${stat.color}-400`}>
                        <Icon className="w-6 h-6" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Campaign Performance Chart */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Campaign Performance</h3>
              <div className="h-64 bg-gray-50 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 dark:text-gray-400">Performance chart would be displayed here</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'automation':
        return (
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Email Automation Workflows</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    name: 'Welcome Series',
                    description: 'Onboard new subscribers with a 3-email sequence',
                    trigger: 'New subscriber',
                    status: 'Active',
                    emails: 3
                  },
                  {
                    name: 'Voting Reminders',
                    description: 'Automated reminders for voting deadlines',
                    trigger: 'Voting period starts',
                    status: 'Active',
                    emails: 5
                  },
                  {
                    name: 'Ticket Purchase Follow-up',
                    description: 'Thank you and event details after ticket purchase',
                    trigger: 'Ticket purchased',
                    status: 'Draft',
                    emails: 2
                  }
                ].map((workflow, index) => (
                  <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium text-gray-900 dark:text-white">{workflow.name}</h4>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        workflow.status === 'Active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {workflow.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{workflow.description}</p>
                    <div className="text-xs text-gray-500 dark:text-gray-500 mb-3">
                      <div>Trigger: {workflow.trigger}</div>
                      <div>Emails: {workflow.emails}</div>
                    </div>
                    <div className="flex space-x-2">
                      <button className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white py-2 px-3 rounded text-sm font-medium hover:from-amber-600 hover:to-orange-600 transition-colors">
                        Edit
                      </button>
                      <button className="p-2 border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        {workflow.status === 'Active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Email Marketing System</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Create, manage, and optimize email campaigns for Kenya Tourism Awards 2025
          </p>
        </div>
        <div className="flex items-center space-x-4">
          {user?.role === 'superadmin' && (
            <button
              onClick={() => setShowPermissionsModal(true)}
              className="bg-gray-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-700 transition-colors flex items-center space-x-2"
            >
              <Shield className="w-4 h-4" />
              <span>Manage Permissions</span>
            </button>
          )}
          <button
            onClick={() => setShowCreateForm(true)}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>New Campaign</span>
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Subscribers</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">5,420</p>
            </div>
            <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Campaigns Sent</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">24</p>
            </div>
            <div className="p-3 rounded-lg bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400">
              <Send className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Avg. Open Rate</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">68.5%</p>
            </div>
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400">
              <Eye className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Revenue Generated</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">KES 2.4M</p>
            </div>
            <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400">
              <BarChart3 className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'campaigns', label: 'Campaigns', icon: Mail },
              { id: 'templates', label: 'Templates', icon: Palette },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 },
              { id: 'automation', label: 'Automation', icon: Zap }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>

      {showCreateForm && <CreateCampaignForm />}
      {showPermissionsModal && <PermissionsModal />}
    </div>
  );
};

export default EmailMarketing;