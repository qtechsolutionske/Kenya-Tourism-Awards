import React, { useState } from 'react';
import { BarChart3, TrendingUp, Users, Award, Vote, Calendar, Download, Filter } from 'lucide-react';

const Analytics: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('30d');
  const [selectedMetric, setSelectedMetric] = useState('all');

  const metrics = [
    {
      title: 'Total Nominations',
      value: 247,
      change: '+23%',
      changeType: 'positive' as const,
      icon: Award,
      color: 'amber' as const
    },
    {
      title: 'Total Votes Cast',
      value: 12847,
      change: '+156%',
      changeType: 'positive' as const,
      icon: Vote,
      color: 'green' as const
    },
    {
      title: 'Active Participants',
      value: 1842,
      change: '+45%',
      changeType: 'positive' as const,
      icon: Users,
      color: 'blue' as const
    },
    {
      title: 'Engagement Rate',
      value: '78.5%',
      change: '+12%',
      changeType: 'positive' as const,
      icon: TrendingUp,
      color: 'purple' as const
    }
  ];

  const categoryData = [
    { name: 'Best Luxury Hotel', nominations: 23, votes: 1247, engagement: 85 },
    { name: 'Best Safari Lodge', nominations: 18, votes: 1089, engagement: 78 },
    { name: 'Best Beach Resort', nominations: 15, votes: 967, engagement: 72 },
    { name: 'Best Tourism Personality', nominations: 12, votes: 2156, engagement: 92 },
    { name: 'Best County to Visit', nominations: 19, votes: 1834, engagement: 88 }
  ];

  const getColorClasses = (color: string) => {
    const colorMap = {
      amber: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400',
      green: 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400',
      blue: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
      purple: 'bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400',
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Analytics Dashboard</h2>
          <p className="text-gray-600 dark:text-gray-400">Comprehensive insights into KTA 2025 performance.</p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
            <option value="1y">Last year</option>
          </select>
          <button className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2">
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">{metric.title}</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white">{metric.value}</p>
                  <p className={`text-sm mt-2 ${
                    metric.changeType === 'positive' 
                      ? 'text-green-600 dark:text-green-400' 
                      : 'text-red-600 dark:text-red-400'
                  }`}>
                    {metric.change} from last period
                  </p>
                </div>
                <div className={`p-3 rounded-lg ${getColorClasses(metric.color)}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Voting Trends</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
              <span>Daily Votes</span>
              <span>Last 7 days</span>
            </div>
            <div className="h-64 bg-gray-50 dark:bg-gray-700 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">Chart visualization would go here</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Geographic Distribution</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
              <span>Votes by County</span>
              <span>Top 5</span>
            </div>
            <div className="space-y-3">
              {[
                { county: 'Nairobi', votes: 3247, percentage: 25 },
                { county: 'Mombasa', votes: 2156, percentage: 17 },
                { county: 'Nakuru', votes: 1834, percentage: 14 },
                { county: 'Kisumu', votes: 1567, percentage: 12 },
                { county: 'Eldoret', votes: 1234, percentage: 10 }
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{item.county}</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{item.votes} votes</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-amber-500 to-orange-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${item.percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Category Performance</h3>
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={selectedMetric}
              onChange={(e) => setSelectedMetric(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Metrics</option>
              <option value="nominations">Nominations</option>
              <option value="votes">Votes</option>
              <option value="engagement">Engagement</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Category</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Nominations</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Votes</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Engagement</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Trend</th>
              </tr>
            </thead>
            <tbody>
              {categoryData.map((category, index) => (
                <tr key={index} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <td className="py-4 px-4">
                    <span className="font-medium text-gray-900 dark:text-white">{category.name}</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-gray-900 dark:text-white">{category.nominations}</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-gray-900 dark:text-white">{category.votes.toLocaleString()}</span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${category.engagement}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{category.engagement}%</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-1">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <span className="text-sm text-green-600 dark:text-green-400">+{Math.floor(Math.random() * 20 + 5)}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Top Performing Nominees</h4>
          <div className="space-y-3">
            {[
              { name: 'Hemingways Nairobi', votes: 1247 },
              { name: 'Angama Mara', votes: 1089 },
              { name: 'Alfajiri Villas', votes: 967 }
            ].map((nominee, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm text-gray-900 dark:text-white">{nominee.name}</span>
                <span className="text-sm font-medium text-amber-600 dark:text-amber-400">{nominee.votes}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Jury Activity</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Evaluations Completed</span>
              <span className="text-sm font-medium text-gray-900 dark:text-white">156/200</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Average Score</span>
              <span className="text-sm font-medium text-gray-900 dark:text-white">8.2/10</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Active Jury Members</span>
              <span className="text-sm font-medium text-gray-900 dark:text-white">23/25</span>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
          <h4 className="font-semibold text-gray-900 dark:text-white mb-4">System Health</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Server Uptime</span>
              <span className="text-sm font-medium text-green-600 dark:text-green-400">99.9%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Response Time</span>
              <span className="text-sm font-medium text-gray-900 dark:text-white">245ms</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Error Rate</span>
              <span className="text-sm font-medium text-green-600 dark:text-green-400">0.01%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;