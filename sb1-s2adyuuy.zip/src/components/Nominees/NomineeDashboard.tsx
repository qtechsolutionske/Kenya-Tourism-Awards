import React, { useState } from 'react';
import { 
  User, Share2, BarChart3, DollarSign, Trophy, Eye, Copy, 
  TrendingUp, Users, Clock, Award, Calendar, MapPin, 
  ExternalLink, Edit, Save, Camera, Upload, Link2, 
  Target, Heart, Star, CheckCircle
} from 'lucide-react';

interface NomineeProfile {
  id: string;
  nomineeName: string;
  organizationName: string;
  category: string;
  description: string;
  county: string;
  images: string[];
  votingLink: string;
  totalVotes: number;
  currentRanking: number;
  votingProgress: number;
  campaignBudget: {
    allocated: number;
    spent: number;
    remaining: number;
    breakdown: Array<{
      category: string;
      amount: number;
      description: string;
    }>;
  };
}

const mockProfile: NomineeProfile = {
  id: 'nominee-1',
  nomineeName: 'Hemingways Nairobi',
  organizationName: 'Hemingways Collection',
  category: 'Best Luxury Hotel',
  description: 'Exceptional luxury hospitality with world-class amenities and service excellence.',
  county: 'Nairobi',
  images: [
    'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=800'
  ],
  votingLink: 'https://kta2025.com/vote/hemingways-nairobi-luxury-hotel',
  totalVotes: 1247,
  currentRanking: 2,
  votingProgress: 85,
  campaignBudget: {
    allocated: 500000,
    spent: 325000,
    remaining: 175000,
    breakdown: [
      { category: 'Social Media Ads', amount: 150000, description: 'Facebook, Instagram, and LinkedIn campaigns' },
      { category: 'Print Materials', amount: 75000, description: 'Brochures, banners, and posters' },
      { category: 'Event Participation', amount: 100000, description: 'Trade shows and exhibitions' }
    ]
  }
};

const NomineeDashboard: React.FC = () => {
  const [profile] = useState<NomineeProfile>(mockProfile);
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'budget' | 'profile'>('overview');
  const [linkCopied, setLinkCopied] = useState(false);

  const copyVotingLink = async () => {
    await navigator.clipboard.writeText(profile.votingLink);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'analytics':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                    #{profile.currentRanking}
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Current Ranking</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                    {profile.totalVotes}
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Total Votes</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                    {profile.votingProgress}%
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Progress</p>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Voting Trend</h3>
              <div className="h-64 bg-gray-50 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 dark:text-gray-400">Voting analytics chart</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'budget':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                    KES {profile.campaignBudget.allocated.toLocaleString()}
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Total Budget</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600 dark:text-red-400 mb-2">
                    KES {profile.campaignBudget.spent.toLocaleString()}
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Spent</p>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                    KES {profile.campaignBudget.remaining.toLocaleString()}
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">Remaining</p>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Budget Breakdown</h3>
              <div className="space-y-4">
                {profile.campaignBudget.breakdown.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">{item.category}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{item.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-gray-900 dark:text-white">
                        KES {item.amount.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {Math.round((item.amount / profile.campaignBudget.allocated) * 100)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'profile':
        return (
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Profile Information</h3>
                <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  <Edit className="w-4 h-4" />
                  <span>Edit Profile</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Nominee Name
                  </label>
                  <input
                    type="text"
                    value={profile.nomineeName}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    readOnly
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Organization
                  </label>
                  <input
                    type="text"
                    value={profile.organizationName}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Category
                  </label>
                  <input
                    type="text"
                    value={profile.category}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-600 text-gray-500 dark:text-gray-400"
                    readOnly
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    County
                  </label>
                  <input
                    type="text"
                    value={profile.county}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Description
                </label>
                <textarea
                  value={profile.description}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Profile Images
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {profile.images.map((image, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={image}
                        alt={`${profile.nomineeName} ${index + 1}`}
                        className="w-full aspect-square object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                        <button className="p-2 bg-white rounded-lg">
                          <Edit className="w-4 h-4 text-gray-900" />
                        </button>
                      </div>
                    </div>
                  ))}
                  <div className="aspect-square border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex flex-col items-center justify-center hover:border-blue-500 cursor-pointer transition-colors">
                    <Upload className="w-6 h-6 text-gray-400 mb-2" />
                    <span className="text-xs text-gray-500 dark:text-gray-400">Add Image</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-6">
            {/* Voting Link Section */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Your Voting Link</h3>
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 mb-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Link2 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <span className="font-medium text-blue-900 dark:text-blue-400">Share this link to get votes:</span>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={profile.votingLink}
                    readOnly
                    className="flex-1 px-3 py-2 bg-white dark:bg-gray-700 border border-blue-300 dark:border-blue-600 rounded-lg text-blue-900 dark:text-blue-300 text-sm"
                  />
                  <button
                    onClick={copyVotingLink}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      linkCopied
                        ? 'bg-green-600 text-white'
                        : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                  >
                    {linkCopied ? (
                      <>
                        <CheckCircle className="w-4 h-4" />
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <button className="p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Share on Facebook
                </button>
                <button className="p-3 bg-sky-500 text-white rounded-lg hover:bg-sky-600 transition-colors">
                  Share on Twitter
                </button>
                <button className="p-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Share on WhatsApp
                </button>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700 text-center">
                <Trophy className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">#{profile.currentRanking}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Ranking</div>
              </div>
              
              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700 text-center">
                <Users className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">{profile.totalVotes}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Votes</div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700 text-center">
                <Target className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">{profile.votingProgress}%</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Progress</div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700 text-center">
                <Eye className="w-8 h-8 text-teal-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900 dark:text-white">2.4K</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Views</div>
              </div>
            </div>

            {/* Profile Summary */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Profile Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">{profile.nomineeName}</h4>
                  <p className="text-blue-600 dark:text-blue-400 mb-2">{profile.organizationName}</p>
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <Award className="w-4 h-4" />
                    <span>{profile.category}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                    <MapPin className="w-4 h-4" />
                    <span>{profile.county}</span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mt-4">{profile.description}</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Profile Images</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {profile.images.slice(0, 4).map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`${profile.nomineeName} ${index + 1}`}
                        className="w-full aspect-square object-cover rounded-lg"
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Nominee Dashboard</h2>
            <p className="text-blue-100 text-lg">
              Manage your nomination and track voting progress
            </p>
          </div>
          <div className="hidden md:block">
            <Award className="w-24 h-24 text-blue-200" />
          </div>
        </div>
      </div>

      {/* Current Status */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <Trophy className="w-12 h-12 text-blue-600 dark:text-blue-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-blue-900 dark:text-blue-400">
              #{profile.currentRanking}
            </div>
            <div className="text-blue-700 dark:text-blue-500 font-medium">Current Ranking</div>
          </div>

          <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <Users className="w-12 h-12 text-green-600 dark:text-green-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-green-900 dark:text-green-400">
              {profile.totalVotes}
            </div>
            <div className="text-green-700 dark:text-green-500 font-medium">Total Votes</div>
          </div>

          <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
            <BarChart3 className="w-12 h-12 text-purple-600 dark:text-purple-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-purple-900 dark:text-purple-400">
              {profile.votingProgress}%
            </div>
            <div className="text-purple-700 dark:text-purple-500 font-medium">Progress</div>
          </div>

          <div className="text-center p-4 bg-teal-50 dark:bg-teal-900/20 rounded-lg">
            <DollarSign className="w-12 h-12 text-teal-600 dark:text-teal-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-teal-900 dark:text-teal-400">
              {Math.round(((profile.campaignBudget.allocated - profile.campaignBudget.remaining) / profile.campaignBudget.allocated) * 100)}%
            </div>
            <div className="text-teal-700 dark:text-teal-500 font-medium">Budget Used</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', label: 'Overview', icon: Eye },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 },
              { id: 'budget', label: 'Budget', icon: DollarSign },
              { id: 'profile', label: 'Profile', icon: User }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default NomineeDashboard;