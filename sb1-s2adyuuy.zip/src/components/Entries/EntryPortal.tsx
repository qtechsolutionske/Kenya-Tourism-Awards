import React, { useState, useEffect } from 'react';
import { 
  Award, Clock, CheckCircle, AlertTriangle, ArrowRight,
  FileText, Upload, Users, Trophy, Calendar, Lock,
  Unlock, Eye, Star, Target, BarChart3, Play, Pause,
  Settings, Download, ExternalLink
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useEntries } from '../../hooks/useEntries';
import { categories } from '../../data/categories';
import DynamicFormRenderer from './DynamicFormRenderer';

const EntryPortal: React.FC = () => {
  const { user } = useAuth();
  const { 
    processState, 
    fetchProcessState, 
    updateProcessState,
    formDefinitions, 
    fetchFormDefinitions,
    createSubmission 
  } = useEntries();
  
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showEntryForm, setShowEntryForm] = useState(false);
  const [selectedFormDef, setSelectedFormDef] = useState(null);

  useEffect(() => {
    fetchProcessState();
    fetchFormDefinitions(true); // Only published forms
  }, [fetchProcessState, fetchFormDefinitions]);

  const isEntriesOpen = processState?.currentStage === 'entries_open';
  const isEntriesClosed = processState?.currentStage === 'entries_closed';
  const isVettingPhase = processState?.currentStage === 'jury_vetting';

  const getStageInfo = () => {
    switch (processState?.currentStage) {
      case 'setup':
        return {
          title: 'System Setup in Progress',
          description: 'Entry forms are being prepared. Please check back soon.',
          icon: Settings,
          color: 'gray',
          canSubmit: false
        };
      case 'entries_open':
        return {
          title: 'Entries Now Open!',
          description: 'Submit your entry for Kenya Tourism Awards 2025',
          icon: Unlock,
          color: 'green',
          canSubmit: true
        };
      case 'entries_closed':
        return {
          title: 'Entry Submission Closed',
          description: 'The entry submission period has ended. Reviews are now in progress.',
          icon: Lock,
          color: 'red',
          canSubmit: false
        };
      case 'jury_vetting':
        return {
          title: 'Jury Review in Progress',
          description: 'Expert jury is currently evaluating all submissions.',
          icon: Users,
          color: 'blue',
          canSubmit: false
        };
      case 'vetting_closed':
        return {
          title: 'Vetting Complete',
          description: 'Jury evaluation completed. Preparing for public voting phase.',
          icon: CheckCircle,
          color: 'purple',
          canSubmit: false
        };
      case 'voting_open':
        return {
          title: 'Public Voting Open',
          description: 'Vote for your favorite entries in each category.',
          icon: Trophy,
          color: 'blue',
          canSubmit: false
        };
      case 'voting_closed':
        return {
          title: 'Voting Closed',
          description: 'Voting has ended. Results are being finalized.',
          icon: Clock,
          color: 'gray',
          canSubmit: false
        };
      case 'results_announced':
        return {
          title: 'Winners Announced!',
          description: 'Congratulations to all winners and participants.',
          icon: Trophy,
          color: 'amber',
          canSubmit: false
        };
      default:
        return {
          title: 'Entry Portal',
          description: 'Submit your entry for Kenya Tourism Awards 2025',
          icon: Award,
          color: 'amber',
          canSubmit: false
        };
    }
  };

  const stageInfo = getStageInfo();
  const StageIcon = stageInfo.icon;

  const handleCategorySelect = (categorySlug: string) => {
    const formDef = formDefinitions.find(f => f.slug === categorySlug);
    if (formDef) {
      setSelectedCategory(categorySlug);
      setSelectedFormDef(formDef);
      setShowEntryForm(true);
    }
  };

  const handleSubmissionComplete = async (submissionData: any) => {
    try {
      await createSubmission(submissionData);
      setShowEntryForm(false);
      setSelectedCategory(null);
      // Show success message
    } catch (error) {
      console.error('Submission failed:', error);
    }
  };

  if (showEntryForm && selectedFormDef) {
    return (
      <DynamicFormRenderer
        formDefinition={selectedFormDef}
        onSubmit={handleSubmissionComplete}
        onCancel={() => {
          setShowEntryForm(false);
          setSelectedCategory(null);
          setSelectedFormDef(null);
        }}
        isLoading={false}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className={`bg-gradient-to-r from-${stageInfo.color}-500 to-${stageInfo.color}-600 py-20`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center overflow-x-hidden">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <StageIcon className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
            </div>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 sm:mb-6 px-4">
            {stageInfo.title}
          </h1>
          <p className="text-lg sm:text-xl text-white/90 max-w-3xl mx-auto mb-6 sm:mb-8 px-4">
            {stageInfo.description}
          </p>
          
          {isEntriesOpen && processState?.stageEnd && (
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4 lg:space-x-6">
              <div className="bg-white/20 backdrop-blur-sm rounded-lg px-6 py-3 text-white">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5" />
                  <span className="text-sm sm:text-base">Deadline: {new Date(processState.stageEnd).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-lg px-6 py-3 text-white">
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5" />
                  <span className="text-sm sm:text-base">Days remaining: {Math.ceil((new Date(processState.stageEnd).getTime() - Date.now()) / (1000 * 60 * 60 * 24))}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Admin Controls */}
      {(user?.role === 'superadmin' || user?.role === 'admin') && (
        <div className="bg-gray-100 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Admin Controls</h3>
              <div className="flex items-center space-x-4">
                {user?.role === 'superadmin' && (
                  <button
                    onClick={() => {
                      if (isEntriesOpen) {
                        updateProcessState({
                          currentStage: 'entries_closed',
                          stageStart: new Date(),
                          updatedBy: user.id
                        });
                      } else if (processState?.currentStage === 'entries_closed') {
                        updateProcessState({
                          currentStage: 'entries_open',
                          stageStart: new Date(),
                          updatedBy: user.id
                        });
                      }
                    }}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
                      isEntriesOpen
                        ? 'bg-red-600 text-white hover:bg-red-700'
                        : 'bg-green-600 text-white hover:bg-green-700'
                    }`}
                  >
                    {isEntriesOpen ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    <span>{isEntriesOpen ? 'Close Entries' : 'Open Entries'}</span>
                  </button>
                )}
                <a
                  href="/dashboard/entries"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>View Submissions</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Entry Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16 overflow-x-hidden">
        {/* Status Banner */}
        <div className={`mb-8 sm:mb-12 bg-${stageInfo.color}-50 dark:bg-${stageInfo.color}-900/20 border border-${stageInfo.color}-200 dark:border-${stageInfo.color}-800 rounded-xl p-4 sm:p-6`}>
          <div className="flex items-center space-x-4">
            <StageIcon className={`w-8 h-8 text-${stageInfo.color}-600 dark:text-${stageInfo.color}-400`} />
            <div className="flex-1">
              <h3 className={`text-sm sm:text-base font-semibold text-${stageInfo.color}-900 dark:text-${stageInfo.color}-400 mb-1`}>
                Current Status: {stageInfo.title}
              </h3>
              <p className={`text-sm text-${stageInfo.color}-700 dark:text-${stageInfo.color}-500`}>
                {stageInfo.description}
              </p>
            </div>
            {processState?.stageEnd && isEntriesOpen && (
              <div className="text-right">
                <div className={`text-base sm:text-lg font-bold text-${stageInfo.color}-900 dark:text-${stageInfo.color}-400`}>
                  {Math.ceil((new Date(processState.stageEnd).getTime() - Date.now()) / (1000 * 60 * 60 * 24))} days left
                </div>
                <div className={`text-xs sm:text-sm text-${stageInfo.color}-700 dark:text-${stageInfo.color}-500`}>
                  To submit entries
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Select Award Category
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto px-4">
            Choose the category that best fits your entry and complete the submission form
          </p>
        </div>

        {/* Category Groups */}
        {Object.entries(
          categories.reduce((groups, category) => {
            if (!groups[category.group]) {
              groups[category.group] = [];
            }
            groups[category.group].push(category);
            return groups;
          }, {} as Record<string, typeof categories>)
        ).map(([groupKey, groupCategories]) => (
          <div key={groupKey} className="mb-12">
            <h3 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white mb-4 sm:mb-6 capitalize">
              {groupKey === 'facilities' ? 'Facilities, Establishments & Organizations' :
               groupKey === 'nightlife' ? 'Nightlife & Entertainment' :
               groupKey === 'culinary' ? 'Culinary & Gastronomy' :
               groupKey === 'transport' ? 'Transport & Mobility' :
               groupKey === 'icons' ? 'Industry Icons' :
               groupKey === 'media' ? 'Film & Media in Tourism' :
               groupKey === 'destinations' ? 'Travel Destinations' :
               groupKey.charAt(0).toUpperCase() + groupKey.slice(1)}
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
              {groupCategories.map((category) => {
                const formDef = formDefinitions.find(f => f.slug === category.id);
                const submissionCount = Math.floor(Math.random() * 25) + 5; // Mock count
                
                return (
                  <div
                    key={category.id}
                    className={`bg-white dark:bg-gray-800 rounded-lg sm:rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden ${
                      !stageInfo.canSubmit ? 'opacity-60' : 'hover:-translate-y-1'
                    }`}
                  >
                    <div className="p-4 sm:p-6">
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-amber-500 to-orange-500 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                          <Award className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm sm:text-base lg:text-lg font-semibold text-gray-900 dark:text-white line-clamp-2">
                            {category.name}
                          </h4>
                          {!formDef?.published && (
                            <span className="text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 px-2 py-1 rounded-full mt-1 inline-block">
                              Form Not Available
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-gray-600 dark:text-gray-400 text-sm mb-3 sm:mb-4 line-clamp-3">
                        {category.description}
                      </p>

                      <div className="mb-4">
                        <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-500 mb-2">
                          <FileText className="w-3 h-3" />
                          <span>{category.requirements.length} requirements</span>
                        </div>
                        
                        <div className="space-y-1">
                          {category.requirements.slice(0, 3).map((req, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <CheckCircle className="w-3 h-3 text-green-500 mt-1 flex-shrink-0" />
                              <span className="text-xs text-gray-600 dark:text-gray-400">{req}</span>
                            </div>
                          ))}
                          {category.requirements.length > 3 && (
                            <div className="text-xs text-gray-500 dark:text-gray-500">
                              +{category.requirements.length - 3} more requirements
                            </div>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleCategorySelect(category.id)}
                        disabled={!stageInfo.canSubmit || !formDef?.published}
                        className={`w-full py-2.5 sm:py-3 px-3 sm:px-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center space-x-2 text-sm sm:text-base ${
                          stageInfo.canSubmit && formDef?.published
                            ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600 transform hover:scale-105'
                            : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                        }`}
                      >
                        {stageInfo.canSubmit ? (
                          formDef?.published ? (
                            <>
                              <Award className="w-4 h-4" />
                              <span>Submit Entry</span>
                              <ArrowRight className="w-4 h-4" />
                            </>
                          ) : (
                            <>
                              <Settings className="w-4 h-4" />
                              <span>Form Not Ready</span>
                            </>
                          )
                        ) : (
                          <>
                            <Lock className="w-4 h-4" />
                            <span>Submissions Closed</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="px-4 sm:px-6 py-3 bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600">
                      <div className="flex items-center justify-between text-xs sm:text-sm">
                        <span className="text-gray-600 dark:text-gray-400">Current Entries:</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          {submissionCount} submitted
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {/* Help Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 sm:p-8 mt-8 sm:mt-12">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Need Help with Your Entry?
            </h3>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto px-4">
              Our support team is here to assist you throughout the entry process
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
            <div className="text-center p-4 sm:p-6 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h4 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-white mb-2">Entry Guidelines</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Detailed requirements and guidelines for each category
              </p>
              <button className="bg-blue-600 text-white px-3 sm:px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 mx-auto text-sm sm:text-base">
                <Download className="w-4 h-4" />
                <span>Download Guide</span>
              </button>
            </div>

            <div className="text-center p-6 bg-green-50 dark:bg-green-900/20 rounded-xl">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Support Team</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Get assistance from our dedicated support team
              </p>
              <a
                href="/contact"
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 mx-auto"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Contact Support</span>
              </a>
            </div>

            <div className="text-center p-6 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Previous Winners</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                See examples of winning entries from previous years
              </p>
              <a
                href="/winners"
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2 mx-auto"
              >
                <Trophy className="w-4 h-4" />
                <span>View Winners</span>
              </a>
            </div>
          </div>
        </div>

        {/* Process Timeline */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-8 mt-12">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Awards Process Timeline
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                stage: 'entries_open',
                title: 'Entries Open',
                description: 'Submit your entries',
                status: processState?.currentStage === 'entries_open' ? 'current' : 
                        ['entries_closed', 'jury_vetting', 'vetting_closed', 'voting_open'].includes(processState?.currentStage || '') ? 'completed' : 'upcoming'
              },
              {
                stage: 'jury_vetting',
                title: 'Jury Review',
                description: 'Expert evaluation',
                status: processState?.currentStage === 'jury_vetting' ? 'current' : 
                        ['vetting_closed', 'voting_open', 'voting_closed'].includes(processState?.currentStage || '') ? 'completed' : 'upcoming'
              },
              {
                stage: 'voting_open',
                title: 'Public Voting',
                description: 'Community voting',
                status: processState?.currentStage === 'voting_open' ? 'current' : 
                        ['voting_closed', 'results_announced'].includes(processState?.currentStage || '') ? 'completed' : 'upcoming'
              },
              {
                stage: 'results_announced',
                title: 'Results & Gala',
                description: 'Winners announced',
                status: processState?.currentStage === 'results_announced' ? 'current' : 'upcoming'
              }
            ].map((phase, index) => {
              const isCompleted = phase.status === 'completed';
              const isCurrent = phase.status === 'current';
              const isUpcoming = phase.status === 'upcoming';

              return (
                <div key={index} className="text-center">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transition-colors ${
                    isCompleted ? 'bg-green-500 text-white' :
                    isCurrent ? 'bg-amber-500 text-white' :
                    'bg-gray-300 dark:bg-gray-600 text-gray-600 dark:text-gray-400'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-8 h-8" />
                    ) : isCurrent ? (
                      <Clock className="w-8 h-8 animate-pulse" />
                    ) : (
                      <div className="w-8 h-8 border-2 border-current rounded-full" />
                    )}
                  </div>
                  <h4 className={`font-semibold mb-1 ${
                    isCurrent ? 'text-amber-900 dark:text-amber-400' :
                    isCompleted ? 'text-green-900 dark:text-green-400' :
                    'text-gray-600 dark:text-gray-500'
                  }`}>
                    {phase.title}
                  </h4>
                  <p className={`text-sm ${
                    isCurrent ? 'text-amber-700 dark:text-amber-500' :
                    isCompleted ? 'text-green-700 dark:text-green-500' :
                    'text-gray-500 dark:text-gray-500'
                  }`}>
                    {phase.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EntryPortal;