import React, { useState, useEffect } from 'react';
import { 
  Save, ArrowRight, Upload, X, FileText, Image, 
  CheckCircle, AlertCircle, Info, Award, User,
  Mail, Phone, MapPin, Calendar, Globe, Building,
  Plus, Trash2, Eye
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { FormDefinition, FormField, Submission } from '../../types/entries';

interface DynamicFormRendererProps {
  formDefinition: FormDefinition;
  onSubmit: (data: Partial<Submission>) => Promise<void>;
  onSaveDraft?: (data: Partial<Submission>) => Promise<void>;
  onCancel?: () => void;
  initialData?: Record<string, any>;
  isLoading?: boolean;
}

const DynamicFormRenderer: React.FC<DynamicFormRendererProps> = ({ 
  formDefinition,
  onSubmit,
  onSaveDraft,
  onCancel,
  initialData = {},
  isLoading = false
}) => {
  const { user } = useAuth();
  const [formData, setFormData] = useState<Record<string, any>>(initialData);
  const [files, setFiles] = useState<Record<string, File[]>>({});
  const [currentStep, setCurrentStep] = useState(0);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDraft, setIsDraft] = useState(false);

  // Initialize form data with default values
  useEffect(() => {
    const initialFormData: Record<string, any> = { ...initialData };
    
    formDefinition.schema.sections.forEach(section => {
      section.fields.forEach(field => {
        if (!(field.name in initialFormData)) {
          if (field.type === 'checkbox') {
            initialFormData[field.name] = false;
          } else if (field.type === 'multiselect') {
            initialFormData[field.name] = [];
          } else if (field.type === 'repeatable') {
            initialFormData[field.name] = [];
          } else {
            initialFormData[field.name] = '';
          }
        }
      });
    });
    
    setFormData(initialFormData);
  }, [formDefinition, initialData]);

  const validateField = (field: FormField, value: any): string | null => {
    // Required field validation
    if (field.required && (!value || (Array.isArray(value) && value.length === 0) || (typeof value === 'string' && value.trim() === ''))) {
      return `${field.label} is required`;
    }

    if (!value && !field.required) return null;

    const validation = field.validation;
    if (!validation) return null;

    // String validations
    if (typeof value === 'string' && value.trim()) {
      if (validation.minLength && value.length < validation.minLength) {
        return `${field.label} must be at least ${validation.minLength} characters`;
      }
      if (validation.maxLength && value.length > validation.maxLength) {
        return `${field.label} must be no more than ${validation.maxLength} characters`;
      }
      if (validation.maxWords) {
        const wordCount = value.trim().split(/\s+/).length;
        if (wordCount > validation.maxWords) {
          return `${field.label} must be no more than ${validation.maxWords} words`;
        }
      }
      if (validation.pattern) {
        const regex = new RegExp(validation.pattern);
        if (!regex.test(value)) {
          return `${field.label} format is invalid`;
        }
      }
    }

    // Number validations
    if (field.type === 'number' && typeof value === 'number') {
      if (validation.min !== undefined && value < validation.min) {
        return `${field.label} must be at least ${validation.min}`;
      }
      if (validation.max !== undefined && value > validation.max) {
        return `${field.label} must be no more than ${validation.max}`;
      }
    }

    // File validations
    if ((field.type === 'file' || field.type === 'image') && files[field.name]) {
      const fieldFiles = files[field.name];
      if (validation.maxFiles && fieldFiles.length > validation.maxFiles) {
        return `${field.label} can have maximum ${validation.maxFiles} files`;
      }
      
      for (const file of fieldFiles) {
        if (validation.maxFileSize && file.size > validation.maxFileSize * 1024 * 1024) {
          return `File ${file.name} is too large (max ${validation.maxFileSize}MB)`;
        }
        
        if (validation.fileTypes && validation.fileTypes.length > 0) {
          const fileType = file.type;
          if (!validation.fileTypes.includes(fileType)) {
            return `File ${file.name} type not allowed. Allowed types: ${validation.fileTypes.join(', ')}`;
          }
        }
      }
    }

    return null;
  };

  const validateSection = (sectionIndex: number): boolean => {
    const section = formDefinition.schema.sections[sectionIndex];
    const sectionErrors: Record<string, string> = {};
    let hasErrors = false;

    section.fields.forEach(field => {
      const error = validateField(field, formData[field.name]);
      if (error) {
        sectionErrors[field.name] = error;
        hasErrors = true;
      }
    });

    setErrors(prev => ({ ...prev, ...sectionErrors }));
    return !hasErrors;
  };

  const handleNext = () => {
    if (validateSection(currentStep)) {
      setCurrentStep(prev => prev + 1);
      setErrors({}); // Clear errors when moving to next step
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => prev - 1);
    setErrors({}); // Clear errors when going back
  };

  const handleFileUpload = (fieldName: string, uploadedFiles: FileList) => {
    const fileArray = Array.from(uploadedFiles);
    setFiles(prev => ({ ...prev, [fieldName]: fileArray }));
    
    // Store file references in form data
    setFormData(prev => ({ 
      ...prev, 
      [fieldName]: fileArray.map(f => ({
        name: f.name,
        size: f.size,
        type: f.type,
        lastModified: f.lastModified
      }))
    }));
  };

  const handleSaveDraft = async () => {
    if (!onSaveDraft) return;
    
    setIsDraft(true);
    try {
      await onSaveDraft({
        formDefinitionId: formDefinition.id,
        categoryGroup: formDefinition.categoryGroup,
        category: formDefinition.category,
        submitterId: user?.id,
        submitterEmail: user?.email || formData.contact_email,
        nomineeName: formData.nominee_name || formData.full_name,
        organizationName: formData.organization_name,
        contactPerson: formData.contact_person,
        contactEmail: formData.contact_email,
        contactPhone: formData.contact_phone,
        county: formData.county,
        yearEstablished: formData.year_established ? parseInt(formData.year_established) : undefined,
        physicalAddress: formData.physical_address,
        websiteUrl: formData.website,
        nomineeDetails: formData,
        attachments: {}, // Files would be uploaded separately
        status: 'pending',
        publicVotes: 0,
        priority: 0,
        featured: false
      });
    } catch (error) {
      console.error('Failed to save draft:', error);
    } finally {
      setIsDraft(false);
    }
  };

  const handleSubmit = async () => {
    // Validate all sections
    let allValid = true;
    for (let i = 0; i < formDefinition.schema.sections.length; i++) {
      if (!validateSection(i)) {
        allValid = false;
        if (i < currentStep) {
          setCurrentStep(i); // Go to first section with errors
          break;
        }
      }
    }

    if (!allValid) return;

    setIsSubmitting(true);

    try {
      // Upload files first (this would be implemented with your storage solution)
      const uploadedAttachments: Record<string, string[]> = {};
      
      for (const [fieldName, fieldFiles] of Object.entries(files)) {
        if (fieldFiles.length > 0) {
          // Simulate file upload - replace with actual upload logic
          uploadedAttachments[fieldName] = fieldFiles.map(file => 
            `https://storage.example.com/uploads/${Date.now()}_${file.name}`
          );
        }
      }

      // Create submission data
      const submissionData: Partial<Submission> = {
        formDefinitionId: formDefinition.id,
        categoryGroup: formDefinition.categoryGroup,
        category: formDefinition.category,
        submitterId: user?.id,
        submitterEmail: user?.email || formData.contact_email,
        nomineeName: formData.nominee_name || formData.full_name,
        organizationName: formData.organization_name,
        contactPerson: formData.contact_person,
        contactEmail: formData.contact_email,
        contactPhone: formData.contact_phone,
        county: formData.county,
        yearEstablished: formData.year_established ? parseInt(formData.year_established) : undefined,
        physicalAddress: formData.physical_address,
        websiteUrl: formData.website,
        nomineeDetails: formData,
        attachments: uploadedAttachments,
        status: 'pending',
        publicVotes: 0,
        priority: 0,
        featured: false,
        submissionUserAgent: navigator.userAgent
      };

      await onSubmit(submissionData);
      
    } catch (error) {
      console.error('Submission failed:', error);
      setErrors({ submit: 'Submission failed. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateFormData = (fieldName: string, value: any) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
    // Clear field error when value changes
    if (errors[fieldName]) {
      setErrors(prev => ({ ...prev, [fieldName]: '' }));
    }
  };

  const addRepeatableItem = (fieldName: string) => {
    const current = formData[fieldName] || [];
    setFormData(prev => ({
      ...prev,
      [fieldName]: [...current, {}]
    }));
  };

  const removeRepeatableItem = (fieldName: string, index: number) => {
    const current = formData[fieldName] || [];
    setFormData(prev => ({
      ...prev,
      [fieldName]: current.filter((_: any, i: number) => i !== index)
    }));
  };

  const updateRepeatableItem = (fieldName: string, index: number, subFieldName: string, value: any) => {
    const current = formData[fieldName] || [];
    const updated = [...current];
    updated[index] = { ...updated[index], [subFieldName]: value };
    setFormData(prev => ({ ...prev, [fieldName]: updated }));
  };

  const getWordCount = (text: string) => {
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  };

  const renderField = (field: FormField, sectionIndex?: number) => {
    const value = formData[field.name];
    const error = errors[field.name];

    const baseInputClass = `w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-colors ${
      error 
        ? 'border-red-500 bg-red-50 dark:bg-red-900/20' 
        : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700'
    } text-gray-900 dark:text-white`;

    switch (field.type) {
      case 'textarea':
        const wordCount = typeof value === 'string' ? getWordCount(value) : 0;
        const maxWords = field.validation?.maxWords;
        return (
          <div className="space-y-2">
            <textarea
              value={value || ''}
              onChange={(e) => updateFormData(field.name, e.target.value)}
              className={baseInputClass}
              placeholder={field.placeholder}
              rows={4}
              maxLength={field.validation?.maxLength}
            />
            {maxWords && (
              <div className={`text-sm ${wordCount > maxWords ? 'text-red-600' : 'text-gray-500'} dark:text-gray-400`}>
                {wordCount}/{maxWords} words
              </div>
            )}
          </div>
        );

      case 'select':
        return (
          <select
            value={value || ''}
            onChange={(e) => updateFormData(field.name, e.target.value)}
            className={baseInputClass}
          >
            <option value="">{field.placeholder || 'Select an option'}</option>
            {field.options?.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        );

      case 'multiselect':
        const selectedValues = Array.isArray(value) ? value : [];
        return (
          <div className="space-y-2">
            <div className="border border-gray-300 dark:border-gray-600 rounded-lg p-3 bg-white dark:bg-gray-700">
              {field.options?.map((option) => (
                <label key={option.value} className="flex items-center space-x-2 py-1">
                  <input
                    type="checkbox"
                    checked={selectedValues.includes(option.value)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        updateFormData(field.name, [...selectedValues, option.value]);
                      } else {
                        updateFormData(field.name, selectedValues.filter(v => v !== option.value));
                      }
                    }}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <span className="text-sm text-gray-900 dark:text-white">{option.label}</span>
                </label>
              ))}
            </div>
          </div>
        );

      case 'checkbox':
        return (
          <label className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={value || false}
              onChange={(e) => updateFormData(field.name, e.target.checked)}
              className="text-amber-500 focus:ring-amber-500"
            />
            <span className="text-gray-900 dark:text-white">{field.label}</span>
          </label>
        );

      case 'radio':
        return (
          <div className="space-y-2">
            {field.options?.map((option) => (
              <label key={option.value} className="flex items-center space-x-3">
                <input
                  type="radio"
                  name={field.name}
                  value={option.value}
                  checked={value === option.value}
                  onChange={(e) => updateFormData(field.name, e.target.value)}
                  className="text-amber-500 focus:ring-amber-500"
                />
                <span className="text-gray-900 dark:text-white">{option.label}</span>
              </label>
            ))}
          </div>
        );

      case 'repeatable':
        const repeatableValue = Array.isArray(value) ? value : [];
        return (
          <div className="space-y-4">
            {repeatableValue.map((item: any, index: number) => (
              <div key={index} className="border border-gray-300 dark:border-gray-600 rounded-lg p-4 bg-gray-50 dark:bg-gray-800">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-900 dark:text-white">
                    {field.label} {index + 1}
                  </h4>
                  <button
                    type="button"
                    onClick={() => removeRepeatableItem(field.name, index)}
                    className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 p-1 rounded"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                {field.repeatable?.fields.map((subField) => {
                  const subFieldError = errors[`${field.name}_${index}_${subField.name}`];
                  return (
                    <div key={subField.name} className="mb-3">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {subField.label} {subField.required && <span className="text-red-500">*</span>}
                      </label>
                      {subField.type === 'textarea' ? (
                        <textarea
                          value={item[subField.name] || ''}
                          onChange={(e) => updateRepeatableItem(field.name, index, subField.name, e.target.value)}
                          className={`w-full px-3 py-2 border rounded-lg ${subFieldError ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                          placeholder={subField.placeholder}
                          rows={3}
                        />
                      ) : (
                        <input
                          type={subField.type}
                          value={item[subField.name] || ''}
                          onChange={(e) => updateRepeatableItem(field.name, index, subField.name, e.target.value)}
                          className={`w-full px-3 py-2 border rounded-lg ${subFieldError ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                          placeholder={subField.placeholder}
                        />
                      )}
                      {subField.validation?.maxWords && subField.type === 'textarea' && (
                        <div className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                          {getWordCount(item[subField.name] || '')}/{subField.validation.maxWords} words
                        </div>
                      )}
                      {subFieldError && (
                        <p className="text-sm text-red-600 dark:text-red-400 mt-1">{subFieldError}</p>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
            
            {(!field.repeatable?.maxItems || repeatableValue.length < field.repeatable.maxItems) && (
              <button
                type="button"
                onClick={() => addRepeatableItem(field.name)}
                className="w-full border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-gray-600 dark:text-gray-400 hover:border-amber-500 hover:text-amber-600 dark:hover:text-amber-400 transition-colors"
              >
                <Plus className="w-5 h-5 mx-auto mb-2" />
                <span>{field.repeatable?.addButtonText || `Add ${field.label}`}</span>
              </button>
            )}
          </div>
        );

      case 'file':
      case 'image':
        return (
          <div className="space-y-3">
            <div className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              error ? 'border-red-300 bg-red-50 dark:bg-red-900/20' : 'border-gray-300 dark:border-gray-600 hover:border-amber-500'
            }`}>
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600 dark:text-gray-400 mb-2">
                {field.type === 'image' ? 'Upload images' : 'Upload documents'}
              </p>
              <input
                type="file"
                accept={field.validation?.fileTypes?.join(',') || 
                        (field.type === 'image' ? 'image/*' : '*')}
                multiple={field.validation?.maxFiles !== 1}
                onChange={(e) => e.target.files && handleFileUpload(field.name, e.target.files)}
                className="hidden"
                id={`file-${field.name}`}
              />
              <label
                htmlFor={`file-${field.name}`}
                className="cursor-pointer bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors inline-flex items-center space-x-2"
              >
                <Upload className="w-4 h-4" />
                <span>Choose Files</span>
              </label>
              
              <div className="mt-2 text-xs text-gray-500 dark:text-gray-500">
                {field.validation?.maxFileSize && (
                  <p>Max file size: {field.validation.maxFileSize}MB</p>
                )}
                {field.validation?.maxFiles && (
                  <p>Max files: {field.validation.maxFiles}</p>
                )}
                {field.validation?.fileTypes && (
                  <p>Allowed types: {field.validation.fileTypes.map(type => type.split('/')[1]).join(', ')}</p>
                )}
              </div>
            </div>
            
            {files[field.name] && files[field.name].length > 0 && (
              <div className="space-y-2">
                <h5 className="font-medium text-gray-900 dark:text-white text-sm">Selected Files:</h5>
                {files[field.name].map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                      <span className="text-sm font-medium text-green-900 dark:text-green-400">
                        {file.name}
                      </span>
                      <span className="text-xs text-green-700 dark:text-green-500">
                        ({(file.size / 1024 / 1024).toFixed(1)} MB)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const newFiles = files[field.name].filter((_, i) => i !== index);
                        setFiles(prev => ({ ...prev, [field.name]: newFiles }));
                      }}
                      className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 p-1 rounded"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      default:
        return (
          <input
            type={field.type}
            value={value || ''}
            onChange={(e) => updateFormData(field.name, e.target.value)}
            className={baseInputClass}
            placeholder={field.placeholder}
            min={field.validation?.min}
            max={field.validation?.max}
            maxLength={field.validation?.maxLength}
          />
        );
    }
  };

  if (!formDefinition) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading entry form...</p>
        </div>
      </div>
    );
  }

  const currentSection = formDefinition.schema.sections[currentStep];
  const isLastStep = currentStep === formDefinition.schema.sections.length - 1;
  const completionPercentage = Math.round(((currentStep + 1) / formDefinition.schema.sections.length) * 100);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 overflow-x-hidden">
      <div className="max-w-4xl mx-auto px-4 py-6 sm:py-8">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 sm:p-6 lg:p-8 mb-6 sm:mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl sm:rounded-2xl flex items-center justify-center flex-shrink-0">
              <Award className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white line-clamp-2">
                {formDefinition.title}
              </h1>
              <p className="text-gray-600 dark:text-gray-400 text-sm sm:text-base lg:text-lg line-clamp-2">
                {formDefinition.category} • {formDefinition.categoryGroup}
              </p>
            </div>
          </div>

          {formDefinition.description && (
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 sm:p-4 mb-4 sm:mb-6">
              <div className="flex items-start space-x-3">
                <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                <p className="text-sm sm:text-base text-blue-900 dark:text-blue-300">{formDefinition.description}</p>
              </div>
            </div>
          )}

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
              <span>Step {currentStep + 1} of {formDefinition.schema.sections.length}</span>
              <span>{completionPercentage}% Complete</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-amber-500 to-orange-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
          </div>

          {/* Section Navigation */}
          <div className="flex space-x-2 overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600">
            {formDefinition.schema.sections.map((section, index) => (
              <button
                key={section.id}
                onClick={() => setCurrentStep(index)}
                className={`flex-shrink-0 px-2 sm:px-3 py-2 rounded-lg font-medium text-xs sm:text-sm transition-colors whitespace-nowrap ${
                  index === currentStep
                    ? 'bg-amber-500 text-white'
                    : index < currentStep
                    ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                    : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
                }`}
              >
                {section.title}
              </button>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 sm:p-6 lg:p-8">
          <div className="mb-8">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {currentSection.title}
            </h2>
            {currentSection.description && (
              <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">{currentSection.description}</p>
            )}
          </div>

          {/* Form Fields */}
          <div className="space-y-4 sm:space-y-6">
            {currentSection.fields.map((field) => (
              <div key={field.id}>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {field.label} {field.required && <span className="text-red-500">*</span>}
                </label>
                
                {renderField(field)}
                
                {field.helpText && (
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                    {field.helpText}
                  </p>
                )}
                
                {errors[field.name] && (
                  <div className="flex items-center space-x-2 mt-2">
                    <AlertCircle className="w-4 h-4 text-red-500" />
                    <p className="text-sm text-red-600 dark:text-red-400">
                      {errors[field.name]}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between space-y-3 sm:space-y-0 mt-6 sm:mt-8 pt-4 sm:pt-6 border-t border-gray-200 dark:border-gray-700">
            <div className="flex space-x-3">
              <button
                type="button"
                onClick={currentStep === 0 ? onCancel : handlePrevious}
                className="px-4 sm:px-6 py-2.5 sm:py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm sm:text-base"
              >
                {currentStep === 0 ? 'Cancel' : 'Previous'}
              </button>

              {onSaveDraft && (
                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isDraft}
                  className="px-4 sm:px-6 py-2.5 sm:py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2 text-sm sm:text-base"
                >
                  {isDraft ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  <span>{isDraft ? 'Saving...' : 'Save Draft'}</span>
                </button>
              )}
            </div>

            {isLastStep ? (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={isSubmitting || isLoading}
                className="w-full sm:w-auto px-6 sm:px-8 py-2.5 sm:py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:from-green-600 hover:to-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2 text-sm sm:text-base"
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                <span>{isSubmitting ? 'Submitting...' : 'Submit Entry'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className="w-full sm:w-auto px-4 sm:px-6 py-2.5 sm:py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center justify-center space-x-2 text-sm sm:text-base"
              >
                <span>Next Step</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Requirements Sidebar */}
        {formDefinition.schema.requirements.length > 0 && (
          <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-6 mt-8">
            <h3 className="font-semibold text-amber-900 dark:text-amber-400 mb-4">
              Entry Requirements
            </h3>
            <ul className="space-y-2">
              {formDefinition.schema.requirements.map((requirement, index) => (
                <li key={index} className="flex items-start space-x-2 text-sm text-amber-800 dark:text-amber-500">
                  <CheckCircle className="w-4 h-4 mt-0.5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                  <span>{requirement}</span>
                </li>
              ))}
            </ul>
            
            {formDefinition.schema.helpText && (
              <div className="mt-4 pt-4 border-t border-amber-200 dark:border-amber-800">
                <p className="text-sm text-amber-800 dark:text-amber-500">
                  {formDefinition.schema.helpText}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Error Summary */}
        {Object.keys(errors).length > 0 && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-6 mt-8">
            <h3 className="font-semibold text-red-900 dark:text-red-400 mb-4">
              Please Fix the Following Issues:
            </h3>
            <ul className="space-y-1">
              {Object.entries(errors).map(([fieldName, error]) => (
                <li key={fieldName} className="flex items-start space-x-2 text-sm text-red-800 dark:text-red-500">
                  <AlertCircle className="w-4 h-4 mt-0.5 text-red-600 dark:text-red-400 flex-shrink-0" />
                  <span>{error}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default DynamicFormRenderer;