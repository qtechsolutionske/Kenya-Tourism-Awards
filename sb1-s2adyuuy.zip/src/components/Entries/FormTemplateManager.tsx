import React, { useState, useEffect } from 'react';
import { 
  Plus, Edit, Eye, Copy, Trash2, Save, X, Upload, Download,
  Settings, FileText, Award, Users, Search, Filter, 
  CheckCircle, AlertCircle, Clock, Star, BarChart3, AlertTriangle
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useEntries } from '../../hooks/useEntries';
import { FormDefinition } from '../../../types/entries';
import { entryFormTemplates } from '../../data/entryFormTemplates';
import DynamicFormRenderer from './DynamicFormRenderer';

const FormTemplateManager: React.FC = () => {
  const { user } = useAuth();
  const { 
    formDefinitions, 
    fetchFormDefinitions, 
    createFormDefinition, 
    updateFormDefinition 
  } = useEntries();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [groupFilter, setGroupFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [editingForm, setEditingForm] = useState<FormDefinition | null>(null);
  const [previewForm, setPreviewForm] = useState<FormDefinition | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);

  useEffect(() => {
    fetchFormDefinitions();
  }, [fetchFormDefinitions]);

  // Check permissions
  const canManageForms = user && ['superadmin', 'admin', 'manager'].includes(user.role);
  
  if (!canManageForms) {
    return (
      <div className="p-6 text-center">
        <FileText className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Form template management is only available to super administrators, administrators, and managers.
        </p>
      </div>
    );
  }

  const filteredForms = formDefinitions.filter(form => {
    const matchesSearch = form.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         form.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         form.slug.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGroup = groupFilter === 'all' || form.categoryGroup === groupFilter;
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'published' && form.published) ||
                         (statusFilter === 'draft' && !form.published);
    
    return matchesSearch && matchesGroup && matchesStatus;
  });

  const handleInitializeTemplates = async () => {
    setIsInitializing(true);
    try {
      // Create all 51 form templates
      const results = [];
      for (const template of entryFormTemplates) {
        try {
          const result = await createFormDefinition(template);
          results.push(result);
        } catch (error) {
          console.error(`Failed to create form for ${template.category}:`, error);
        }
      }
      
      console.log(`Created ${results.length} form templates`);
      fetchFormDefinitions(); // Refresh list
      setShowImportModal(false);
    } catch (error) {
      console.error('Failed to initialize templates:', error);
    } finally {
      setIsInitializing(false);
    }
  };

  const duplicateForm = async (form: FormDefinition) => {
    try {
      const newForm = {
        ...form,
        slug: `${form.slug}-copy-${Date.now()}`,
        title: `${form.title} (Copy)`,
        published: false,
        version: 1,
        createdBy: user!.id
      };
      
      await createFormDefinition(newForm);
      fetchFormDefinitions();
    } catch (error) {
      console.error('Failed to duplicate form:', error);
    }
  };

  const toggleFormStatus = async (formId: string, published: boolean) => {
    try {
      await updateFormDefinition(formId, { 
        published,
        updatedBy: user!.id,
        version: formDefinitions.find(f => f.id === formId)?.version || 1
      });
      fetchFormDefinitions();
    } catch (error) {
      console.error('Failed to update form status:', error);
    }
  };

  const exportFormTemplates = () => {
    const exportData = formDefinitions.map(form => ({
      slug: form.slug,
      category: form.category,
      categoryGroup: form.categoryGroup,
      title: form.title,
      description: form.description,
      schema: form.schema,
      published: form.published,
      version: form.version,
      metadata: form.metadata
    }));

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `form-templates-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Entry Form Templates
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Manage all 51 entry form templates for Kenya Tourism Awards 2025
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={exportFormTemplates}
            className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2"
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
          {formDefinitions.length === 0 && (
            <button
              onClick={() => setShowImportModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <Upload className="w-4 h-4" />
              <span>Initialize Templates</span>
            </button>
          )}
          <button
            onClick={() => setEditingForm({} as FormDefinition)} 
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>New Form</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Forms</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{formDefinitions.length}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Published</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {formDefinitions.filter(f => f.published).length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Draft Forms</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {formDefinitions.filter(f => !f.published).length}
              </p>
            </div>
            <Edit className="w-8 h-8 text-amber-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Categories</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {new Set(formDefinitions.map(f => f.categoryGroup)).size}
              </p>
            </div>
            <Award className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search form templates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={groupFilter}
                onChange={(e) => setGroupFilter(e.target.value)}
                className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">All Groups</option>
                <option value="facilities">Facilities & Establishments</option>
                <option value="nightlife">Nightlife & Entertainment</option>
                <option value="culinary">Culinary & Gastronomy</option>
                <option value="transport">Transport & Mobility</option>
                <option value="icons">Industry Icons</option>
                <option value="media">Film & Media</option>
                <option value="destinations">Travel Destinations</option>
              </select>
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Status</option>
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>
        </div>
      </div>

      {/* Forms Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Form Template</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Category Group</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Fields</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Status</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Version</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Updated</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredForms.map((form) => (
                <tr key={form.id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <td className="py-4 px-6">
                    <div>
                      <div className="font-medium text-gray-900 dark:text-white">{form.title}</div>
                      <div className="text-sm text-amber-600 dark:text-amber-400">{form.category}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-500">/{form.slug}</div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900 dark:text-white capitalize">
                      {form.categoryGroup.replace(/([A-Z])/g, ' $1')}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="text-sm text-gray-900 dark:text-white">
                      {form.schema.sections.reduce((total, section) => total + section.fields.length, 0)} fields
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-500">
                      {form.schema.sections.length} sections
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      {form.published ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <Clock className="w-4 h-4 text-amber-500" />
                      )}
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        form.published
                          ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400'
                      }`}>
                        {form.published ? 'Published' : 'Draft'}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900 dark:text-white">v{form.version}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {form.updatedAt.toLocaleDateString()}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setPreviewForm(form)}
                        className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                        title="Preview form"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingForm(form)}
                        className="p-2 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                        title="Edit form"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => duplicateForm(form)}
                        className="p-2 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 rounded-lg transition-colors"
                        title="Duplicate form"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => toggleFormStatus(form.id, !form.published)}
                        className={`p-2 rounded-lg transition-colors ${
                          form.published
                            ? 'text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20'
                            : 'text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20'
                        }`}
                        title={form.published ? 'Unpublish form' : 'Publish form'}
                      >
                        {form.published ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredForms.length === 0 && (
          <div className="text-center py-12">
            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No forms found</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {formDefinitions.length === 0 
                ? 'Initialize the form templates to get started.' 
                : 'Try adjusting your search or filter criteria.'
              }
            </p>
            {formDefinitions.length === 0 && (
              <button
                onClick={() => setShowImportModal(true)}
                className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors"
              >
                Initialize Form Templates
              </button>
            )}
          </div>
        )}
      </div>

      {/* Initialize Templates Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                  Initialize Form Templates
                </h3>
                <button
                  onClick={() => setShowImportModal(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 dark:text-blue-400 mb-2">
                  Create All 51 Form Templates
                </h4>
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  This will create form templates for all award categories based on the official entry requirements document:
                </p>
                <ul className="text-sm text-blue-800 dark:text-blue-300 mt-3 space-y-1">
                  <li>• 15 Facilities, Establishments & Organizations forms</li>
                  <li>• 5 Nightlife & Entertainment forms</li>
                  <li>• 4 Culinary & Gastronomy forms</li>
                  <li>• 8 Transport & Mobility forms</li>
                  <li>• 7 Industry Icons forms</li>
                  <li>• 4 Film & Media in Tourism forms</li>
                  <li>• 6 Travel Destinations forms</li>
                  <li>• 2 Special Category forms</li>
                </ul>
              </div>

              <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-900 dark:text-amber-400 mb-1">Important Notes</h4>
                    <ul className="text-sm text-amber-800 dark:text-amber-500 space-y-1">
                      <li>• All forms will be created in draft mode</li>
                      <li>• You can edit and customize each form before publishing</li>
                      <li>• This action cannot be undone (but forms can be deleted individually)</li>
                      <li>• Existing forms with matching slugs will not be overwritten</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setShowImportModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleInitializeTemplates}
                  disabled={isInitializing}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-3 rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
                >
                  {isInitializing ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Upload className="w-5 h-5" />
                  )}
                  <span>{isInitializing ? 'Creating Templates...' : 'Initialize Templates'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {previewForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                  Preview: {previewForm.title}
                </h3>
                <button
                  onClick={() => setPreviewForm(null)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
              <DynamicFormRenderer
                formDefinition={previewForm}
                onSubmit={async () => {}} // Preview mode - no submission
                onCancel={() => setPreviewForm(null)}
                isLoading={false}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FormTemplateManager;