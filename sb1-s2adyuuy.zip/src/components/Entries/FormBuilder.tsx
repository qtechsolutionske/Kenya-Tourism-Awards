import React, { useState, useEffect } from 'react';
import { 
  Plus, Save, Eye, X, ArrowUp, ArrowDown, Trash2, Copy,
  Type, Mail, Phone, Calendar, Upload, Image, FileText,
  CheckSquare, Circle, List, Hash, Globe, Settings
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useFormDefinitions } from '../../hooks/useSubmissions';
import { FormDefinition, FormField } from '../../types/submissions';
import { categories } from '../../data/categories';

interface FormBuilderProps {
  formId?: string;
  onSave: (form: FormDefinition) => void;
  onCancel: () => void;
}

const fieldTypes = [
  { type: 'text', label: 'Text Input', icon: Type, description: 'Single line text' },
  { type: 'textarea', label: 'Text Area', icon: FileText, description: 'Multi-line text' },
  { type: 'email', label: 'Email', icon: Mail, description: 'Email address' },
  { type: 'phone', label: 'Phone', icon: Phone, description: 'Phone number' },
  { type: 'url', label: 'URL', icon: Globe, description: 'Website URL' },
  { type: 'number', label: 'Number', icon: Hash, description: 'Numeric input' },
  { type: 'date', label: 'Date', icon: Calendar, description: 'Date picker' },
  { type: 'select', label: 'Dropdown', icon: List, description: 'Single selection' },
  { type: 'checkbox', label: 'Checkbox', icon: CheckSquare, description: 'Yes/No option' },
  { type: 'radio', label: 'Radio Buttons', icon: Circle, description: 'Single choice' },
  { type: 'file', label: 'File Upload', icon: Upload, description: 'Document upload' },
  { type: 'image', label: 'Image Upload', icon: Image, description: 'Image upload' }
];

const FormBuilder: React.FC<FormBuilderProps> = ({ formId, onSave, onCancel }) => {
  const { user } = useAuth();
  const { forms, fetchForms, createForm, updateForm } = useFormDefinitions();
  const [formData, setFormData] = useState<FormDefinition>({
    id: '',
    slug: '',
    categoryGroup: '',
    category: '',
    title: '',
    description: '',
    schema: {
      sections: [{
        id: 'basic_info',
        title: 'Basic Information',
        fields: [],
        order: 1
      }],
      requirements: [],
      maxAttachments: 10,
      allowedFileTypes: ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'],
      maxFileSize: 5
    },
    published: false,
    version: 1,
    metadata: {},
    createdBy: user?.id || '',
    createdAt: new Date(),
    updatedAt: new Date()
  });
  
  const [activeSection, setActiveSection] = useState(0);
  const [showFieldPicker, setShowFieldPicker] = useState(false);
  const [editingField, setEditingField] = useState<string | null>(null);

  useEffect(() => {
    if (formId) {
      fetchForms().then(forms => {
        const form = forms.find(f => f.id === formId);
        if (form) {
          setFormData(form);
        }
      });
    }
  }, [formId, fetchForms]);

  const addSection = () => {
    setFormData(prev => ({
      ...prev,
      schema: {
        ...prev.schema,
        sections: [
          ...prev.schema.sections,
          {
            id: `section_${Date.now()}`,
            title: 'New Section',
            fields: [],
            order: prev.schema.sections.length + 1
          }
        ]
      }
    }));
  };

  const addField = (sectionIndex: number, fieldType: FormField['type']) => {
    const newField: FormField = {
      id: `field_${Date.now()}`,
      type: fieldType,
      name: `field_${Date.now()}`,
      label: 'New Field',
      required: false,
      validation: {},
      metadata: {}
    };

    setFormData(prev => {
      const newSections = [...prev.schema.sections];
      newSections[sectionIndex] = {
        ...newSections[sectionIndex],
        fields: [...newSections[sectionIndex].fields, newField]
      };
      
      return {
        ...prev,
        schema: {
          ...prev.schema,
          sections: newSections
        }
      };
    });
    
    setShowFieldPicker(false);
  };

  const updateField = (sectionIndex: number, fieldIndex: number, updates: Partial<FormField>) => {
    setFormData(prev => {
      const newSections = [...prev.schema.sections];
      newSections[sectionIndex] = {
        ...newSections[sectionIndex],
        fields: newSections[sectionIndex].fields.map((field, i) => 
          i === fieldIndex ? { ...field, ...updates } : field
        )
      };
      
      return {
        ...prev,
        schema: {
          ...prev.schema,
          sections: newSections
        }
      };
    });
  };

  const removeField = (sectionIndex: number, fieldIndex: number) => {
    setFormData(prev => {
      const newSections = [...prev.schema.sections];
      newSections[sectionIndex] = {
        ...newSections[sectionIndex],
        fields: newSections[sectionIndex].fields.filter((_, i) => i !== fieldIndex)
      };
      
      return {
        ...prev,
        schema: {
          ...prev.schema,
          sections: newSections
        }
      };
    });
  };

  const moveField = (sectionIndex: number, fieldIndex: number, direction: 'up' | 'down') => {
    const section = formData.schema.sections[sectionIndex];
    const targetIndex = direction === 'up' ? fieldIndex - 1 : fieldIndex + 1;
    
    if (targetIndex < 0 || targetIndex >= section.fields.length) return;

    setFormData(prev => {
      const newSections = [...prev.schema.sections];
      const fields = [...newSections[sectionIndex].fields];
      [fields[fieldIndex], fields[targetIndex]] = [fields[targetIndex], fields[fieldIndex]];
      
      newSections[sectionIndex] = {
        ...newSections[sectionIndex],
        fields
      };
      
      return {
        ...prev,
        schema: {
          ...prev.schema,
          sections: newSections
        }
      };
    });
  };

  const generateSlug = (category: string) => {
    return category
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
  };

  const handleSave = async () => {
    try {
      if (!formData.slug) {
        setFormData(prev => ({ ...prev, slug: generateSlug(prev.category) }));
      }

      if (formId) {
        await updateForm(formId, { ...formData, updatedBy: user?.id });
      } else {
        await createForm(formData);
      }
      
      onSave(formData);
    } catch (error) {
      console.error('Failed to save form:', error);
    }
  };

  const FieldEditor = ({ 
    sectionIndex, 
    fieldIndex, 
    field 
  }: { 
    sectionIndex: number; 
    fieldIndex: number; 
    field: FormField; 
  }) => (
    <div className="border-2 border-blue-500 rounded-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-medium text-gray-900 dark:text-white">Edit Field</h4>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => updateField(sectionIndex, fieldIndex, field)}
            className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
          >
            <Save className="w-4 h-4" />
          </button>
          <button
            onClick={() => setEditingField(null)}
            className="px-3 py-1 bg-gray-600 text-white text-sm rounded hover:bg-gray-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Field Label
          </label>
          <input
            type="text"
            value={field.label}
            onChange={(e) => updateField(sectionIndex, fieldIndex, { label: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Field Name
          </label>
          <input
            type="text"
            value={field.name}
            onChange={(e) => updateField(sectionIndex, fieldIndex, { name: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-mono"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Placeholder
          </label>
          <input
            type="text"
            value={field.placeholder || ''}
            onChange={(e) => updateField(sectionIndex, fieldIndex, { placeholder: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Help Text
          </label>
          <input
            type="text"
            value={field.helpText || ''}
            onChange={(e) => updateField(sectionIndex, fieldIndex, { helpText: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        </div>
      </div>

      <div className="mt-4 flex items-center space-x-4">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={field.required}
            onChange={(e) => updateField(sectionIndex, fieldIndex, { required: e.target.checked })}
            className="text-amber-500 focus:ring-amber-500"
          />
          <span className="text-sm text-gray-900 dark:text-white">Required Field</span>
        </label>
      </div>

      {(field.type === 'select' || field.type === 'radio') && (
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Options (one per line)
          </label>
          <textarea
            value={field.options?.map(opt => opt.label).join('\n') || ''}
            onChange={(e) => {
              const options = e.target.value.split('\n').map((line, i) => ({
                value: line.toLowerCase().replace(/\s+/g, '_'),
                label: line.trim()
              })).filter(opt => opt.label);
              updateField(sectionIndex, fieldIndex, { options });
            }}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            placeholder="Option 1&#10;Option 2&#10;Option 3"
          />
        </div>
      )}

      {field.type === 'textarea' && (
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Min Length
            </label>
            <input
              type="number"
              value={field.validation?.minLength || ''}
              onChange={(e) => updateField(sectionIndex, fieldIndex, {
                validation: { ...field.validation, minLength: parseInt(e.target.value) || undefined }
              })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Max Length
            </label>
            <input
              type="number"
              value={field.validation?.maxLength || ''}
              onChange={(e) => updateField(sectionIndex, fieldIndex, {
                validation: { ...field.validation, maxLength: parseInt(e.target.value) || undefined }
              })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        </div>
      )}

      {(field.type === 'file' || field.type === 'image') && (
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Max Files
            </label>
            <input
              type="number"
              value={field.validation?.maxFiles || 1}
              onChange={(e) => updateField(sectionIndex, fieldIndex, {
                validation: { ...field.validation, maxFiles: parseInt(e.target.value) || 1 }
              })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Max Size (MB)
            </label>
            <input
              type="number"
              value={field.validation?.maxFileSize || 5}
              onChange={(e) => updateField(sectionIndex, fieldIndex, {
                validation: { ...field.validation, maxFileSize: parseInt(e.target.value) || 5 }
              })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        </div>
      )}
    </div>
  );

  const FieldCard = ({ 
    sectionIndex, 
    fieldIndex, 
    field 
  }: { 
    sectionIndex: number; 
    fieldIndex: number; 
    field: FormField; 
  }) => {
    const FieldIcon = fieldTypes.find(ft => ft.type === field.type)?.icon || Type;
    
    return (
      <div className="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-amber-100 dark:bg-amber-900/20 rounded-lg">
              <FieldIcon className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white">{field.label}</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                {field.type} {field.required && '• Required'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-1">
            <button
              onClick={() => moveField(sectionIndex, fieldIndex, 'up')}
              className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded"
              disabled={fieldIndex === 0}
            >
              <ArrowUp className="w-4 h-4" />
            </button>
            <button
              onClick={() => moveField(sectionIndex, fieldIndex, 'down')}
              className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded"
              disabled={fieldIndex === formData.schema.sections[sectionIndex].fields.length - 1}
            >
              <ArrowDown className="w-4 h-4" />
            </button>
            <button
              onClick={() => setEditingField(`${sectionIndex}-${fieldIndex}`)}
              className="p-1 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded"
            >
              <Edit className="w-4 h-4" />
            </button>
            <button
              onClick={() => removeField(sectionIndex, fieldIndex)}
              className="p-1 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Field Preview */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded p-3 text-sm">
          <label className="block text-gray-700 dark:text-gray-300 mb-1">
            {field.label} {field.required && <span className="text-red-500">*</span>}
          </label>
          
          {field.type === 'textarea' ? (
            <textarea
              placeholder={field.placeholder}
              disabled
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-500"
              rows={3}
            />
          ) : field.type === 'select' ? (
            <select disabled className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-500">
              <option>{field.placeholder || 'Select an option'}</option>
              {field.options?.map((option, i) => (
                <option key={i} value={option.value}>{option.label}</option>
              ))}
            </select>
          ) : field.type === 'checkbox' ? (
            <div className="flex items-center space-x-2">
              <input type="checkbox" disabled className="text-amber-500" />
              <span className="text-gray-500">{field.placeholder || 'Checkbox option'}</span>
            </div>
          ) : field.type === 'file' || field.type === 'image' ? (
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
              <Upload className="w-6 h-6 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">{field.placeholder || 'Upload files'}</p>
            </div>
          ) : (
            <input
              type={field.type === 'text' ? 'text' : field.type}
              placeholder={field.placeholder}
              disabled
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-500"
            />
          )}
          
          {field.helpText && (
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">{field.helpText}</p>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={onCancel}
              className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                {formId ? 'Edit Form Template' : 'Create Form Template'}
              </h2>
              <p className="text-gray-600 dark:text-gray-400">
                {formData.category || 'Configure entry form fields and validation'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2">
              <Eye className="w-4 h-4" />
              <span>Preview</span>
            </button>
            <button
              onClick={handleSave}
              className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-2 rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Form</span>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Form Settings */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Form Settings</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Category Group
              </label>
              <select
                value={formData.categoryGroup}
                onChange={(e) => setFormData(prev => ({ ...prev, categoryGroup: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="">Select Group</option>
                <option value="facilities">Facilities & Establishments</option>
                <option value="nightlife">Nightlife & Entertainment</option>
                <option value="culinary">Culinary & Gastronomy</option>
                <option value="transport">Transport & Mobility</option>
                <option value="icons">Industry Icons</option>
                <option value="media">Film & Media</option>
                <option value="destinations">Travel Destinations</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Specific Category
              </label>
              <select
                value={formData.category}
                onChange={(e) => {
                  const selectedCategory = e.target.value;
                  setFormData(prev => ({ 
                    ...prev, 
                    category: selectedCategory,
                    slug: generateSlug(selectedCategory),
                    title: `Entry Form - ${selectedCategory}`
                  }));
                }}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="">Select Category</option>
                {categories
                  .filter(cat => !formData.categoryGroup || cat.group === formData.categoryGroup)
                  .map(category => (
                    <option key={category.id} value={category.name}>
                      {category.name}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Form Title
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.published}
                onChange={(e) => setFormData(prev => ({ ...prev, published: e.target.checked }))}
                className="text-amber-500 focus:ring-amber-500"
              />
              <label className="text-sm text-gray-900 dark:text-white">Published</label>
            </div>
          </div>
        </div>

        {/* Form Builder */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Form Sections</h3>
              <button
                onClick={addSection}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add Section</span>
              </button>
            </div>

            {/* Section Tabs */}
            <div className="border-b border-gray-200 dark:border-gray-700 mb-6">
              <nav className="flex space-x-8">
                {formData.schema.sections.map((section, index) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(index)}
                    className={`py-2 px-1 border-b-2 font-medium text-sm ${
                      activeSection === index
                        ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                        : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                    }`}
                  >
                    {section.title}
                  </button>
                ))}
              </nav>
            </div>

            {/* Active Section Content */}
            {formData.schema.sections[activeSection] && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <input
                    type="text"
                    value={formData.schema.sections[activeSection].title}
                    onChange={(e) => {
                      const newSections = [...formData.schema.sections];
                      newSections[activeSection] = {
                        ...newSections[activeSection],
                        title: e.target.value
                      };
                      setFormData(prev => ({
                        ...prev,
                        schema: { ...prev.schema, sections: newSections }
                      }));
                    }}
                    className="text-lg font-semibold bg-transparent border-none focus:ring-0 text-gray-900 dark:text-white"
                  />
                  <button
                    onClick={() => setShowFieldPicker(true)}
                    className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Field</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {formData.schema.sections[activeSection].fields.map((field, fieldIndex) => 
                    editingField === `${activeSection}-${fieldIndex}` ? (
                      <FieldEditor
                        key={field.id}
                        sectionIndex={activeSection}
                        fieldIndex={fieldIndex}
                        field={field}
                      />
                    ) : (
                      <FieldCard
                        key={field.id}
                        sectionIndex={activeSection}
                        fieldIndex={fieldIndex}
                        field={field}
                      />
                    )
                  )}
                  
                  {formData.schema.sections[activeSection].fields.length === 0 && (
                    <div className="text-center py-8 border border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                      <Settings className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500 dark:text-gray-400">No fields in this section</p>
                      <button
                        onClick={() => setShowFieldPicker(true)}
                        className="mt-4 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors"
                      >
                        Add First Field
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Field Picker Modal */}
      {showFieldPicker && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Add Field</h3>
                <button
                  onClick={() => setShowFieldPicker(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {fieldTypes.map((fieldType) => {
                  const Icon = fieldType.icon;
                  return (
                    <button
                      key={fieldType.type}
                      onClick={() => addField(activeSection, fieldType.type as FormField['type'])}
                      className="p-6 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors text-left"
                    >
                      <Icon className="w-8 h-8 text-amber-600 dark:text-amber-400 mb-3" />
                      <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                        {fieldType.label}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {fieldType.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FormBuilder;