import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Filter, Eye, Edit, Trash2, CheckCircle, 
  XCircle, Clock, Award, Download, Upload, FileText,
  User, Mail, Phone, MapPin, Calendar, ExternalLink,
  Star, BarChart3, AlertTriangle, Settings, Target,
  Copy, Share2, MessageSquare, Flag, Trophy
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useSubmissions, useUserPrivileges } from '../../hooks/useSubmissions';
import { categories } from '../../data/categories';
import { Submission } from '../../types/submissions';
import { PRIVILEGE_TYPES } from '../../types/submissions';

const EntriesManagement: React.FC = () => {
  const { user } = useAuth();
  const { submissions, isLoading, error, fetchSubmissions, updateSubmissionStatus } = useSubmissions();
  const { privileges, fetchUserPrivileges, hasPrivilege } = useUserPrivileges();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [selectedSubmissions, setSelectedSubmissions] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchSubmissions();
    if (user?.id) {
      fetchUserPrivileges(user.id);
    }
  }, [fetchSubmissions, fetchUserPrivileges, user?.id]);

  // Check permissions
  const canViewSubmissions = hasPrivilege(privileges, PRIVILEGE_TYPES.VIEW_SUBMISSIONS) || 
                           hasPrivilege(privileges, PRIVILEGE_TYPES.FULL_ACCESS) ||
                           user?.role === 'superadmin' || user?.role === 'admin';
  const canManageSubmissions = hasPrivilege(privileges, PRIVILEGE_TYPES.EDIT_SUBMISSIONS) || 
                             hasPrivilege(privileges, PRIVILEGE_TYPES.FULL_ACCESS) ||
                             user?.role === 'superadmin' || user?.role === 'admin';
  const canApproveSubmissions = hasPrivilege(privileges, PRIVILEGE_TYPES.APPROVE_SUBMISSIONS) || 
                              hasPrivilege(privileges, PRIVILEGE_TYPES.FULL_ACCESS) ||
                              user?.role === 'superadmin' || user?.role === 'admin';
  const hasFullAccess = user?.role === 'superadmin';

  if (!canViewSubmissions) {
    return (
      <div className="p-6 text-center">
        <AlertTriangle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          You don't have permission to view submissions. Please contact your administrator.
        </p>
      </div>
    );
  }

  const filteredSubmissions = submissions.filter(submission => {
    const matchesSearch = 
      submission.nomineeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      submission.organizationName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      submission.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
      submission.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || submission.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || submission.category === categoryFilter;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const getStatusIcon = (status: Submission['status']) => {
    switch (status) {
      case 'verified':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'rejected':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'shortlisted':
        return <Award className="w-4 h-4 text-amber-500" />;
      case 'winner':
        return <Trophy className="w-4 h-4 text-purple-500" />;
      case 'under_review':
        return <Clock className="w-4 h-4 text-blue-500" />;
      default:
        return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: Submission['status']) => {
    switch (status) {
      case 'verified':
        return 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400';
      case 'rejected':
        return 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-400';
      case 'shortlisted':
        return 'bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-400';
      case 'winner':
        return 'bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-400';
      case 'under_review':
        return 'bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
    }
  };

  const handleStatusChange = async (submissionId: string, newStatus: Submission['status']) => {
    if (!canApproveSubmissions && !hasFullAccess) {
      alert('You don\'t have permission to change submission status');
      return;
    }

    try {
      await updateSubmissionStatus(submissionId, newStatus);
      
      // Log the change for audit trail
      console.log(`Status changed to ${newStatus} for submission ${submissionId} by ${user?.role} user ${user?.id}`);
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  const toggleSubmissionSelection = (submissionId: string) => {
    setSelectedSubmissions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(submissionId)) {
        newSet.delete(submissionId);
      } else {
        newSet.add(submissionId);
      }
      return newSet;
    });
  };

  const selectAllSubmissions = () => {
    if (selectedSubmissions.size === filteredSubmissions.length) {
      setSelectedSubmissions(new Set());
    } else {
      setSelectedSubmissions(new Set(filteredSubmissions.map(s => s.id)));
    }
  };

  const SubmissionDetailsModal = () => {
    if (!selectedSubmission) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {selectedSubmission.nomineeName}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">{selectedSubmission.category}</p>
              </div>
              <button
                onClick={() => setSelectedSubmission(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Details */}
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-6">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Entry Information</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-600 dark:text-gray-400">Nominee Name</label>
                      <p className="font-medium text-gray-900 dark:text-white">{selectedSubmission.nomineeName}</p>
                    </div>
                    {selectedSubmission.organizationName && (
                      <div>
                        <label className="text-sm text-gray-600 dark:text-gray-400">Organization</label>
                        <p className="font-medium text-gray-900 dark:text-white">{selectedSubmission.organizationName}</p>
                      </div>
                    )}
                    <div>
                      <label className="text-sm text-gray-600 dark:text-gray-400">Contact Person</label>
                      <p className="font-medium text-gray-900 dark:text-white">{selectedSubmission.contactPerson}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-600 dark:text-gray-400">Email</label>
                      <p className="font-medium text-gray-900 dark:text-white">{selectedSubmission.contactEmail}</p>
                    </div>
                    {selectedSubmission.county && (
                      <div>
                        <label className="text-sm text-gray-600 dark:text-gray-400">County</label>
                        <p className="font-medium text-gray-900 dark:text-white">{selectedSubmission.county}</p>
                      </div>
                    )}
                    {selectedSubmission.yearEstablished && (
                      <div>
                        <label className="text-sm text-gray-600 dark:text-gray-400">Year Established</label>
                        <p className="font-medium text-gray-900 dark:text-white">{selectedSubmission.yearEstablished}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Attachments */}
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Attachments</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.entries(selectedSubmission.attachments).map(([type, urls]) => (
                      <div key={type} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                        <h5 className="font-medium text-gray-900 dark:text-white mb-2 capitalize">
                          {type.replace('_', ' ')}
                        </h5>
                        {Array.isArray(urls) ? (
                          <div className="space-y-2">
                            {urls.map((url, index) => (
                              <a
                                key={index}
                                href={url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center space-x-2 text-sm text-blue-600 dark:text-blue-400 hover:underline"
                              >
                                <FileText className="w-4 h-4" />
                                <span>View {type} {index + 1}</span>
                              </a>
                            ))}
                          </div>
                        ) : (
                          <a
                            href={urls}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-2 text-sm text-blue-600 dark:text-blue-400 hover:underline"
                          >
                            <FileText className="w-4 h-4" />
                            <span>View {type}</span>
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Entry Details */}
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Entry Details</h4>
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                    {Object.entries(selectedSubmission.nomineeDetails).map(([key, value]) => (
                      <div key={key} className="mb-4 last:mb-0">
                        <label className="text-sm font-medium text-gray-600 dark:text-gray-400 capitalize">
                          {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                        </label>
                        <p className="text-gray-900 dark:text-white mt-1">
                          {typeof value === 'string' ? value : JSON.stringify(value)}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Sidebar Actions */}
              <div className="space-y-6">
                {/* Status */}
                <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Status & Actions</h4>
                  
                  <div className="flex items-center space-x-3 mb-4">
                    {getStatusIcon(selectedSubmission.status)}
                    <span className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(selectedSubmission.status)}`}>
                      {selectedSubmission.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>

                  {canApproveSubmissions && (
                    <div className="space-y-3">
                      <select
                        defaultValue={selectedSubmission.status}
                        onChange={(e) => handleStatusChange(selectedSubmission.id, e.target.value as Submission['status'])}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      >
                        <option value="pending">Pending</option>
                        <option value="under_review">Under Review</option>
                        <option value="verified">Verified</option>
                        <option value="rejected">Rejected</option>
                        <option value="shortlisted">Shortlisted</option>
                        <option value="winner">Winner</option>
                        <option value="runner_up">Runner Up</option>
                      </select>
                      
                      <textarea
                        placeholder="Review notes..."
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                        rows={3}
                      />
                      
                      <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                        Update Status
                      </button>
                    </div>
                  )}
                </div>

                {/* Scoring */}
                {selectedSubmission.juryScore && (
                  <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                    <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Scoring</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Jury Score</span>
                        <span className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                          {selectedSubmission.juryScore}/10
                        </span>
                        {hasFullAccess && (
                          <button className="w-full flex items-center space-x-2 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                            <Trash2 className="w-4 h-4" />
                            <span>Delete Entry</span>
                          </button>
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Public Votes</span>
                        <span className="text-lg font-semibold text-blue-600 dark:text-blue-400">
                          {selectedSubmission.publicVotes}
                        </span>
                      </div>
                      {selectedSubmission.totalScore && (
                        <div className="pt-3 border-t border-gray-200 dark:border-gray-600">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-900 dark:text-white">Total Score</span>
                            <span className="text-xl font-bold text-purple-600 dark:text-purple-400">
                              {selectedSubmission.totalScore}
                            </span>
                            <p className="text-xs text-gray-500 dark:text-gray-500">
                              User Agent: {selectedSubmission.submissionUserAgent?.substring(0, 50)}...
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Quick Actions */}
                <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h4>
                  <div className="space-y-3">
                    <button className="w-full flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                      <Mail className="w-4 h-4" />
                      <span>Email Submitter</span>
                    </button>
                    <button className="w-full flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                      <Copy className="w-4 h-4" />
                      <span>Copy Entry Link</span>
                    </button>
                    <button className="w-full flex items-center space-x-2 px-3 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors">
                      <Flag className="w-4 h-4" />
                      <span>Mark as Featured</span>
                    </button>
                    <button className="w-full flex items-center space-x-2 px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                      <Download className="w-4 h-4" />
                      <span>Export Data</span>
                    </button>
                  </div>
                </div>

                {/* Submission Timeline */}
                <div className="bg-white dark:bg-gray-700 rounded-xl p-6 border border-gray-200 dark:border-gray-600">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Timeline</h4>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">Entry Submitted</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                          {selectedSubmission.createdAt.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">Under Review</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                          {selectedSubmission.updatedAt.toLocaleString()}
                        </p>
                        {hasFullAccess && selectedSubmission.submissionIp && (
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-gray-500 rounded-full mt-2"></div>
                            <div>
                              <p className="text-sm font-medium text-gray-900 dark:text-white">Technical Details</p>
                              <p className="text-xs text-gray-600 dark:text-gray-400">
                                IP: {selectedSubmission.submissionIp}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Entries & Submissions Management
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Review and manage all entry submissions for KTA 2025
          </p>
        </div>
        <div className="flex items-center space-x-4">
          {canManageSubmissions && (
            <button
              onClick={() => setShowBulkActions(!showBulkActions)}
              className="bg-gray-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-700 transition-colors flex items-center space-x-2"
            >
              <Settings className="w-4 h-4" />
              <span>Bulk Actions</span>
            </button>
          )}
          <button
            onClick={() => window.open('/submit-entry', '_blank')}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>New Entry</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Entries</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{submissions.length}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Pending Review</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {submissions.filter(s => s.status === 'pending').length}
              </p>
            </div>
            <Clock className="w-8 h-8 text-amber-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Verified</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {submissions.filter(s => s.status === 'verified').length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Shortlisted</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {submissions.filter(s => s.status === 'shortlisted').length}
              </p>
            </div>
            <Star className="w-8 h-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Winners</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {submissions.filter(s => s.status === 'winner').length}
              </p>
            </div>
            <Trophy className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search entries..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="under_review">Under Review</option>
                <option value="verified">Verified</option>
                <option value="rejected">Rejected</option>
                <option value="shortlisted">Shortlisted</option>
                <option value="winner">Winner</option>
                <option value="runner_up">Runner Up</option>
              </select>
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Categories</option>
              {categories.map(category => (
                <option key={category.id} value={category.name}>
                  {category.name}
                </option>
              ))}
            </select>
            <button
              onClick={() => fetchSubmissions({ status: statusFilter, category: categoryFilter })}
              className="bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <BarChart3 className="w-4 h-4" />
              <span>Export</span>
            </button>
          </div>
        </div>

        {/* Bulk Actions */}
        {showBulkActions && selectedSubmissions.size > 0 && (
          <div className="mb-4 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-blue-900 dark:text-blue-400">
                {selectedSubmissions.size} entries selected
              </span>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700">
                  Approve All
                </button>
                <button className="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700">
                  Reject All
                </button>
                <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
                  Export Selected
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Submissions Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-400">Loading entries...</p>
          </div>
        ) : error ? (
          <div className="p-8 text-center">
            <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <p className="text-red-600 dark:text-red-400">{error}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="text-left py-4 px-6">
                    <input
                      type="checkbox"
                      checked={selectedSubmissions.size === filteredSubmissions.length}
                      onChange={selectAllSubmissions}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                  </th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Entry</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Category</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Contact</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Status</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Score</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Submitted</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900 dark:text-white">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredSubmissions.map((submission) => (
                  <tr 
                    key={submission.id} 
                    className={`border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors ${
                      selectedSubmissions.has(submission.id) ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                    }`}
                  >
                    <td className="py-4 px-6">
                      <input
                        type="checkbox"
                        checked={selectedSubmissions.has(submission.id)}
                        onChange={() => toggleSubmissionSelection(submission.id)}
                        className="text-amber-500 focus:ring-amber-500"
                      />
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        {submission.featured && (
                          <Star className="w-4 h-4 text-amber-500" />
                        )}
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">
                            {submission.nomineeName}
                          </div>
                          {submission.organizationName && (
                            <div className="text-sm text-gray-600 dark:text-gray-400">
                              {submission.organizationName}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div>
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {submission.category}
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">
                          {submission.categoryGroup}
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div>
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {submission.contactPerson}
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">
                          {submission.contactEmail}
                        </div>
                        {submission.county && (
                          <div className="text-xs text-gray-500 dark:text-gray-500">
                            {submission.county}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(submission.status)}
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(submission.status)}`}>
                          {submission.status.replace('_', ' ').toUpperCase()}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm">
                        {submission.juryScore && (
                          <div className="font-medium text-amber-600 dark:text-amber-400">
                            {submission.juryScore}/10
                          </div>
                        )}
                        <div className="text-gray-600 dark:text-gray-400">
                          {submission.publicVotes} votes
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {submission.createdAt.toLocaleDateString()}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedSubmission(submission)}
                          className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                          title="View details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {canManageSubmissions && (
                          <button
                            className="p-2 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                            title="Edit entry"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        )}
                        {canApproveSubmissions && (
                          <button
                            className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                            title="Delete entry"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {filteredSubmissions.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No entries found</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {searchTerm || statusFilter !== 'all' || categoryFilter !== 'all'
                ? 'Try adjusting your search or filter criteria.'
                : 'No entries have been submitted yet.'
              }
            </p>
          </div>
        )}
      </div>

      {selectedSubmission && <SubmissionDetailsModal />}
    </div>
  );
};

export default EntriesManagement;