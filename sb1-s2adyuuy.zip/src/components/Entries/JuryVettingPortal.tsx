import React, { useState, useEffect } from 'react';
import { 
  Award, Star, FileText, Clock, CheckCircle, User, 
  Filter, Search, Eye, Edit, Save, X, BarChart3,
  Users, Target, TrendingUp, Download, Upload,
  MessageSquare, Flag, ExternalLink
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useEntries, useSubmissionReviews } from '../../hooks/useEntries';
import { scoringRubrics } from '../../data/entryFormTemplates';
import { Submission, SubmissionReview } from '../../types/entries';

interface JuryEvaluation {
  submission: Submission;
  review?: SubmissionReview;
  isAssigned: boolean;
}

const JuryVettingPortal: React.FC = () => {
  const { user } = useAuth();
  const { submissions, fetchSubmissions } = useEntries();
  const { reviews, fetchReviews, createReview } = useSubmissionReviews();
  const [evaluations, setEvaluations] = useState<JuryEvaluation[]>([]);
  const [selectedEvaluation, setSelectedEvaluation] = useState<JuryEvaluation | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [blindReview, setBlindReview] = useState(false);

  useEffect(() => {
    loadEvaluations();
  }, []);

  const loadEvaluations = async () => {
    const allSubmissions = await fetchSubmissions({ status: 'verified' });
    
    // Filter submissions assigned to this jury member
    const assignedEvaluations: JuryEvaluation[] = allSubmissions
      .filter(submission => {
        // In real implementation, check jury category assignments
        // For now, show all verified submissions
        return submission.status === 'verified' || submission.status === 'under_review';
      })
      .map(submission => ({
        submission,
        review: undefined, // Will be loaded individually
        isAssigned: true
      }));

    setEvaluations(assignedEvaluations);
  };

  const filteredEvaluations = evaluations.filter(evaluation => {
    const sub = evaluation.submission;
    const matchesSearch = sub.nomineeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sub.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || sub.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'completed' && evaluation.review?.reviewStatus === 'submitted') ||
                         (statusFilter === 'pending' && !evaluation.review);
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-green-600 dark:text-green-400';
    if (score >= 6) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  const EvaluationForm = ({ evaluation }: { evaluation: JuryEvaluation }) => {
    const submission = evaluation.submission;
    const rubric = scoringRubrics[submission.categoryGroup as keyof typeof scoringRubrics] || scoringRubrics.facilities;
    
    const [scores, setScores] = useState<Record<string, number>>(
      evaluation.review?.scores || {}
    );
    const [comments, setComments] = useState(evaluation.review?.comments || '');
    const [recommendations, setRecommendations] = useState(evaluation.review?.recommendations || '');
    const [reviewStatus, setReviewStatus] = useState<SubmissionReview['reviewStatus']>('draft');

    const calculateOverallScore = () => {
      const totalWeightedScore = rubric.reduce((total, criterion) => {
        const score = scores[criterion.criterion] || 0;
        return total + (score * (criterion.weight / 100));
      }, 0);
      return Math.round(totalWeightedScore * 10) / 10;
    };

    const handleSaveReview = async () => {
      try {
        const overallScore = calculateOverallScore();
        
        await createReview({
          submissionId: submission.id,
          reviewerId: user!.id,
          reviewerRole: user!.role,
          scores,
          overallScore,
          comments,
          recommendations,
          reviewStatus,
          reviewedAt: reviewStatus === 'submitted' ? new Date() : undefined
        });

        setSelectedEvaluation(null);
        loadEvaluations();
      } catch (error) {
        console.error('Failed to save review:', error);
      }
    };

    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">
              {blindReview ? 'Anonymous Entry' : submission.nomineeName}
            </h3>
            <p className="text-gray-600 dark:text-gray-400">{submission.category}</p>
            {!blindReview && submission.organizationName && (
              <p className="text-sm text-gray-500 dark:text-gray-500">{submission.organizationName}</p>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setSelectedEvaluation(null)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Submission Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Entry Description */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Entry Description</h4>
              <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                {submission.nomineeDetails.entry_description || 'No description provided'}
              </p>
            </div>

            {/* Key Achievements */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Key Achievements</h4>
              <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                {submission.nomineeDetails.achievements || 'No achievements listed'}
              </p>
            </div>

            {/* Attachments */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Supporting Materials</h4>
              <div className="grid grid-cols-2 gap-4">
                {Object.entries(submission.attachments).map(([type, urls]) => (
                  <div key={type} className="border border-gray-300 dark:border-gray-600 rounded-lg p-3">
                    <h5 className="font-medium text-gray-900 dark:text-white mb-2 capitalize text-sm">
                      {type.replace('_', ' ')}
                    </h5>
                    {Array.isArray(urls) ? (
                      <div className="space-y-1">
                        {urls.slice(0, 3).map((url, index) => (
                          <a
                            key={index}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-2 text-xs text-blue-600 dark:text-blue-400 hover:underline"
                          >
                            <FileText className="w-3 h-3" />
                            <span>View {type} {index + 1}</span>
                          </a>
                        ))}
                      </div>
                    ) : (
                      <a
                        href={urls}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center space-x-2 text-xs text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        <FileText className="w-3 h-3" />
                        <span>View {type}</span>
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Scoring */}
            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Evaluation Scoring</h4>
              <div className="space-y-6">
                {rubric.map((criterion) => (
                  <div key={criterion.criterion} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-medium text-gray-900 dark:text-white">
                          {criterion.criterion}
                        </h5>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Weight: {criterion.weight}% • Max Score: {criterion.maxScore}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className={`text-2xl font-bold ${getScoreColor(scores[criterion.criterion] || 0)}`}>
                          {scores[criterion.criterion] || 0}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-500">/ {criterion.maxScore}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {Array.from({ length: criterion.maxScore }, (_, i) => i + 1).map((rating) => (
                        <button
                          key={rating}
                          onClick={() => setScores(prev => ({ ...prev, [criterion.criterion]: rating }))}
                          className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-sm font-medium transition-colors ${
                            (scores[criterion.criterion] || 0) >= rating
                              ? 'bg-amber-500 border-amber-500 text-white'
                              : 'border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:border-amber-400'
                          }`}
                        >
                          {rating}
                        </button>
                      ))}
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      {Array.from({ length: 5 }, (_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor((scores[criterion.criterion] || 0) / 2)
                              ? 'text-amber-400 fill-current'
                              : 'text-gray-300 dark:text-gray-600'
                          }`}
                        />
                      ))}
                      <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                        {scores[criterion.criterion] || 0}/10
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Overall Score */}
            <div className="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-6 border border-amber-200 dark:border-amber-800">
              <div className="text-center">
                <h4 className="font-semibold text-amber-900 dark:text-amber-400 mb-2">Overall Score</h4>
                <div className="text-4xl font-bold text-amber-600 dark:text-amber-400 mb-2">
                  {calculateOverallScore()}/10
                </div>
                <div className="w-full bg-amber-200 dark:bg-amber-800 rounded-full h-3 mb-2">
                  <div
                    className="bg-amber-500 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${(calculateOverallScore() / 10) * 100}%` }}
                  />
                </div>
                <p className="text-sm text-amber-700 dark:text-amber-500">
                  Weighted average based on criteria
                </p>
              </div>
            </div>

            {/* Comments */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-4 border border-gray-200 dark:border-gray-600">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-3">Comments & Justification</h4>
              <textarea
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                placeholder="Provide detailed feedback and justification for your scores..."
              />
            </div>

            {/* Recommendations */}
            <div className="bg-white dark:bg-gray-700 rounded-xl p-4 border border-gray-200 dark:border-gray-600">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-3">Recommendations</h4>
              <textarea
                value={recommendations}
                onChange={(e) => setRecommendations(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                placeholder="Recommendations for improvement or recognition..."
              />
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <button
                onClick={() => {
                  setReviewStatus('draft');
                  handleSaveReview();
                }}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-center space-x-2"
              >
                <Save className="w-4 h-4" />
                <span>Save as Draft</span>
              </button>
              
              <button
                onClick={() => {
                  setReviewStatus('submitted');
                  handleSaveReview();
                }}
                className="w-full px-4 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:from-green-600 hover:to-emerald-600 transition-colors flex items-center justify-center space-x-2"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Submit Review</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Check permissions
  if (user?.role !== 'jury' && user?.role !== 'admin' && user?.role !== 'superadmin') {
    return (
      <div className="p-6 text-center">
        <Award className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Access Denied</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Jury vetting portal is only available to jury members, administrators, and super administrators.
        </p>
      </div>
    );
  }

  if (selectedEvaluation) {
    return (
      <div className="p-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
        <EvaluationForm evaluation={selectedEvaluation} />
      </div>
    );
  }

  const completedEvaluations = evaluations.filter(e => e.review?.reviewStatus === 'submitted').length;
  const pendingEvaluations = evaluations.filter(e => !e.review || e.review.reviewStatus !== 'submitted').length;

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Jury Vetting Portal</h2>
            <p className="text-blue-100 text-lg">
              Review and evaluate entries for Kenya Tourism Awards 2025
            </p>
          </div>
          <div className="hidden md:block">
            <Award className="w-24 h-24 text-blue-200" />
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Assigned Entries</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{evaluations.length}</p>
            </div>
            <Award className="w-8 h-8 text-amber-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Completed</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{completedEvaluations}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Pending</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{pendingEvaluations}</p>
            </div>
            <Clock className="w-8 h-8 text-orange-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Progress</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {evaluations.length > 0 ? Math.round((completedEvaluations / evaluations.length) * 100) : 0}%
              </p>
            </div>
            <BarChart3 className="w-8 h-8 text-blue-500" />
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search evaluations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">All Categories</option>
                {Array.from(new Set(evaluations.map(e => e.submission.category))).map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-3 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={blindReview}
                onChange={(e) => setBlindReview(e.target.checked)}
                className="text-amber-500 focus:ring-amber-500"
              />
              <span className="text-sm text-gray-700 dark:text-gray-300">Blind Review</span>
            </label>
          </div>
        </div>

        {/* Evaluations List */}
        <div className="space-y-4">
          {filteredEvaluations.map((evaluation) => {
            const submission = evaluation.submission;
            const hasReview = evaluation.review?.reviewStatus === 'submitted';
            
            return (
              <div
                key={submission.id}
                className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors cursor-pointer"
                onClick={() => setSelectedEvaluation(evaluation)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-medium text-gray-900 dark:text-white">
                        {blindReview ? `Entry ${submission.id.slice(-6)}` : submission.nomineeName}
                      </h3>
                      <div className="flex items-center space-x-2">
                        {hasReview ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <Clock className="w-4 h-4 text-amber-500" />
                        )}
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          hasReview
                            ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400'
                        }`}>
                          {hasReview ? 'Completed' : 'Pending Review'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                      <span>{submission.category}</span>
                      {!blindReview && submission.county && <span>{submission.county}</span>}
                      <span>{submission.createdAt.toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  {evaluation.review?.overallScore && (
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${getScoreColor(evaluation.review.overallScore)}`}>
                        {evaluation.review.overallScore}/10
                      </div>
                      <div className="flex items-center space-x-1 mt-1">
                        {Array.from({ length: 5 }, (_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${
                              i < Math.floor(evaluation.review!.overallScore! / 2)
                                ? 'text-amber-400 fill-current'
                                : 'text-gray-300 dark:text-gray-600'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {filteredEvaluations.length === 0 && (
          <div className="text-center py-12">
            <Award className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No evaluations found</h3>
            <p className="text-gray-600 dark:text-gray-400">
              {evaluations.length === 0 
                ? 'No entries have been assigned for review yet.' 
                : 'Try adjusting your search or filter criteria.'
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default JuryVettingPortal;