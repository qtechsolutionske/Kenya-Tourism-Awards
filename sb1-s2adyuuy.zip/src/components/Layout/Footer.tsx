import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, Award, ExternalLink } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 overflow-x-hidden">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {/* Logo & Description */}
          <div className="sm:col-span-2 lg:col-span-1">
            <img 
              src="/Kenya Tourism Awards Gold Logo.svg" 
              alt="Kenya Tourism Awards" 
              className="h-8 sm:h-10 lg:h-12 w-auto mb-4 filter brightness-0 invert"
              onError={(e) => {
                e.currentTarget.src = "/Kenya Tourism Awards Black Logo.svg";
              }}
            />
            <h3 className="text-base sm:text-lg font-bold mb-2">Kenya Tourism Awards</h3>
            <p className="text-gray-400 text-sm mb-4 leading-relaxed">
              Celebrating excellence, innovation, and sustainability in Kenya's vibrant tourism industry.
            </p>
            <div className="flex space-x-3 sm:space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Quick Links</h4>
            <ul className="space-y-1.5 sm:space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors flex items-center">
                  <Award className="w-3 h-3 mr-2" />
                  About Awards
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors block">
                  Categories
                </a>
              </li>
              <li>
                <a href="/entries" className="text-gray-400 hover:text-white text-sm transition-colors block">
                  Submit Entry
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Nominees
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Winners
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Gallery
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  News & Events
                </a>
              </li>
            </ul>
          </div>

          {/* Participate */}
          <div>
            <h4 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Participate</h4>
            <ul className="space-y-1.5 sm:space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors block">
                  Submit Entry
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Vote Now
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Gala Tickets
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors block">
                  Sponsor Packages
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Sponsorship
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Partnership
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Media Kit
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Contact Us</h4>
            <ul className="space-y-2 sm:space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 text-amber-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-400 text-sm">Tourism House</p>
                  <p className="text-gray-400 text-sm">Uhuru Highway, Nairobi</p>
                  <p className="text-gray-400 text-sm">Kenya</p>
                </div>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-amber-400" />
                <p className="text-gray-400 text-sm">+254 707 242620</p>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-amber-400" />
                <p className="text-gray-400 text-sm break-all">info@kenyatourismawards.com</p>
              </li>
            </ul>
            
            <div className="mt-4 sm:mt-6">
              <h5 className="text-sm font-medium mb-2">Important Dates</h5>
              <div className="bg-slate-800 rounded-lg p-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Voting Closes:</span>
                  <span className="text-amber-400 font-medium">Mar 10, 2025</span>
                </div>
                <div className="flex justify-between items-center text-xs mt-1">
                  <span className="text-gray-400">Gala Night:</span>
                  <span className="text-amber-400 font-medium">Mar 15, 2025</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-8 sm:mt-12 pt-6 sm:pt-8">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-4 lg:space-y-0">
            <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-6 text-center sm:text-left">
              <p className="text-gray-400 text-xs sm:text-sm">
                © 2025 Kenya Tourism Awards. All rights reserved.
              </p>
              <div className="flex flex-wrap justify-center sm:justify-start gap-3 sm:gap-4">
                <a href="#" className="text-gray-400 hover:text-white text-xs transition-colors whitespace-nowrap">
                  Privacy Policy
                </a>
                <a href="#" className="text-gray-400 hover:text-white text-xs transition-colors whitespace-nowrap">
                  Terms of Service
                </a>
                <a href="#" className="text-gray-400 hover:text-white text-xs transition-colors whitespace-nowrap">
                  Cookie Policy
                </a>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 text-center">
              <span className="text-gray-400 text-xs whitespace-nowrap">Powered by</span>
              <div className="flex items-center space-x-1">
                <Award className="w-4 h-4 text-amber-400" />
                <span className="text-amber-400 text-xs font-medium whitespace-nowrap">Tourism Excellence</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;