import React, { useState } from 'react';
import { Bell, Search, User, LogOut, Settings, Sun, Moon, Trophy, Menu, X, Star, Calendar, Award } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useTheme } from '../../contexts/ThemeContext';

interface HeaderProps {
  onNotificationClick: () => void;
  notificationCount: number;
  onAuthClick?: () => void;
  onSignupClick?: () => void;
  onPublicRouteChange?: (route: string) => void;
  currentPublicRoute?: string;
  isLoggedIn: boolean;
}

const Header: React.FC<HeaderProps> = ({ 
  onNotificationClick, 
  notificationCount, 
  onAuthClick,
  onSignupClick,
  onPublicRouteChange,
  currentPublicRoute,
  isLoggedIn
}) => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [tickerPaused, setTickerPaused] = useState(false);

  const publicNavItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'entries', label: 'Enter' },
    { id: 'nominees', label: 'Categories' },
    { id: 'team', label: 'Team' },
    { id: 'winners', label: 'Winners' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'gala', label: 'Gala' },
    { id: 'sponsors', label: 'Sponsors' },
    { id: 'contact', label: 'Contact' }
  ];

  const tickerNews = [
    { icon: Star, text: 'Entry submissions open until February 15, 2025 - Submit now!' },
    { icon: Trophy, text: '247 entries submitted across 28 categories!' },
    { icon: Calendar, text: 'Gala Night: March 15, 2025 at KICC Nairobi' },
    { icon: Award, text: 'Join 12,000+ voters in celebrating excellence' }
  ];

  return (
    <header className="sticky top-0 left-0 right-0 z-50">
      {/* Ticker Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white overflow-hidden hidden md:block">
        <div 
          className={`whitespace-nowrap ${tickerPaused ? '' : 'animate-marquee'}`}
          onMouseEnter={() => setTickerPaused(true)}
          onMouseLeave={() => setTickerPaused(false)}
        >
          <div className="inline-flex items-center space-x-12 py-2 px-4">
            {[...Array(3)].map((_, setIndex) =>
              tickerNews.map((news, newsIndex) => {
                const Icon = news.icon;
                return (
                  <div key={`${setIndex}-${newsIndex}`} className="flex items-center space-x-2 text-sm font-medium">
                    <Icon className="w-4 h-4" />
                    <span>{news.text}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm shadow-lg border-b border-gray-200/50 dark:border-gray-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3 flex-shrink-0">
              <img 
                src="/Kenya Tourism Awards Gold Logo.svg" 
                alt="Kenya Tourism Awards" 
                className="h-8 sm:h-10 w-auto"
                onError={(e) => {
                  e.currentTarget.src = "/Kenya Tourism Awards Black Logo.svg";
                }}
              />
            </div>

            {/* Public Navigation - Desktop */}
            {!isLoggedIn && (
              <nav className="hidden lg:flex items-center space-x-6 xl:space-x-8">
                {publicNavItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => onPublicRouteChange?.(item.id)}
                    className={`text-sm font-medium transition-colors whitespace-nowrap ${
                      currentPublicRoute === item.id
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-gray-700 dark:text-gray-300 hover:text-amber-600 dark:hover:text-amber-400'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </nav>
            )}

            {/* Right Side Actions */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              {/* Search - Only for logged in users */}
              {isLoggedIn && (
                <div className="hidden lg:block relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Search..."
                    className="pl-10 pr-4 py-2 w-48 xl:w-64 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent text-sm"
                  />
                </div>
              )}

              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                className="p-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
              >
                {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </button>
              {isLoggedIn ? (
                <>
                  {/* Notifications */}
                  <button
                    onClick={onNotificationClick}
                    className="relative p-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
                  >
                    <Bell className="w-5 h-5" />
                    {notificationCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                        {notificationCount > 9 ? '9+' : notificationCount}
                      </span>
                    )}
                  </button>

                  {/* User Menu */}
                  <div className="relative">
                    <button
                      onClick={() => setShowUserMenu(!showUserMenu)}
                      className="flex items-center space-x-1 sm:space-x-2 p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
                    >
                      <div className="w-7 h-7 sm:w-8 sm:h-8 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <span className="hidden sm:block text-sm font-medium text-slate-900 dark:text-white">
                        {user?.name?.split(' ')[0]}
                      </span>
                    </button>

                    {showUserMenu && (
                      <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-2 z-50">
                        <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-700">
                          <p className="text-sm font-medium text-slate-900 dark:text-white">{user?.name}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{user?.email}</p>
                        </div>
                        <button className="w-full px-4 py-2 text-left text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center space-x-2">
                          <Settings className="w-4 h-4" />
                          <span>Settings</span>
                        </button>
                        <button 
                          onClick={logout}
                          className="w-full px-4 py-2 text-left text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center space-x-2"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <>
                  {/* Auth Buttons - Desktop */}
                  <div className="hidden lg:flex items-center space-x-3">
                    <button
                      onClick={onAuthClick}
                      className="px-3 sm:px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
                    >
                      Sign In
                    </button>
                    <button
                      onClick={onSignupClick}
                      className="px-3 sm:px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white text-sm font-medium rounded-lg hover:from-blue-600 hover:to-indigo-600 transition-colors"
                    >
                      Enter
                    </button>
                  </div>

                  {/* Mobile Menu Button */}
                  <button
                    onClick={() => setShowMobileMenu(!showMobileMenu)}
                    className="lg:hidden p-2 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
                  >
                    {showMobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Mobile Menu */}
          {!isLoggedIn && showMobileMenu && (
            <div className="lg:hidden border-t border-gray-200 dark:border-gray-700 py-4">
              <nav className="flex flex-col space-y-2">
                {publicNavItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      onPublicRouteChange?.(item.id);
                      setShowMobileMenu(false);
                    }}
                    className={`text-left px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                      currentPublicRoute === item.id
                        ? 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20'
                        : 'text-gray-700 dark:text-gray-300 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-gray-50 dark:hover:bg-gray-800'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
                <div className="pt-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
                  <button
                    onClick={() => {
                      onAuthClick?.();
                      setShowMobileMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => {
                      onPublicRouteChange?.('entries');
                      setShowMobileMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white text-sm font-medium rounded-lg hover:from-blue-600 hover:to-indigo-600 transition-colors"
                  >
                    Enter
                  </button>
                </div>
              </nav>
            </div>
          )}
        </div>
      </div>
    </header>

  );
};

export default Header;