import React, { useState, useEffect, useRef } from 'react';
import { Trophy, Award, Star, Sparkles, Play } from 'lucide-react';

interface PreloaderConfig {
  type: 'logo' | 'video';
  logoUrl?: string;
  videoUrl?: string;
  videoPoster?: string;
  brandColors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  effects: {
    showSparkles: boolean;
    showPulse: boolean;
    showRotation: boolean;
    showParticles: boolean;
    duration: number;
  };
  text: {
    title: string;
    subtitle: string;
    loadingText: string;
  };
}

interface PreloaderProps {
  onComplete: () => void;
  config?: PreloaderConfig;
}

const defaultConfig: PreloaderConfig = {
  type: 'logo',
  logoUrl: '/Kenya Tourism Awards Gold Logo.svg',
  brandColors: {
    primary: '#f59e0b',
    secondary: '#ea580c', 
    accent: '#dc2626'
  },
  effects: {
    showSparkles: true,
    showPulse: true,
    showRotation: false,
    showParticles: true,
    duration: 3000
  },
  text: {
    title: 'Kenya Tourism Awards',
    subtitle: 'Celebrating Excellence in Tourism',
    loadingText: 'Loading...'
  }
};

const Preloader: React.FC<PreloaderProps> = ({ onComplete, config = defaultConfig }) => {
  const [progress, setProgress] = useState(0);
  const [showVideo, setShowVideo] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + (100 / (config.effects.duration / 100));
      });
    }, 100);

    return () => clearInterval(interval);
  }, [onComplete, config.effects.duration]);

  // Particle animation effect
  useEffect(() => {
    if (!config.effects.showParticles || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
    }> = [];

    const createParticle = () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 2,
      vy: (Math.random() - 0.5) * 2,
      life: 0,
      maxLife: Math.random() * 100 + 50
    });

    // Initialize particles
    for (let i = 0; i < 50; i++) {
      particles.push(createParticle());
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((particle, index) => {
        particle.x += particle.vx;
        particle.y += particle.vy;
        particle.life++;

        const opacity = 1 - particle.life / particle.maxLife;
        ctx.globalAlpha = opacity * 0.3;
        
        const gradient = ctx.createRadialGradient(
          particle.x, particle.y, 0,
          particle.x, particle.y, 3
        );
        gradient.addColorStop(0, config.brandColors.primary);
        gradient.addColorStop(1, 'transparent');
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, 3, 0, Math.PI * 2);
        ctx.fill();

        if (particle.life >= particle.maxLife) {
          particles[index] = createParticle();
        }
      });

      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [config.effects.showParticles, config.brandColors.primary]);

  const sparkles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 2,
    duration: 1.5 + Math.random()
  }));

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
      style={{
        background: `linear-gradient(135deg, ${config.brandColors.primary}20, ${config.brandColors.secondary}20, ${config.brandColors.accent}20)`
      }}
    >
      {/* Particle Canvas */}
      {config.effects.showParticles && (
        <canvas
          ref={canvasRef}
          className="absolute inset-0 pointer-events-none"
        />
      )}

      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 via-transparent to-slate-900/90"></div>
        
        {/* Sparkles Effect */}
        {config.effects.showSparkles && (
          <div className="absolute inset-0">
            {sparkles.map(sparkle => (
              <div
                key={sparkle.id}
                className="absolute animate-pulse pointer-events-none"
                style={{
                  left: `${sparkle.x}%`,
                  top: `${sparkle.y}%`,
                  animationDelay: `${sparkle.delay}s`,
                  animationDuration: `${sparkle.duration}s`
                }}
              >
                <Sparkles 
                  className="w-4 h-4 opacity-60" 
                  style={{ color: config.brandColors.primary }}
                />
              </div>
            ))}
          </div>
        )}

        {/* Geometric Shapes */}
        <div 
          className="absolute top-20 left-20 w-32 h-32 rounded-full blur-xl animate-pulse"
          style={{ backgroundColor: `${config.brandColors.primary}10` }}
        />
        <div 
          className="absolute bottom-32 right-16 w-24 h-24 rounded-full blur-lg animate-pulse delay-1000"
          style={{ backgroundColor: `${config.brandColors.secondary}10` }}
        />
        <div 
          className="absolute top-1/2 right-8 w-16 h-16 rounded-full blur-md animate-pulse delay-500"
          style={{ backgroundColor: `${config.brandColors.accent}10` }}
        />
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center max-w-md mx-auto px-6">
        {config.type === 'video' && config.videoUrl ? (
          <div className="relative mb-8">
            {!showVideo ? (
              <div className="relative">
                <div 
                  className="w-48 h-48 mx-auto rounded-full bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm border border-white/30 flex items-center justify-center"
                  style={{ 
                    background: `linear-gradient(135deg, ${config.brandColors.primary}40, ${config.brandColors.secondary}40)`
                  }}
                >
                  {config.videoPoster ? (
                    <img
                      src={config.videoPoster}
                      alt="Video Preview"
                      className="w-44 h-44 rounded-full object-cover"
                    />
                  ) : (
                    <Trophy className={`w-24 h-24 text-white ${config.effects.showPulse ? 'animate-pulse' : ''}`} />
                  )}
                  <button
                    onClick={() => setShowVideo(true)}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-colors rounded-full"
                  >
                    <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center hover:bg-white hover:scale-110 transition-all duration-300">
                      <Play className="w-8 h-8 text-slate-900 ml-1" />
                    </div>
                  </button>
                </div>
              </div>
            ) : (
              <div className="w-48 h-48 mx-auto rounded-full overflow-hidden mb-8">
                <video
                  src={config.videoUrl}
                  autoPlay
                  muted
                  loop
                  className="w-full h-full object-cover"
                />
              </div>
            )}
          </div>
        ) : (
          <div className="relative mb-8">
            <div 
              className={`w-48 h-48 mx-auto rounded-full bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm border border-white/30 flex items-center justify-center ${
                config.effects.showPulse ? 'animate-pulse' : ''
              } ${config.effects.showRotation ? 'animate-spin' : ''}`}
              style={{ 
                background: `linear-gradient(135deg, ${config.brandColors.primary}40, ${config.brandColors.secondary}40)`
              }}
            >
              {config.logoUrl ? (
                <img
                  src={config.logoUrl}
                  alt="Logo"
                  className="w-32 h-32 object-contain filter brightness-0 invert"
                  onError={(e) => {
                    e.currentTarget.src = "/Kenya Tourism Awards Black Logo.svg";
                  }}
                />
              ) : (
                <Trophy className="w-24 h-24 text-white" />
              )}
            </div>
          </div>
        )}

        {/* Title */}
        <h1 
          className="text-4xl font-bold mb-4 animate-fade-in-up" 
          style={{ color: config.brandColors.primary }}
        >
          {config.text.title}
        </h1>
        <p className="text-xl text-white/80 mb-8 animate-fade-in-up delay-300">
          {config.text.subtitle}
        </p>

        {/* Progress Bar */}
        <div className="mb-6 animate-fade-in-up delay-500">
          <div className="flex items-center justify-between text-white/60 text-sm mb-2">
            <span>{config.text.loadingText}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-white/20 rounded-full h-2 overflow-hidden">
            <div 
              className="h-full rounded-full transition-all duration-300 shadow-lg relative overflow-hidden"
              style={{ 
                width: `${progress}%`,
                backgroundColor: config.brandColors.primary
              }}
            >
              <div 
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"
              />
            </div>
          </div>
        </div>

        {/* Loading Animation */}
        <div className="flex justify-center space-x-2 animate-fade-in-up delay-700">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-2 h-2 rounded-full animate-bounce"
              style={{ 
                backgroundColor: config.brandColors.primary,
                animationDelay: `${i * 0.2}s`
              }}
            />
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        
        .animate-fade-in-up {
          animation: fadeInUp 0.6s ease-out forwards;
        }
        
        .delay-300 {
          animation-delay: 0.3s;
        }
        
        .delay-500 {
          animation-delay: 0.5s;
        }
        
        .delay-700 {
          animation-delay: 0.7s;
        }
        
        .animate-shimmer {
          animation: shimmer 2s infinite;
        }
      `}</style>
    </div>
  );
};

export default Preloader;