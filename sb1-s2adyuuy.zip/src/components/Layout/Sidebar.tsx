import React from 'react';
import { 
  Home, 
  Award, 
  Users, 
  Vote,
  Calendar,
  Trophy,
  Mail,
  BarChart3,
  FileText,
  UserCheck,
  Ticket,
  Settings,
  HelpCircle,
  Layout,
  MessageSquare,
  Menu,
  User,
  Clock,
  Share2,
  DollarSign,
  CreditCard,
  ArrowLeft,
  Shield
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface SidebarMenuItem {
  id: string;
  label: string;
  icon: React.ComponentType<any>;
  description: string;
  badge?: string;
}

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, onTabChange }) => {
  const { user } = useAuth();

  const getNavigationItems = (): SidebarMenuItem[] => {
    const commonItems: SidebarMenuItem[] = [
      { id: 'dashboard', label: 'Dashboard', icon: Home, description: 'Overview and statistics' },
    ];

    if (user?.role === 'superadmin' || user?.role === 'admin') {
      return [
        ...commonItems,
        { id: 'entries-system', label: 'Entries System', icon: Settings, description: 'Manage entry stages' },
        { id: 'form-templates', label: 'Form Templates', icon: Layout, description: 'Manage entry forms' },
        { id: 'entries', label: 'Entries & Submissions', icon: FileText, description: 'Manage submissions', badge: '247' },
        { id: 'jury-vetting', label: 'Jury Vetting', icon: UserCheck, description: 'Review submissions' },
        { id: 'roles', label: 'Role Management', icon: Shield, description: 'Assign user privileges' },
        { id: 'system-stages', label: 'System Stages', icon: Settings, description: 'Manage process stages' },
        { id: 'voting-management', label: 'Voting System', icon: Vote, description: 'Configure voting settings' },
        { id: 'winners', label: 'Winners', icon: Trophy, description: 'Award winners' },
        { id: 'gala', label: 'Gala Event', icon: Calendar, description: 'Awards ceremony' },
        { id: 'analytics', label: 'Analytics', icon: BarChart3, description: 'Performance insights' },
        { id: 'email', label: 'Communications', icon: Mail, description: 'Email campaigns' },
        { id: 'users', label: 'User Management', icon: Users, description: 'System users' },
        { id: 'content', label: 'Content Management', icon: Layout, description: 'Edit website content' },
        { id: 'payments', label: 'Payment Management', icon: CreditCard, description: 'Configure payments' },
        { id: 'pages', label: 'Page Management', icon: FileText, description: 'Manage website pages' },
        { id: 'navigation', label: 'Navigation', icon: Menu, description: 'Manage site navigation' },
        { id: 'team-directory', label: 'Team Directory', icon: Users, description: 'View team profiles' },
        { id: 'jury-directory', label: 'Jury Panel', icon: UserCheck, description: 'View jury members' },
        { id: 'team-management', label: 'Team Management', icon: Users, description: 'Manage team members' },
        { id: 'team-messages', label: 'Team Messages', icon: Mail, description: 'Internal messaging' },
        { id: 'team-approvals', label: 'Team Approvals', icon: UserCheck, description: 'Approve team members' },
        { id: 'branding', label: 'Branding Settings', icon: Settings, description: 'Customize branding' },
        { id: 'slider-management', label: 'Homepage Slider', icon: Layout, description: 'Manage homepage slider' },
        { id: 'settings', label: 'Settings', icon: Settings, description: 'System settings' },
      ];
    } else if (user?.role === 'jury') {
      return [
        ...commonItems,
        { id: 'jury-vetting', label: 'Evaluations', icon: Award, description: 'Review submissions', badge: '15' },
        { id: 'jury-directory', label: 'Jury Panel', icon: UserCheck, description: 'View jury members' },
        { id: 'team-messages', label: 'Messages', icon: Mail, description: 'Team communication' },
        { id: 'winners', label: 'Winners', icon: Trophy, description: 'View winners' },
      ];
    } else if (user?.role === 'nominee') {
      return [
        ...commonItems,
        { id: 'nominee-profile', label: 'My Profile', icon: User, description: 'Manage nominee profile' },
        { id: 'voting-link', label: 'Voting Link', icon: Share2, description: 'Share voting link' },
        { id: 'performance', label: 'Performance', icon: BarChart3, description: 'View voting analytics' },
        { id: 'entry-portal', label: 'Submit Entry', icon: FileText, description: 'Submit new entry' },
        { id: 'budget', label: 'Campaign Budget', icon: DollarSign, description: 'Manage campaign spending' },
        { id: 'vote-history', label: 'Vote History', icon: Clock, description: 'View voting progress' },
      ];
    } else {
      return [
        ...commonItems,
        { id: 'voting', label: 'Vote Now', icon: Vote, description: 'Cast your votes', badge: '28' },
        { id: 'vote-history', label: 'Vote History', icon: Clock, description: 'Your voting history' },
        { id: 'entry-portal', label: 'Submit Entry', icon: FileText, description: 'Submit an entry' },
        { id: 'team-directory', label: 'Team', icon: Users, description: 'Meet the team' },
        { id: 'winners', label: 'Winners', icon: Trophy, description: 'View winners' },
        { id: 'gala', label: 'Gala Tickets', icon: Ticket, description: 'Book tickets' },
      ];
    }
  };

  const bottomItems: SidebarMenuItem[] = [
    { id: 'help', label: 'Help & Support', icon: HelpCircle, description: 'Get assistance' },
  ];

  const navigationItems = getNavigationItems();

  const MenuItem = ({ item }: { item: SidebarMenuItem }) => {
    const Icon = item.icon;
    const isActive = activeTab === item.id;
    
    return (
      <button
        onClick={() => onTabChange(item.id)}
        className={`w-full group flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 ${
          isActive
            ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg'
            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'
        }`}
        title={item.description}
      >
        <Icon className={`mr-3 h-5 w-5 flex-shrink-0 ${
          isActive ? 'text-white' : 'text-gray-400 group-hover:text-gray-500 dark:group-hover:text-gray-300'
        }`} />
        <span className="flex-1 text-left">{item.label}</span>
        {item.badge && (
          <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
            isActive 
              ? 'bg-white/20 text-white' 
              : 'bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400'
          }`}>
            {item.badge}
          </span>
        )}
      </button>
    );
  };

  return (
    <div className="fixed left-0 top-28 bottom-0 w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 z-30">
      <div className="flex flex-col h-full">
        {/* Navigation */}
        <nav className="flex-1 px-4 pt-6 space-y-2 overflow-y-auto">
          {/* Back to Main Site Button */}
          <button
            onClick={() => window.location.href = '/'}
            className="w-full group flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white border-b border-gray-200 dark:border-gray-700 mb-6"
          >
            <ArrowLeft className="mr-3 h-5 w-5 text-gray-400 group-hover:text-gray-500 dark:group-hover:text-gray-300" />
            <span>Back to Main Site</span>
          </button>
          
          {navigationItems.map((item) => (
            <MenuItem key={item.id} item={item} />
          ))}
        </nav>

        {/* Bottom Section */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
          {bottomItems.map((item) => (
            <MenuItem key={item.id} item={item} />
          ))}
          
          {/* User Info */}
          <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-xl">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-white text-sm font-bold">
                  {user?.name?.charAt(0) || 'U'}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                  {user?.name}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                  {user?.role}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;