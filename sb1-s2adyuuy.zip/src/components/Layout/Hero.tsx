import React, { useState, useEffect } from 'react';
import { Trophy, Award, Star, Calendar, ArrowRight, Sparkles, Play, ChevronLeft, ChevronRight, MapPin, Users, Camera } from 'lucide-react';
import HomepageSlider from '../Slider/HomepageSlider';
import { mockSlides, defaultSliderSettings } from '../../data/sliderData';

const Hero: React.FC = () => {
  const handleSliderEvent = (event: any) => {
    // Track analytics events
    console.log('Slider event:', event);
  };

  return (
    <HomepageSlider 
      slides={mockSlides}
      settings={defaultSliderSettings}
      onEvent={handleSliderEvent}
    />
  );
};

export default Hero;