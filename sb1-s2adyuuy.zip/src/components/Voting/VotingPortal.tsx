import React from 'react';
import EnhancedVotingPortal from './EnhancedVotingPortal';


const VotingPortal: React.FC = () => {
  return <EnhancedVotingPortal />;
};

export default VotingPortal;