import React, { useState, useEffect } from 'react';
import { 
  Vote, Award, Users, Clock, CheckCircle, Star, Shield, 
  Zap, DollarSign, Mail, Phone, MapPin, User, AlertTriangle,
  CreditCard, Smartphone, Lock, Unlock, Eye, EyeOff, Info,
  Send, RefreshCw, BarChart3, Target, Heart, Gift, Ticket
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useVoting } from '../../hooks/useVoting';
import { useSubmissions } from '../../hooks/useSubmissions';
import { usePayments } from '../../hooks/usePayments';
import { VotingSettings, VoteRequest, VotingBundle } from '../../types/voting';
import { categories } from '../../data/categories';
import PaymentModal from '../Payments/PaymentModal';

const EnhancedVotingPortal: React.FC = () => {
  const { user } = useAuth();
  const { submissions, fetchSubmissions } = useSubmissions();
  const { 
    fetchVotingSettings, 
    submitVote, 
    getVoterHistory,
    isLoading: votingLoading,
    error: votingError 
  } = useVoting();

  const [votingSettings, setVotingSettings] = useState<VotingSettings | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [voterInfo, setVoterInfo] = useState({
    email: '',
    phone: '',
    fullName: '',
    county: ''
  });
  const [selectedSubmission, setSelectedSubmission] = useState<string | null>(null);
  const [selectedBundle, setSelectedBundle] = useState<string>('1');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentData, setPaymentData] = useState<any>(null);
  const [voteHistory, setVoteHistory] = useState<any[]>([]);
  const [showVoterForm, setShowVoterForm] = useState(false);
  const [emailVerified, setEmailVerified] = useState(false);
  const [captchaVerified, setCaptchaVerified] = useState(false);

  useEffect(() => {
    loadVotingSettings();
    loadSubmissions();
  }, []);

  useEffect(() => {
    if (user?.email) {
      setVoterInfo(prev => ({ ...prev, email: user.email }));
      loadVoterHistory(user.email);
    }
  }, [user]);

  const loadVotingSettings = async () => {
    const settings = await fetchVotingSettings();
    setVotingSettings(settings);
  };

  const loadSubmissions = async () => {
    await fetchSubmissions({ status: 'shortlisted' });
  };

  const loadVoterHistory = async (email: string) => {
    const history = await getVoterHistory(email);
    setVoteHistory(history);
  };

  const filteredSubmissions = submissions.filter(submission => 
    selectedCategory === 'all' || submission.category === selectedCategory
  );

  const hasVotedForSubmission = (submissionId: string) => {
    return voteHistory.some(vote => vote.submissionId === submissionId && vote.status === 'confirmed');
  };

  const getRemainingVotes = () => {
    if (!votingSettings) return 0;
    const today = new Date().toDateString();
    const todayVotes = voteHistory.filter(vote => 
      vote.voteTime.toDateString() === today && vote.status === 'confirmed'
    ).length;
    return Math.max(0, votingSettings.maxVotesPerEmailPerDay - todayVotes);
  };

  const handleVoteClick = (submission: any) => {
    if (!voterInfo.email) {
      setSelectedSubmission(submission.id);
      setShowVoterForm(true);
      return;
    }

    if (hasVotedForSubmission(submission.id)) {
      alert('You have already voted for this nominee.');
      return;
    }

    if (getRemainingVotes() <= 0) {
      alert('You have reached your daily voting limit.');
      return;
    }

    proceedWithVote(submission);
  };

  const proceedWithVote = async (submission: any) => {
    if (!votingSettings) return;

    const bundle = Object.entries(votingSettings.bundleOptions)[parseInt(selectedBundle) - 1];
    if (!bundle) return;

    const [bundleId, bundleData] = bundle;
    const voteRequest: VoteRequest = {
      voterEmail: voterInfo.email,
      voterPhone: voterInfo.phone,
      voterName: voterInfo.fullName,
      voterCounty: voterInfo.county,
      submissionId: submission.id,
      category: submission.category,
      bundleId,
      voteCount: bundleData.votes,
      captchaToken: captchaVerified ? 'verified' : undefined
    };

    if (votingSettings.votingMode === 'free') {
      // Free voting
      const result = await submitVote(voteRequest);
      
      if (result.success) {
        alert('Vote submitted successfully! Check your email for confirmation.');
        setSelectedSubmission(null);
        setShowVoterForm(false);
        loadVoterHistory(voterInfo.email);
        loadSubmissions(); // Refresh to update vote counts
      } else {
        alert(result.error || 'Failed to submit vote');
      }
    } else {
      // Paid voting - show payment modal
      const bundleData = votingSettings.bundleOptions[bundleId as keyof typeof votingSettings.bundleOptions];
      setPaymentData({
        amount: bundleData.price,
        orderId: `vote_${submission.id}_${Date.now()}`,
        orderDetails: {
          description: `${bundleData.votes} vote${bundleData.votes > 1 ? 's' : ''} for ${submission.nomineeName}`,
          items: [{
            name: bundleData.label,
            quantity: 1,
            price: bundleData.price
          }]
        },
        voteRequest
      });
      setShowPaymentModal(true);
    }
  };

  const handlePaymentSuccess = async (paymentResult: any) => {
    // Confirm the vote after successful payment
    const result = await submitVote({
      ...paymentData.voteRequest,
      paymentReference: paymentResult.reference
    });

    if (result.success) {
      alert('Payment successful! Your vote has been confirmed.');
      setShowPaymentModal(false);
      setSelectedSubmission(null);
      setShowVoterForm(false);
      loadVoterHistory(voterInfo.email);
      loadSubmissions();
    } else {
      alert('Payment successful but vote submission failed. Please contact support.');
    }
  };

  const VoterFormModal = () => {
    const selectedSub = submissions.find(s => s.id === selectedSubmission);
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                  Vote for {selectedSub?.nomineeName}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">{selectedSub?.category}</p>
              </div>
              <button
                onClick={() => setShowVoterForm(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                ×
              </button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Voting Mode Info */}
            {votingSettings && (
              <div className={`rounded-lg p-4 ${
                votingSettings.votingMode === 'free'
                  ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
                  : 'bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800'
              }`}>
                <div className="flex items-center space-x-3">
                  {votingSettings.votingMode === 'free' ? (
                    <Heart className="w-5 h-5 text-green-600 dark:text-green-400" />
                  ) : (
                    <DollarSign className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                  )}
                  <div>
                    <h4 className={`font-semibold ${
                      votingSettings.votingMode === 'free'
                        ? 'text-green-900 dark:text-green-400'
                        : 'text-amber-900 dark:text-amber-400'
                    }`}>
                      {votingSettings.votingMode === 'free' ? 'Free Voting Active' : 'Paid Voting Active'}
                    </h4>
                    <p className={`text-sm ${
                      votingSettings.votingMode === 'free'
                        ? 'text-green-700 dark:text-green-500'
                        : 'text-amber-700 dark:text-amber-500'
                    }`}>
                      {votingSettings.votingMode === 'free'
                        ? 'Cast your vote at no cost'
                        : `Each vote costs KSh ${votingSettings.feePerVote}`
                      }
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Voter Information Form */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="email"
                    value={voterInfo.email}
                    onChange={(e) => setVoterInfo(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="your@email.com"
                    required
                    readOnly={!!user?.email}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="tel"
                    value={voterInfo.phone}
                    onChange={(e) => setVoterInfo(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="+254712345678"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    value={voterInfo.fullName}
                    onChange={(e) => setVoterInfo(prev => ({ ...prev, fullName: e.target.value }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Your full name"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  County
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <select
                    value={voterInfo.county}
                    onChange={(e) => setVoterInfo(prev => ({ ...prev, county: e.target.value }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="">Select your county</option>
                    <option value="nairobi">Nairobi</option>
                    <option value="mombasa">Mombasa</option>
                    <option value="kisumu">Kisumu</option>
                    <option value="nakuru">Nakuru</option>
                    {/* Add all 47 counties */}
                  </select>
                </div>
              </div>
            </div>

            {/* Bundle Selection for Paid Voting */}
            {votingSettings?.votingMode === 'paid' && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-4">Select Vote Bundle</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {Object.entries(votingSettings.bundleOptions).map(([bundleId, bundle]) => (
                    <label key={bundleId} className="cursor-pointer">
                      <input
                        type="radio"
                        name="bundle"
                        value={bundleId}
                        checked={selectedBundle === bundleId}
                        onChange={(e) => setSelectedBundle(e.target.value)}
                        className="sr-only"
                      />
                      <div className={`border-2 rounded-xl p-4 transition-all ${
                        selectedBundle === bundleId
                          ? 'border-amber-500 bg-amber-50 dark:bg-amber-900/20'
                          : 'border-gray-300 dark:border-gray-600 hover:border-amber-300'
                      }`}>
                        <div className="text-center">
                          <h5 className="font-bold text-gray-900 dark:text-white">{bundle.label}</h5>
                          <div className="text-2xl font-bold text-amber-600 dark:text-amber-400 my-2">
                            KSh {bundle.price}
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {bundle.votes} vote{bundle.votes > 1 ? 's' : ''}
                          </p>
                          {bundle.savings && (
                            <div className="text-xs text-green-600 dark:text-green-400 mt-1">
                              Save KSh {bundle.savings}
                            </div>
                          )}
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Security & Verification Info */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <Shield className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900 dark:text-blue-400 mb-2">Secure Voting</h4>
                  <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
                    <li>• One vote per email per category</li>
                    <li>• Email confirmation sent after each vote</li>
                    <li>• Anti-fraud protection enabled</li>
                    <li>• Nominees cannot vote for themselves</li>
                    {votingSettings?.emailConfirmationEnabled && <li>• Email verification required</li>}
                  </ul>
                </div>
              </div>
            </div>

            {/* Vote Limits Info */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Daily Vote Limit
                </span>
                <span className="text-sm text-gray-900 dark:text-white">
                  {voteHistory.filter(v => v.voteTime.toDateString() === new Date().toDateString()).length}/
                  {votingSettings?.maxVotesPerEmailPerDay || 1}
                </span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2 mt-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-indigo-500 h-2 rounded-full transition-all"
                  style={{ 
                    width: `${Math.min(100, (voteHistory.filter(v => 
                      v.voteTime.toDateString() === new Date().toDateString()
                    ).length / (votingSettings?.maxVotesPerEmailPerDay || 1)) * 100)}%` 
                  }}
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowVoterForm(false)}
                className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => selectedSubmission && proceedWithVote(submissions.find(s => s.id === selectedSubmission))}
                disabled={!voterInfo.email || (!captchaVerified && votingSettings?.enableCaptcha)}
                className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-3 rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
              >
                {votingSettings?.votingMode === 'paid' ? (
                  <>
                    <CreditCard className="w-4 h-4" />
                    <span>Proceed to Payment</span>
                  </>
                ) : (
                  <>
                    <Vote className="w-4 h-4" />
                    <span>Submit Vote</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (!votingSettings) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading voting portal...</p>
        </div>
      </div>
    );
  }

  if (!votingSettings.isVotingOpen) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <Lock className="w-16 h-16 text-gray-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Voting is Closed</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            The voting period has ended. Thank you for your participation!
          </p>
          <a
            href="/winners"
            className="inline-block bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-lg font-medium hover:from-amber-600 hover:to-orange-600 transition-colors"
          >
            View Results
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 space-y-4 sm:space-y-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header */}
      <div className={`rounded-2xl p-8 text-white ${
        votingSettings.votingMode === 'free'
          ? 'bg-gradient-to-r from-green-500 to-emerald-600'
          : 'bg-gradient-to-r from-amber-500 to-orange-600'
      }`}>
        <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold mb-2 text-center sm:text-left">
              {votingSettings.votingMode === 'free' ? 'Free Voting Portal' : 'Enhanced Voting Portal'}
            </h2>
            <p className={`text-lg ${
              votingSettings.votingMode === 'free' ? 'text-green-100' : 'text-amber-100'
            } text-center sm:text-left`}>
              {votingSettings.votingMode === 'free'
                ? 'Cast your votes for free and help recognize excellence'
                : `Support your favorites with KSh ${votingSettings.feePerVote} per vote`
              }
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start space-y-2 sm:space-y-0 sm:space-x-4 mt-4 text-sm">
              {votingSettings.votingDeadline && (
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>Ends: {votingSettings.votingDeadline.toLocaleDateString()}</span>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <Target className="w-4 h-4" />
                <span>Daily Limit: {votingSettings.maxVotesPerEmailPerDay}</span>
              </div>
            </div>
          </div>
          <div className="hidden sm:block">
            {votingSettings.votingMode === 'free' ? (
              <Heart className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 text-green-200" />
            ) : (
              <Ticket className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 text-amber-200" />
            )}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 lg:gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs sm:text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Available Categories</p>
              <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white">28</p>
            </div>
            <Award className="w-6 h-6 sm:w-8 sm:h-8 text-amber-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Your Votes Today</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {voteHistory.filter(v => v.voteTime.toDateString() === new Date().toDateString()).length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Remaining Votes</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{getRemainingVotes()}</p>
            </div>
            <Target className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Total Participants</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">1,842</p>
            </div>
            <Users className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Security Notice */}
      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 sm:p-6 border border-blue-200 dark:border-blue-800">
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <Shield className="w-6 h-6 text-blue-600 dark:text-blue-400" />
          <div>
            <h3 className="text-base sm:text-lg font-semibold text-blue-900 dark:text-blue-400">Secure & Fair Voting System</h3>
            <p className="text-sm text-blue-800 dark:text-blue-300 mb-3 sm:mb-0">
              Your votes are encrypted, tracked, and verified. Advanced fraud detection prevents cheating and ensures fair results.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 sm:gap-6 text-xs sm:text-sm text-blue-700 dark:text-blue-400 w-full sm:w-auto">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4" />
              <span>Real-time counting</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Fraud protection</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4" />
              <span>Email confirmation</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 flex-shrink-0">
            Filter by Category:
          </label>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full sm:w-auto border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-amber-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="all">All Categories</option>
            {Array.from(new Set(submissions.map(s => s.category))).map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
          <div className="text-sm text-gray-600 dark:text-gray-400 self-center">
            Showing {filteredSubmissions.length} nominees
          </div>
        </div>
      </div>

      {/* Nominees Grid */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 sm:p-6">
        <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white mb-4 sm:mb-6">Vote for Your Favorites</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
          {filteredSubmissions.map((submission) => {
            const hasVoted = hasVotedForSubmission(submission.id);
            const isNominee = user?.email === submission.submitterEmail || user?.email === submission.contactEmail;
            
            return (
              <div 
                key={submission.id} 
                className={`border rounded-lg sm:rounded-xl overflow-hidden transition-shadow ${
                  hasVoted 
                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20' 
                    : isNominee && !votingSettings.allowNomineeVoting
                    ? 'border-gray-300 dark:border-gray-600 opacity-50'
                    : 'border-gray-200 dark:border-gray-700 hover:shadow-lg'
                }`}
              >
                <div className="relative">
                  <div className="w-full h-32 sm:h-40 lg:h-48 bg-gradient-to-r from-gray-300 to-gray-400 flex items-center justify-center">
                    <Award className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-gray-600" />
                  </div>
                  
                  {hasVoted && (
                    <div className="absolute top-2 sm:top-4 right-2 sm:right-4 bg-green-500 text-white p-1.5 sm:p-2 rounded-full">
                      <CheckCircle className="w-4 h-4" />
                    </div>
                  )}
                  
                  {isNominee && !votingSettings.allowNomineeVoting && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="bg-red-500 text-white px-3 py-2 rounded-lg text-xs sm:text-sm font-medium">
                        Self-voting not allowed
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="p-4 sm:p-6">
                  <div className="mb-4">
                    <h4 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-white mb-1 line-clamp-2">
                      {submission.nomineeName}
                    </h4>
                    {submission.organizationName && (
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                        {submission.organizationName}
                      </p>
                    )}
                    <div className="flex items-center space-x-2 text-xs sm:text-sm text-amber-600 dark:text-amber-400 mb-1">
                      <Award className="w-4 h-4" />
                      <span className="line-clamp-1">{submission.category}</span>
                    </div>
                    {submission.county && (
                      <div className="flex items-center space-x-2 text-xs sm:text-sm text-gray-500 dark:text-gray-500">
                        <MapPin className="w-4 h-4" />
                        <span>{submission.county}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 sm:w-4 sm:h-4 text-amber-400 fill-current" />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {submission.publicVotes} votes
                    </span>
                  </div>
                  
                  <button
                    onClick={() => handleVoteClick(submission)}
                    disabled={hasVoted || (isNominee && !votingSettings.allowNomineeVoting) || getRemainingVotes() <= 0}
                    className={`w-full py-2.5 sm:py-3 px-3 sm:px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2 text-sm sm:text-base ${
                      hasVoted
                        ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400 cursor-not-allowed'
                        : (isNominee && !votingSettings.allowNomineeVoting) || getRemainingVotes() <= 0
                        ? 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                        : votingSettings.votingMode === 'paid'
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600'
                        : 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white hover:from-blue-600 hover:to-indigo-600'
                    }`}
                  >
                    {hasVoted ? (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        <span>Voted</span>
                      </>
                    ) : (isNominee && !votingSettings.allowNomineeVoting) ? (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>Not Allowed</span>
                      </>
                    ) : getRemainingVotes() <= 0 ? (
                      <>
                        <AlertTriangle className="w-4 h-4" />
                        <span>Limit Reached</span>
                      </>
                    ) : votingSettings.votingMode === 'paid' ? (
                      <>
                        <DollarSign className="w-4 h-4" />
                        <span>Vote (KSh {votingSettings.feePerVote})</span>
                      </>
                    ) : (
                      <>
                        <Vote className="w-4 h-4" />
                        <span>Vote Now</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {filteredSubmissions.length === 0 && (
          <div className="text-center py-12">
            <Vote className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-base sm:text-lg font-medium text-gray-900 dark:text-white mb-2">No nominees found</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Try selecting a different category or check back later.
            </p>
          </div>
        )}
      </div>

      {showVoterForm && <VoterFormModal />}
      
      {showPaymentModal && paymentData && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          amount={paymentData.amount}
          orderId={paymentData.orderId}
          orderDetails={paymentData.orderDetails}
          onPaymentSuccess={handlePaymentSuccess}
          onPaymentError={(error) => {
            console.error('Payment failed:', error);
            setShowPaymentModal(false);
          }}
        />
      )}
    </div>
  );
};

export default EnhancedVotingPortal;