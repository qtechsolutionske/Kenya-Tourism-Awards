import React from 'react';
import { useState, useEffect } from 'react';
import { AuthContext, useAuthState } from './hooks/useAuth';
import { useAnimateOnScroll, useSectionTitleAnimation } from './hooks/useAnimateOnScroll';
import { ThemeProvider } from './contexts/ThemeContext';
import LoginForm from './components/Auth/LoginForm';
import SignupForm from './components/Auth/SignupForm';
import Header from './components/Layout/Header';
import Sidebar from './components/Layout/Sidebar';
import Hero from './components/Layout/Hero';
import PublicHomepage from './components/Public/PublicHomepage';
import PublicAbout from './components/Public/PublicAbout';
import PublicNominees from './components/Public/PublicNominees';
import PublicGallery from './components/Public/PublicGallery';
import PublicContact from './components/Public/PublicContact';
import PublicGala from './components/Public/PublicGala';
import PublicWinners from './components/Public/PublicWinners';
import PublicTeam from './components/Public/PublicTeam';
import TeamApprovalManager from './components/Admin/TeamApprovalManager';
import Footer from './components/Layout/Footer';
import Dashboard from './components/Dashboard/Dashboard';
import EntriesSystemManager from './components/Admin/EntriesSystemManager';
import FormTemplateManager from './components/Entries/FormTemplateManager';
import EntryPortal from './components/Entries/EntryPortal';
import JuryVettingPortal from './components/Entries/JuryVettingPortal';
import JuryPortal from './components/Jury/JuryPortal';
import VotingPortal from './components/Voting/VotingPortal';
import GalaEvent from './components/Gala/GalaEvent';
import WinnersSpotlight from './components/Winners/WinnersSpotlight';
import EmailMarketing from './components/Email/EmailMarketing';
import UserManagement from './components/Admin/UserManagement';
import Analytics from './components/Analytics/Analytics';
import SliderManagement from './components/Admin/SliderManagement';
import VotingManagement from './components/Admin/VotingManagement';
import NotificationPanel from './components/Notifications/NotificationPanel';
import ContentManagement from './components/Admin/ContentManagement';
import EntriesManagement from './components/Entries/EntriesManagement';
import FormBuilder from './components/Entries/FormBuilder';
import RoleManagement from './components/Admin/RoleManagement';
import SystemStageManager from './components/Admin/SystemStageManager';
import TeamDirectory from './components/Team/TeamDirectory';
import TeamProfile from './components/Team/TeamProfile';
import TeamManagement from './components/Team/TeamManagement';
import TeamMessaging from './components/Team/TeamMessaging';
import BrandingSettings from './components/Admin/BrandingSettings';
import Preloader from './components/Layout/Preloader';
import VoteHistory from './components/Voting/VoteHistory'; 
import NomineeDashboard from './components/Nominees/NomineeDashboard';
import PaymentManagement from './components/Admin/PaymentManagement';
import PageManagement from './components/Pages/PageManagement';
import NavigationManagement from './components/Pages/NavigationManagement';
import PublicSponsors from './components/Public/PublicSponsors';
import DynamicPageRenderer from './components/Pages/DynamicPageRenderer';

// Role constants
const ROLES = {
  SUPERADMIN: 'superadmin',
  ADMIN: 'admin',
  JURY: 'jury',
  VOTER: 'voter',
  NOMINEE: 'nominee'
} as const;

function App() {
  const authState = useAuthState();
  useAnimateOnScroll(); // Initialize scroll animations
  useSectionTitleAnimation(); // Apply animations to all section titles
  const [activeTab, setActiveTab] = useState('home');
  const [selectedTeamMember, setSelectedTeamMember] = useState(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [publicRoute, setPublicRoute] = useState('home');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showPreloader, setShowPreloader] = useState(true);
  const [preloaderCompleted, setPreloaderCompleted] = useState(false);

  const handlePreloaderComplete = () => {
    setShowPreloader(false);
    setPreloaderCompleted(true);
  };

  // Role-based dashboard redirect
  const getDashboardRoute = (role: string) => {
    switch (role) {
      case ROLES.SUPERADMIN:
      case ROLES.ADMIN:
        return 'dashboard';
      case ROLES.JURY:
        return 'jury';
      case ROLES.VOTER:
      case ROLES.NOMINEE:
        return 'voting';
      default:
        return 'dashboard';
    }
  };

  // Redirect to appropriate dashboard after login
  useEffect(() => {
    if (authState.user && activeTab === 'home') {
      const dashboardRoute = getDashboardRoute(authState.user.role);
      setActiveTab(dashboardRoute);
    }
  }, [authState.user]);

  if (authState.isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-amber-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="relative mb-8">
            <div className="w-24 h-24 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mx-auto"></div>
            <div className="absolute inset-0 w-24 h-24 border-4 border-transparent border-t-amber-300 rounded-full animate-spin mx-auto" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-4">Kenya Tourism Awards</h2>
          <p className="text-amber-200 text-lg">Celebrating Excellence in Tourism</p>
        </div>
      </div>
    );
  }

  // Public routes - accessible without login
  const renderPublicContent = () => {
    switch (publicRoute) {
      case 'about':
        return <PublicAbout />;
      case 'nominees':
        return <PublicNominees />;
      case 'team':
        return <PublicTeam />;
      case 'gallery':
        return <PublicGallery />;
      case 'contact':
        return <PublicContact />;
      case 'gala':
        return <PublicGala />;
      case 'winners':
        return <PublicWinners />;
      case 'sponsors':
        return <PublicSponsors />;
      default:
        return <PublicHomepage />;
    }
  };

  // Protected routes - require login
  const renderProtectedContent = () => {
    switch (activeTab) {
      case 'entries-system':
        return <EntriesSystemManager />;
      case 'form-templates':
        return <FormTemplateManager />;
      case 'entries':
        return <EntriesManagement />;
      case 'jury-vetting':
        return <JuryVettingPortal />;
      case 'roles':
        return <RoleManagement />;
      case 'stages':
        return <SystemStageManager />;
      case 'jury':
        return <JuryPortal />;
      case 'voting':
        return <VotingPortal />;
      case 'gala':
        return <GalaEvent />;
      case 'winners':
        return <WinnersSpotlight />;
      case 'email':
        return <EmailMarketing />;
      case 'users':
        return <UserManagement />;
      case 'analytics':
        return <Analytics />;
      case 'content':
        return <ContentManagement />;
      case 'team-directory':
        return selectedTeamMember ? (
          <TeamProfile 
            member={selectedTeamMember}
            onBack={() => setSelectedTeamMember(null)}
          />
        ) : (
          <TeamDirectory onMemberSelect={setSelectedTeamMember} />
        );
      case 'jury-directory':
        return selectedTeamMember ? (
          <TeamProfile 
            member={selectedTeamMember}
            onBack={() => setSelectedTeamMember(null)}
          />
        ) : (
          <TeamDirectory onMemberSelect={setSelectedTeamMember} viewMode="jury" />
        );
      case 'team-management':
        return <TeamManagement />;
      case 'team-messages':
        return <TeamMessaging />;
      case 'team-approvals':
        return <TeamApprovalManager />;
      case 'branding':
        return <BrandingSettings />;
      case 'slider-management':
        return <SliderManagement />;
      case 'vote-history':
        return <VoteHistory />;
      case 'payments':
        return <PaymentManagement />;
      case 'system-stages':
        return <SystemStageManager />;
      case 'voting-management':
        return <VotingManagement />;
      case 'pages':
        return <PageManagement />;
      case 'navigation':
        return <NavigationManagement />;
      case 'nominee-profile':
      case 'voting-link':
        case 'entry-portal':
        return <EntryPortal />;
      case 'performance':
      case 'budget':
        return <NomineeDashboard />;
      default:
        return <Dashboard />;
    }
  };

  // Show auth forms if user is trying to access protected routes
  if (!authState.user && (showAuthModal || (activeTab !== 'home' && !['about', 'nominees', 'gallery', 'contact'].includes(activeTab)))) {
    return (
      <AuthContext.Provider value={authState}>
        <ThemeProvider>
          <div className="min-h-screen bg-gradient-to-br from-slate-900 via-amber-900 to-slate-900">
            {authMode === 'login' ? (
              <LoginForm 
                onSwitchToSignup={() => setAuthMode('signup')} 
                onClose={() => setShowAuthModal(false)}
              />
            ) : (
              <SignupForm 
                onSwitchToLogin={() => setAuthMode('login')}
                onClose={() => setShowAuthModal(false)}
              />
            )}
          </div>
        </ThemeProvider>
      </AuthContext.Provider>
    );
  }

  return (
    <>
      {showPreloader && !preloaderCompleted && (
        <Preloader onComplete={handlePreloaderComplete} />
      )}

    <AuthContext.Provider value={authState}>
      <ThemeProvider>
        <div className={`min-h-screen bg-gray-50 dark:bg-slate-900 transition-opacity duration-500 ${showPreloader ? 'opacity-0' : 'opacity-100'}`}>
          {/* Public Header - always visible */}
          <Header 
            onNotificationClick={() => setShowNotifications(true)}
            notificationCount={authState.user ? 2 : 0}
            onAuthClick={() => {
              setAuthMode('login');
              setShowAuthModal(true);
            }}
            onSignupClick={() => {
              setAuthMode('signup');
              setShowAuthModal(true);
            }}
            onPublicRouteChange={setPublicRoute}
            currentPublicRoute={publicRoute}
            isLoggedIn={!!authState.user}
          />

          {authState.user ? (
            // Logged in users - show dashboard with sidebar
            <div className="flex">
              <Sidebar 
                activeTab={activeTab}
                onTabChange={setActiveTab}
              />
              <div className="flex-1 ml-64 overflow-x-hidden">
                <main className="pt-16 md:pt-20 lg:pt-24">
                  {renderProtectedContent()}
                </main>
              </div>
            </div>
          ) : (
            // Public users - show public content
            <div>
              <main className={publicRoute === 'home' ? '' : 'pt-16 md:pt-20'}>
                {publicRoute === 'home' && <Hero />}
                {publicRoute === 'entries' && <EntryPortal />}
                {renderPublicContent()}
                {publicRoute !== 'entries' && <Footer />}
              </main>
            </div>
          )}

          {authState.user && (
            <NotificationPanel 
              isOpen={showNotifications}
              onClose={() => setShowNotifications(false)}
            />
          )}
        </div>
      </ThemeProvider>
    </AuthContext.Provider>
    </>
  );
}

export default App;