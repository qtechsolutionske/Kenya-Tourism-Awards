export interface Voter {
  id: string;
  email: string;
  phone?: string;
  fullName?: string;
  county?: string;
  emailVerified: boolean;
  phoneVerified: boolean;
  verificationToken?: string;
  verificationExpiresAt?: Date;
  isBlocked: boolean;
  blockReason?: string;
  totalVotesCast: number;
  totalAmountPaid: number;
  lastVoteAt?: Date;
  ipAddresses: string[];
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface Vote {
  id: string;
  voterId?: string;
  submissionId: string;
  category: string;
  voteTime: Date;
  isPaid: boolean;
  paymentId?: string;
  paymentReference?: string;
  amountPaid: number;
  voteWeight: number;
  ipAddress?: string;
  userAgent?: string;
  status: 'pending' | 'confirmed' | 'rejected' | 'refunded';
  fraudScore: number;
  verificationMethod?: string;
  referralCode?: string;
  metadata: Record<string, any>;
  createdAt: Date;
}

export interface VotingSettings {
  id: number;
  votingMode: 'free' | 'paid' | 'mixed';
  isVotingOpen: boolean;
  feePerVote: number;
  bundleOptions: Record<string, {
    votes: number;
    price: number;
    label: string;
    savings?: number;
  }>;
  maxVotesPerEmailPerDay: number;
  maxVotesPerIpPerDay: number;
  allowNomineeVoting: boolean;
  requireEmailVerification: boolean;
  requirePhoneVerification: boolean;
  enableOtpVerification: boolean;
  enableCaptcha: boolean;
  blockedEmailDomains: string[];
  fraudDetectionEnabled: boolean;
  fraudThresholdScore: number;
  emailConfirmationEnabled: boolean;
  emailTemplateId?: string;
  rateLimitWindowMinutes: number;
  referralEnabled: boolean;
  referralBonusVotes: number;
  auditLoggingEnabled: boolean;
  publicLeaderboardEnabled: boolean;
  anonymousVotingEnabled: boolean;
  votingDeadline?: Date;
  updatedBy?: string;
  updatedAt: Date;
}

export interface VoteConfirmation {
  id: string;
  voteId: string;
  voterEmail: string;
  confirmationToken: string;
  emailSentAt?: Date;
  emailOpenedAt?: Date;
  emailClickedAt?: Date;
  status: 'pending' | 'sent' | 'delivered' | 'opened' | 'clicked' | 'failed';
  templateUsed?: string;
  metadata: Record<string, any>;
  createdAt: Date;
}

export interface VoteFraudLog {
  id: string;
  voteId: string;
  voterEmail: string;
  fraudType: 'duplicate_email' | 'duplicate_ip' | 'suspicious_pattern' | 'blocked_domain' | 
            'nominee_self_vote' | 'rate_limit_exceeded' | 'suspicious_payment' | 
            'bot_detection' | 'geo_anomaly';
  fraudScore: number;
  detectionReason: string;
  ipAddress?: string;
  userAgent?: string;
  actionTaken: string;
  metadata: Record<string, any>;
  detectedAt: Date;
}

export interface VotingBundle {
  id: string;
  votes: number;
  price: number;
  label: string;
  savings?: number;
  description?: string;
}

export interface VoteRequest {
  voterEmail: string;
  voterPhone?: string;
  voterName?: string;
  voterCounty?: string;
  submissionId: string;
  category: string;
  bundleId?: string;
  voteCount?: number;
  referralCode?: string;
  captchaToken?: string;
}

export interface VoteResponse {
  success: boolean;
  data?: {
    voteId: string;
    confirmationToken: string;
    requiresPayment: boolean;
    paymentUrl?: string;
    message: string;
  };
  error?: string;
}

export interface VotingAnalytics {
  totalVotes: number;
  paidVotes: number;
  freeVotes: number;
  totalRevenue: number;
  uniqueVoters: number;
  votingsByCategory: Record<string, number>;
  votingsByHour: Record<string, number>;
  fraudAttempts: number;
  blockedVotes: number;
  conversionRate: number;
  averageVotesPerUser: number;
}

export const FRAUD_TYPES = {
  DUPLICATE_EMAIL: 'duplicate_email',
  DUPLICATE_IP: 'duplicate_ip',
  SUSPICIOUS_PATTERN: 'suspicious_pattern',
  BLOCKED_DOMAIN: 'blocked_domain',
  NOMINEE_SELF_VOTE: 'nominee_self_vote',
  RATE_LIMIT_EXCEEDED: 'rate_limit_exceeded',
  SUSPICIOUS_PAYMENT: 'suspicious_payment',
  BOT_DETECTION: 'bot_detection',
  GEO_ANOMALY: 'geo_anomaly'
} as const;

export const VOTING_MODES = {
  FREE: 'free',
  PAID: 'paid',
  MIXED: 'mixed'
} as const;

export const VOTE_STATUS = {
  PENDING: 'pending',
  CONFIRMED: 'confirmed',
  REJECTED: 'rejected',
  REFUNDED: 'refunded'
} as const;