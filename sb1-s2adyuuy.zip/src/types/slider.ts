export interface SliderSettings {
  autoplay: {
    enabled: boolean;
    interval: number;
    pauseOnHover: boolean;
    pauseOnFocus: boolean;
    disableOnMobile: boolean;
    resumeOnLeave: boolean;
  };
  navigation: {
    arrows: boolean;
    arrowsStyle: 'default' | 'minimal' | 'rounded' | 'square';
    arrowsPosition: 'inside' | 'outside';
    bullets: boolean;
    bulletsStyle: 'dots' | 'lines' | 'numbers' | 'progress';
    bulletsPosition: 'bottom' | 'top';
    pausePlay: boolean;
    progressBar: boolean;
  };
  interaction: {
    loop: boolean;
    swipeEnabled: boolean;
    dragEnabled: boolean;
    keyboardEnabled: boolean;
    touchThreshold: number;
  };
  transitions: {
    type: 'fade' | 'slide' | 'swipe' | 'coverflow' | 'cube' | 'parallax';
    duration: number;
    easing: string;
    respectReducedMotion: boolean;
  };
  layout: {
    heightMode: 'fixed' | 'responsive' | 'intrinsic';
    aspectRatio?: string;
    maxHeight?: number;
    adaptiveHeight: boolean;
  };
  performance: {
    lazyLoading: boolean;
    preloadAdjacent: boolean;
    reducedDataMode: boolean;
    maxConcurrentLoads: number;
  };
  accessibility: {
    announceSlides: boolean;
    focusTrapping: boolean;
    ariaLabels: {
      slider: string;
      nextButton: string;
      prevButton: string;
      pauseButton: string;
      playButton: string;
      slide: string;
    };
  };
}

export interface SlideContent {
  headline: string;
  subhead?: string;
  body?: string;
  primaryCTA?: {
    label: string;
    url: string;
    target: '_self' | '_blank';
    rel?: string;
    eventKey?: string;
  };
  secondaryCTA?: {
    label: string;
    url: string;
    target: '_self' | '_blank';
  };
  textAlignment: 'left' | 'center' | 'right';
  overlay: {
    type: 'auto' | 'manual';
    color?: string;
    opacity?: number;
  };
}

export interface SlideMedia {
  type: 'image' | 'video' | 'lottie';
  
  // Image fields
  src?: string;
  srcSet?: string;
  sizes?: string;
  alt?: string;
  focalPoint?: { x: number; y: number };
  variants?: {
    mobile: string;
    tablet: string;
    desktop: string;
  };
  
  // Video fields
  videoSrc?: string;
  poster?: string;
  muted?: boolean;
  loop?: boolean;
  controls?: boolean;
  playsinline?: boolean;
  
  // Lottie fields
  lottieData?: string;
  lottieSpeed?: number;
  lottieLoop?: boolean;
  lottieAutoplay?: boolean;
}

export interface SlideTargeting {
  devices: ('mobile' | 'tablet' | 'desktop')[];
  locales?: string[];
  campaigns?: string[];
  userSegments?: string[];
  geoRegions?: string[];
}

export interface SlideSchedule {
  startAt?: Date;
  endAt?: Date;
  timezone: string;
}

export interface Slide {
  id: string;
  sliderId: string;
  type: 'hero' | 'video' | 'split' | 'testimonial' | 'countdown' | 'lottie' | 'map' | 'cards';
  title: string;
  content: SlideContent;
  media: SlideMedia;
  effects?: {
    transition?: string;
    duration?: number;
    kenBurns?: boolean;
    parallax?: number;
  };
  targeting: SlideTargeting;
  schedule: SlideSchedule;
  priority: number;
  status: 'draft' | 'review' | 'scheduled' | 'published' | 'archived';
  version: number;
  analytics?: {
    conversionGoal?: string;
    eventKeys?: string[];
  };
  accessibility: {
    altText?: string;
    ariaLabel?: string;
    skipToContent?: boolean;
  };
  createdBy: string;
  updatedBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Slider {
  id: string;
  name: string;
  slug: string;
  pageBinding: string[];
  settings: SliderSettings;
  status: 'active' | 'archived';
  createdBy: string;
  updatedBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface SliderExperiment {
  id: string;
  sliderId: string;
  name: string;
  variants: {
    [key: string]: {
      slideIds: string[];
      name: string;
    };
  };
  trafficSplit: { [key: string]: number };
  metric: 'click' | 'cta' | 'conversion' | 'dwell_time';
  status: 'draft' | 'running' | 'paused' | 'completed';
  startedAt?: Date;
  endedAt?: Date;
  results?: {
    [key: string]: {
      impressions: number;
      conversions: number;
      conversionRate: number;
      significance?: number;
    };
  };
}

export interface SliderEvent {
  id: string;
  sliderId: string;
  slideId?: string;
  sessionId: string;
  event: 'impression' | 'view' | 'next' | 'prev' | 'bullet' | 'pause' | 'play' | 'cta_click' | 'exit';
  meta: {
    device?: string;
    variant?: string;
    position?: number;
    dwellTimeMs?: number;
    userAgent?: string;
  };
  occurredAt: Date;
}