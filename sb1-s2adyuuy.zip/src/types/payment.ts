export interface PaymentMethod {
  id: string;
  method: 'mpesa' | 'paystack';
  displayName: string;
  description: string;
  iconUrl?: string;
  isEnabled: boolean;
  isLive: boolean;
  config: Record<string, any>;
  fees: PaymentFees;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentFees {
  transactionFee: number; // Fixed fee in currency units
  percentageFee: number; // Percentage fee (e.g., 1.5 for 1.5%)
}

export interface Payment {
  id: string;
  userId?: string;
  orderId: string;
  method: 'mpesa' | 'paystack';
  reference: string;
  amount: number;
  currency: string;
  status: 'pending' | 'success' | 'failed' | 'refunded';
  phoneNumber?: string;
  email?: string;
  metadata: Record<string, any>;
  callbackData?: Record<string, any>;
  verifiedAt?: Date;
  failedReason?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface GalaTicket {
  id: string;
  paymentId?: string;
  ticketType: 'standard' | 'vip' | 'vvip' | 'corporate';
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  buyerName: string;
  buyerEmail: string;
  buyerPhone: string;
  organization?: string;
  specialRequirements?: string;
  qrCode?: string;
  ticketStatus: 'pending' | 'confirmed' | 'cancelled';
  eventDate: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentLog {
  id: string;
  paymentId: string;
  eventType: string;
  eventData: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

export interface MPESASTKResponse {
  success: boolean;
  data?: {
    checkoutRequestId: string;
    merchantRequestId: string;
    paymentId: string;
    message: string;
  };
  error?: string;
}

export interface PaystackInitResponse {
  success: boolean;
  data?: {
    authorizationUrl: string;
    accessCode: string;
    reference: string;
    paymentId: string;
    publicKey: string;
  };
  error?: string;
}

export interface PaymentStatusResponse {
  success: boolean;
  data?: {
    status: Payment['status'];
    amount: number;
    currency: string;
    reference: string;
    verifiedAt?: string;
    failedReason?: string;
  };
  error?: string;
}