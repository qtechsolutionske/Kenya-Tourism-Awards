export interface FormField {
  id: string;
  name: string;
  type: 'text' | 'textarea' | 'email' | 'phone' | 'url' | 'number' | 'date' | 'select' | 'multiselect' | 'checkbox' | 'radio' | 'file' | 'image' | 'repeatable';
  label: string;
  placeholder?: string;
  required: boolean;
  validation?: {
    minLength?: number;
    maxLength?: number;
    maxWords?: number;
    pattern?: string;
    min?: number;
    max?: number;
    fileTypes?: string[];
    maxFiles?: number;
    maxFileSize?: number; // in MB
  };
  options?: Array<{ value: string; label: string; }>;
  helpText?: string;
  conditional?: {
    field: string;
    operator: 'equals' | 'not_equals' | 'contains' | 'greater_than' | 'less_than';
    value: any;
  };
  repeatable?: {
    fields: FormField[];
    maxItems: number;
    addButtonText?: string;
  };
  metadata?: Record<string, any>;
}

export interface FormDefinition {
  id: string;
  slug: string;
  categoryGroup: string;
  category: string;
  title: string;
  description?: string;
  schema: {
    sections: Array<{
      id: string;
      title: string;
      description?: string;
      fields: FormField[];
      order: number;
    }>;
    requirements: string[];
    maxAttachments: number;
    allowedFileTypes: string[];
    maxFileSize: number;
    helpText?: string;
  };
  published: boolean;
  version: number;
  metadata: Record<string, any>;
  createdBy: string;
  updatedBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Submission {
  id: string;
  formDefinitionId: string;
  categoryGroup: string;
  category: string;
  submitterId?: string;
  submitterEmail?: string;
  nomineeName: string;
  organizationName?: string;
  contactPerson: string;
  contactEmail: string;
  contactPhone?: string;
  county?: string;
  yearEstablished?: number;
  physicalAddress?: string;
  websiteUrl?: string;
  nomineeDetails: Record<string, any>;
  attachments: Record<string, string[]>;
  status: 'pending' | 'under_review' | 'verified' | 'rejected' | 'shortlisted' | 'winner' | 'runner_up';
  juryScore?: number;
  publicVotes: number;
  totalScore?: number;
  rejectionReason?: string;
  reviewNotes?: string;
  priority: number;
  featured: boolean;
  submissionIp?: string;
  submissionUserAgent?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProcessState {
  id: number;
  currentStage: 'setup' | 'entries_open' | 'entries_closed' | 'jury_vetting' | 'vetting_closed' | 'voting_open' | 'voting_closed' | 'results_announced';
  stageStart?: Date;
  stageEnd?: Date;
  autoTransition: {
    entries_to_vetting?: { enabled: boolean; delay_hours: number; };
    vetting_to_voting?: { enabled: boolean; delay_hours: number; };
    voting_to_results?: { enabled: boolean; delay_hours: number; };
  };
  stageMetadata: Record<string, any>;
  updatedBy?: string;
  updatedAt: Date;
}

export interface SubmissionReview {
  id: string;
  submissionId: string;
  reviewerId: string;
  reviewerRole: string;
  scores: Record<string, number>;
  overallScore?: number;
  comments?: string;
  recommendations?: string;
  reviewStatus: 'draft' | 'submitted' | 'final';
  reviewedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface SubmissionAttachment {
  id: string;
  submissionId: string;
  fileType: string;
  originalName: string;
  fileUrl: string;
  fileSize?: number;
  mimeType?: string;
  uploadStatus: 'uploading' | 'uploaded' | 'processed' | 'failed';
  altText?: string;
  caption?: string;
  metadata: Record<string, any>;
  uploadedBy?: string;
  createdAt: Date;
}

export interface SubmissionHistory {
  id: string;
  submissionId: string;
  versionNumber: number;
  fieldChanges: Record<string, any>;
  changedBy?: string;
  changeReason?: string;
  createdAt: Date;
}

// Privilege types enum
export const PRIVILEGE_TYPES = {
  // System-wide
  FULL_ACCESS: 'full_access',
  MANAGE_SYSTEM: 'manage_system',
  VIEW_ANALYTICS: 'view_analytics',
  
  // Form management
  CREATE_FORMS: 'create_forms',
  EDIT_FORMS: 'edit_forms',
  PUBLISH_FORMS: 'publish_forms',
  DELETE_FORMS: 'delete_forms',
  
  // Submission management
  VIEW_SUBMISSIONS: 'view_submissions',
  EDIT_SUBMISSIONS: 'edit_submissions',
  APPROVE_SUBMISSIONS: 'approve_submissions',
  REJECT_SUBMISSIONS: 'reject_submissions',
  SHORTLIST_SUBMISSIONS: 'shortlist_submissions',
  
  // Review system
  REVIEW_SUBMISSIONS: 'review_submissions',
  SCORE_SUBMISSIONS: 'score_submissions',
  FINAL_REVIEW: 'final_review',
  
  // User management
  MANAGE_USERS: 'manage_users',
  ASSIGN_PRIVILEGES: 'assign_privileges',
  VIEW_USER_ACTIVITY: 'view_user_activity',
  
  // Content management
  MANAGE_CONTENT: 'manage_content',
  MANAGE_PAGES: 'manage_pages',
  MANAGE_NAVIGATION: 'manage_navigation',
  
  // Communication
  SEND_NOTIFICATIONS: 'send_notifications',
  MANAGE_EMAIL_CAMPAIGNS: 'manage_email_campaigns'
} as const;

export type PrivilegeType = typeof PRIVILEGE_TYPES[keyof typeof PRIVILEGE_TYPES];

export const RESOURCE_TYPES = {
  SYSTEM: 'system',
  FORMS: 'forms',
  SUBMISSIONS: 'submissions',
  USERS: 'users',
  CONTENT: 'content',
  ANALYTICS: 'analytics',
  COMMUNICATIONS: 'communications'
} as const;

export type ResourceType = typeof RESOURCE_TYPES[keyof typeof RESOURCE_TYPES];