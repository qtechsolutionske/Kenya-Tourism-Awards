export interface TeamMember {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
  phone?: string;
  avatar: string;
  banner?: string;
  bio: string;
  organization?: string;
  website?: string;
  socialLinks: {
    linkedin?: string;
    twitter?: string;
    facebook?: string;
    instagram?: string;
  };
  specialization?: string;
  experience: number;
  joinedYear: number;
  currentYear: number;
  isActive: boolean;
  isPublic: boolean;
  
  // Jury specific
  juryCategories?: string[];
  judgingHistory?: JudgingHistory[];
  
  // Staff specific
  eventResponsibilities?: EventResponsibility[];
  
  // Portfolio
  portfolio: PortfolioEntry[];
  
  // Achievements & Recognition
  achievements: Achievement[];
  badges: Badge[];
  
  // Media & Content
  gallery: GalleryItem[];
  videos: VideoLink[];
  downloadableCV?: string;
  
  // Analytics
  profileViews?: number;
  lastProfileUpdate: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface JudgingHistory {
  year: number;
  categories: string[];
  totalNominations: number;
  averageScore: number;
}

export interface EventResponsibility {
  eventName: string;
  role: string;
  year: number;
  description: string;
}

export interface PortfolioEntry {
  id: string;
  type: 'pdf' | 'image' | 'link' | 'article';
  title: string;
  description: string;
  url: string;
  thumbnail?: string;
  publishedDate?: Date;
  tags: string[];
  category: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  date: Date;
  type: 'award' | 'certification' | 'publication' | 'milestone';
  organization?: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  earnedDate: Date;
}

export interface GalleryItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail: string;
  caption: string;
  event?: string;
  date: Date;
}

export interface VideoLink {
  id: string;
  platform: 'youtube' | 'vimeo' | 'facebook';
  url: string;
  title: string;
  description: string;
  thumbnail: string;
  publishedDate: Date;
}

export interface TeamMessage {
  id: string;
  senderId: string;
  receiverId: string;
  subject: string;
  message: string;
  isRead: boolean;
  sentAt: Date;
  replyToId?: string;
}

export interface Endorsement {
  id: string;
  fromMemberId: string;
  toMemberId: string;
  message: string;
  isPublic: boolean;
  createdAt: Date;
}