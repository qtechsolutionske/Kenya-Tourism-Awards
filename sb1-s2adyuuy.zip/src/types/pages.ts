export interface Page {
  id: string;
  title: string;
  slug: string;
  templateType: 'default' | 'landing' | 'blog' | 'service' | 'gallery' | 'contact';
  status: 'draft' | 'published' | 'archived' | 'scheduled';
  visibility: 'public' | 'private' | 'authenticated' | 'admin_only';
  metaTitle?: string;
  metaDescription?: string;
  metaKeywords?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  canonicalUrl?: string;
  featuredImage?: string;
  excerpt?: string;
  isSystemPage: boolean;
  showInNavigation: boolean;
  navigationParentId?: string;
  navigationOrder: number;
  publishedAt?: Date;
  createdBy: string;
  updatedBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PageSection {
  id: string;
  pageId: string;
  sectionType: 'hero' | 'text' | 'image' | 'gallery' | 'team' | 'testimonials' | 'services' | 'contact_form' | 'stats' | 'video' | 'map' | 'faq' | 'cta';
  sectionName: string;
  content: Record<string, any>;
  styles?: Record<string, any>;
  settings?: Record<string, any>;
  isVisible: boolean;
  sectionOrder: number;
  createdBy: string;
  updatedBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PageRevision {
  id: string;
  pageId: string;
  revisionNumber: number;
  title: string;
  contentSnapshot: Record<string, any>;
  sectionsSnapshot: PageSection[];
  changeSummary?: string;
  createdBy: string;
  createdAt: Date;
}

export interface NavigationItem {
  id: string;
  pageId?: string;
  label: string;
  url?: string;
  isExternal: boolean;
  targetBlank: boolean;
  parentId?: string;
  menuLocation: 'main' | 'footer' | 'admin';
  orderPosition: number;
  isVisible: boolean;
  requiredRole?: string;
  iconClass?: string;
  cssClasses?: string;
  createdBy: string;
  updatedBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface SectionTemplate {
  type: PageSection['sectionType'];
  name: string;
  description: string;
  icon: string;
  defaultContent: Record<string, any>;
  fields: SectionField[];
}

export interface SectionField {
  name: string;
  type: 'text' | 'textarea' | 'richtext' | 'image' | 'video' | 'url' | 'color' | 'number' | 'select' | 'checkbox' | 'array';
  label: string;
  placeholder?: string;
  required?: boolean;
  options?: Array<{ value: string; label: string; }>;
  validation?: {
    minLength?: number;
    maxLength?: number;
    pattern?: string;
  };
}

export interface PageBuilderProps {
  page: Page;
  sections: PageSection[];
  onSave: (page: Partial<Page>, sections: PageSection[]) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}