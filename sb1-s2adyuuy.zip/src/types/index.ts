export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'superadmin' | 'admin' | 'jury' | 'voter' | 'nominee' | 'user';
  permissions: string[];
  accessToken?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Category {
  id: string;
  name: string;
  group: 'facilities' | 'nightlife' | 'culinary' | 'transport' | 'icons' | 'media' | 'destinations';
  description: string;
  requirements: string[];
  isActive: boolean;
}

export interface Nomination {
  id: string;
  categoryId: string;
  nomineeName: string;
  organizationName?: string;
  yearEstablished?: number;
  address: string;
  county: string;
  contactPerson: string;
  phone: string;
  email: string;
  website?: string;
  description: string;
  logo?: string;
  image?: string;
  supportingMaterials: string[];
  testimonials: string[];
  awards: string[];
  status: 'pending' | 'approved' | 'rejected' | 'shortlisted';
  submittedAt: Date;
  juryScore?: number;
  publicVotes?: number;
}

export interface JuryMember {
  id: string;
  userId: string;
  name: string;
  expertise: string;
  assignedCategories: string[];
  isActive: boolean;
}

export interface Vote {
  id: string;
  voterId: string;
  nominationId: string;
  categoryId: string;
  timestamp: Date;
  ipAddress: string;
  deviceInfo: string;
}

export interface GalaTicket {
  id: string;
  type: 'standard' | 'vip' | 'vvip' | 'corporate';
  price: number;
  buyerName: string;
  buyerEmail: string;
  buyerPhone: string;
  paymentStatus: 'pending' | 'completed' | 'failed';
  paymentMethod: 'mpesa' | 'card' | 'bank';
  qrCode: string;
  purchasedAt: Date;
}

export interface EmailCampaign {
  id: string;
  name: string;
  subject: string;
  content: string;
  recipients: string[];
  scheduledAt?: Date;
  sentAt?: Date;
  status: 'draft' | 'scheduled' | 'sent' | 'failed';
  openRate?: number;
  clickRate?: number;
}

export interface Winner {
  id: string;
  nominationId: string;
  categoryId: string;
  year: number;
  position: 'winner' | 'runner-up' | 'third';
  announcedAt: Date;
}

export interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  read: boolean;
  userId?: string;
  createdAt: Date;
}

// Project-related types (keeping for backward compatibility)
export interface Project {
  id: string;
  name: string;
  description: string;
  status: 'planning' | 'active' | 'completed' | 'on-hold';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  startDate: Date;
  endDate: Date;
  progress: number;
  teamMembers: string[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'in-progress' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo: string;
  projectId: string;
  dueDate: Date;
  createdAt: Date;
  updatedAt: Date;
}