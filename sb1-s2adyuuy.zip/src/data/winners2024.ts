export interface Winner2024 {
  id: string;
  category: string;
  categoryGroup: string;
  winner: string;
  organization?: string;
  description: string;
  website?: string;
  logo?: string;
  image: string;
  achievements: string[];
  location: string;
  yearEstablished?: number;
  specialNotes?: string;
  isEditable?: boolean;
}

export const winners2024: Winner2024[] = [
  // FACILITIES & ESTABLISHMENTS
  {
    id: 'luxury-hotel-2024',
    category: 'Best Luxury Hotel',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Gem Forest Hotel Nairobi',
    organization: 'MGallery Collection',
    description: 'A sophisticated boutique hotel offering exceptional luxury accommodations and personalized service in the heart of Nairobi. Part of the prestigious MGallery Collection.',
    website: 'https://www.gemforesthotel.com',
    image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Part of the prestigious MGallery Collection',
      'Exceptional personalized service standards',
      'Prime location in Nairobi with luxury amenities',
      'Recognition for sustainable luxury practices'
    ],
    location: 'Nairobi',
    yearEstablished: 2018,
    specialNotes: 'MGallery Collection boutique property',
    isEditable: true
  },
  {
    id: 'hotel-group-2024',
    category: 'Best Hotel Group',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Sarova Hotels & Resorts',
    description: 'Leading hospitality group with properties across Kenya, offering diverse luxury experiences from safari lodges to beach resorts.',
    website: 'https://www.sarovahotels.com',
    image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Multi-property hospitality excellence',
      'Diverse portfolio from city hotels to safari lodges',
      'Consistent quality standards across all properties',
      'Strong local presence with international standards'
    ],
    location: 'Kenya-wide',
    yearEstablished: 1976,
    specialNotes: 'Leading Kenyan hospitality group',
    isEditable: true
  },
  {
    id: 'beach-resort-2024',
    category: 'Best Beach Resort in Kenya',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Baobab Beach Resort and Spa',
    description: 'Premier beachfront resort offering world-class amenities, spa services, and direct access to pristine beaches.',
    website: 'https://www.baobabbeach.com',
    image: 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Stunning beachfront location',
      'World-class spa and wellness facilities',
      'Multiple dining options with ocean views',
      'Family-friendly amenities and activities'
    ],
    location: 'Diani Beach, Kwale',
    yearEstablished: 1991,
    specialNotes: 'Iconic beachfront property',
    isEditable: true
  },
  {
    id: 'restaurant-2024',
    category: 'Best Restaurant in Kenya',
    categoryGroup: 'Facilities & Establishments',
    winner: '270° Rooftop',
    description: 'Sophisticated rooftop dining experience with panoramic city views and exceptional contemporary cuisine.',
    website: 'https://www.270degrees.co.ke',
    image: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Panoramic 270-degree city views',
      'Contemporary cuisine with international standards',
      'Award-winning rooftop design and atmosphere',
      'Exceptional cocktail and wine program'
    ],
    location: 'Nairobi',
    yearEstablished: 2019,
    specialNotes: 'Premier rooftop dining destination',
    isEditable: true
  },
  {
    id: 'safari-lodge-2024',
    category: 'Best Safari Lodge',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Spirit of the Masai Mara',
    description: 'Luxury safari lodge offering authentic wilderness experiences with unparalleled views of the Maasai Mara ecosystem.',
    website: 'https://www.spiritofthemasaimara.com',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Prime Maasai Mara location with wildlife access',
      'Luxury tented accommodations with modern amenities',
      'Exceptional game viewing and safari experiences',
      'Strong community and conservation partnerships'
    ],
    location: 'Maasai Mara, Narok',
    yearEstablished: 2015,
    specialNotes: 'Exclusive safari experience',
    isEditable: true
  },
  {
    id: 'halal-restaurant-2024',
    category: 'Best Halal-Certified Restaurant',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Al-Yusra Restaurant',
    description: 'Authentic halal dining experience serving traditional and contemporary Middle Eastern and Kenyan cuisine.',
    website: 'https://www.alyusra.co.ke',
    image: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Certified halal food preparation and service',
      'Authentic Middle Eastern and Kenyan cuisine',
      'Strong community following and reputation',
      'Cultural dining experience with traditional hospitality'
    ],
    location: 'Nairobi',
    yearEstablished: 2012,
    specialNotes: 'Premier halal dining destination',
    isEditable: true
  },
  {
    id: 'halal-hotel-2024',
    category: 'Best Halal-Certified Hotel',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Maa Hotel & Suites',
    description: 'Modern hotel offering halal-certified accommodations and dining services with contemporary amenities.',
    website: 'https://www.maahotel.com',
    image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Comprehensive halal certification across all services',
      'Modern accommodations with cultural sensitivity',
      'Halal dining options and prayer facilities',
      'Excellent service standards for Muslim travelers'
    ],
    location: 'Nairobi',
    yearEstablished: 2017,
    specialNotes: 'Leading halal hospitality provider',
    isEditable: true
  },
  {
    id: 'nightclub-2024',
    category: 'Best Bar / Night Club / Lounge',
    categoryGroup: 'Facilities & Establishments',
    winner: 'The Bar Next Door, Kiambu Road',
    description: 'Trendy nightlife venue offering vibrant atmosphere, premium cocktails, and exceptional entertainment experiences.',
    website: 'https://www.thebarnextdoor.co.ke',
    image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Innovative cocktail menu and premium spirits',
      'Dynamic entertainment programming',
      'Contemporary design and vibrant atmosphere',
      'Strong local following and reputation'
    ],
    location: 'Kiambu Road, Nairobi',
    yearEstablished: 2020,
    specialNotes: 'Premier nightlife destination',
    isEditable: true
  },
  {
    id: 'golf-resort-2024',
    category: 'Best Golf Resort in Kenya',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Vipingo Ridge Ltd',
    description: 'Championship golf resort offering world-class golfing facilities combined with luxury accommodations and coastal beauty.',
    website: 'https://www.vipingoridge.com',
    image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Championship 18-hole golf course',
      'Stunning coastal location and views',
      'Luxury residential and hospitality facilities',
      'International golf tournament hosting capabilities'
    ],
    location: 'Kilifi County',
    yearEstablished: 2010,
    specialNotes: 'Premier coastal golf destination',
    isEditable: true
  },
  {
    id: 'tented-safari-2024',
    category: 'Best Tented Safari Camp',
    categoryGroup: 'Facilities & Establishments',
    winner: 'Enkopiro Camp, Maasai Mara',
    description: 'Intimate tented camp offering authentic safari experiences with luxury amenities in the heart of the Maasai Mara.',
    website: 'https://www.enkopirocamp.com',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Authentic tented safari accommodations',
      'Prime Maasai Mara location for wildlife viewing',
      'Intimate camp size for personalized service',
      'Strong conservation and community partnerships'
    ],
    location: 'Maasai Mara, Narok',
    yearEstablished: 2018,
    specialNotes: 'Intimate safari camp experience',
    isEditable: true
  },

  // TRANSPORT & MOBILITY
  {
    id: 'domestic-airline-2024',
    category: 'Best Domestic Airline in Kenya',
    categoryGroup: 'Transport & Mobility',
    winner: 'SafariLink',
    description: 'Leading domestic airline providing reliable and safe air transport services connecting Kenya\'s major destinations.',
    website: 'https://www.flysafarilink.com',
    image: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Extensive domestic route network',
      'Excellent safety record and reliability',
      'Modern fleet and professional service',
      'Strong tourism industry partnerships'
    ],
    location: 'Nairobi (HQ)',
    yearEstablished: 2012,
    specialNotes: 'Leading domestic aviation provider',
    isEditable: true
  },
  {
    id: 'tours-travel-2024',
    category: 'Best Tours & Travel Agency in Kenya',
    categoryGroup: 'Transport & Mobility',
    winner: 'AfriQuest Expeditions',
    description: 'Premier tour operator offering comprehensive safari and adventure experiences across East Africa.',
    website: 'https://www.afriquestexpeditions.com',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Comprehensive East Africa tour packages',
      'Expert local guides and safari specialists',
      'Sustainable tourism practices',
      'Excellent customer satisfaction ratings'
    ],
    location: 'Nairobi',
    yearEstablished: 2015,
    specialNotes: 'East Africa safari specialists',
    isEditable: true
  },
  {
    id: 'inbound-operator-2024',
    category: 'Best Inbound Tour Operator in Kenya',
    categoryGroup: 'Transport & Mobility',
    winner: 'Ongeri Expeditions',
    description: 'Specialized inbound tour operator focusing on authentic Kenyan experiences for international visitors.',
    website: 'https://www.ongeriexpeditions.com',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Specialized inbound tourism expertise',
      'Authentic Kenyan cultural experiences',
      'International market knowledge',
      'Sustainable and responsible tourism practices'
    ],
    location: 'Nairobi',
    yearEstablished: 2014,
    specialNotes: 'Inbound tourism specialists',
    isEditable: true
  },
  {
    id: 'outbound-operator-2024',
    category: 'Best Outbound Tour Operator',
    categoryGroup: 'Transport & Mobility',
    winner: 'Viutravel',
    description: 'Leading outbound tour operator connecting Kenyan travelers to destinations worldwide with exceptional service.',
    website: 'https://www.viutravel.com',
    image: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Global destination expertise',
      'Comprehensive outbound travel services',
      'Strong international partnerships',
      'Excellent customer service and support'
    ],
    location: 'Nairobi',
    yearEstablished: 2016,
    specialNotes: 'Global travel specialists',
    isEditable: true
  },

  // SPECIAL RECOGNITION
  {
    id: 'conservation-org-2024',
    category: 'Best Conservation Organisation in Kenya',
    categoryGroup: 'Special Recognition',
    winner: 'Taita Taveta Wildlife Conservancies Association',
    description: 'Leading conservation organization protecting wildlife and ecosystems while promoting community-based conservation.',
    website: 'https://www.ttwca.org',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Community-based conservation leadership',
      'Wildlife protection and ecosystem preservation',
      'Sustainable tourism development',
      'Strong local community engagement'
    ],
    location: 'Taita Taveta County',
    yearEstablished: 2009,
    specialNotes: 'Community conservation pioneers',
    isEditable: true
  },
  {
    id: 'tourism-influencer-2024',
    category: 'Best Tourism Influencer in Kenya',
    categoryGroup: 'Special Recognition',
    winner: 'Ryan Mwenda (Simba)',
    description: 'Dynamic tourism influencer showcasing Kenya\'s diverse attractions through engaging content and authentic storytelling.',
    website: 'https://www.instagram.com/ryan_simba',
    image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Engaging tourism content creation',
      'Large social media following and engagement',
      'Authentic Kenyan destination promotion',
      'Strong influence on travel decision-making'
    ],
    location: 'Nairobi',
    specialNotes: 'Leading travel content creator',
    isEditable: true
  },
  {
    id: 'training-institution-2024',
    category: 'Best Tourism Training Institution in Kenya',
    categoryGroup: 'Special Recognition',
    winner: 'Boma International Hospitality College',
    description: 'Premier hospitality training institution developing the next generation of tourism professionals in Kenya.',
    website: 'https://www.bomacollege.ac.ke',
    image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Comprehensive hospitality education programs',
      'Industry-relevant curriculum and training',
      'Strong graduate employment rates',
      'Modern facilities and expert faculty'
    ],
    location: 'Nairobi',
    yearEstablished: 2008,
    specialNotes: 'Leading hospitality education provider',
    isEditable: true
  },

  // INDUSTRY ICONS
  {
    id: 'tourism-personality-2024',
    category: 'Tourism Personality of the Year',
    categoryGroup: 'Industry Icons',
    winner: 'Marley Sianto',
    description: 'Visionary tourism leader driving innovation and excellence in Kenya\'s tourism sector through strategic leadership.',
    image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Strategic tourism sector leadership',
      'Innovation in tourism product development',
      'Strong industry advocacy and representation',
      'Mentorship of emerging tourism professionals'
    ],
    location: 'Nairobi',
    specialNotes: 'Tourism sector visionary',
    isEditable: true
  },
  {
    id: 'lifetime-achievement-2024',
    category: 'Lifetime Achievement Award',
    categoryGroup: 'Industry Icons',
    winner: 'Alex Chamwada',
    description: 'Legendary media personality and tourism advocate who has showcased Kenya\'s beauty and culture for decades.',
    image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Decades of tourism promotion through media',
      'Showcasing Kenya\'s natural beauty and culture',
      'Influential tourism advocacy and storytelling',
      'Inspiring generations of tourism professionals'
    ],
    location: 'Nairobi',
    specialNotes: 'Media legend and tourism ambassador',
    isEditable: true
  },
  {
    id: 'sports-male-2024',
    category: 'Sports Tourism Male Personality',
    categoryGroup: 'Industry Icons',
    winner: 'Emmanuel Wanyonyi',
    description: 'World-class athlete promoting Kenya as a premier sports tourism destination through exceptional achievements.',
    image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'International athletics excellence',
      'Global sports tourism promotion for Kenya',
      'Inspiring youth in sports and tourism',
      'Ambassador for Kenya\'s sporting heritage'
    ],
    location: 'Kenya',
    specialNotes: 'World athletics champion',
    isEditable: true
  },
  {
    id: 'sports-female-2024',
    category: 'Sports Tourism Female Personality',
    categoryGroup: 'Industry Icons',
    winner: 'Faith Kipyegon',
    description: 'Olympic champion and world record holder promoting Kenya\'s excellence in sports tourism on the global stage.',
    image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Olympic gold medalist and world record holder',
      'Global ambassador for Kenya sports tourism',
      'Inspiring female participation in sports',
      'Promoting Kenya\'s athletic excellence worldwide'
    ],
    location: 'Kenya',
    specialNotes: 'Olympic champion and world record holder',
    isEditable: true
  },

  // TRAILBLAZER COUNTIES
  {
    id: 'best-county-overall-2024',
    category: 'Best County to Visit Overall',
    categoryGroup: 'Trailblazer Counties',
    winner: 'Kilifi County',
    description: 'Outstanding coastal county offering diverse tourism experiences from pristine beaches to rich cultural heritage.',
    website: 'https://www.kilifi.go.ke',
    image: 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Diverse tourism attractions and experiences',
      'Beautiful coastal beaches and marine parks',
      'Rich Swahili cultural heritage',
      'Excellent tourism infrastructure development'
    ],
    location: 'Coastal Kenya',
    specialNotes: 'Diverse coastal tourism destination',
    isEditable: true
  },
  {
    id: 'best-coastal-county-2024',
    category: 'Best Coastal County',
    categoryGroup: 'Trailblazer Counties',
    winner: 'Lamu County',
    description: 'Historic coastal county preserving Swahili culture and architecture while offering unique tourism experiences.',
    website: 'https://www.lamu.go.ke',
    image: 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'UNESCO World Heritage Site status',
      'Preserved Swahili architecture and culture',
      'Unique dhow sailing and cultural experiences',
      'Sustainable cultural tourism development'
    ],
    location: 'Indian Ocean Coast',
    specialNotes: 'UNESCO World Heritage destination',
    isEditable: true
  },
  {
    id: 'wildlife-county-2024',
    category: 'Best County Promoting Wildlife / Safari in Kenya',
    categoryGroup: 'Trailblazer Counties',
    winner: 'Taita Taveta County',
    description: 'Leading wildlife destination promoting conservation and sustainable safari tourism with diverse ecosystems.',
    website: 'https://www.taita-taveta.go.ke',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Diverse wildlife and ecosystem conservation',
      'Community-based conservation initiatives',
      'Sustainable safari tourism development',
      'Strong wildlife protection measures'
    ],
    location: 'Southeast Kenya',
    specialNotes: 'Wildlife conservation leader',
    isEditable: true
  },
  {
    id: 'cultural-tourism-county-2024',
    category: 'Best County in Promotion of Cultural Tourism',
    categoryGroup: 'Trailblazer Counties',
    winner: 'Turkana County',
    description: 'Authentic cultural tourism destination showcasing traditional lifestyles and archaeological significance.',
    website: 'https://www.turkana.go.ke',
    image: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Rich cultural heritage and traditions',
      'Archaeological significance and discoveries',
      'Authentic cultural tourism experiences',
      'Community-based cultural preservation'
    ],
    location: 'Northern Kenya',
    specialNotes: 'Cultural heritage destination',
    isEditable: true
  },

  // SURPRISE CATEGORIES
  {
    id: 'airport-hotel-2024',
    category: 'Best Airport Hotel',
    categoryGroup: 'Surprise Categories',
    winner: 'Argyle Grand Hotel, Nairobi Airport',
    description: 'Premier airport hotel offering convenient luxury accommodations and excellent service for travelers.',
    website: 'https://www.argylegrandhotel.com',
    image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Strategic airport location for convenience',
      'Luxury accommodations and modern amenities',
      'Excellent service for business and leisure travelers',
      'Strong reputation for reliability and comfort'
    ],
    location: 'Jomo Kenyatta International Airport',
    yearEstablished: 2019,
    specialNotes: 'Premier airport hospitality',
    isEditable: true
  },
  {
    id: 'nightlife-trendsetter-2024',
    category: 'Nightlife Trendsetter of the Year',
    categoryGroup: 'Surprise Categories',
    winner: 'TIMBA XO',
    description: 'Innovative nightlife concept setting new trends in entertainment and hospitality experiences.',
    website: 'https://www.timbaxo.com',
    image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=800',
    achievements: [
      'Innovative nightlife and entertainment concept',
      'Trendsetting in hospitality experiences',
      'Strong social media presence and influence',
      'Young demographic engagement and appeal'
    ],
    location: 'Nairobi',
    yearEstablished: 2021,
    specialNotes: 'Nightlife innovation leader',
    isEditable: true
  }
];

// Group winners by category group for easier display
export const winnersByGroup = {
  'Facilities & Establishments': winners2024.filter(w => w.categoryGroup === 'Facilities & Establishments'),
  'Transport & Mobility': winners2024.filter(w => w.categoryGroup === 'Transport & Mobility'),
  'Special Recognition': winners2024.filter(w => w.categoryGroup === 'Special Recognition'),
  'Industry Icons': winners2024.filter(w => w.categoryGroup === 'Industry Icons'),
  'Trailblazer Counties': winners2024.filter(w => w.categoryGroup === 'Trailblazer Counties'),
  'Surprise Categories': winners2024.filter(w => w.categoryGroup === 'Surprise Categories')
};

// Statistics for dashboard display
export const winners2024Stats = {
  totalWinners: winners2024.length,
  categoryGroups: Object.keys(winnersByGroup).length,
  facilities: winnersByGroup['Facilities & Establishments'].length,
  transport: winnersByGroup['Transport & Mobility'].length,
  recognition: winnersByGroup['Special Recognition'].length,
  icons: winnersByGroup['Industry Icons'].length,
  counties: winnersByGroup['Trailblazer Counties'].length,
  surprise: winnersByGroup['Surprise Categories'].length
};

export default winners2024;