// Legacy winners data - now replaced by comprehensive winners2024.ts
// This file is kept for backward compatibility and historical data

import { winners2024 } from './winners2024';

// Re-export 2024 winners in legacy format for existing components
export const previousWinners = winners2024.map(winner => ({
  year: 2024,
  category: winner.category,
  winner: winner.winner,
  description: winner.description,
  image: winner.image,
  achievements: winner.achievements
}));

// Export additional winner data for enhanced display
export default previousWinners;