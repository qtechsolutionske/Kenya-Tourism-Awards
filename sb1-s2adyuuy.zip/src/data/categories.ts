import { Category } from '../types';

export const categories: Category[] = [
  // CATEGORY GROUP 1: FACILITIES, ESTABLISHMENTS & ORGANISATIONS
  {
    id: 'luxury-hotel',
    name: 'Best Luxury Hotel',
    group: 'facilities',
    description: 'Excellence in luxury hospitality services and amenities',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'beach-resort',
    name: 'Best Beach Resort',
    group: 'facilities',
    description: 'Outstanding beachfront hospitality and guest experiences',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'conference-hotel',
    name: 'Best Conference Hotel',
    group: 'facilities',
    description: 'Excellence in business and conference facilities',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'airport-hotel',
    name: 'Best Airport Hotel',
    group: 'facilities',
    description: 'Excellence in airport hospitality and convenience',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'hotel-group',
    name: 'Best Hotel Group',
    group: 'facilities',
    description: 'Excellence in hotel group operations and management',
    requirements: [
      'Name of Hotel Group',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'serviced-apartments',
    name: 'Best Serviced Apartments',
    group: 'facilities',
    description: 'Excellence in serviced apartment hospitality',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'restaurant',
    name: 'Best Restaurant',
    group: 'facilities',
    description: 'Excellence in restaurant services and dining experience',
    requirements: [
      'Name of Restaurant',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and venue image',
      'Entry description (max 300 words)',
      'Up to 3 customer testimonials',
      'Awards/recognitions list',
      'Menu samples'
    ],
    isActive: true
  },
  {
    id: 'safari-lodge',
    name: 'Best Safari Lodge',
    group: 'facilities',
    description: 'Outstanding safari experiences and wildlife hospitality',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'halal-restaurant',
    name: 'Best Halal Certified Restaurant',
    group: 'facilities',
    description: 'Excellence in halal-certified dining services',
    requirements: [
      'Name of Restaurant',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and venue image',
      'Entry description (max 300 words)',
      'Up to 3 customer testimonials',
      'Awards/recognitions list',
      'Halal certification documents'
    ],
    isActive: true
  },
  {
    id: 'halal-hotel',
    name: 'Best Halal Certified Hotel',
    group: 'facilities',
    description: 'Excellence in halal-certified hospitality services',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Halal certification documents'
    ],
    isActive: true
  },
  {
    id: 'tented-safari-camp',
    name: 'Best Tented Safari Camp',
    group: 'facilities',
    description: 'Excellence in tented camping safari experiences',
    requirements: [
      'Name of Camp',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and camp image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Brochure or fact sheet'
    ],
    isActive: true
  },
  {
    id: 'golf-resort',
    name: 'Best Golf Resort',
    group: 'facilities',
    description: 'Excellence in golf resort facilities and experiences',
    requirements: [
      'Name of Resort',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and resort image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Golf facility details'
    ],
    isActive: true
  },
  {
    id: 'city-golf-resort',
    name: 'Best City Golf Resort',
    group: 'facilities',
    description: 'Excellence in urban golf resort experiences',
    requirements: [
      'Name of Resort',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and resort image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Golf facility details'
    ],
    isActive: true
  },
  {
    id: 'family-hotel',
    name: 'Best Family Hotel',
    group: 'facilities',
    description: 'Excellence in family-friendly hospitality and amenities',
    requirements: [
      'Name of Property/Organization',
      'Name of Parent Group (if applicable)',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and property image',
      'Entry description (max 300 words)',
      'Up to 3 guest testimonials',
      'Awards/recognitions list',
      'Family facilities details'
    ],
    isActive: true
  },
  {
    id: 'conservation-org',
    name: 'Best Conservation Organization',
    group: 'facilities',
    description: 'Excellence in wildlife and environmental conservation',
    requirements: [
      'Organization Name',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and organization image',
      'Entry description (max 300 words)',
      'Up to 3 testimonials',
      'Awards/recognitions list',
      'Conservation programs overview'
    ],
    isActive: true
  },
  {
    id: 'hospitality-school',
    name: 'Hospitality School of the Year',
    group: 'facilities',
    description: 'Excellence in hospitality education and training',
    requirements: [
      'School Name',
      'Year of Establishment',
      'Physical Address & County',
      'Contact Person Details',
      'High-resolution logo and school image',
      'Entry description (max 300 words)',
      'Up to 3 testimonials',
      'Awards/recognitions list',
      'Curriculum and programs overview'
    ],
    isActive: true
  },

  // CATEGORY GROUP 2: NIGHTLIFE & ENTERTAINMENT
  {
    id: 'night-club',
    name: 'Best Night Club',
    group: 'nightlife',
    description: 'Excellence in nightlife entertainment and ambiance',
    requirements: [
      'Name of Venue',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'High-resolution logo and venue image',
      'Entry description (max 300 words)',
      'Event images/flyers',
      'Guest reviews',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'live-music-venue',
    name: 'Best Live Music Venue',
    group: 'nightlife',
    description: 'Excellence in live music entertainment and venue atmosphere',
    requirements: [
      'Name of Venue',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'High-resolution logo and venue image',
      'Entry description (max 300 words)',
      'Event images/flyers',
      'Guest reviews',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'rooftop-bar',
    name: 'Best Rooftop Bar & Lounge',
    group: 'nightlife',
    description: 'Outstanding rooftop dining and entertainment experience',
    requirements: [
      'Name of Venue',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'High-resolution logo and venue image',
      'Entry description (max 300 words)',
      'Event images/flyers',
      'Guest reviews',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'beachfront-nightspot',
    name: 'Best Beachfront Night Spot',
    group: 'nightlife',
    description: 'Excellence in beachfront entertainment and nightlife',
    requirements: [
      'Name of Venue',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'High-resolution logo and venue image',
      'Entry description (max 300 words)',
      'Event images/flyers',
      'Guest reviews',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'cultural-night-experience',
    name: 'Best Cultural Night Experience',
    group: 'nightlife',
    description: 'Excellence in cultural entertainment and authentic experiences',
    requirements: [
      'Name of Venue',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'High-resolution logo and venue image',
      'Entry description (max 300 words)',
      'Event images/flyers',
      'Guest reviews',
      'Awards list'
    ],
    isActive: true
  },

  // CATEGORY GROUP 3: CULINARY & GASTRONOMY
  {
    id: 'fine-dining',
    name: 'Best Fine Dining Restaurant',
    group: 'culinary',
    description: 'Excellence in fine dining and culinary artistry',
    requirements: [
      'Name of Restaurant',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'Logo and venue/dish image',
      'Entry description (max 300 words)',
      'Up to 3 customer testimonials',
      'Menu samples/images',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'farm-to-table',
    name: 'Best Farm-to-Table Experience',
    group: 'culinary',
    description: 'Excellence in sustainable farm-to-table dining',
    requirements: [
      'Name of Restaurant',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'Logo and venue/dish image',
      'Entry description (max 300 words)',
      'Up to 3 customer testimonials',
      'Menu samples/images',
      'Farm partnership details'
    ],
    isActive: true
  },
  {
    id: 'traditional-cuisine',
    name: 'Best Traditional Kenyan Cuisine Restaurant',
    group: 'culinary',
    description: 'Excellence in authentic Kenyan culinary traditions',
    requirements: [
      'Name of Restaurant',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'Logo and venue/dish image',
      'Entry description (max 300 words)',
      'Up to 3 customer testimonials',
      'Menu samples/images',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'wine-whisky-lounge',
    name: 'Best Wine & Whisky Lounge',
    group: 'culinary',
    description: 'Excellence in wine and whisky experiences',
    requirements: [
      'Name of Lounge',
      'Year of Establishment',
      'Address & County',
      'Contact Person Details',
      'Logo and venue image',
      'Entry description (max 300 words)',
      'Up to 3 customer testimonials',
      'Wine/whisky collection highlights',
      'Awards list'
    ],
    isActive: true
  },

  // CATEGORY GROUP 4: TRANSPORT AND MOBILITY
  {
    id: 'domestic-airline',
    name: 'Best Domestic Airline',
    group: 'transport',
    description: 'Excellence in domestic air travel services',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and service image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Brochures',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'plane-charter',
    name: 'Best Plane Charter',
    group: 'transport',
    description: 'Excellence in charter flight services',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and aircraft image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Service brochures',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'tour-travel-agency',
    name: 'Best Tour and Travel Agency',
    group: 'transport',
    description: 'Excellence in tour and travel services',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and service image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Tour packages overview',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'inbound-tour-operator',
    name: 'Best Inbound Tour Operator',
    group: 'transport',
    description: 'Excellence in inbound tourism operations',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and service image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Brochures',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'outbound-tour-operator',
    name: 'Best Outbound Tour Operator',
    group: 'transport',
    description: 'Excellence in outbound tourism operations',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and service image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Destination packages overview',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'luxury-tour-operator',
    name: 'Best Luxury Tour Operator',
    group: 'transport',
    description: 'Excellence in luxury tourism experiences',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and service image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Luxury packages overview',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'adventure-tour-operator',
    name: 'Best Adventure Tour Operator',
    group: 'transport',
    description: 'Excellence in adventure tourism and outdoor experiences',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and service image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Adventure packages overview',
      'Safety certifications'
    ],
    isActive: true
  },
  {
    id: 'luxury-car-rental',
    name: 'Best Luxury Car Rental Company',
    group: 'transport',
    description: 'Excellence in luxury car rental services',
    requirements: [
      'Company Name',
      'Year Established',
      'HQ Location & County',
      'Contact Person Details',
      'Logo and fleet image',
      'Entry description (max 300 words)',
      'Customer feedback',
      'Fleet overview',
      'Awards list'
    ],
    isActive: true
  },

  // CATEGORY GROUP 5: INDUSTRY ICONS
  {
    id: 'lifetime-achievement',
    name: 'Lifetime Achievement Award',
    group: 'icons',
    description: 'Recognition for transformative contributions to tourism',
    requirements: [
      'Full Name',
      'Organization (if any)',
      'Current Position',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Biography (max 300 words)',
      'Up to 3 testimonials',
      'Press features',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'tourism-personality',
    name: 'Best Tourism Personality of the Year',
    group: 'icons',
    description: 'Outstanding individual contribution to tourism industry',
    requirements: [
      'Full Name',
      'Organization (if any)',
      'Current Position',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Biography (max 300 words)',
      'Up to 3 testimonials',
      'Press features',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'male-sports-tourism-personality',
    name: 'Best Male Sports Tourism Personality',
    group: 'icons',
    description: 'Excellence in male sports tourism leadership',
    requirements: [
      'Full Name',
      'Organization (if any)',
      'Current Position',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Biography (max 300 words)',
      'Up to 3 testimonials',
      'Sports achievements',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'female-sports-tourism-personality',
    name: 'Best Female Sports Tourism Personality',
    group: 'icons',
    description: 'Excellence in female sports tourism leadership',
    requirements: [
      'Full Name',
      'Organization (if any)',
      'Current Position',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Biography (max 300 words)',
      'Up to 3 testimonials',
      'Sports achievements',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'hotel-general-manager',
    name: 'Best Hotel General Manager of the Year',
    group: 'icons',
    description: 'Outstanding leadership in hotel management',
    requirements: [
      'Full Name',
      'Hotel/Organization',
      'Current Position',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Biography (max 300 words)',
      'Up to 3 testimonials',
      'Management achievements',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'young-tourism-leader',
    name: 'Young Tourism Leader Award',
    group: 'icons',
    description: 'Recognition for emerging tourism leaders under 35',
    requirements: [
      'Full Name',
      'Organization (if any)',
      'Current Position',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Biography (max 300 words)',
      'Up to 3 testimonials',
      'Leadership initiatives',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'wildlife-conservation-champion',
    name: 'Wildlife Conservation Champion',
    group: 'icons',
    description: 'Excellence in wildlife conservation efforts',
    requirements: [
      'Full Name',
      'Organization (if any)',
      'Current Position',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Biography (max 300 words)',
      'Up to 3 testimonials',
      'Conservation projects',
      'Awards list'
    ],
    isActive: true
  },

  // CATEGORY GROUP 6: FILM & MEDIA IN TOURISM
  {
    id: 'travel-documentary',
    name: 'Best Travel Documentary of the Year',
    group: 'media',
    description: 'Excellence in travel documentary production',
    requirements: [
      'Name',
      'Organization/Platform',
      'Medium',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Work summary (max 300 words)',
      'Media samples/links',
      'Engagement data',
      'Up to 3 testimonials'
    ],
    isActive: true
  },
  {
    id: 'travel-photographer',
    name: 'Best Travel Photographer of the Year',
    group: 'media',
    description: 'Excellence in travel photography showcasing Kenya',
    requirements: [
      'Name',
      'Organization/Platform',
      'Medium',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Work summary (max 300 words)',
      'Media samples/links',
      'Engagement data',
      'Up to 3 testimonials'
    ],
    isActive: true
  },
  {
    id: 'tourism-influencer',
    name: 'Best Tourism Influencer of the Year',
    group: 'media',
    description: 'Excellence in digital tourism influence and content creation',
    requirements: [
      'Name',
      'Organization/Platform',
      'Medium',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Work summary (max 300 words)',
      'Media samples/links',
      'Engagement data',
      'Up to 3 testimonials'
    ],
    isActive: true
  },
  {
    id: 'travel-journalist',
    name: 'Best Travel Journalist of the Year',
    group: 'media',
    description: 'Excellence in travel journalism and storytelling',
    requirements: [
      'Name',
      'Organization/Platform',
      'Medium',
      'County',
      'Contact Person Details',
      'High-resolution headshot',
      'Work summary (max 300 words)',
      'Media samples/links',
      'Published articles',
      'Up to 3 testimonials'
    ],
    isActive: true
  },

  // CATEGORY GROUP 7: TRAVEL DESTINATIONS
  {
    id: 'best-county',
    name: 'Best County to Visit',
    group: 'destinations',
    description: 'Outstanding county tourism experience and infrastructure',
    requirements: [
      'Destination Name',
      'Nominating Authority/Body',
      'County',
      'Contact Person Details',
      'Logo and destination image',
      'Tourism appeal description (max 300 words)',
      'Visitor reviews',
      'Media features',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'emerging-destination',
    name: 'Best Emerging Tourism Destination',
    group: 'destinations',
    description: 'Recognition for up-and-coming tourism destinations',
    requirements: [
      'Destination Name',
      'Nominating Authority/Body',
      'County',
      'Contact Person Details',
      'Logo and destination image',
      'Tourism appeal description (max 300 words)',
      'Visitor reviews',
      'Media features',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'cultural-tourism-destination',
    name: 'Best Cultural Tourism Destination',
    group: 'destinations',
    description: 'Excellence in cultural heritage and tourism experiences',
    requirements: [
      'Destination Name',
      'Nominating Authority/Body',
      'County',
      'Contact Person Details',
      'Logo and destination image',
      'Cultural appeal description (max 300 words)',
      'Visitor reviews',
      'Cultural heritage details',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'safari-destination',
    name: 'Best Safari Destination',
    group: 'destinations',
    description: 'Outstanding safari experiences and wildlife viewing',
    requirements: [
      'Destination Name',
      'Nominating Authority/Body',
      'County',
      'Contact Person Details',
      'Logo and destination image',
      'Safari appeal description (max 300 words)',
      'Visitor reviews',
      'Wildlife conservation efforts',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'camping-destination',
    name: 'Best Camping Destination',
    group: 'destinations',
    description: 'Excellence in camping facilities and outdoor experiences',
    requirements: [
      'Destination Name',
      'Nominating Authority/Body',
      'County',
      'Contact Person Details',
      'Logo and destination image',
      'Camping appeal description (max 300 words)',
      'Visitor reviews',
      'Facilities overview',
      'Awards list'
    ],
    isActive: true
  },
  {
    id: 'marine-island-destination',
    name: 'Best Marine & Island Destination',
    group: 'destinations',
    description: 'Excellence in marine and island tourism experiences',
    requirements: [
      'Destination Name',
      'Nominating Authority/Body',
      'County',
      'Contact Person Details',
      'Logo and destination image',
      'Marine appeal description (max 300 words)',
      'Visitor reviews',
      'Marine activities overview',
      'Awards list'
    ],
    isActive: true
  }
];

export const categoryGroups = {
  facilities: 'Facilities, Establishments & Organizations',
  nightlife: 'Nightlife & Entertainment', 
  culinary: 'Culinary & Gastronomy',
  transport: 'Transport & Mobility',
  icons: 'Industry Icons',
  media: 'Film & Media in Tourism',
  destinations: 'Travel Destinations'
};