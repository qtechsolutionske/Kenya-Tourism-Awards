import { TeamMember } from '../types/team';

export const teamMembers: TeamMember[] = [
  // New Team Members - Pending Approval
  {
    id: 'allan-ndekwe',
    name: 'Allan Ndekwe',
    role: 'Co-Founder and CEO',
    department: 'Leadership',
    email: 'allan.ndekwe@kta.com',
    phone: '+254 700 001 001',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Allan is the Co-Founder and CEO of Duke Hub Group Limited and Kenya Tourism Awards (KTA). Allan is a public relations and corporate communications professional keen on promoting and positioning Kenya as travel destination of choice. At the Kenya Tourism Awards he is instrumental for setting and driving the mission to recognize and celebrate innovation and impact within Kenya\'s Tourism Sector. Allan has previously worked as head of operations at Luminar Safaris and is a member of the Advisory Board of the Vacations & Cribs Association of Kenya(VACAK).',
    organization: 'Duke Hub Group Limited',
    website: 'https://dukehubgroup.com',
    socialLinks: {
      linkedin: 'https://linkedin.com/in/allan-ndekwe',
      twitter: 'https://twitter.com/allanndekwe'
    },
    specialization: 'Public Relations & Corporate Communications',
    experience: 12,
    joinedYear: 2020,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [],
    achievements: [
      {
        id: 'allan-1',
        title: 'Co-Founder Kenya Tourism Awards',
        description: 'Founded KTA to recognize excellence in Kenya\'s tourism sector',
        date: new Date('2020-01-01'),
        type: 'milestone',
        organization: 'Kenya Tourism Awards'
      }
    ],
    badges: [
      {
        id: 'allan-badge-1',
        name: 'Co-Founder',
        description: 'Co-founder of Kenya Tourism Awards',
        icon: 'Trophy',
        color: 'amber',
        earnedDate: new Date('2020-01-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'george-matogo',
    name: 'George Matogo',
    role: 'Co-Founder and Product & Partnerships Lead',
    department: 'Partnerships',
    email: 'george.matogo@kta.com',
    phone: '+254 700 002 002',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'George is the Co-Founder of Duke Hub Group Limited and the Kenya Tourism Awards. He is an experienced finance and strategy professional. At the Kenya Tourism Awards he leads product development, finance and partnerships.',
    organization: 'Duke Hub Group Limited',
    socialLinks: {
      linkedin: 'https://linkedin.com/in/george-matogo'
    },
    specialization: 'Finance & Strategy',
    experience: 15,
    joinedYear: 2020,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [],
    achievements: [
      {
        id: 'george-1',
        title: 'Co-Founder Kenya Tourism Awards',
        description: 'Founded KTA with focus on finance and partnerships',
        date: new Date('2020-01-01'),
        type: 'milestone',
        organization: 'Kenya Tourism Awards'
      }
    ],
    badges: [
      {
        id: 'george-badge-1',
        name: 'Co-Founder',
        description: 'Co-founder of Kenya Tourism Awards',
        icon: 'Trophy',
        color: 'blue',
        earnedDate: new Date('2020-01-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'sharon-bett',
    name: 'Sharon Bett',
    role: 'Head of Jury and Research',
    department: 'Evaluation',
    email: 'sharon.bett@kta.com',
    phone: '+254 700 003 003',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Sharon Bett is a highly accomplished hospitality and marketing professional with extensive experience in delivering exceptional guest experiences, brand development, and strategic service excellence. She has worked with renowned global hospitality brands, including the largest Marriott property in North America. As the Presiding Jury for the Kenya Tourism Awards, Miss Bett brings a wealth of knowledge and a deep dedication to recognizing and celebrating excellence in Kenya\'s tourism and hospitality industries, while shaping the future of the sector with integrity and foresight.',
    specialization: 'Hospitality & Marketing',
    experience: 18,
    joinedYear: 2021,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    juryCategories: ['luxury-hotel', 'beach-resort', 'conference-hotel', 'safari-lodge'],
    judgingHistory: [
      {
        year: 2024,
        categories: ['luxury-hotel', 'beach-resort'],
        totalNominations: 38,
        averageScore: 8.8
      }
    ],
    portfolio: [],
    achievements: [
      {
        id: 'sharon-1',
        title: 'Marriott Excellence Award',
        description: 'Recognized for outstanding service at largest Marriott property in North America',
        date: new Date('2019-06-15'),
        type: 'award',
        organization: 'Marriott International'
      }
    ],
    badges: [
      {
        id: 'sharon-badge-1',
        name: 'Head of Jury',
        description: 'Leading jury evaluation for KTA',
        icon: 'Award',
        color: 'purple',
        earnedDate: new Date('2021-03-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'naomi-ngatia',
    name: 'Naomi Ngatia',
    role: 'Public Sector Liaison',
    department: 'Partnerships',
    email: 'naomi.ngatia@kta.com',
    phone: '+254 700 004 004',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Naomi has had broad experience working in the public sector at the National Government and County Government levels. She possesses valuable expertise in legal, administrative and public affairs and has helped drive several public-private sector initiatives. Naomi is the public sector relations advisor to the Kenya Tourism Awards.',
    specialization: 'Public Affairs & Legal',
    experience: 14,
    joinedYear: 2021,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [],
    achievements: [
      {
        id: 'naomi-1',
        title: 'Public-Private Partnership Excellence',
        description: 'Led successful public-private sector initiatives',
        date: new Date('2022-09-15'),
        type: 'milestone',
        organization: 'Government of Kenya'
      }
    ],
    badges: [
      {
        id: 'naomi-badge-1',
        name: 'Public Sector Expert',
        description: 'Expertise in government relations',
        icon: 'Shield',
        color: 'indigo',
        earnedDate: new Date('2021-06-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'vivian-moraa',
    name: 'Vivian Moraa',
    role: 'Public Relations Lead',
    department: 'Media',
    email: 'vivian.moraa@kta.com',
    phone: '+254 700 005 005',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'At the Kenya Tourism Awards, Vivian is the driving force behind our Public Relations efforts. She leads the development and execution of a comprehensive PR strategy that effectively communicates the Awards\' mission, milestones and impact to key stakeholders and the public. Vivian excels in crafting compelling narratives, fostering strong media relations and securing high-profile coverage to position the Kenya Tourism Awards as a premium brand in Kenya\'s tourism industry.',
    specialization: 'Public Relations & Media Strategy',
    experience: 8,
    joinedYear: 2022,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [],
    achievements: [
      {
        id: 'vivian-1',
        title: 'Media Excellence Award',
        description: 'Outstanding PR campaign for tourism industry',
        date: new Date('2023-11-20'),
        type: 'award',
        organization: 'PR Society of Kenya'
      }
    ],
    badges: [
      {
        id: 'vivian-badge-1',
        name: 'PR Expert',
        description: 'Excellence in public relations',
        icon: 'Megaphone',
        color: 'pink',
        earnedDate: new Date('2022-08-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'blair-reznick',
    name: 'Blair Reznick',
    role: 'Creative Director',
    department: 'Media',
    email: 'blair.reznick@kta.com',
    phone: '+254 700 006 006',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Blair is a Global Digital Marketing and Communications Specialist with deep experience supporting brands, institutions, and high-level events across Africa and beyond. He has worked with leading regional and international bodies such as the African Union, IGAD, COMESA, and the United Nations, where he has contributed to strategic communications, digital campaigns, and impactful event branding. At KTA, Blair serves as the Creative Director, driving brand visibility, audience engagement, and digital storytelling.',
    organization: 'International Organizations',
    specialization: 'Digital Marketing & Creative Direction',
    experience: 12,
    joinedYear: 2022,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [
      {
        id: 'blair-1',
        type: 'article',
        title: 'Digital Campaigns for African Union',
        description: 'Strategic communications and digital campaign development',
        url: 'https://example.com/blair-au-campaign',
        publishedDate: new Date('2023-06-15'),
        tags: ['digital marketing', 'communications', 'africa'],
        category: 'International Work'
      }
    ],
    achievements: [
      {
        id: 'blair-1',
        title: 'UN Digital Excellence Recognition',
        description: 'Recognized for outstanding digital communication campaigns',
        date: new Date('2023-03-20'),
        type: 'award',
        organization: 'United Nations'
      }
    ],
    badges: [
      {
        id: 'blair-badge-1',
        name: 'Creative Director',
        description: 'Leading creative strategy for KTA',
        icon: 'Palette',
        color: 'purple',
        earnedDate: new Date('2022-05-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'sheila-kaime',
    name: 'Sheila Kaime',
    role: 'Events Management Lead',
    department: 'Operations',
    email: 'sheila.kaime@kta.com',
    phone: '+254 700 007 007',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Sheila is a creative and detail-oriented expert in Client Relations, Event Management, and Marketing, with over 8 years of experience delivering strategic business solutions. She has crafted impactful marketing strategies and executed diverse events across multiple sectors. Known for her ability to manage budgets, coordinate vendors, and lead seamless event execution, Sheila consistently delivers results that exceed client expectations and elevate brand experiences.',
    specialization: 'Event Management & Client Relations',
    experience: 8,
    joinedYear: 2021,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    eventResponsibilities: [
      {
        eventName: 'Kenya Tourism Awards Gala 2024',
        role: 'Lead Event Manager',
        year: 2024,
        description: 'Led comprehensive event management for KTA Gala 2024'
      },
      {
        eventName: 'Tourism Industry Summit 2023',
        role: 'Event Coordinator',
        year: 2023,
        description: 'Coordinated multi-sector tourism summit with 500+ attendees'
      }
    ],
    portfolio: [],
    achievements: [
      {
        id: 'sheila-1',
        title: 'Event Excellence Recognition',
        description: 'Outstanding event management across multiple sectors',
        date: new Date('2023-08-10'),
        type: 'award',
        organization: 'Kenya Event Planners Association'
      }
    ],
    badges: [
      {
        id: 'sheila-badge-1',
        name: 'Event Management Expert',
        description: 'Excellence in event planning and execution',
        icon: 'Calendar',
        color: 'green',
        earnedDate: new Date('2021-10-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'kelvin-ndassya',
    name: 'Kelvin Ndassya',
    role: 'Operations Lead',
    department: 'Operations',
    email: 'kelvin.ndassya@kta.com',
    phone: '+254 700 008 008',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Kelvin is a political scientist with specialized expertise in sustainable development, governance, and policy advisory. His academic background is complemented by practical experience in development frameworks and institutional engagement. With over 6 years of experience in sales and management across e-commerce, tours and travel, and public relations, Kelvin has a proven track record in driving business growth, improving operations, and delivering results in dynamic environments.',
    specialization: 'Sustainable Development & Operations',
    experience: 6,
    joinedYear: 2022,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [],
    achievements: [
      {
        id: 'kelvin-1',
        title: 'Operations Excellence Award',
        description: 'Outstanding operations management and process improvement',
        date: new Date('2023-12-05'),
        type: 'award',
        organization: 'KTA Internal'
      }
    ],
    badges: [
      {
        id: 'kelvin-badge-1',
        name: 'Operations Lead',
        description: 'Excellence in operational management',
        icon: 'Settings',
        color: 'blue',
        earnedDate: new Date('2022-09-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'collins-oywaya',
    name: 'Collins Oywaya',
    role: 'Sustainability Lead',
    department: 'Administration',
    email: 'collins.oywaya@kta.com',
    phone: '+254 700 009 009',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Collins holds a degree in Political Science and is currently pursuing a Master\'s in International Relations at Moi University. He brings expertise in leadership, advocacy, and community engagement to the Kenya Tourism Awards. As an environmentalist and youth leader, Collins advises on promoting sustainable tourism and empowering young people to actively shape the future of the tourism sector.',
    organization: 'Moi University',
    specialization: 'Sustainability & Youth Leadership',
    experience: 4,
    joinedYear: 2023,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [],
    achievements: [
      {
        id: 'collins-1',
        title: 'Youth Leadership Award',
        description: 'Recognition for youth leadership in environmental advocacy',
        date: new Date('2023-05-10'),
        type: 'award',
        organization: 'Environmental Youth Network'
      }
    ],
    badges: [
      {
        id: 'collins-badge-1',
        name: 'Sustainability Champion',
        description: 'Leading sustainability initiatives',
        icon: 'Leaf',
        color: 'green',
        earnedDate: new Date('2023-02-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'devotah-bright',
    name: 'Devotah Bright',
    role: 'Social Enterprise Lead',
    department: 'Administration',
    email: 'devotah.bright@kta.com',
    phone: '+254 700 010 010',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Devotah has a strong background in healthcare and community advocacy. As the Advocacy Director for the Raising Hearts Foundation, she leads initiatives focused on social impact and community empowerment. Her passion and experience in advocacy are instrumental in developing and driving the KTA Initiatives Platform.',
    organization: 'Raising Hearts Foundation',
    specialization: 'Healthcare & Community Advocacy',
    experience: 7,
    joinedYear: 2022,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [],
    achievements: [
      {
        id: 'devotah-1',
        title: 'Community Impact Award',
        description: 'Outstanding community advocacy and social impact initiatives',
        date: new Date('2023-04-25'),
        type: 'award',
        organization: 'Raising Hearts Foundation'
      }
    ],
    badges: [
      {
        id: 'devotah-badge-1',
        name: 'Community Advocate',
        description: 'Excellence in community empowerment',
        icon: 'Heart',
        color: 'pink',
        earnedDate: new Date('2022-11-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'brian-kivuti',
    name: 'Brian Kivuti',
    role: 'Tech Lead',
    department: 'Technology',
    email: 'brian.kivuti@kta.com',
    phone: '+254 700 011 011',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Brian is an experienced full-stack software developer with 5 years of expertise in building robust backend APIs and developing dynamic web and mobile applications. He has successfully delivered scalable solutions across industries including edtech, foodtech, BPO, real estate, fintech, and manufacturing. Brian leads the KTA\'s technical vision, ensuring innovative and reliable digital platforms.',
    specialization: 'Full-Stack Development & Technical Architecture',
    experience: 5,
    joinedYear: 2021,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [
      {
        id: 'brian-1',
        type: 'link',
        title: 'KTA Digital Platform',
        description: 'Full-stack development of KTA voting and management platform',
        url: 'https://kenyatourismawards.com',
        publishedDate: new Date('2024-01-15'),
        tags: ['fullstack', 'react', 'nodejs', 'database'],
        category: 'Platform Development'
      }
    ],
    achievements: [
      {
        id: 'brian-1',
        title: 'Technical Innovation Award',
        description: 'Outstanding technical implementation of KTA platform',
        date: new Date('2024-03-10'),
        type: 'award',
        organization: 'Kenya Tourism Awards'
      }
    ],
    badges: [
      {
        id: 'brian-badge-1',
        name: 'Tech Lead',
        description: 'Leading technical development',
        icon: 'Code',
        color: 'teal',
        earnedDate: new Date('2021-07-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 'mzazi-willy-tuva',
    name: 'Mzazi Willy Tuva',
    role: 'Media Advisor',
    department: 'Media',
    email: 'mzazi.tuva@kta.com',
    phone: '+254 700 012 012',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Mzazi Willy Tuva is a celebrated radio and TV host, widely known for Mambo Mseto and Mseto East Africa. With extensive experience in media and deep industry connections, Tuva serves as an advisor to the Kenya Tourism Awards, guiding media strategy and public relations.',
    organization: 'Radio Africa Group',
    specialization: 'Media & Broadcasting',
    experience: 20,
    joinedYear: 2020,
    currentYear: 2025,
    isActive: true,
    isPublic: true, // Approved
    portfolio: [
      {
        id: 'tuva-1',
        type: 'article',
        title: 'Mambo Mseto - Media Impact',
        description: 'Leading popular radio and TV show with millions of viewers',
        url: 'https://radioafrica.co.ke/mambo-mseto',
        publishedDate: new Date('2023-01-01'),
        tags: ['broadcasting', 'media', 'entertainment'],
        category: 'Media Programs'
      }
    ],
    achievements: [
      {
        id: 'tuva-1',
        title: 'Media Personality of the Year',
        description: 'Outstanding contribution to Kenyan media and entertainment',
        date: new Date('2022-12-01'),
        type: 'award',
        organization: 'Kenya Media Awards'
      }
    ],
    badges: [
      {
        id: 'tuva-badge-1',
        name: 'Media Advisor',
        description: 'Strategic media advisory role',
        icon: 'Mic',
        color: 'red',
        earnedDate: new Date('2020-06-01')
      }
    ],
    gallery: [],
    videos: [
      {
        id: 'tuva-video-1',
        platform: 'youtube',
        url: 'https://youtube.com/watch?v=mambo-mseto',
        title: 'Mambo Mseto Highlights',
        description: 'Popular episodes from Mambo Mseto show',
        thumbnail: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=400',
        publishedDate: new Date('2023-10-15')
      }
    ],
    profileViews: 0,
    lastProfileUpdate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },

  // Existing team members (keeping current ones)
  {
    id: '1',
    name: 'Dr. Sarah Mwangi',
    role: 'Awards Director',
    department: 'Leadership',
    email: 'sarah.mwangi@kta.com',
    phone: '+254 700 001 001',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Leading tourism expert with 15+ years in industry development and strategic planning. Dr. Mwangi has been instrumental in shaping Kenya\'s tourism policy and has worked with various international organizations to promote sustainable tourism practices.',
    organization: 'Kenya Tourism Board',
    website: 'https://sarahmwangi.co.ke',
    socialLinks: {
      linkedin: 'https://linkedin.com/in/sarah-mwangi',
      twitter: 'https://twitter.com/sarahmwangi',
      facebook: 'https://facebook.com/sarah.mwangi'
    },
    specialization: 'Tourism Policy & Strategy',
    experience: 15,
    joinedYear: 2020,
    currentYear: 2025,
    isActive: true,
    isPublic: true,
    portfolio: [
      {
        id: '1',
        type: 'article',
        title: 'Sustainable Tourism in Kenya: A Strategic Approach',
        description: 'Research paper on sustainable tourism development strategies',
        url: 'https://example.com/paper1',
        publishedDate: new Date('2024-06-15'),
        tags: ['sustainability', 'strategy', 'policy'],
        category: 'Research'
      }
    ],
    achievements: [
      {
        id: '1',
        title: 'Tourism Excellence Award',
        description: 'Recognized for outstanding contribution to Kenya tourism',
        date: new Date('2023-12-01'),
        type: 'award',
        organization: 'East Africa Tourism Association'
      }
    ],
    badges: [
      {
        id: '1',
        name: 'Founding Director',
        description: 'Original founding member of KTA',
        icon: 'Trophy',
        color: 'amber',
        earnedDate: new Date('2020-01-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 1247,
    lastProfileUpdate: new Date('2024-12-01'),
    createdAt: new Date('2020-01-01'),
    updatedAt: new Date('2024-12-01')
  },
  {
    id: '2',
    name: 'James Kiprotich',
    role: 'Jury Coordinator',
    department: 'Evaluation',
    email: 'james.kiprotich@kta.com',
    phone: '+254 700 002 002',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Hospitality veteran and former hotel general manager with extensive experience in luxury hospitality operations. James brings deep industry knowledge to the jury coordination role.',
    organization: 'Hemingways Collection',
    socialLinks: {
      linkedin: 'https://linkedin.com/in/james-kiprotich'
    },
    specialization: 'Luxury Hospitality',
    experience: 12,
    joinedYear: 2021,
    currentYear: 2025,
    isActive: true,
    isPublic: true,
    juryCategories: ['luxury-hotel', 'conference-hotel', 'safari-lodge'],
    judgingHistory: [
      {
        year: 2024,
        categories: ['luxury-hotel', 'conference-hotel'],
        totalNominations: 45,
        averageScore: 8.2
      },
      {
        year: 2023,
        categories: ['luxury-hotel'],
        totalNominations: 23,
        averageScore: 8.7
      }
    ],
    portfolio: [],
    achievements: [],
    badges: [
      {
        id: '2',
        name: 'Senior Jury Member',
        description: 'Experienced jury coordinator',
        icon: 'Award',
        color: 'blue',
        earnedDate: new Date('2022-01-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 892,
    lastProfileUpdate: new Date('2024-11-15'),
    createdAt: new Date('2021-02-01'),
    updatedAt: new Date('2024-11-15')
  },
  {
    id: '3',
    name: 'Grace Wanjiku',
    role: 'Events Manager',
    department: 'Operations',
    email: 'grace.wanjiku@kta.com',
    phone: '+254 700 003 003',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Award-winning event planner specializing in luxury experiences and large-scale corporate events. Grace has managed some of Kenya\'s most prestigious tourism events.',
    organization: 'Prestige Events Kenya',
    website: 'https://gracewanjiku.com',
    socialLinks: {
      linkedin: 'https://linkedin.com/in/grace-wanjiku',
      instagram: 'https://instagram.com/gracewanjiku'
    },
    specialization: 'Event Planning & Management',
    experience: 8,
    joinedYear: 2022,
    currentYear: 2025,
    isActive: true,
    isPublic: true,
    eventResponsibilities: [
      {
        eventName: 'Kenya Tourism Awards Gala 2024',
        role: 'Lead Event Coordinator',
        year: 2024,
        description: 'Managed end-to-end event planning for 1,200+ guests'
      },
      {
        eventName: 'Tourism Industry Summit 2024',
        role: 'Logistics Manager',
        year: 2024,
        description: 'Coordinated venue, catering, and guest management'
      }
    ],
    portfolio: [
      {
        id: '2',
        type: 'pdf',
        title: 'KTA Gala 2024 Event Summary',
        description: 'Comprehensive report on gala event execution',
        url: '/portfolio/grace-gala-2024.pdf',
        publishedDate: new Date('2024-04-01'),
        tags: ['events', 'gala', 'management'],
        category: 'Event Reports'
      }
    ],
    achievements: [
      {
        id: '2',
        title: 'Best Event Manager 2024',
        description: 'Recognized by Kenya Event Planners Association',
        date: new Date('2024-09-15'),
        type: 'award',
        organization: 'KEPA'
      }
    ],
    badges: [
      {
        id: '3',
        name: 'Event Excellence',
        description: 'Exceptional event management skills',
        icon: 'Calendar',
        color: 'green',
        earnedDate: new Date('2023-06-01')
      }
    ],
    gallery: [
      {
        id: '1',
        type: 'image',
        url: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=800',
        thumbnail: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=400',
        caption: 'KTA Gala 2024 Setup',
        event: 'Gala 2024',
        date: new Date('2024-03-15')
      }
    ],
    videos: [
      {
        id: '1',
        platform: 'youtube',
        url: 'https://youtube.com/watch?v=example1',
        title: 'Behind the Scenes: KTA Gala 2024',
        description: 'Event planning and execution highlights',
        thumbnail: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=400',
        publishedDate: new Date('2024-03-20')
      }
    ],
    profileViews: 634,
    lastProfileUpdate: new Date('2024-12-05'),
    createdAt: new Date('2022-03-01'),
    updatedAt: new Date('2024-12-05')
  },
  {
    id: '4',
    name: 'Michael Ochieng',
    role: 'Marketing Director',
    department: 'Marketing',
    email: 'michael.ochieng@kta.com',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=1200',
    bio: 'Digital marketing strategist with expertise in tourism promotion and brand development. Michael has led successful campaigns that have significantly increased tourism awareness and engagement.',
    organization: 'Digital Kenya Marketing',
    socialLinks: {
      linkedin: 'https://linkedin.com/in/michael-ochieng',
      twitter: 'https://twitter.com/michaelochieng'
    },
    specialization: 'Digital Marketing & Brand Strategy',
    experience: 10,
    joinedYear: 2021,
    currentYear: 2025,
    isActive: true,
    isPublic: true,
    portfolio: [
      {
        id: '3',
        type: 'article',
        title: 'Digital Tourism Marketing in East Africa',
        description: 'Comprehensive guide to digital marketing strategies',
        url: 'https://example.com/article1',
        publishedDate: new Date('2024-08-10'),
        tags: ['digital marketing', 'tourism', 'strategy'],
        category: 'Articles'
      }
    ],
    achievements: [],
    badges: [
      {
        id: '4',
        name: 'Digital Innovator',
        description: 'Leading digital marketing initiatives',
        icon: 'Zap',
        color: 'purple',
        earnedDate: new Date('2023-01-01')
      }
    ],
    gallery: [],
    videos: [],
    profileViews: 456,
    lastProfileUpdate: new Date('2024-11-20'),
    createdAt: new Date('2021-06-01'),
    updatedAt: new Date('2024-11-20')
  }
];

export const teamDepartments = [
  'Leadership',
  'Evaluation',
  'Operations', 
  'Marketing',
  'Administration',
  'Technology',
  'Media',
  'Partnerships'
];

export const teamRoles = [
  'Co-Founder and CEO',
  'Co-Founder and Product & Partnerships Lead',
  'Awards Director',
  'Head of Jury and Research',
  'Public Sector Liaison',
  'Public Relations Lead',
  'Creative Director',
  'Events Management Lead',
  'Operations Lead',
  'Sustainability Lead',
  'Social Enterprise Lead',
  'Tech Lead',
  'Media Advisor',
  'Jury Coordinator',
  'Events Manager',
  'Marketing Director'
];