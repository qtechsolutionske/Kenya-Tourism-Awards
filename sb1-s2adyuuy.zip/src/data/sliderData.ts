import { Slide, SliderSettings } from '../types/slider';

export const defaultSliderSettings: SliderSettings = {
  autoplay: {
    enabled: true,
    interval: 6000,
    pauseOnHover: true,
    pauseOnFocus: true,
    disableOnMobile: true,
    resumeOnLeave: true,
  },
  navigation: {
    arrows: true,
    arrowsStyle: 'default',
    arrowsPosition: 'inside',
    bullets: true,
    bulletsStyle: 'dots',
    bulletsPosition: 'bottom',
    pausePlay: true,
    progressBar: true,
  },
  interaction: {
    loop: true,
    swipeEnabled: true,
    dragEnabled: true,
    keyboardEnabled: true,
    touchThreshold: 50,
  },
  transitions: {
    type: 'fade',
    duration: 1000,
    easing: 'ease-in-out',
    respectReducedMotion: true,
  },
  layout: {
    heightMode: 'fixed',
    aspectRatio: '16/9',
    adaptiveHeight: false,
  },
  performance: {
    lazyLoading: true,
    preloadAdjacent: true,
    reducedDataMode: true,
    maxConcurrentLoads: 3,
  },
  accessibility: {
    announceSlides: true,
    focusTrapping: true,
    ariaLabels: {
      slider: 'Kenya Tourism Awards homepage highlights',
      nextButton: 'View next destination highlight',
      prevButton: 'View previous destination highlight',
      pauseButton: 'Pause slideshow',
      playButton: 'Resume slideshow',
      slide: 'Destination slide',
    },
  },
};

export const mockSlides: Slide[] = [
  {
    id: '1',
    sliderId: 'homepage-slider',
    type: 'hero',
    title: 'Maasai Mara Hero',
    content: {
      headline: 'Kenya Tourism Awards 2025',
      subhead: 'Celebrating excellence, innovation, and sustainability in Kenya\'s tourism industry',
      body: 'Join thousands of tourism stakeholders in recognizing outstanding achievements across 28 award categories.',
      primaryCTA: {
        label: 'Submit Nomination',
        url: '/nominations',
        target: '_self',
        eventKey: 'hero_cta_nominate'
      },
      secondaryCTA: {
        label: 'View Nominees',
        url: '/nominees',
        target: '_self'
      },
      textAlignment: 'left',
      overlay: { type: 'manual', color: 'black', opacity: 50 }
    },
    media: {
      type: 'image',
      src: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      alt: 'Maasai Mara National Reserve showcasing Kenya\'s premier safari destination',
      focalPoint: { x: 0.5, y: 0.4 },
      variants: {
        mobile: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=828',
        tablet: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=1280',
        desktop: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=1920'
      }
    },
    effects: {
      transition: 'fade',
      duration: 1000,
      kenBurns: true,
      parallax: 0.2
    },
    targeting: { devices: ['mobile', 'tablet', 'desktop'] },
    schedule: { timezone: 'Africa/Nairobi' },
    priority: 1,
    status: 'published',
    version: 1,
    analytics: {
      conversionGoal: 'nomination_submission',
      eventKeys: ['hero_cta_nominate', 'hero_cta_view']
    },
    accessibility: {
      altText: 'Stunning landscape of Maasai Mara National Reserve during the Great Migration, showcasing Kenya\'s world-renowned wildlife destination',
      ariaLabel: 'Kenya Tourism Awards 2025 hero section with nomination call-to-action'
    },
    createdBy: 'admin@kta.com',
    createdAt: new Date('2024-12-01'),
    updatedAt: new Date('2024-12-12')
  },
  {
    id: '2',
    sliderId: 'homepage-slider',
    type: 'video',
    title: 'Tourism Excellence Video',
    content: {
      headline: 'Experience Kenya\'s Tourism Excellence',
      subhead: 'Discover award-winning destinations and hospitality',
      body: 'From luxury safari lodges to pristine coastal resorts, explore the nominees setting new standards in tourism.',
      primaryCTA: {
        label: 'Explore Nominees',
        url: '/nominees',
        target: '_self',
        eventKey: 'video_cta_explore'
      },
      textAlignment: 'center',
      overlay: { type: 'manual', color: 'black', opacity: 40 }
    },
    media: {
      type: 'video',
      videoSrc: 'https://player.vimeo.com/external/371433846.sd.mp4?s=236da2f3c0fd273d2c6d9a064f3ae35579b2bbdf&profile_id=139',
      poster: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      alt: 'Tourism excellence video showcasing Kenya\'s premier destinations and hospitality',
      muted: true,
      loop: true,
      controls: false,
      playsinline: true
    },
    targeting: { devices: ['desktop', 'tablet'] }, // Hide on mobile for performance
    schedule: { timezone: 'Africa/Nairobi' },
    priority: 2,
    status: 'published',
    version: 1,
    analytics: {
      conversionGoal: 'nominee_exploration',
      eventKeys: ['video_cta_explore', 'video_play_toggle']
    },
    accessibility: {
      altText: 'Promotional video highlighting Kenya\'s tourism excellence and award nominees',
      ariaLabel: 'Video presentation of Kenya tourism destinations and hospitality excellence'
    },
    createdBy: 'admin@kta.com',
    createdAt: new Date('2024-12-02'),
    updatedAt: new Date('2024-12-10')
  },
  {
    id: '3',
    sliderId: 'homepage-slider',
    type: 'split',
    title: 'Voting Call-to-Action',
    content: {
      headline: 'Your Vote Matters',
      subhead: 'Shape Kenya\'s Tourism Future',
      body: 'Join over 12,000 tourism stakeholders in recognizing excellence. Vote for your favorite nominees across 28 categories and help celebrate the best in Kenya\'s tourism industry.',
      primaryCTA: {
        label: 'Cast Your Votes',
        url: '/voting',
        target: '_self',
        eventKey: 'split_cta_vote'
      },
      secondaryCTA: {
        label: 'Learn About Categories',
        url: '/about',
        target: '_self'
      },
      textAlignment: 'left',
      overlay: { type: 'auto' }
    },
    media: {
      type: 'image',
      src: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      alt: 'Kenya Tourism Awards gala ceremony with industry leaders celebrating excellence',
      focalPoint: { x: 0.7, y: 0.3 }
    },
    targeting: { devices: ['mobile', 'tablet', 'desktop'] },
    schedule: {
      startAt: new Date('2025-03-01T00:00:00Z'),
      endAt: new Date('2025-03-10T23:59:59Z'),
      timezone: 'Africa/Nairobi'
    },
    priority: 3,
    status: 'scheduled',
    version: 1,
    analytics: {
      conversionGoal: 'voting_participation',
      eventKeys: ['split_cta_vote', 'split_cta_learn']
    },
    accessibility: {
      altText: 'Elegant awards ceremony setup with stage lighting and table arrangements for Kenya Tourism Awards gala',
      ariaLabel: 'Voting call-to-action slide encouraging participation in Kenya Tourism Awards'
    },
    createdBy: 'admin@kta.com',
    createdAt: new Date('2024-12-05'),
    updatedAt: new Date('2024-12-08')
  },
  {
    id: '4',
    sliderId: 'homepage-slider',
    type: 'countdown',
    title: 'Voting Deadline',
    content: {
      headline: 'Voting Ends Soon!',
      subhead: 'Don\'t Miss Your Chance',
      body: 'Only a few days left to vote for your favorite tourism nominees. Make your voice heard!',
      primaryCTA: {
        label: 'Vote Now',
        url: '/voting',
        target: '_self',
        eventKey: 'countdown_cta_urgent_vote'
      },
      textAlignment: 'center',
      overlay: { type: 'manual', color: 'red', opacity: 60 }
    },
    media: {
      type: 'image',
      src: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      alt: 'Urgent voting deadline reminder with clock and ballot imagery'
    },
    targeting: { devices: ['mobile', 'tablet', 'desktop'] },
    schedule: {
      startAt: new Date('2025-03-08T00:00:00Z'),
      endAt: new Date('2025-03-10T23:59:59Z'),
      timezone: 'Africa/Nairobi'
    },
    priority: 1, // High priority during voting period
    status: 'scheduled',
    version: 1,
    analytics: {
      conversionGoal: 'last_minute_voting',
      eventKeys: ['countdown_cta_urgent_vote', 'countdown_view']
    },
    accessibility: {
      altText: 'Time-sensitive voting deadline countdown with urgency messaging for Kenya Tourism Awards',
      ariaLabel: 'Urgent reminder about voting deadline with live countdown timer'
    },
    createdBy: 'admin@kta.com',
    createdAt: new Date('2024-12-06'),
    updatedAt: new Date('2024-12-09')
  }
];