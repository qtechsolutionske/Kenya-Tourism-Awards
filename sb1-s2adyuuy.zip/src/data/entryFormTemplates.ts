import { FormDefinition } from '../types/entries';
import { categories } from './categories';

// Base form template sections that apply to all categories
const baseFormSections = [
  {
    id: 'basic_info',
    title: 'Basic Information',
    description: 'Essential details about the nominee/organization',
    fields: [
      {
        id: 'nominee_name',
        name: 'nominee_name',
        type: 'text' as const,
        label: 'Name of Nominee/Property/Organization',
        placeholder: 'Enter the official name',
        required: true,
        validation: { minLength: 2, maxLength: 255 }
      },
      {
        id: 'organization_name',
        name: 'organization_name',
        type: 'text' as const,
        label: 'Parent Group/Organization (if applicable)',
        placeholder: 'Enter parent organization name',
        required: false,
        validation: { maxLength: 255 }
      },
      {
        id: 'year_established',
        name: 'year_established',
        type: 'number' as const,
        label: 'Year of Establishment',
        placeholder: 'e.g., 2010',
        required: true,
        validation: { min: 1900, max: new Date().getFullYear() }
      },
      {
        id: 'physical_address',
        name: 'physical_address',
        type: 'textarea' as const,
        label: 'Physical Address',
        placeholder: 'Enter complete physical address',
        required: true,
        validation: { minLength: 10, maxLength: 500 }
      },
      {
        id: 'county',
        name: 'county',
        type: 'select' as const,
        label: 'County',
        required: true,
        options: [
          { value: 'nairobi', label: 'Nairobi' },
          { value: 'mombasa', label: 'Mombasa' },
          { value: 'kwale', label: 'Kwale' },
          { value: 'kilifi', label: 'Kilifi' },
          { value: 'tana-river', label: 'Tana River' },
          { value: 'lamu', label: 'Lamu' },
          { value: 'taita-taveta', label: 'Taita-Taveta' },
          { value: 'nakuru', label: 'Nakuru' },
          { value: 'narok', label: 'Narok' },
          { value: 'kajiado', label: 'Kajiado' },
          { value: 'laikipia', label: 'Laikipia' },
          { value: 'samburu', label: 'Samburu' },
          { value: 'isiolo', label: 'Isiolo' },
          { value: 'meru', label: 'Meru' },
          { value: 'embu', label: 'Embu' },
          { value: 'kitui', label: 'Kitui' },
          { value: 'machakos', label: 'Machakos' },
          { value: 'makueni', label: 'Makueni' },
          { value: 'kiambu', label: 'Kiambu' },
          { value: 'murang\'a', label: 'Murang\'a' },
          { value: 'kirinyaga', label: 'Kirinyaga' },
          { value: 'nyeri', label: 'Nyeri' },
          { value: 'nyandarua', label: 'Nyandarua' },
          { value: 'kisumu', label: 'Kisumu' },
          { value: 'siaya', label: 'Siaya' },
          { value: 'busia', label: 'Busia' },
          { value: 'kakamega', label: 'Kakamega' },
          { value: 'vihiga', label: 'Vihiga' },
          { value: 'bungoma', label: 'Bungoma' },
          { value: 'trans-nzoia', label: 'Trans Nzoia' },
          { value: 'uasin-gishu', label: 'Uasin Gishu' },
          { value: 'elgeyo-marakwet', label: 'Elgeyo-Marakwet' },
          { value: 'nandi', label: 'Nandi' },
          { value: 'baringo', label: 'Baringo' },
          { value: 'kericho', label: 'Kericho' },
          { value: 'bomet', label: 'Bomet' },
          { value: 'west-pokot', label: 'West Pokot' },
          { value: 'turkana', label: 'Turkana' },
          { value: 'marsabit', label: 'Marsabit' },
          { value: 'wajir', label: 'Wajir' },
          { value: 'mandera', label: 'Mandera' },
          { value: 'garissa', label: 'Garissa' },
          { value: 'tharaka-nithi', label: 'Tharaka-Nithi' },
          { value: 'homa-bay', label: 'Homa Bay' },
          { value: 'migori', label: 'Migori' },
          { value: 'kisii', label: 'Kisii' },
          { value: 'nyamira', label: 'Nyamira' }
        ]
      }
    ],
    order: 1
  },
  {
    id: 'contact_info',
    title: 'Contact Information',
    description: 'Primary contact details for communications',
    fields: [
      {
        id: 'contact_person',
        name: 'contact_person',
        type: 'text' as const,
        label: 'Contact Person Name',
        placeholder: 'Full name of primary contact',
        required: true,
        validation: { minLength: 2, maxLength: 255 }
      },
      {
        id: 'contact_email',
        name: 'contact_email',
        type: 'email' as const,
        label: 'Contact Email Address',
        placeholder: 'contact@example.com',
        required: true,
        validation: { pattern: '^[^@]+@[^@]+\\.[^@]+$' }
      },
      {
        id: 'contact_phone',
        name: 'contact_phone',
        type: 'phone' as const,
        label: 'Contact Phone Number',
        placeholder: '+254 700 000 000',
        required: true,
        validation: { pattern: '^\\+?[0-9\\s\\-]{10,15}$' }
      },
      {
        id: 'website',
        name: 'website',
        type: 'url' as const,
        label: 'Website URL (Optional)',
        placeholder: 'https://www.example.com',
        required: false,
        validation: { pattern: '^https?://.*' }
      }
    ],
    order: 2
  },
  {
    id: 'entry_details',
    title: 'Entry Description',
    description: 'Detailed description and supporting information',
    fields: [
      {
        id: 'entry_description',
        name: 'entry_description',
        type: 'textarea' as const,
        label: 'Entry Description',
        placeholder: 'Describe why this nominee deserves the award (maximum 300 words)',
        required: true,
        validation: { minLength: 50, maxWords: 300 },
        helpText: 'Highlight key achievements, unique features, and reasons for nomination'
      },
      {
        id: 'achievements',
        name: 'achievements',
        type: 'textarea' as const,
        label: 'Key Achievements & Awards',
        placeholder: 'List major achievements, recognitions, and awards received',
        required: true,
        validation: { minLength: 20, maxWords: 200 }
      }
    ],
    order: 3
  },
  {
    id: 'attachments',
    title: 'Supporting Materials',
    description: 'Upload required documents and images',
    fields: [
      {
        id: 'logo',
        name: 'logo',
        type: 'image' as const,
        label: 'High-Resolution Logo',
        required: true,
        validation: { 
          maxFiles: 1, 
          maxFileSize: 5,
          fileTypes: ['image/png', 'image/jpeg', 'image/svg+xml']
        },
        helpText: 'Upload company/organization logo in high resolution (PNG, JPEG, or SVG)'
      },
      {
        id: 'property_images',
        name: 'property_images',
        type: 'image' as const,
        label: 'Property/Nominee Images',
        required: true,
        validation: { 
          maxFiles: 5, 
          maxFileSize: 10,
          fileTypes: ['image/png', 'image/jpeg']
        },
        helpText: 'Upload high-quality images showcasing the nominee (maximum 5 images)'
      },
      {
        id: 'testimonials',
        name: 'testimonials',
        type: 'repeatable' as const,
        label: 'Guest/Customer Testimonials (up to 3)',
        required: true,
        repeatable: {
          fields: [
            {
              id: 'testimonial_text',
              name: 'testimonial_text',
              type: 'textarea',
              label: 'Testimonial',
              required: true,
              validation: { maxWords: 150 }
            },
            {
              id: 'customer_name',
              name: 'customer_name',
              type: 'text',
              label: 'Customer Name',
              required: true,
              validation: { maxLength: 100 }
            },
            {
              id: 'customer_title',
              name: 'customer_title',
              type: 'text',
              label: 'Customer Title/Organization',
              required: false,
              validation: { maxLength: 150 }
            }
          ],
          maxItems: 3,
          addButtonText: 'Add Testimonial'
        }
      },
      {
        id: 'brochure',
        name: 'brochure',
        type: 'file' as const,
        label: 'Brochure or Fact Sheet',
        required: true,
        validation: { 
          maxFiles: 1, 
          maxFileSize: 10,
          fileTypes: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
        },
        helpText: 'Upload detailed brochure or fact sheet (PDF, DOC, or DOCX)'
      },
      {
        id: 'awards_certificates',
        name: 'awards_certificates',
        type: 'file' as const,
        label: 'Awards & Recognition Certificates',
        required: false,
        validation: { 
          maxFiles: 5, 
          maxFileSize: 5,
          fileTypes: ['application/pdf', 'image/png', 'image/jpeg']
        },
        helpText: 'Upload certificates and awards (optional)'
      }
    ],
    order: 4
  }
];

// Category-specific customizations
const getCategorySpecificFields = (categoryGroup: string, categoryName: string) => {
  const customizations: Record<string, any> = {};

  // Customizations for Icons/Personal entries
  if (categoryGroup === 'icons') {
    customizations.basic_info = {
      removeFields: ['organization_name'],
      modifyFields: {
        nominee_name: { label: 'Full Name', placeholder: 'Enter nominee\'s full name' }
      },
      addFields: [
        {
          id: 'current_position',
          name: 'current_position',
          type: 'text',
          label: 'Current Position/Title',
          required: true,
          validation: { maxLength: 200 }
        }
      ]
    };
    
    customizations.entry_details = {
      addFields: [
        {
          id: 'biography',
          name: 'biography',
          type: 'textarea',
          label: 'Professional Biography',
          placeholder: 'Professional background and career highlights (maximum 300 words)',
          required: true,
          validation: { minLength: 50, maxWords: 300 },
          helpText: 'Brief professional background and career highlights'
        }
      ]
    };

    customizations.attachments = {
      modifyFields: {
        logo: { label: 'High-Resolution Headshot', helpText: 'Professional headshot photo' },
        property_images: { label: 'Professional Photos', helpText: 'Additional professional photos' },
        testimonials: { label: 'References/Recommendations' },
        brochure: { label: 'CV/Resume', required: true }
      }
    };
  }

  // Customizations for Media entries
  if (categoryGroup === 'media') {
    customizations.contact_info = {
      addFields: [
        {
          id: 'media_platform',
          name: 'media_platform',
          type: 'text',
          label: 'Media Platform/Organization',
          placeholder: 'TV station, newspaper, online platform, etc.',
          required: true,
          validation: { maxLength: 255 }
        },
        {
          id: 'medium_type',
          name: 'medium_type',
          type: 'select',
          label: 'Primary Medium',
          required: true,
          options: [
            { value: 'television', label: 'Television' },
            { value: 'print', label: 'Print Media' },
            { value: 'online', label: 'Online/Digital' },
            { value: 'radio', label: 'Radio' },
            { value: 'photography', label: 'Photography' },
            { value: 'film', label: 'Film/Documentary' }
          ]
        }
      ]
    };

    customizations.entry_details = {
      addFields: [
        {
          id: 'portfolio_samples',
          name: 'portfolio_samples',
          type: 'textarea',
          label: 'Portfolio/Work Samples Links',
          placeholder: 'Provide links to your published work',
          required: true,
          validation: { minLength: 20, maxWords: 100 }
        },
        {
          id: 'engagement_metrics',
          name: 'engagement_metrics',
          type: 'textarea',
          label: 'Audience/Engagement Metrics',
          placeholder: 'Readership, viewership, followers, engagement rates, etc.',
          required: false,
          validation: { maxWords: 150 }
        }
      ]
    };

    customizations.attachments = {
      addFields: [
        {
          id: 'media_samples',
          name: 'media_samples',
          type: 'file',
          label: 'Media Samples/Portfolio',
          required: true,
          validation: { 
            maxFiles: 10, 
            maxFileSize: 50,
            fileTypes: ['application/pdf', 'image/png', 'image/jpeg', 'video/mp4', 'video/quicktime', 'audio/mp3']
          },
          helpText: 'Upload samples of your work (articles, photos, videos, audio)'
        }
      ]
    };
  }

  // Customizations for Culinary entries
  if (categoryGroup === 'culinary') {
    customizations.entry_details = {
      addFields: [
        {
          id: 'cuisine_type',
          name: 'cuisine_type',
          type: 'multiselect',
          label: 'Cuisine Type/Specialization',
          required: true,
          options: [
            { value: 'traditional_kenyan', label: 'Traditional Kenyan' },
            { value: 'continental', label: 'Continental' },
            { value: 'asian', label: 'Asian' },
            { value: 'mediterranean', label: 'Mediterranean' },
            { value: 'indian', label: 'Indian' },
            { value: 'italian', label: 'Italian' },
            { value: 'french', label: 'French' },
            { value: 'fusion', label: 'Fusion' },
            { value: 'seafood', label: 'Seafood' },
            { value: 'vegetarian', label: 'Vegetarian/Vegan' },
            { value: 'halal', label: 'Halal Certified' },
            { value: 'fine_dining', label: 'Fine Dining' },
            { value: 'casual_dining', label: 'Casual Dining' }
          ]
        },
        {
          id: 'dining_capacity',
          name: 'dining_capacity',
          type: 'number',
          label: 'Dining Capacity (number of guests)',
          required: true,
          validation: { min: 1, max: 5000 }
        },
        {
          id: 'chef_credentials',
          name: 'chef_credentials',
          type: 'textarea',
          label: 'Chef Credentials & Experience',
          placeholder: 'Head chef qualifications, experience, awards',
          required: false,
          validation: { maxWords: 200 }
        }
      ]
    };

    customizations.attachments = {
      addFields: [
        {
          id: 'menu_samples',
          name: 'menu_samples',
          type: 'file',
          label: 'Current Menus & Food Images',
          required: true,
          validation: { 
            maxFiles: 10, 
            maxFileSize: 5,
            fileTypes: ['application/pdf', 'image/png', 'image/jpeg']
          },
          helpText: 'Upload current menus and high-quality food photography'
        }
      ]
    };
  }

  // Customizations for Transport entries
  if (categoryGroup === 'transport') {
    customizations.basic_info = {
      addFields: [
        {
          id: 'fleet_size',
          name: 'fleet_size',
          type: 'number',
          label: 'Fleet Size',
          placeholder: 'Number of vehicles/aircraft',
          required: false,
          validation: { min: 1, max: 10000 }
        },
        {
          id: 'service_routes',
          name: 'service_routes',
          type: 'textarea',
          label: 'Service Routes/Destinations',
          placeholder: 'List primary routes or destinations served',
          required: true,
          validation: { maxWords: 150 }
        }
      ]
    };

    customizations.entry_details = {
      addFields: [
        {
          id: 'safety_certifications',
          name: 'safety_certifications',
          type: 'textarea',
          label: 'Safety Certifications & Standards',
          placeholder: 'List relevant safety certifications and compliance standards',
          required: true,
          validation: { maxWords: 200 }
        }
      ]
    };
  }

  // Customizations for Destinations
  if (categoryGroup === 'destinations') {
    customizations.basic_info = {
      addFields: [
        {
          id: 'nominating_authority',
          name: 'nominating_authority',
          type: 'text',
          label: 'Nominating Authority/Body',
          placeholder: 'County government, tourism board, conservancy, etc.',
          required: true,
          validation: { maxLength: 255 }
        }
      ]
    };

    customizations.entry_details = {
      addFields: [
        {
          id: 'tourism_attractions',
          name: 'tourism_attractions',
          type: 'textarea',
          label: 'Major Tourism Attractions',
          placeholder: 'List key attractions and activities available',
          required: true,
          validation: { minLength: 50, maxWords: 250 }
        },
        {
          id: 'visitor_facilities',
          name: 'visitor_facilities',
          type: 'textarea',
          label: 'Visitor Facilities & Infrastructure',
          placeholder: 'Describe accommodation, transport, and visitor services',
          required: true,
          validation: { minLength: 30, maxWords: 200 }
        },
        {
          id: 'conservation_efforts',
          name: 'conservation_efforts',
          type: 'textarea',
          label: 'Conservation & Sustainability Efforts',
          placeholder: 'Describe environmental and community conservation initiatives',
          required: false,
          validation: { maxWords: 200 }
        }
      ]
    };
  }

  // Add special fields for Facilities group
  if (categoryGroup === 'facilities') {
    // Add specific fields based on category
    if (categoryName.includes('Hotel') || categoryName.includes('Lodge') || categoryName.includes('Resort')) {
      customizations.entry_details = {
        addFields: [
          {
            id: 'room_count',
            name: 'room_count',
            type: 'number',
            label: 'Number of Rooms/Units',
            required: true,
            validation: { min: 1, max: 2000 }
          },
          {
            id: 'hotel_classification',
            name: 'hotel_classification',
            type: 'select',
            label: 'Hotel Classification',
            required: false,
            options: [
              { value: '3_star', label: '3 Star' },
              { value: '4_star', label: '4 Star' },
              { value: '5_star', label: '5 Star' },
              { value: 'boutique', label: 'Boutique' },
              { value: 'resort', label: 'Resort' },
              { value: 'lodge', label: 'Lodge' },
              { value: 'camp', label: 'Camp' }
            ]
          }
        ]
      };
    }

    if (categoryName.includes('Restaurant')) {
      customizations.entry_details = {
        addFields: [
          {
            id: 'seating_capacity',
            name: 'seating_capacity',
            type: 'number',
            label: 'Seating Capacity',
            required: true,
            validation: { min: 10, max: 1000 }
          }
        ]
      };
    }
  }

  return customizations;
};

// Apply customizations to base template
const applyCustomizations = (sections: any[], customizations: Record<string, any>) => {
  return sections.map(section => {
    const sectionCustom = customizations[section.id];
    if (!sectionCustom) return section;

    let newFields = [...section.fields];

    // Remove fields
    if (sectionCustom.removeFields) {
      newFields = newFields.filter(field => !sectionCustom.removeFields.includes(field.name));
    }

    // Modify existing fields
    if (sectionCustom.modifyFields) {
      newFields = newFields.map(field => {
        const modifications = sectionCustom.modifyFields[field.name];
        return modifications ? { ...field, ...modifications } : field;
      });
    }

    // Add new fields
    if (sectionCustom.addFields) {
      newFields.push(...sectionCustom.addFields);
    }

    return {
      ...section,
      fields: newFields
    };
  });
};

// Generate form definitions for all categories
export const generateFormDefinitions = (): Omit<FormDefinition, 'id' | 'createdAt' | 'updatedAt'>[] => {
  return categories.map(category => {
    const customizations = getCategorySpecificFields(category.group, category.name);
    const customizedSections = applyCustomizations(baseFormSections, customizations);
    
    return {
      slug: category.id,
      categoryGroup: category.group,
      category: category.name,
      title: `Entry Form - ${category.name}`,
      description: category.description,
      schema: {
        sections: customizedSections,
        requirements: category.requirements,
        maxAttachments: 15,
        allowedFileTypes: ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'svg', 'mp4', 'mov', 'mp3'],
        maxFileSize: 10,
        helpText: `Please ensure all required fields are completed and files are in the specified formats. ${
          category.group === 'icons' ? 'For individual nominations, focus on professional achievements and impact.' :
          category.group === 'media' ? 'Include portfolio samples and engagement metrics to demonstrate reach and impact.' :
          category.group === 'culinary' ? 'Showcase your cuisine specialization and dining experience quality.' :
          'Highlight what makes your nominee exceptional in this category.'
        }`
      },
      published: true,
      version: 1,
      metadata: {
        categoryId: category.id,
        categoryGroup: category.group,
        isActive: category.isActive,
        createdFromTemplate: true,
        templateVersion: '2.0',
        lastReviewed: new Date().toISOString()
      },
      createdBy: 'system'
    };
  });
};

// Export the generated templates
export const entryFormTemplates = generateFormDefinitions();

// Scoring rubric templates for different category groups
export const scoringRubrics = {
  facilities: [
    { criterion: 'Service Excellence', weight: 30, maxScore: 10 },
    { criterion: 'Innovation & Uniqueness', weight: 25, maxScore: 10 },
    { criterion: 'Guest Experience', weight: 25, maxScore: 10 },
    { criterion: 'Sustainability Practices', weight: 20, maxScore: 10 }
  ],
  culinary: [
    { criterion: 'Food Quality & Taste', weight: 35, maxScore: 10 },
    { criterion: 'Service Excellence', weight: 25, maxScore: 10 },
    { criterion: 'Ambiance & Atmosphere', weight: 20, maxScore: 10 },
    { criterion: 'Value for Money', weight: 20, maxScore: 10 }
  ],
  transport: [
    { criterion: 'Service Quality', weight: 30, maxScore: 10 },
    { criterion: 'Safety & Reliability', weight: 30, maxScore: 10 },
    { criterion: 'Innovation', weight: 20, maxScore: 10 },
    { criterion: 'Customer Satisfaction', weight: 20, maxScore: 10 }
  ],
  destinations: [
    { criterion: 'Tourism Appeal', weight: 30, maxScore: 10 },
    { criterion: 'Infrastructure & Facilities', weight: 25, maxScore: 10 },
    { criterion: 'Conservation Efforts', weight: 25, maxScore: 10 },
    { criterion: 'Community Impact', weight: 20, maxScore: 10 }
  ],
  icons: [
    { criterion: 'Industry Impact', weight: 40, maxScore: 10 },
    { criterion: 'Leadership & Innovation', weight: 30, maxScore: 10 },
    { criterion: 'Professional Achievement', weight: 20, maxScore: 10 },
    { criterion: 'Community Contribution', weight: 10, maxScore: 10 }
  ],
  media: [
    { criterion: 'Content Quality', weight: 35, maxScore: 10 },
    { criterion: 'Audience Engagement', weight: 30, maxScore: 10 },
    { criterion: 'Tourism Promotion Impact', weight: 25, maxScore: 10 },
    { criterion: 'Professional Standards', weight: 10, maxScore: 10 }
  ]
};