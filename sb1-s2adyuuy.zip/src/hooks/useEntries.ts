import { useState, useCallback } from 'react';
import { useAuth } from './useAuth';
import { 
  FormDefinition, 
  Submission, 
  ProcessState, 
  SubmissionReview,
  PRIVILEGE_TYPES 
} from '../types/entries';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const useEntries = () => {
  const { user } = useAuth();
  const [formDefinitions, setFormDefinitions] = useState<FormDefinition[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [processState, setProcessState] = useState<ProcessState | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {
      'apikey': supabaseAnonKey,
      'Content-Type': 'application/json'
    };
    
    return headers;
  };
  const fetchFormDefinitions = useCallback(async (publishedOnly: boolean = false) => {
    try {
      setIsLoading(true);
      setError(null);

      let url = `${supabaseUrl}/rest/v1/form_definitions?select=*&order=category_group,category`;
      if (publishedOnly) {
        url += '&published=eq.true';
      }

      const response = await fetch(url, {
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        throw new Error('Failed to fetch form definitions');
      }

      const data = await response.json();
      const forms = data.map((item: any): FormDefinition => ({
        id: item.id,
        slug: item.slug,
        categoryGroup: item.category_group,
        category: item.category,
        title: item.title,
        description: item.description,
        schema: item.schema,
        published: item.published,
        version: item.version,
        metadata: item.metadata,
        createdBy: item.created_by,
        updatedBy: item.updated_by,
        createdAt: new Date(item.created_at),
        updatedAt: new Date(item.updated_at)
      }));
      
      setFormDefinitions(forms);
      return forms;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createFormDefinition = useCallback(async (formData: Omit<FormDefinition, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/form_definitions`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          slug: formData.slug,
          category_group: formData.categoryGroup,
          category: formData.category,
          title: formData.title,
          description: formData.description,
          schema: formData.schema,
          published: formData.published,
          version: formData.version,
          metadata: formData.metadata,
          created_by: formData.createdBy,
          updated_by: formData.createdBy
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create form definition');
      }

      const newForm = await response.json();
      setFormDefinitions(prev => [...prev, newForm[0]]);
      return newForm[0];
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateFormDefinition = useCallback(async (formId: string, updates: Partial<FormDefinition>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/form_definitions?id=eq.${formId}`, {
        method: 'PATCH',
        headers: {
          ...getAuthHeaders(),
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          slug: updates.slug,
          title: updates.title,
          description: updates.description,
          schema: updates.schema,
          published: updates.published,
          metadata: updates.metadata,
          updated_by: updates.updatedBy,
          version: updates.version
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update form definition');
      }

      const updatedForm = await response.json();
      setFormDefinitions(prev => prev.map(form => 
        form.id === formId ? updatedForm[0] : form
      ));
      return updatedForm[0];
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchSubmissions = useCallback(async (filters?: { 
    status?: string; 
    category?: string; 
    submitterId?: string; 
  }) => {
    try {
      setIsLoading(true);
      setError(null);

      let url = `${supabaseUrl}/rest/v1/submissions?select=*&order=created_at.desc`;
      
      if (filters?.status && filters.status !== 'all') {
        url += `&status=eq.${filters.status}`;
      }
      if (filters?.category && filters.category !== 'all') {
        url += `&category=eq.${filters.category}`;
      }
      if (filters?.submitterId) {
        url += `&submitter_id=eq.${filters.submitterId}`;
      }

      const response = await fetch(url, {
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        throw new Error('Failed to fetch submissions');
      }

      const data = await response.json();
      const submissions = data.map((item: any): Submission => ({
        id: item.id,
        formDefinitionId: item.form_definition_id,
        categoryGroup: item.category_group,
        category: item.category,
        submitterId: item.submitter_id,
        submitterEmail: item.submitter_email,
        nomineeName: item.nominee_name,
        organizationName: item.organization_name,
        contactPerson: item.contact_person,
        contactEmail: item.contact_email,
        contactPhone: item.contact_phone,
        county: item.county,
        yearEstablished: item.year_established,
        physicalAddress: item.physical_address,
        websiteUrl: item.website_url,
        nomineeDetails: item.nominee_details,
        attachments: item.attachments,
        status: item.status,
        juryScore: item.jury_score,
        publicVotes: item.public_votes,
        totalScore: item.total_score,
        rejectionReason: item.rejection_reason,
        reviewNotes: item.review_notes,
        priority: item.priority,
        featured: item.featured,
        submissionIp: item.submission_ip,
        submissionUserAgent: item.submission_user_agent,
        createdAt: new Date(item.created_at),
        updatedAt: new Date(item.updated_at)
      }));
      
      setSubmissions(submissions);
      return submissions;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createSubmission = useCallback(async (submissionData: Partial<Submission>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/submissions`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          form_definition_id: submissionData.formDefinitionId,
          category_group: submissionData.categoryGroup,
          category: submissionData.category,
          submitter_id: submissionData.submitterId,
          submitter_email: submissionData.submitterEmail,
          nominee_name: submissionData.nomineeName,
          organization_name: submissionData.organizationName,
          contact_person: submissionData.contactPerson,
          contact_email: submissionData.contactEmail,
          contact_phone: submissionData.contactPhone,
          county: submissionData.county,
          year_established: submissionData.yearEstablished,
          physical_address: submissionData.physicalAddress,
          website_url: submissionData.websiteUrl,
          nominee_details: submissionData.nomineeDetails,
          attachments: submissionData.attachments,
          status: submissionData.status || 'pending',
          priority: submissionData.priority || 0,
          featured: submissionData.featured || false,
          submission_user_agent: submissionData.submissionUserAgent
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create submission');
      }

      const newSubmission = await response.json();
      setSubmissions(prev => [newSubmission[0], ...prev]);
      return newSubmission[0];
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateSubmissionStatus = useCallback(async (
    submissionId: string, 
    status: Submission['status'],
    reviewNotes?: string,
    rejectionReason?: string
  ) => {
    try {
      setIsLoading(true);
      setError(null);

      const updateData: any = { status };
      if (reviewNotes) updateData.review_notes = reviewNotes;
      if (rejectionReason) updateData.rejection_reason = rejectionReason;

      const response = await fetch(`${supabaseUrl}/rest/v1/submissions?id=eq.${submissionId}`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify(updateData)
      });

      if (!response.ok) {
        throw new Error('Failed to update submission status');
      }

      setSubmissions(prev => prev.map(sub => 
        sub.id === submissionId 
          ? { ...sub, status, reviewNotes, rejectionReason }
          : sub
      ));

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [user?.accessToken]);

  const fetchProcessState = useCallback(async () => {
    try {
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/process_state?id=eq.1`, {
        headers: getAuthHeaders()
      });

      if (response.ok) {
        const data = await response.json();
        if (data.length > 0) {
          const item = data[0];
          setProcessState({
            id: item.id,
            currentStage: item.current_stage,
            stageStart: item.stage_start ? new Date(item.stage_start) : undefined,
            stageEnd: item.stage_end ? new Date(item.stage_end) : undefined,
            autoTransition: item.auto_transition,
            stageMetadata: item.stage_metadata,
            updatedBy: item.updated_by,
            updatedAt: new Date(item.updated_at)
          });
        } else {
          // If no process state exists, create initial state and start entries
          await updateProcessState({
            currentStage: 'entries_open',
            stageStart: new Date(),
            stageEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
            autoTransition: {
              entries_to_vetting: { enabled: false, delay_hours: 24 },
              vetting_to_voting: { enabled: false, delay_hours: 48 },
              voting_to_results: { enabled: false, delay_hours: 12 }
            },
            stageMetadata: {
              entries_target: 300,
              categories_active: 28,
              auto_started: true
            },
            updatedBy: 'system'
          });
        }
      }
    } catch (err) {
      console.error('Error fetching process state:', err);
    }
  }, []);

  const updateProcessState = useCallback(async (updates: Partial<ProcessState>) => {
    try {
      setIsLoading(true);

      const updateData: any = {};
      if (updates.currentStage) updateData.current_stage = updates.currentStage;
      if (updates.stageStart) updateData.stage_start = updates.stageStart.toISOString();
      if (updates.stageEnd) updateData.stage_end = updates.stageEnd.toISOString();
      if (updates.autoTransition) updateData.auto_transition = updates.autoTransition;
      if (updates.stageMetadata) updateData.stage_metadata = updates.stageMetadata;
      if (updates.updatedBy) updateData.updated_by = updates.updatedBy;

      const response = await fetch(`${supabaseUrl}/rest/v1/process_state?id=eq.1`, {
        method: 'PATCH',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify(updateData)
      });

      if (response.ok) {
        const updated = await response.json();
        setProcessState(prev => prev ? { ...prev, ...updates } : null);
        return updated[0];
      }
    } catch (err) {
      console.error('Error updating process state:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    formDefinitions,
    submissions,
    processState,
    isLoading,
    error,
    fetchFormDefinitions,
    createFormDefinition,
    updateFormDefinition,
    fetchSubmissions,
    createSubmission,
    updateSubmissionStatus,
    fetchProcessState,
    updateProcessState
  };
};

export const useSubmissionReviews = () => {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<SubmissionReview[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const getAuthHeaders = () => {
    const token = user?.accessToken || supabaseAnonKey;
    return {
      'apikey': supabaseAnonKey,
      'Authorization': `Bearer ${token}`
    };
  };
  const fetchReviews = useCallback(async (submissionId: string) => {
    try {
      setIsLoading(true);

      const response = await fetch(
        `${supabaseUrl}/rest/v1/submission_reviews?submission_id=eq.${submissionId}&select=*`,
        {
          headers: getAuthHeaders()
        }
      );

      if (response.ok) {
        const data = await response.json();
        setReviews(data);
        return data;
      }
    } catch (err) {
      console.error('Error fetching reviews:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createReview = useCallback(async (reviewData: Omit<SubmissionReview, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/submission_reviews`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          submission_id: reviewData.submissionId,
          reviewer_id: reviewData.reviewerId,
          reviewer_role: reviewData.reviewerRole,
          scores: reviewData.scores,
          overall_score: reviewData.overallScore,
          comments: reviewData.comments,
          recommendations: reviewData.recommendations,
          review_status: reviewData.reviewStatus
        })
      });

      if (response.ok) {
        const newReview = await response.json();
        setReviews(prev => [...prev, newReview[0]]);
        return newReview[0];
      }
    } catch (err) {
      console.error('Error creating review:', err);
      throw err;
    }
  }, [user?.accessToken]);

  return {
    reviews,
    isLoading,
    fetchReviews,
    createReview
  };
};