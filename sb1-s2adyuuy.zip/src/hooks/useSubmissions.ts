import { useState, useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';
import { 
  FormDefinition, 
  Submission, 
  ProcessState, 
  UserPrivilege, 
  SubmissionReview,
  PRIVILEGE_TYPES 
} from '../types/submissions';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const useSubmissions = () => {
  const { user } = useAuth();
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {
      'apikey': supabaseAnonKey,
      'Content-Type': 'application/json'
    };
    
    // Only add Authorization header if we have a valid JWT token
    if (user?.accessToken) {
      headers['Authorization'] = `Bearer ${user.accessToken}`;
    }
    
    return headers;
  };
  const fetchSubmissions = useCallback(async (filters?: { 
    status?: string; 
    category?: string; 
    submitterId?: string; 
  }) => {
    try {
      setIsLoading(true);
      setError(null);

      let url = `${supabaseUrl}/rest/v1/submissions?select=*&order=created_at.desc`;
      
      if (filters?.status && filters.status !== 'all') {
        url += `&status=eq.${filters.status}`;
      }
      if (filters?.category && filters.category !== 'all') {
        url += `&category=eq.${filters.category}`;
      }
      if (filters?.submitterId) {
        url += `&submitter_id=eq.${filters.submitterId}`;
      }

      const response = await fetch(url, {
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        throw new Error('Failed to fetch submissions');
      }

      const data = await response.json();
      const submissions = data.map((item: any): Submission => ({
        id: item.id,
        formDefinitionId: item.form_definition_id,
        categoryGroup: item.category_group,
        category: item.category,
        submitterId: item.submitter_id,
        submitterEmail: item.submitter_email,
        nomineeName: item.nominee_name,
        organizationName: item.organization_name,
        contactPerson: item.contact_person,
        contactEmail: item.contact_email,
        contactPhone: item.contact_phone,
        county: item.county,
        yearEstablished: item.year_established,
        physicalAddress: item.physical_address,
        websiteUrl: item.website_url,
        nomineeDetails: item.nominee_details,
        attachments: item.attachments,
        status: item.status,
        juryScore: item.jury_score,
        publicVotes: item.public_votes,
        totalScore: item.total_score,
        rejectionReason: item.rejection_reason,
        reviewNotes: item.review_notes,
        priority: item.priority,
        featured: item.featured,
        submissionIp: item.submission_ip,
        submissionUserAgent: item.submission_user_agent,
        createdAt: new Date(item.created_at),
        updatedAt: new Date(item.updated_at)
      }));
      
      setSubmissions(submissions);
      return submissions;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createSubmission = useCallback(async (submissionData: Omit<Submission, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/submissions`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          form_definition_id: submissionData.formDefinitionId,
          category_group: submissionData.categoryGroup,
          category: submissionData.category,
          submitter_id: submissionData.submitterId,
          submitter_email: submissionData.submitterEmail,
          nominee_name: submissionData.nomineeName,
          organization_name: submissionData.organizationName,
          contact_person: submissionData.contactPerson,
          contact_email: submissionData.contactEmail,
          contact_phone: submissionData.contactPhone,
          county: submissionData.county,
          year_established: submissionData.yearEstablished,
          physical_address: submissionData.physicalAddress,
          website_url: submissionData.websiteUrl,
          nominee_details: submissionData.nomineeDetails,
          attachments: submissionData.attachments,
          status: submissionData.status,
          priority: submissionData.priority,
          featured: submissionData.featured,
          submission_ip: submissionData.submissionIp,
          submission_user_agent: submissionData.submissionUserAgent
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create submission');
      }

      const newSubmission = await response.json();
      const submission = newSubmission[0];
      setSubmissions(prev => [submission, ...prev]);
      return submission;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateSubmissionStatus = useCallback(async (
    submissionId: string, 
    status: Submission['status'],
    reviewNotes?: string,
    rejectionReason?: string
  ) => {
    try {
      setIsLoading(true);
      setError(null);

      const updateData: any = { status };
      if (reviewNotes) updateData.review_notes = reviewNotes;
      if (rejectionReason) updateData.rejection_reason = rejectionReason;

      const response = await fetch(`${supabaseUrl}/rest/v1/submissions?id=eq.${submissionId}`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify(updateData)
      });

      if (!response.ok) {
        throw new Error('Failed to update submission status');
      }

      setSubmissions(prev => prev.map(sub => 
        sub.id === submissionId 
          ? { ...sub, status, reviewNotes, rejectionReason }
          : sub
      ));

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [user?.accessToken]);

  return {
    submissions,
    isLoading,
    error,
    fetchSubmissions,
    createSubmission,
    updateSubmissionStatus
  };
};

export const useFormDefinitions = () => {
  const { user } = useAuth();
  const [forms, setForms] = useState<FormDefinition[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {
      'apikey': supabaseAnonKey,
      'Content-Type': 'application/json'
    };
    
    // Only add Authorization header if we have a valid JWT token
    if (user?.accessToken) {
      headers['Authorization'] = `Bearer ${user.accessToken}`;
    }
    
    return headers;
  };
  const fetchForms = useCallback(async (publishedOnly: boolean = false) => {
    try {
      setIsLoading(true);
      setError(null);

      let url = `${supabaseUrl}/rest/v1/form_definitions?select=*&order=category_group,category`;
      if (publishedOnly) {
        url += '&published=eq.true';
      }

      const response = await fetch(url, {
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        throw new Error('Failed to fetch forms');
      }

      const data = await response.json();
      const forms = data.map((item: any): FormDefinition => ({
        id: item.id,
        slug: item.slug,
        categoryGroup: item.category_group,
        category: item.category,
        title: item.title,
        description: item.description,
        schema: item.schema,
        published: item.published,
        version: item.version,
        metadata: item.metadata,
        createdBy: item.created_by,
        updatedBy: item.updated_by,
        createdAt: new Date(item.created_at),
        updatedAt: new Date(item.updated_at)
      }));
      
      setForms(forms);
      return forms;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createForm = useCallback(async (formData: Omit<FormDefinition, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/form_definitions`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          slug: formData.slug,
          category_group: formData.categoryGroup,
          category: formData.category,
          title: formData.title,
          description: formData.description,
          schema: formData.schema,
          published: formData.published,
          version: formData.version,
          metadata: formData.metadata,
          created_by: formData.createdBy,
          updated_by: formData.createdBy
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create form');
      }

      const newForm = await response.json();
      setForms(prev => [...prev, newForm[0]]);
      return newForm[0];
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateForm = useCallback(async (formId: string, updates: Partial<FormDefinition>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/form_definitions?id=eq.${formId}`, {
        method: 'PATCH',
        headers: {
          ...getAuthHeaders(),
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          slug: updates.slug,
          title: updates.title,
          description: updates.description,
          schema: updates.schema,
          published: updates.published,
          metadata: updates.metadata,
          updated_by: updates.updatedBy
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update form');
      }

      const updatedForm = await response.json();
      setForms(prev => prev.map(form => 
        form.id === formId ? updatedForm[0] : form
      ));
      return updatedForm[0];
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [user?.accessToken]);

  return {
    forms,
    isLoading,
    error,
    fetchForms,
    createForm,
    updateForm
  };
};

export const useProcessState = () => {
  const { user } = useAuth();
  const [state, setState] = useState<ProcessState | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {
      'apikey': supabaseAnonKey,
      'Content-Type': 'application/json'
    };
    
    // Only add Authorization header if we have a valid JWT token
    if (user?.accessToken) {
      headers['Authorization'] = `Bearer ${user.accessToken}`;
    }
    
    return headers;
  };
  const fetchProcessState = useCallback(async () => {
    try {
      setIsLoading(true);

      const response = await fetch(`${supabaseUrl}/rest/v1/process_state?id=eq.1`, {
        headers: getAuthHeaders()
      });

      if (response.ok) {
        const data = await response.json();
        if (data.length > 0) {
          const item = data[0];
          setState({
            id: item.id,
            currentStage: item.current_stage,
            stageStart: item.stage_start ? new Date(item.stage_start) : undefined,
            stageEnd: item.stage_end ? new Date(item.stage_end) : undefined,
            autoTransition: item.auto_transition,
            stageMetadata: item.stage_metadata,
            updatedBy: item.updated_by,
            updatedAt: new Date(item.updated_at)
          });
        }
      }
    } catch (err) {
      console.error('Error fetching process state:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateProcessState = useCallback(async (updates: Partial<ProcessState>) => {
    try {
      setIsLoading(true);

      const updateData: any = {};
      if (updates.currentStage) updateData.current_stage = updates.currentStage;
      if (updates.stageStart) updateData.stage_start = updates.stageStart.toISOString();
      if (updates.stageEnd) updateData.stage_end = updates.stageEnd.toISOString();
      if (updates.autoTransition) updateData.auto_transition = updates.autoTransition;
      if (updates.stageMetadata) updateData.stage_metadata = updates.stageMetadata;
      if (updates.updatedBy) updateData.updated_by = updates.updatedBy;

      const response = await fetch(`${supabaseUrl}/rest/v1/process_state?id=eq.1`, {
        method: 'PATCH',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify(updateData)
      });

      if (response.ok) {
        const updated = await response.json();
        setState(prev => prev ? { ...prev, ...updates } : null);
        return updated[0];
      }
    } catch (err) {
      console.error('Error updating process state:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [user?.accessToken]);

  return {
    state,
    isLoading,
    fetchProcessState,
    updateProcessState
  };
};

export const useUserPrivileges = () => {
  const { user } = useAuth();
  const [privileges, setPrivileges] = useState<UserPrivilege[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {
      'apikey': supabaseAnonKey
    };
    
    return headers;
  };
  const fetchUserPrivileges = useCallback(async (userId: string) => {
    try {
      setIsLoading(true);

      const response = await fetch(
        `${supabaseUrl}/rest/v1/user_privileges?user_id=eq.${userId}&is_active=eq.true&select=*`,
        {
          headers: getAuthHeaders()
        }
      );

      if (response.ok) {
        const data = await response.json();
        setPrivileges(data);
        return data;
      }
    } catch (err) {
      console.error('Error fetching user privileges:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const grantPrivilege = useCallback(async (
    userId: string,
    privilegeType: string,
    resourceType?: string,
    resourceId?: string,
    grantedBy?: string,
    expiresAt?: Date,
    accessToken?: string
  ) => {
    try {
      const authToken = accessToken || supabaseAnonKey;
      const response = await fetch(`${supabaseUrl}/rest/v1/user_privileges`, {
        method: 'POST',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          user_id: userId,
          privilege_type: privilegeType,
          resource_type: resourceType,
          resource_id: resourceId,
          granted_by: grantedBy,
          expires_at: expiresAt?.toISOString(),
          is_active: true
        })
      });

      if (response.ok) {
        const newPrivilege = await response.json();
        setPrivileges(prev => [...prev, newPrivilege[0]]);
        return newPrivilege[0];
      }
    } catch (err) {
      console.error('Error granting privilege:', err);
      throw err;
    }
  }, []);

  const revokePrivilege = useCallback(async (privilegeId: string, accessToken?: string) => {
    try {
      const authToken = accessToken || supabaseAnonKey;
      const response = await fetch(`${supabaseUrl}/rest/v1/user_privileges?id=eq.${privilegeId}`, {
        method: 'PATCH',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ is_active: false })
      });

      if (response.ok) {
        setPrivileges(prev => prev.map(priv => 
          priv.id === privilegeId ? { ...priv, isActive: false } : priv
        ));
      }
    } catch (err) {
      console.error('Error revoking privilege:', err);
      throw err;
    }
  }, []);

  const hasPrivilege = useCallback((
    userPrivileges: UserPrivilege[], 
    requiredPrivilege: string,
    resourceType?: string
  ): boolean => {
    return userPrivileges.some(priv => 
      priv.isActive && 
      (priv.privilegeType === PRIVILEGE_TYPES.FULL_ACCESS || 
       priv.privilegeType === requiredPrivilege) &&
      (!resourceType || !priv.resourceType || priv.resourceType === resourceType)
    );
  }, []);

  return {
    privileges,
    isLoading,
    fetchUserPrivileges,
    grantPrivilege,
    revokePrivilege,
    hasPrivilege
  };
};