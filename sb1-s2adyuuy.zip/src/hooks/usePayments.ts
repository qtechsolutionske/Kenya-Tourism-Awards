import { useState, useCallback } from 'react';
import { Payment, PaymentMethod, MPESASTKResponse, PaystackInitResponse, PaymentStatusResponse } from '../types/payment';

export const usePayments = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  const getPaymentMethods = useCallback(async (): Promise<PaymentMethod[]> => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/payment_methods?is_enabled=eq.true&order=sort_order`, {
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch payment methods');
      }

      const data = await response.json();
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [supabaseUrl, supabaseAnonKey]);

  const initiateMPESAPayment = useCallback(async (
    phone: string,
    amount: number,
    orderId: string,
    accountReference: string,
    transactionDesc: string
  ): Promise<MPESASTKResponse> => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/functions/v1/payments-mpesa/initiate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          phone,
          amount,
          orderId,
          accountReference,
          transactionDesc
        })
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'MPESA payment initiation failed');
      }

      return data;
    } catch (err) {
      const error = err instanceof Error ? err.message : 'Unknown error';
      setError(error);
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  }, [supabaseUrl, supabaseAnonKey]);

  const initiatePaystackPayment = useCallback(async (
    email: string,
    amount: number,
    orderId: string,
    currency: string = 'KES',
    metadata: Record<string, any> = {}
  ): Promise<PaystackInitResponse> => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/functions/v1/payments-paystack/initialize`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email,
          amount,
          orderId,
          currency,
          metadata
        })
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Paystack payment initiation failed');
      }

      return data;
    } catch (err) {
      const error = err instanceof Error ? err.message : 'Unknown error';
      setError(error);
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  }, [supabaseUrl, supabaseAnonKey]);

  const checkPaymentStatus = useCallback(async (paymentId: string): Promise<PaymentStatusResponse> => {
    try {
      setIsLoading(true);
      setError(null);

      // Try MPESA first
      let response = await fetch(`${supabaseUrl}/functions/v1/payments-mpesa/status?payment_id=${paymentId}`, {
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
        }
      });

      if (!response.ok) {
        // Try Paystack
        response = await fetch(`${supabaseUrl}/functions/v1/payments-paystack/verify?payment_id=${paymentId}`, {
          headers: {
            'Authorization': `Bearer ${supabaseAnonKey}`,
          }
        });
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to check payment status');
      }

      return data;
    } catch (err) {
      const error = err instanceof Error ? err.message : 'Unknown error';
      setError(error);
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  }, [supabaseUrl, supabaseAnonKey]);

  const verifyPaystackPayment = useCallback(async (reference: string): Promise<PaymentStatusResponse> => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/functions/v1/payments-paystack/verify?reference=${reference}`, {
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
        }
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Payment verification failed');
      }

      return data;
    } catch (err) {
      const error = err instanceof Error ? err.message : 'Unknown error';
      setError(error);
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  }, [supabaseUrl, supabaseAnonKey]);

  return {
    isLoading,
    error,
    getPaymentMethods,
    initiateMPESAPayment,
    initiatePaystackPayment,
    checkPaymentStatus,
    verifyPaystackPayment
  };
};