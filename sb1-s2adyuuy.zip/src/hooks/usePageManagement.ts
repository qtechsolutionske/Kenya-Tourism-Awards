import { useState, useEffect, useCallback } from 'react';
import { Page, PageSection, PageRevision, NavigationItem } from '../types/pages';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const usePageManagement = () => {
  const [pages, setPages] = useState<Page[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPages = useCallback(async (filters?: { status?: string; visibility?: string; template?: string }) => {
    try {
      setIsLoading(true);
      setError(null);

      let url = `${supabaseUrl}/rest/v1/pages?select=*&order=navigation_order`;
      
      if (filters?.status && filters.status !== 'all') {
        url += `&status=eq.${filters.status}`;
      }
      if (filters?.visibility && filters.visibility !== 'all') {
        url += `&visibility=eq.${filters.visibility}`;
      }
      if (filters?.template && filters.template !== 'all') {
        url += `&template_type=eq.${filters.template}`;
      }

      const response = await fetch(url, {
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch pages');
      }

      const data = await response.json();
      setPages(data);
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createPage = useCallback(async (pageData: Omit<Page, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/pages`, {
        method: 'POST',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          title: pageData.title,
          slug: pageData.slug,
          template_type: pageData.templateType,
          status: pageData.status,
          visibility: pageData.visibility,
          meta_title: pageData.metaTitle,
          meta_description: pageData.metaDescription,
          meta_keywords: pageData.metaKeywords,
          og_title: pageData.ogTitle,
          og_description: pageData.ogDescription,
          og_image: pageData.ogImage,
          featured_image: pageData.featuredImage,
          excerpt: pageData.excerpt,
          show_in_navigation: pageData.showInNavigation,
          navigation_parent_id: pageData.navigationParentId,
          navigation_order: pageData.navigationOrder,
          created_by: pageData.createdBy,
          updated_by: pageData.createdBy
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create page');
      }

      const newPage = await response.json();
      setPages(prev => [...prev, newPage[0]]);
      return newPage[0];
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updatePage = useCallback(async (pageId: string, updates: Partial<Page>) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/pages?id=eq.${pageId}`, {
        method: 'PATCH',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          title: updates.title,
          slug: updates.slug,
          template_type: updates.templateType,
          status: updates.status,
          visibility: updates.visibility,
          meta_title: updates.metaTitle,
          meta_description: updates.metaDescription,
          meta_keywords: updates.metaKeywords,
          og_title: updates.ogTitle,
          og_description: updates.ogDescription,
          og_image: updates.ogImage,
          featured_image: updates.featuredImage,
          excerpt: updates.excerpt,
          show_in_navigation: updates.showInNavigation,
          navigation_parent_id: updates.navigationParentId,
          navigation_order: updates.navigationOrder,
          updated_by: updates.updatedBy
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update page');
      }

      const updatedPage = await response.json();
      setPages(prev => prev.map(page => page.id === pageId ? updatedPage[0] : page));
      return updatedPage[0];
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const deletePage = useCallback(async (pageId: string) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/pages?id=eq.${pageId}`, {
        method: 'DELETE',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete page');
      }

      setPages(prev => prev.filter(page => page.id !== pageId));
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchPageSections = useCallback(async (pageId: string) => {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/page_sections?page_id=eq.${pageId}&order=section_order`, {
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch page sections');
      }

      return await response.json();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      return [];
    }
  }, []);

  const createSection = useCallback(async (sectionData: Omit<PageSection, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/page_sections`, {
        method: 'POST',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          page_id: sectionData.pageId,
          section_type: sectionData.sectionType,
          section_name: sectionData.sectionName,
          content: sectionData.content,
          styles: sectionData.styles,
          settings: sectionData.settings,
          is_visible: sectionData.isVisible,
          section_order: sectionData.sectionOrder,
          created_by: sectionData.createdBy,
          updated_by: sectionData.createdBy
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create section');
      }

      const newSection = await response.json();
      return newSection[0];
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    }
  }, []);

  const updateSection = useCallback(async (sectionId: string, updates: Partial<PageSection>) => {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/page_sections?id=eq.${sectionId}`, {
        method: 'PATCH',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          section_name: updates.sectionName,
          content: updates.content,
          styles: updates.styles,
          settings: updates.settings,
          is_visible: updates.isVisible,
          section_order: updates.sectionOrder,
          updated_by: updates.updatedBy
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update section');
      }

      const updatedSection = await response.json();
      return updatedSection[0];
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    }
  }, []);

  const deleteSection = useCallback(async (sectionId: string) => {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/page_sections?id=eq.${sectionId}`, {
        method: 'DELETE',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete section');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    }
  }, []);

  const generateSlug = useCallback((title: string) => {
    return title
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  }, []);

  return {
    pages,
    isLoading,
    error,
    fetchPages,
    createPage,
    updatePage,
    deletePage,
    fetchPageSections,
    createSection,
    updateSection,
    deleteSection,
    generateSlug
  };
};

export const usePageRevisions = () => {
  const [revisions, setRevisions] = useState<PageRevision[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchRevisions = useCallback(async (pageId: string) => {
    try {
      setIsLoading(true);
      const response = await fetch(`${supabaseUrl}/rest/v1/page_revisions?page_id=eq.${pageId}&order=created_at.desc`, {
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setRevisions(data);
      }
    } catch (err) {
      console.error('Error fetching revisions:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return { revisions, isLoading, fetchRevisions };
};