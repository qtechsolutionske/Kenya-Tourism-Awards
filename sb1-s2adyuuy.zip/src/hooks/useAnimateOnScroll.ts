import { useEffect } from 'react';

export const useAnimateOnScroll = () => {
  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    // Observe all elements with animate classes including section titles
    const animateElements = document.querySelectorAll('.animate-on-scroll, .section-title-animated');
    animateElements.forEach((el) => observer.observe(el));

    return () => {
      animateElements.forEach((el) => observer.unobserve(el));
    };
  }, []);
};

// Hook for manual animation triggering
export const useManualAnimation = () => {
  const triggerAnimation = (selector: string) => {
    const elements = document.querySelectorAll(selector);
    elements.forEach((el) => {
      if (el.classList.contains('animate-on-scroll')) {
        el.classList.add('animate-in');
      }
      if (el.classList.contains('section-title-animated')) {
        el.classList.add('animate-in');
      }
    });
  };

  return { triggerAnimation };
};

// Hook to apply section title animation classes to all headings
export const useSectionTitleAnimation = () => {
  useEffect(() => {
    // Find all h1, h2, h3 elements that don't already have animation classes
    const headings = document.querySelectorAll('h1, h2, h3');
    headings.forEach((heading) => {
      if (!heading.classList.contains('section-title-animated')) {
        heading.classList.add('section-title-animated');
      }
    });

    // Set up observer for newly added headings
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const element = node as Element;
            const newHeadings = element.querySelectorAll('h1, h2, h3');
            newHeadings.forEach((heading) => {
              if (!heading.classList.contains('section-title-animated')) {
                heading.classList.add('section-title-animated');
              }
            });
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    return () => {
      observer.disconnect();
    };
  }, []);
};