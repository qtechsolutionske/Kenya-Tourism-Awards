import { useState, useEffect, createContext, useContext } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useAuthState = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('kta-user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Demo users for different roles
    let mockUser: User;
    
    if (email.includes('superadmin')) {
      mockUser = {
        id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
        name: 'Super Administrator',
        email,
        role: 'superadmin',
        permissions: ['*'],
        accessToken: 'mock-superadmin-token-' + Date.now(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    } else if (email.includes('admin')) {
      mockUser = {
        id: 'b1ffcc88-8b1a-5df7-aa5c-5aa8bd381b22',
        name: 'System Administrator',
        email,
        role: 'admin' as const,
        permissions: ['manage_users', 'manage_nominations', 'view_reports'],
        accessToken: 'mock-admin-token-' + Date.now(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    } else if (email.includes('jury')) {
      mockUser = {
        id: 'c2eedd77-7a2b-6ee6-995b-699abd382c33',
        name: 'Jury Member',
        email,
        role: 'jury' as const,
        permissions: ['evaluate_nominations', 'view_assigned_categories'],
        accessToken: 'mock-jury-token-' + Date.now(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    } else {
      mockUser = {
        id: 'd3ffee66-6939-7ff5-884a-588abd383d44',
        name: 'Tourism Stakeholder',
        email,
        role: 'voter' as const,
        permissions: ['vote', 'view_nominees'],
        accessToken: 'mock-voter-token-' + Date.now(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    }
    
    // Add nominee role support
    if (email.includes('nominee')) {
      mockUser = {
        id: 'e4ffff55-5848-8ee4-773d-477abd384e55',
        name: 'Nominee User',
        email,
        role: 'nominee' as const,
        permissions: ['manage_profile', 'view_analytics', 'share_voting_link'],
        accessToken: 'mock-nominee-token-' + Date.now(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    }
    
    setUser(mockUser);
    localStorage.setItem('kta-user', JSON.stringify(mockUser));
    setIsLoading(false);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('kta-user');
  };

  return { user, login, logout, isLoading };
};

export { AuthContext };