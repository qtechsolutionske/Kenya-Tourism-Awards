import { useState, useCallback } from 'react';
import { useAuth } from './useAuth';
import { 
  VotingSettings, 
  Vote, 
  Voter, 
  VoteRequest, 
  VoteResponse, 
  VotingAnalytics,
  VoteConfirmation,
  VoteFraudLog
} from '../types/voting';
import { usePayments } from './usePayments';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const useVoting = () => {
  const { user } = useAuth();
  const { initiateMPESAPayment, initiatePaystackPayment } = usePayments();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {
      'apikey': supabaseAnonKey,
      'Content-Type': 'application/json'
    };
    
    if (user?.accessToken) {
      headers['Authorization'] = `Bearer ${user.accessToken}`;
    }
    
    return headers;
  };

  const fetchVotingSettings = useCallback(async (): Promise<VotingSettings | null> => {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/voting_settings?id=eq.1`, {
        headers: getAuthHeaders()
      });

      if (!response.ok) throw new Error('Failed to fetch voting settings');

      const data = await response.json();
      if (data.length === 0) return null;

      const item = data[0];
      return {
        id: item.id,
        votingMode: item.voting_mode,
        isVotingOpen: item.is_voting_open,
        feePerVote: parseFloat(item.fee_per_vote),
        bundleOptions: item.bundle_options,
        maxVotesPerEmailPerDay: item.max_votes_per_email_per_day,
        maxVotesPerIpPerDay: item.max_votes_per_ip_per_day,
        allowNomineeVoting: item.allow_nominee_voting,
        requireEmailVerification: item.require_email_verification,
        requirePhoneVerification: item.require_phone_verification,
        enableOtpVerification: item.enable_otp_verification,
        enableCaptcha: item.enable_captcha,
        blockedEmailDomains: item.blocked_email_domains,
        fraudDetectionEnabled: item.fraud_detection_enabled,
        fraudThresholdScore: item.fraud_threshold_score,
        emailConfirmationEnabled: item.email_confirmation_enabled,
        emailTemplateId: item.email_template_id,
        rateLimitWindowMinutes: item.rate_limit_window_minutes,
        referralEnabled: item.referral_enabled,
        referralBonusVotes: item.referral_bonus_votes,
        auditLoggingEnabled: item.audit_logging_enabled,
        publicLeaderboardEnabled: item.public_leaderboard_enabled,
        anonymousVotingEnabled: item.anonymous_voting_enabled,
        votingDeadline: item.voting_deadline ? new Date(item.voting_deadline) : undefined,
        updatedBy: item.updated_by,
        updatedAt: new Date(item.updated_at)
      };
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      return null;
    }
  }, []);

  const updateVotingSettings = useCallback(async (updates: Partial<VotingSettings>): Promise<boolean> => {
    if (user?.role !== 'superadmin') {
      setError('Only super administrators can modify voting settings');
      return false;
    }

    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`${supabaseUrl}/rest/v1/voting_settings?id=eq.1`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          voting_mode: updates.votingMode,
          is_voting_open: updates.isVotingOpen,
          fee_per_vote: updates.feePerVote,
          bundle_options: updates.bundleOptions,
          max_votes_per_email_per_day: updates.maxVotesPerEmailPerDay,
          max_votes_per_ip_per_day: updates.maxVotesPerIpPerDay,
          allow_nominee_voting: updates.allowNomineeVoting,
          require_email_verification: updates.requireEmailVerification,
          require_phone_verification: updates.requirePhoneVerification,
          enable_otp_verification: updates.enableOtpVerification,
          enable_captcha: updates.enableCaptcha,
          blocked_email_domains: updates.blockedEmailDomains,
          fraud_detection_enabled: updates.fraudDetectionEnabled,
          fraud_threshold_score: updates.fraudThresholdScore,
          email_confirmation_enabled: updates.emailConfirmationEnabled,
          voting_deadline: updates.votingDeadline?.toISOString(),
          updated_by: user?.id
        })
      });

      if (!response.ok) throw new Error('Failed to update voting settings');
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  const submitVote = useCallback(async (voteRequest: VoteRequest): Promise<VoteResponse> => {
    try {
      setIsLoading(true);
      setError(null);

      // Call the voting edge function
      const response = await fetch(`${supabaseUrl}/functions/v1/voting/submit`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(voteRequest)
      });

      if (!response.ok) throw new Error('Failed to submit vote');

      const result = await response.json();
      return result;
    } catch (err) {
      const error = err instanceof Error ? err.message : 'Unknown error';
      setError(error);
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  }, []);

  const verifyVoter = useCallback(async (email: string, token: string): Promise<boolean> => {
    try {
      const response = await fetch(`${supabaseUrl}/functions/v1/voting/verify`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ email, token })
      });

      const result = await response.json();
      return result.success;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      return false;
    }
  }, []);

  const getVotingAnalytics = useCallback(async (): Promise<VotingAnalytics | null> => {
    try {
      const response = await fetch(`${supabaseUrl}/functions/v1/voting/analytics`, {
        headers: getAuthHeaders()
      });

      if (!response.ok) throw new Error('Failed to fetch voting analytics');

      const result = await response.json();
      return result.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      return null;
    }
  }, []);

  const getVoterHistory = useCallback(async (voterEmail: string): Promise<Vote[]> => {
    try {
      const response = await fetch(
        `${supabaseUrl}/rest/v1/votes?voter_email=eq.${voterEmail}&select=*&order=vote_time.desc`,
        { headers: getAuthHeaders() }
      );

      if (!response.ok) throw new Error('Failed to fetch voter history');

      const data = await response.json();
      return data.map((vote: any) => ({
        id: vote.id,
        voterId: vote.voter_id,
        submissionId: vote.submission_id,
        category: vote.category,
        voteTime: new Date(vote.vote_time),
        isPaid: vote.is_paid,
        paymentId: vote.payment_id,
        paymentReference: vote.payment_reference,
        amountPaid: parseFloat(vote.amount_paid),
        voteWeight: vote.vote_weight,
        ipAddress: vote.ip_address,
        userAgent: vote.user_agent,
        status: vote.status,
        fraudScore: vote.fraud_score,
        verificationMethod: vote.verification_method,
        referralCode: vote.referral_code,
        metadata: vote.metadata,
        createdAt: new Date(vote.created_at)
      }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      return [];
    }
  }, []);

  return {
    isLoading,
    error,
    fetchVotingSettings,
    updateVotingSettings,
    submitVote,
    verifyVoter,
    getVotingAnalytics,
    getVoterHistory
  };
};

export const useVotingAnalytics = () => {
  const [analytics, setAnalytics] = useState<VotingAnalytics | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fetchAnalytics = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`${supabaseUrl}/functions/v1/voting/analytics`, {
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${supabaseAnonKey}`
        }
      });

      if (response.ok) {
        const result = await response.json();
        setAnalytics(result.data);
      }
    } catch (err) {
      console.error('Failed to fetch voting analytics:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return { analytics, isLoading, fetchAnalytics };
};